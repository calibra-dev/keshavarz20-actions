<?php
/**
 * Plugin Name: K20 AI Press
 * Plugin URI: https://keshavarz20.com/
 * Description: Commercial SEO/GEO, evidence, AI assistance and governed automation for WordPress and WooCommerce.
 * Version: 3.2.0
 * Requires at least: 7.1
 * Tested up to: 7.1
 * Requires PHP: 8.3
 * WC requires at least: 11.1
 * WC tested up to: 11.1
 * Requires Plugins: woocommerce
 * Author: کشاورز بیست
 * Author URI: https://keshavarz20.com/
 * Developer: کشاورز بیست
 * Developer URI: https://keshavarz20.com/
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: k20-ai-press
 * Domain Path: /languages
 */

defined( 'ABSPATH' ) || exit;

define( 'K20AI_PRESS_VERSION', '3.2.0' );
define( 'K20AI_PRESS_FILE', __FILE__ );
define( 'K20AI_PRESS_DIR', plugin_dir_path( __FILE__ ) );
define( 'K20AI_PRESS_URL', plugin_dir_url( __FILE__ ) );

/**
 * Load plugin modules behind a fail-safe boundary.
 *
 * A syntax/runtime failure inside an included module must never take down the
 * whole WordPress admin or front-end. Included-file ParseError instances are
 * catchable on supported PHP versions, so keep all module loading and booting
 * inside this guarded block.
 */
function k20ai_press_report_boot_failure( Throwable $error ): void {
    if ( class_exists( 'K20AI_Logger' ) ) {
        K20AI_Logger::error( 'Plugin bootstrap failed.', array( 'exception' => get_class( $error ), 'message' => $error->getMessage() ) );
    } elseif ( defined( 'WP_DEBUG' ) && WP_DEBUG && function_exists( 'error_log' ) ) {
        error_log( '[K20 AI Press] bootstrap failed: ' . $error->getMessage() ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
    }

    if ( function_exists( 'add_action' ) ) {
        add_action(
            'admin_notices',
            static function () use ( $error ): void {
                if ( function_exists( 'current_user_can' ) && ! current_user_can( 'manage_options' ) && ! current_user_can( 'manage_woocommerce' ) ) {
                    return;
                }
                $message = sprintf(
                    /* translators: %s: module bootstrap error message. */
                    __( 'K20 AI Press loaded in safe mode to prevent a fatal error. Module error: %s', 'k20-ai-press' ),
                    $error->getMessage()
                );
                echo '<div class="notice notice-error"><p>' . esc_html( $message ) . '</p></div>';
            }
        );
    }
}

try {
    $k20ai_modules = array(
        'src/k20ai-polyfills.php',
        'src/class-k20ai-security.php',
        'src/class-k20ai-crypto.php',
        'src/class-k20ai-i18n.php',
        'src/class-k20ai-logger.php',
        'src/class-k20ai-data-integrity.php',
        'src/class-k20ai-entity-access.php',
        'src/class-k20ai-database.php',
        'src/class-k20ai-privacy.php',
        'src/class-k20ai-ai-visibility.php',
        'src/class-k20ai-onboarding-migration.php',
        'src/class-k20ai-commercial.php',
        'src/class-k20ai-ability-registry.php',
        'src/trait-k20ai-advanced-intelligence.php',
        'src/trait-k20ai-advanced-commerce.php',
        'src/trait-k20ai-advanced-observability.php',
        'src/class-k20ai-advanced.php',
        'src/class-k20ai-operations.php',
        'src/trait-k20ai-services-product.php',
        'src/class-k20ai-services.php',
        'src/class-k20ai-product-intelligence.php',
        'src/class-k20ai-agent-engine.php',
        'src/class-k20ai-seo-analyzer.php',
        'src/trait-k20ai-seo-scan.php',
        'src/trait-k20ai-seo-workspaces.php',
        'src/trait-k20ai-seo-entity.php',
        'src/class-k20ai-seo-os.php',
        'src/class-k20ai-command-center.php',
        'src/class-k20ai-connection-center.php',
        'src/class-k20ai-ai-orchestrator.php',
        'src/class-k20ai-content-engines.php',
        'src/class-k20ai-bridge.php',
        'src/class-k20ai-seo-rest.php',
        'src/class-k20ai-seo-frontend.php',
        'src/class-k20ai-rest.php',
        'src/class-k20ai-admin.php',
        'src/class-k20ai-plugin.php',
    );

    foreach ( $k20ai_modules as $k20ai_module ) {
        require_once K20AI_PRESS_DIR . $k20ai_module;
    }

    add_action(
        'before_woocommerce_init',
        static function (): void {
            if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
                \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', K20AI_PRESS_FILE, true );
                \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', K20AI_PRESS_FILE, true );
            }
        }
    );

    register_activation_hook( __FILE__, array( 'K20AI_Database', 'activate' ) );
    register_deactivation_hook( __FILE__, array( 'K20AI_Plugin', 'deactivate' ) );

    K20AI_Plugin::instance()->boot();
} catch ( Throwable $k20ai_boot_error ) {
    k20ai_press_report_boot_failure( $k20ai_boot_error );
}

