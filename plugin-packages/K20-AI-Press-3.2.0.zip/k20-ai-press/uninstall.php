<?php
/**
 * K20 AI Press uninstall policy.
 *
 * Operational evidence, audit records and settings are preserved by default so
 * uninstalling the plugin cannot silently destroy compliance/rollback history.
 * A site owner who explicitly defines K20AI_PRESS_REMOVE_DATA_ON_UNINSTALL=true
 * before uninstalling opts into irreversible removal of plugin-owned data.
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

if ( ! defined( 'K20AI_PRESS_REMOVE_DATA_ON_UNINSTALL' ) || true !== K20AI_PRESS_REMOVE_DATA_ON_UNINSTALL ) {
    return;
}

global $wpdb;

foreach ( array(
    'claims', 'evidence', 'entities', 'edges', 'compat_rules', 'vectors_meta', 'bot_visits', 'events', 'jobs',
    'webhook_deliveries', 'prompt_runs', 'citations', 'provider_usage', 'price_history', 'audit_log',
    'supplier_submissions', 'eval_runs', 'feed_snapshots', 'channel_state', 'seo_profiles', 'seo_issues',
    'seo_scans', 'seo_links', 'seo_keywords', 'seo_competitors', 'seo_recommendations', 'seo_actions',
    'seo_crawl', 'seo_signals', 'engine_runs', 'bridge_snapshots', 'agent_runs', 'agent_steps', 'visibility_queries', 'visibility_observations', 'migration_snapshots',
) as $suffix ) {
    $table = $wpdb->prefix . 'k20ai_' . $suffix;
    $wpdb->query( "DROP TABLE IF EXISTS `{$table}`" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.DirectDatabaseQuery.SchemaChange
}

// The explicit wipe flag means remove every plugin-owned option, including versioned
// connection/content-engine containers, locks and transients introduced by future releases.
$option_like = $wpdb->esc_like( 'k20ai_' ) . '%';
$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", $option_like ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching

$transient_like = $wpdb->esc_like( '_transient_k20ai_' ) . '%';
$transient_timeout_like = $wpdb->esc_like( '_transient_timeout_k20ai_' ) . '%';
$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s", $transient_like, $transient_timeout_like ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching

$usermeta_like = $wpdb->esc_like( 'k20ai_' ) . '%';
$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->usermeta} WHERE meta_key LIKE %s", $usermeta_like ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching

foreach ( array(
    'k20ai_recovery_tick', 'k20ai_v3_hourly_tick', 'k20ai_v3_daily_tick', 'k20ai_privacy_cleanup',
    'k20ai_content_engine_tick', 'k20ai_v3_process_scan', 'k20ai_v3_connection_sync',
) as $hook ) {
    wp_clear_scheduled_hook( $hook );
}
