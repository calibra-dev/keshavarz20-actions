<?php
/**
 * K20 AI Press 3.1 premium RTL admin shell.
 *
 * @var string $workspace
 * @var array<string,mixed> $data
 * @var array<string,array<string,mixed>> $workspaces
 * @var array<string,mixed> $settings
 */
defined( 'ABSPATH' ) || exit;

$current_user = wp_get_current_user();
$ui_theme = get_user_meta( $current_user->ID, 'k20ai_ui_theme', true );
$ui_theme = in_array( $ui_theme, array( 'light', 'dark' ), true ) ? $ui_theme : 'light';
$ui_language = K20AI_I18n::user_ui_language( (int) $current_user->ID );
$ui_dir = 'en' === $ui_language ? 'ltr' : 'rtl';
$tr = static fn( string $fa, string $en ): string => K20AI_I18n::pair( $fa, $en, $ui_language );
$site_name = get_bloginfo( 'name' ) ?: ( wp_parse_url( home_url(), PHP_URL_HOST ) ?: 'WordPress' );
$workspace_label = 'en' === $ui_language ? ( $workspaces[ $workspace ]['label_en'] ?? $workspaces[ $workspace ]['label'] ?? 'Overview' ) : ( $workspaces[ $workspace ]['label'] ?? 'نمای کلی' );
$workspace_group = $workspaces[ $workspace ]['group'] ?? 'control';
$workspace_descriptions = array(
    'overview' => $tr( 'نمای مدیریتی زنده از سلامت سئو، محصولات، محتوا، خطاها، موتورها و صف اقدامات.', 'Live management view of SEO health, catalog, content, errors, engines and action queues.' ),
    'products' => $tr( 'کنترل کیفیت سئوی محصولات، داده کاتالوگ، تصاویر، Merchant readiness و اصلاح کنترل‌شده.', 'Real product SEO, catalog truth, media, merchant readiness and controlled enrichment.' ),
    'product-intelligence' => $tr( 'آمادگی محصول برای Commerce و AI با امتیازهای قابل توضیح و شکاف‌های قابل ردیابی.', 'Explainable product, commerce and AI readiness with measurable gaps.' ),
    'competitors-serp' => $tr( 'تحلیل رقبا و SERP فقط بر اساس داده واردشده یا Provider متصل؛ بدون عدد ساختگی.', 'Competitor and SERP analysis only from imported or connected-source evidence.' ),
    'live-editor' => $tr( 'ویرایش امن عنوان، متا، محصول و رسانه با تحلیل زنده، پیش‌نمایش و ثبت Audit.', 'Guarded live editing with preview, audit and evidence-aware AI completion.' ),
    'keywords-content' => $tr( 'کلمات کلیدی، پوشش محتوا، تازه‌بودن و اتصال واقعی Query به صفحات سایت.', 'Keyword coverage, content freshness and query-to-page evidence.' ),
    'images-alt' => $tr( 'ممیزی همه رسانه‌ها، ALT، ابعاد، فرمت، حجم و ارتباط تصویر با صفحه استفاده‌کننده.', 'Media, ALT, dimensions, format, weight and usage relevance audit.' ),
    'schema-preview' => $tr( 'پیش‌نمایش داده ساختاریافته از داده واقعی سایت و بررسی Eligibility قبل از انتشار.', 'Structured-data preview from real site data before publishing.' ),
    'categories-links' => $tr( 'سلامت دسته‌ها، برندها، ویژگی‌ها، لینک‌های داخلی و شناسایی صفحات یتیم.', 'Taxonomy, brand, attributes, internal linking and orphan-page health.' ),
    'technical-health' => $tr( 'Indexability، Canonical، Robots، HTTP status، Sitemap، HTTPS و Issueهای فنی.', 'Indexability, canonicals, robots, HTTP, sitemap, HTTPS and technical issues.' ),
    'rank-tracking' => $tr( 'ردیابی رتبه، Impression و CTR فقط از Search Console یا Import دارای منبع.', 'Rank, impressions and CTR only from sourced Search Console/Bing imports.' ),
    'ai-visibility' => $tr( 'پایش Query، Mention و Citation در موتورهای AI فقط با Observation اندازه‌گیری‌شده و Evidence.', 'Measured AI-engine query, mention and citation observatory with evidence.' ),
    'control-tower' => $tr( 'چهار لایه مشاهده، تشخیص، پیشنهاد و اجرا با Agentها، Approval و Rollback.', 'Observe, diagnose, recommend and execute with approvals and rollback.' ),
    'reports' => $tr( 'خلاصه مدیریتی، گزارش تفکیکی موجودیت‌ها و خروجی CSV/JSON/Print.', 'Management summary, entity breakdown and export tools.' ),
    'content-refresh' => $tr( 'محتوای قدیمی، کم‌امتیاز، تقویم انتشار و صف به‌روزرسانی محتوا.', 'Aging content, low scores, publishing calendar and refresh queue.' ),
    'crawl-monitoring' => $tr( 'خزش امن داخلی، تاریخچه اجرا، توزیع Status Code و مشاهده URLهای بررسی‌شده.', 'Safe internal crawl history, status-code distribution and URL observations.' ),
    'market-radar' => $tr( 'سیگنال‌های داخلی، RSSهای منبع‌دار، رقبا و فرصت‌های محتوایی/تجاری.', 'Internal signals, sourced RSS, competitors and market/content opportunities.' ),
    'connections' => $tr( 'مرکز اتصال واقعی برای Google، Bing، GitHub و موتورهای AI؛ با تست زنده، Sync، خطا و Credential رمزنگاری‌شده.', 'Live connection center for Google, Bing, GitHub, AI providers and embedded Bridge 3.3.' ),
    'content-engines' => $tr( 'موتورهای کسب‌وکارمحور خبر و مقاله با زمان‌بندی، منابع واقعی، پیش‌نویس و تاریخچه اجرا.', 'Business-aware News and Article engines with schedules, sources, drafts and run logs.' ),
    'settings' => $tr( 'قوانین، اتوماسیون، اتصال‌ها، موتورها، Bot Registry و تنظیمات عملیاتی.', 'Governance, automation, integrations, bot registry and operational settings.' ),
    'setup-commercial' => $tr( 'راه‌اندازی اولیه، مهاجرت قابل بازگشت از افزونه‌های SEO، License و Diagnostics.', 'Guided setup, reversible SEO migration, licensing and support diagnostics.' ),
);
$workspace_description = $workspace_descriptions[ $workspace ] ?? '';

$score_class = static function( $value ): string {
    if ( null === $value || '' === $value ) return 'neutral';
    $value = (float) $value;
    if ( $value >= 85 ) return 'success';
    if ( $value >= 60 ) return 'warning';
    return 'danger';
};
$tone_from_status = static function( string $status ): string {
    if ( in_array( $status, array( 'connected','configured','active','completed','pass','approved','applied' ), true ) ) return 'success';
    if ( in_array( $status, array( 'critical','failed','unavailable','danger','rejected' ), true ) ) return 'danger';
    if ( in_array( $status, array( 'warning','waiting-data','disconnected','proposed','running','queued','optional','local-only','not-measured' ), true ) ) return 'warning';
    if ( 'ready' === $status ) return 'info';
    return 'neutral';
};
$status_text = static function( string $status ) use ( $tr ): string {
    $labels = array(
        'ready' => array( 'آماده', 'Ready' ), 'active' => array( 'در حال اجرا', 'Active' ), 'connected' => array( 'متصل', 'Connected' ),
        'waiting-data' => array( 'منتظر داده', 'Waiting for data' ), 'not-measured' => array( 'اندازه‌گیری نشده', 'Not measured' ),
        'completed' => array( 'کامل', 'Completed' ), 'running' => array( 'در حال اجرا', 'Running' ), 'queued' => array( 'در صف', 'Queued' ),
        'failed' => array( 'ناموفق', 'Failed' ), 'unavailable' => array( 'در دسترس نیست', 'Unavailable' ), 'disconnected' => array( 'قطع', 'Disconnected' ),
        'pass' => array( 'تأییدشده', 'Verified' ), 'warning' => array( 'نیازمند بررسی', 'Needs review' ), 'critical' => array( 'بحرانی', 'Critical' ),
    );
    return isset( $labels[ $status ] ) ? $tr( $labels[ $status ][0], $labels[ $status ][1] ) : $status;
};
$percent = static fn( $v ) => null === $v || '' === $v ? '—' : number_format_i18n( (float) $v ) . '٪';
$num = static fn( $v ) => number_format_i18n( (float) ( $v ?? 0 ) );
$short_date = static function( $value ): string {
    if ( ! $value ) return '—';
    $ts = strtotime( (string) $value );
    return $ts ? wp_date( 'Y/m/d H:i', $ts ) : (string) $value;
};
$help = static function( string $text ): void {
    echo '<button type="button" class="k30-info" aria-label="' . esc_attr( $text ) . '" data-tip="' . esc_attr( $text ) . '">i</button>';
};
$card_open = static function( string $title, string $icon = 'dashicons-chart-area', string $class = '', string $help_text = '' ) use ( $help ): void {
    echo '<section class="k30-card ' . esc_attr( $class ) . '"><header class="k30-card-head"><div class="k30-card-title"><span class="dashicons ' . esc_attr( $icon ) . '"></span><h2>' . esc_html( $title ) . '</h2>';
    if ( $help_text ) $help( $help_text );
    echo '</div></header><div class="k30-card-body">';
};
$card_close = static function(): void { echo '</div></section>'; };
$empty_state = static function( string $title, string $description, string $icon = 'dashicons-database' ): void {
    echo '<div class="k30-empty"><span class="dashicons ' . esc_attr( $icon ) . '"></span><strong>' . esc_html( $title ) . '</strong><p>' . esc_html( $description ) . '</p></div>';
};
$status_pill = static function( string $label, string $tone = 'neutral' ) use ( $status_text ): void {
    $known = array( 'ready','active','connected','waiting-data','not-measured','completed','running','queued','failed','unavailable','disconnected','pass','warning','critical' );
    $display = in_array( $label, $known, true ) ? $status_text( $label ) : $label;
    echo '<span class="k30-pill ' . esc_attr( $tone ) . '">' . esc_html( $display ) . '</span>';
};
$metric_card = static function( array $metric ): void {
    $value = $metric['value'] ?? null;
    $tone = $metric['tone'] ?? 'neutral';
    $tag = ! empty( $metric['href'] ) ? 'a' : 'article';
    $href = ! empty( $metric['href'] ) ? ' href="' . esc_url( (string) $metric['href'] ) . '"' : '';
    echo '<' . $tag . ' class="k30-kpi ' . esc_attr( $tone ) . ( ! empty( $metric['href'] ) ? ' is-clickable' : '' ) . '"' . $href . '>';
    echo '<div class="k30-kpi-icon"><span class="dashicons ' . esc_attr( $metric['icon'] ?? 'dashicons-chart-bar' ) . '"></span></div>';
    echo '<div class="k30-kpi-copy"><span>' . esc_html( $metric['label'] ?? '' ) . '</span><strong>' . ( null === $value ? '—' : esc_html( number_format_i18n( (float) $value ) ) ) . esc_html( $metric['suffix'] ?? '' ) . '</strong>';
    if ( ! empty( $metric['hint'] ) ) echo '<small>' . esc_html( $metric['hint'] ) . '</small>';
    echo '</div></' . $tag . '>';
};
$issue_tone = static function( string $severity ): string {
    return 'critical' === $severity ? 'danger' : ( 'warning' === $severity ? 'warning' : 'info' );
};

$current_workspace_args = array( 'page' => 'k20-ai-press', 'workspace' => $workspace );
foreach ( array( 'status','kind','id','category_id','query','q','per_page','paged','entity_query','entity_paged','keyword_paged','content_paged' ) as $arg_key ) {
    if ( ! isset( $_GET[ $arg_key ] ) ) continue; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $raw = wp_unslash( $_GET[ $arg_key ] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $current_workspace_args[ $arg_key ] = in_array( $arg_key, array( 'id','category_id','per_page','paged','entity_paged','keyword_paged','content_paged' ), true ) ? absint( $raw ) : sanitize_text_field( $raw );
}
$workspace_url = static function( array $overrides = array() ) use ( $current_workspace_args ): string {
    $args = array_merge( $current_workspace_args, $overrides );
    foreach ( $args as $key => $value ) if ( null === $value || '' === $value || ( in_array( $key, array( 'paged','entity_paged','keyword_paged','content_paged' ), true ) && (int) $value <= 1 ) ) unset( $args[ $key ] );
    return add_query_arg( $args, admin_url( 'admin.php' ) );
};
$render_pager = static function( array $pagination, string $page_key = 'paged' ) use ( $workspace_url ): void {
    $total = (int) ( $pagination['total'] ?? 0 );
    if ( $total <= 0 ) return;
    $page_key = in_array( $page_key, array( 'paged','entity_paged','keyword_paged','content_paged' ), true ) ? $page_key : 'paged';
    $paged = (int) ( $pagination['paged'] ?? 1 );
    $pages = (int) ( $pagination['pages'] ?? 1 );
    echo '<nav class="k30-pager" aria-label="صفحه‌بندی"><span>' . esc_html( number_format_i18n( (int) ( $pagination['from'] ?? 0 ) ) . '–' . number_format_i18n( (int) ( $pagination['to'] ?? 0 ) ) . ' از ' . number_format_i18n( $total ) ) . '</span><div>';
    if ( ! empty( $pagination['has_prev'] ) ) echo '<a class="k30-mini-button" href="' . esc_url( $workspace_url( array( $page_key => (int) $pagination['prev_page'] ) ) ) . '">قبلی</a>';
    $start = max( 1, $paged - 2 );
    $end = min( $pages, $paged + 2 );
    if ( $start > 1 ) {
        echo '<a class="k30-page-number" href="' . esc_url( $workspace_url( array( $page_key => 1 ) ) ) . '">1</a>';
        if ( $start > 2 ) echo '<span class="k30-page-gap">…</span>';
    }
    for ( $i = $start; $i <= $end; $i++ ) {
        if ( $i === $paged ) echo '<b class="k30-page-number is-active" aria-current="page">' . esc_html( number_format_i18n( $i ) ) . '</b>';
        else echo '<a class="k30-page-number" href="' . esc_url( $workspace_url( array( $page_key => $i ) ) ) . '">' . esc_html( number_format_i18n( $i ) ) . '</a>';
    }
    if ( $end < $pages ) {
        if ( $end < $pages - 1 ) echo '<span class="k30-page-gap">…</span>';
        echo '<a class="k30-page-number" href="' . esc_url( $workspace_url( array( $page_key => $pages ) ) ) . '">' . esc_html( number_format_i18n( $pages ) ) . '</a>';
    }
    if ( ! empty( $pagination['has_next'] ) ) echo '<a class="k30-mini-button" href="' . esc_url( $workspace_url( array( $page_key => (int) $pagination['next_page'] ) ) ) . '">بعدی</a>';
    echo '</div></nav>';
};
$render_refresh = static function() use ( $workspace_url ): void {
    echo '<a class="k30-icon-button k30-workspace-refresh" href="' . esc_url( $workspace_url( array( '_refresh' => time(), 'paged' => null, 'entity_paged' => null, 'keyword_paged' => null, 'content_paged' => null ) ) ) . '" title="بازخوانی داده واقعی" aria-label="بازخوانی داده واقعی"><span class="dashicons dashicons-update"></span></a>';
};

$nav_groups = array(
    'control' => array( 'label' => 'کنترل', 'label_en' => 'Control', 'items' => array( 'overview','control-tower' ) ),
    'catalog' => array( 'label' => 'کاتالوگ', 'label_en' => 'Catalog', 'items' => array( 'products','product-intelligence','images-alt','schema-preview','categories-links' ) ),
    'content' => array( 'label' => 'محتوا', 'label_en' => 'Content', 'items' => array( 'live-editor','keywords-content','content-refresh' ) ),
    'monitoring' => array( 'label' => 'پایش', 'label_en' => 'Monitoring', 'items' => array( 'technical-health','crawl-monitoring','rank-tracking','ai-visibility' ) ),
    'research' => array( 'label' => 'هوش بازار', 'label_en' => 'Market Intelligence', 'items' => array( 'competitors-serp','market-radar','content-engines' ) ),
    'system' => array( 'label' => 'سیستم', 'label_en' => 'System', 'items' => array( 'reports','connections','settings','setup-commercial' ) ),
);
?>
<div class="k30-shell" dir="<?php echo esc_attr( $ui_dir ); ?>" data-theme="<?php echo esc_attr( $ui_theme ); ?>" data-language="<?php echo esc_attr( $ui_language ); ?>" data-workspace="<?php echo esc_attr( $workspace ); ?>">
    <aside class="k30-sidebar" aria-label="<?php echo esc_attr( $tr( 'ناوبری K20 AI Press', 'K20 AI Press navigation' ) ); ?>">
        <div class="k30-brand">
            <div class="k30-brand-mark" aria-hidden="true"><span class="leaf l1"></span><span class="leaf l2"></span><span class="stem"></span></div>
            <div><strong>K20 AI Press</strong><small>SEO / GEO OS · v<?php echo esc_html( K20AI_PRESS_VERSION ); ?></small></div>
            <button type="button" class="k30-sidebar-toggle" data-sidebar-toggle aria-label="<?php echo esc_attr( $tr( 'جمع کردن منو', 'Collapse navigation' ) ); ?>"><span class="dashicons dashicons-menu-alt"></span></button>
        </div>
        <div class="k30-site-switch"><span class="k30-live-dot"></span><div><small><?php echo esc_html( $tr( 'سایت فعال', 'Active site' ) ); ?></small><strong><?php echo esc_html( $site_name ); ?></strong></div><span class="dashicons dashicons-arrow-down-alt2"></span></div>
        <nav class="k30-nav" aria-label="<?php echo esc_attr( $tr( 'ناوبری افزونه', 'Plugin navigation' ) ); ?>">
            <?php foreach ( $nav_groups as $group_key => $group ) : ?>
                <div class="k30-nav-group">
                    <span class="k30-nav-label"><?php echo esc_html( 'en' === $ui_language ? ( $group['label_en'] ?? $group['label'] ) : $group['label'] ); ?></span>
                    <?php foreach ( $group['items'] as $slug ) : $item = $workspaces[ $slug ] ?? null; if ( ! $item ) continue; ?>
                        <a class="k30-nav-item <?php echo $workspace === $slug ? 'is-active' : ''; ?>" href="<?php echo esc_url( admin_url( 'admin.php?page=k20-ai-press&workspace=' . $slug ) ); ?>" data-nav-workspace="<?php echo esc_attr( $slug ); ?>" <?php echo $workspace === $slug ? 'aria-current="page"' : ''; ?>>
                            <span class="dashicons dashicons-<?php echo esc_attr( $item['icon'] ); ?>"></span><span><?php echo esc_html( 'en' === $ui_language ? ( $item['label_en'] ?? $item['label'] ) : $item['label'] ); ?></span>
                            <?php if ( $workspace === $slug ) : ?><i></i><?php endif; ?>
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php endforeach; ?>
        </nav>
        <div class="k30-sidebar-foot">
            <div class="k30-user-card">
                <?php echo get_avatar( $current_user->ID, 38, '', '', array( 'class' => 'k30-avatar' ) ); ?>
                <div><strong><?php echo esc_html( $current_user->display_name ); ?></strong><small><?php echo esc_html( current_user_can( 'manage_options' ) ? $tr( 'مدیر سیستم', 'System admin' ) : $tr( 'مدیر فروشگاه', 'Store manager' ) ); ?></small></div>
            </div>
            <div class="k30-system-mini"><span class="k30-live-dot"></span><span><?php echo esc_html( $tr( 'هسته عملیاتی فعال', 'Operational core active' ) ); ?></span><b>3.0</b></div>
        </div>
    </aside>

    <a class="k30-skip-link" href="#k30-main-content"><?php echo esc_html( $tr( 'رفتن به محتوای اصلی', 'Skip to main content' ) ); ?></a>
    <main class="k30-main" id="k30-main-content" tabindex="-1">
        <header class="k30-topbar">
            <div class="k30-topbar-actions">
                <button class="k30-icon-button k30-mobile-menu" type="button" data-sidebar-toggle aria-label="<?php echo esc_attr( $tr( 'باز کردن منو', 'Open navigation' ) ); ?>"><span class="dashicons dashicons-menu-alt"></span></button>
                <button class="k30-icon-button" type="button" data-command-palette aria-label="<?php echo esc_attr( $tr( 'جست‌وجوی سریع', 'Quick search' ) ); ?>"><span class="dashicons dashicons-search"></span></button>
                <div class="k30-search"><span class="dashicons dashicons-search"></span><input type="search" aria-label="<?php echo esc_attr( $tr( 'جست‌وجوی سریع', 'Quick search' ) ); ?>" placeholder="<?php echo esc_attr( $tr( 'جستجو در محصولات، نوشته‌ها، URL و خطاها…', 'Search products, content, URLs and issues…' ) ); ?>" data-global-search><kbd>⌘ K</kbd></div>
            </div>
            <div class="k30-topbar-center" aria-label="<?php echo esc_attr( $tr( 'تنظیمات نمایش', 'Display preferences' ) ); ?>">
                <div class="k30-theme-switch" data-theme-switch role="group" aria-label="<?php echo esc_attr( $tr( 'تم شب و روز', 'Day and night theme' ) ); ?>">
                    <button type="button" data-theme-value="light" class="<?php echo 'light' === $ui_theme ? 'is-active' : ''; ?>" aria-pressed="<?php echo 'light' === $ui_theme ? 'true' : 'false'; ?>" title="<?php echo esc_attr( $tr( 'تم روز', 'Light theme' ) ); ?>"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="4"></circle><path d="M12 2v2M12 20v2M4.93 4.93l1.42 1.42M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.42-1.42M17.66 6.34l1.41-1.41"></path></svg></button>
                    <span class="k30-theme-track"><i></i></span>
                    <button type="button" data-theme-value="dark" class="<?php echo 'dark' === $ui_theme ? 'is-active' : ''; ?>" aria-pressed="<?php echo 'dark' === $ui_theme ? 'true' : 'false'; ?>" title="<?php echo esc_attr( $tr( 'تم شب', 'Dark theme' ) ); ?>"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20.4 15.4A8.5 8.5 0 0 1 8.6 3.6 8.5 8.5 0 1 0 20.4 15.4Z"></path></svg></button>
                </div>
                <div class="k30-language-switch" data-language-switch role="group" aria-label="<?php echo esc_attr( $tr( 'زبان رابط', 'Interface language' ) ); ?>"><button type="button" data-language-value="fa" class="<?php echo 'fa' === $ui_language ? 'is-active' : ''; ?>" aria-pressed="<?php echo 'fa' === $ui_language ? 'true' : 'false'; ?>">FA</button><button type="button" data-language-value="en" class="<?php echo 'en' === $ui_language ? 'is-active' : ''; ?>" aria-pressed="<?php echo 'en' === $ui_language ? 'true' : 'false'; ?>">EN</button></div>
            </div>
            <div class="k30-topbar-meta">
                <?php $latest = $data['scan'] ?? null; ?>
                <span class="k30-sync"><span class="dashicons dashicons-update"></span><small><?php echo esc_html( $tr( 'آخرین اسکن', 'Last scan' ) ); ?></small><b><?php echo $latest && ! empty( $latest['updated_at'] ) ? esc_html( $short_date( $latest['updated_at'] ) ) : $tr( 'هنوز اجرا نشده', 'Not run yet' ); ?></b></span>
                <button class="k30-button primary" type="button" data-open-control><span class="dashicons dashicons-superhero"></span> <?php echo esc_html( $tr( 'مرکز فرمان', 'Control center' ) ); ?></button>
            </div>
        </header>

        <div class="k30-content">
            <div class="k30-page-header">
                <div class="k30-page-title-wrap">
                    <span class="k30-page-icon dashicons dashicons-<?php echo esc_attr( $workspaces[ $workspace ]['icon'] ?? 'dashboard' ); ?>"></span>
                    <div><div class="k30-breadcrumb">K20 AI Press <span>›</span> <?php echo esc_html( 'en' === $ui_language ? ( $nav_groups[ $workspace_group ]['label_en'] ?? 'System' ) : ( $nav_groups[ $workspace_group ]['label'] ?? 'سیستم' ) ); ?></div><h1><?php echo esc_html( $workspace_label ); ?></h1><p><?php echo esc_html( $workspace_description ); ?></p></div>
                </div>
                <div class="k30-page-meta">
                    <?php $render_refresh(); ?>
                    <span class="k30-badge live"><i></i> <?php echo esc_html( $tr( 'اتصال به سایت', 'Connected to site' ) ); ?></span>
                    <span class="k30-version">v<?php echo esc_html( K20AI_PRESS_VERSION ); ?></span>
                </div>
            </div>

            <?php
            $scan_workspaces = array( 'overview','products','product-intelligence','images-alt','categories-links','crawl-monitoring' );
            if ( in_array( $workspace, $scan_workspaces, true ) ) :
                $scan_row = is_array( $data['scan'] ?? null ) ? (array) $data['scan'] : array();
                $scan_status = (string) ( $scan_row['status'] ?? '' );
                $active_scan_id = in_array( $scan_status, array( 'queued','running' ), true ) ? (int) ( $scan_row['id'] ?? 0 ) : 0;
            ?>
                <div class="k30-live-progress k30-workspace-scan-progress" data-scan-progress data-active-scan-id="<?php echo esc_attr( (string) $active_scan_id ); ?>" <?php echo $active_scan_id > 0 ? '' : 'hidden'; ?>>
                    <div><span data-scan-label><?php echo esc_html( $tr( 'وضعیت اسکن در همین بخش نمایش داده می‌شود.', 'Scan progress is shown only in this workspace.' ) ); ?></span><strong data-scan-percent>0٪</strong></div>
                    <div class="k30-progress" aria-hidden="true"><i data-scan-bar style="width:0%"></i></div>
                </div>
            <?php endif; ?>

            <?php if ( 'overview' === $workspace ) :
                $dash = $data['dashboard'] ?? array(); $kpis = $data['kpis'] ?? array(); $external = $data['external_data'] ?? array(); ?>
                <section class="k30-kpi-grid k30-kpi-grid-6">
                    <?php $icons = array( 'dashicons-shield-alt','dashicons-warning','dashicons-admin-page','dashicons-dismiss','dashicons-clock','dashicons-yes-alt' ); foreach ( $kpis as $i => $metric ) { $metric['icon'] = $icons[ $i ] ?? 'dashicons-chart-bar'; $metric_card( $metric ); } ?>
                </section>
                <div class="k30-workspace-actions"><button class="k30-button secondary" type="button" data-run-scan="full"><span class="dashicons dashicons-update-alt"></span> اسکن کامل سایت</button><small>اسکن از داخل پیشخوان شروع می‌شود؛ هدر سراسری دیگر Worker یا Progress اسکن ندارد.</small></div>
                <?php if ( ! empty( $external['ga4']['available'] ) || ! empty( $external['merchant']['available'] ) || ! empty( $external['pagespeed']['available'] ) ) : ?>
                    <?php $card_open( 'داده زنده سرویس‌های متصل', 'dashicons-cloud-saved', '', 'این اعداد از آخرین Sync واقعی Connection Center می‌آیند؛ در نبود Sync هیچ عدد فرضی ساخته نمی‌شود.' ); ?>
                        <div class="k30-live-source-strip">
                            <?php if ( ! empty( $external['ga4']['available'] ) ) : ?><article><span class="dashicons dashicons-chart-area"></span><div><b>GA4</b><strong><?php echo esc_html( $num( $external['ga4']['sessions'] ?? 0 ) ); ?> نشست</strong><small><?php echo esc_html( $num( $external['ga4']['pageviews'] ?? 0 ) ); ?> بازدید صفحه<?php echo null !== ( $external['ga4']['engagement_rate'] ?? null ) ? ' · تعامل ' . esc_html( (string) $external['ga4']['engagement_rate'] ) . '٪' : ''; ?></small></div></article><?php endif; ?>
                            <?php if ( ! empty( $external['merchant']['available'] ) ) : ?><article><span class="dashicons dashicons-cart"></span><div><b>Merchant Center</b><strong><?php echo esc_html( $num( $external['merchant']['issue_count'] ?? 0 ) ); ?> Issue</strong><small><?php echo esc_html( (string) ( $external['merchant']['severity']['CRITICAL'] ?? 0 ) ); ?> بحرانی · <?php echo esc_html( (string) ( $external['merchant']['severity']['ERROR'] ?? 0 ) ); ?> خطا</small></div></article><?php endif; ?>
                            <?php if ( ! empty( $external['pagespeed']['available'] ) ) : ?><article><span class="dashicons dashicons-performance"></span><div><b>PageSpeed Mobile</b><strong><?php echo null !== ( $external['pagespeed']['score'] ?? null ) ? esc_html( (string) $external['pagespeed']['score'] ) . '/100' : '—'; ?></strong><small><?php echo esc_html( $short_date( $external['pagespeed']['at'] ?? null ) ); ?></small></div></article><?php endif; ?>
                            <a class="k30-live-source-action" href="<?php echo esc_url( admin_url( 'admin.php?page=k20-ai-press&workspace=connections' ) ); ?>"><span class="dashicons dashicons-admin-links"></span> مرکز اتصال</a>
                        </div>
                    <?php $card_close(); ?>
                <?php endif; ?>
                <div class="k30-grid k30-grid-2-1">
                    <?php $card_open( 'صف اول اقدامات هوشمند', 'dashicons-list-view', '', 'اولویت بر پایه شدت خطا، امتیاز سئو، اثر تجاری، ریسک و اعتماد داده محلی محاسبه می‌شود؛ این عدد Domain Authority ساختگی نیست.' ); ?>
                        <?php if ( empty( $dash['priority_queue'] ) ) : $empty_state( 'صف اقدام هنوز ساخته نشده', 'اسکن کامل را اجرا کنید تا مشکلات و پیشنهادهای واقعی از سایت استخراج شوند.', 'dashicons-superhero' ); else : ?>
                            <div class="k30-action-lanes">
                                <?php $lanes = array( 'critical' => array( 'label'=>'بحرانی','tone'=>'danger' ), 'high'=>array('label'=>'نیاز به بهبود','tone'=>'warning'), 'medium'=>array('label'=>'فرصت','tone'=>'success') ); foreach ( $lanes as $key=>$lane ) : $matches = array_values( array_filter( $dash['priority_queue'], static fn($row) => ( $row['priority'] ?? '' ) === $key ) ); ?>
                                    <div class="k30-lane <?php echo esc_attr($lane['tone']); ?>"><header><strong><?php echo esc_html($lane['label']); ?></strong><span><?php echo esc_html( count($matches) ); ?></span></header>
                                        <?php if (!$matches): ?><p>موردی در این سطح دیده نشد.</p><?php else: foreach (array_slice($matches,0,4) as $rec): ?><button type="button" class="k30-lane-item" data-entity-open="<?php echo esc_attr($rec['entity_kind']); ?>" data-entity-id="<?php echo esc_attr($rec['entity_id']); ?>"><b><?php echo esc_html($rec['title']); ?></b><small><?php echo esc_html($rec['entity_title'] ?: $rec['entity_kind']); ?></small></button><?php endforeach; endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    <?php $card_close(); ?>
                    <?php $card_open( 'سلامت سیستم و موتورها', 'dashicons-admin-tools', '', 'وضعیت هر موتور نشان می‌دهد آیا تحلیل محلی فعال است یا برای داده خارجی هنوز اتصال لازم است.' ); ?>
                        <div class="k30-engine-list compact">
                            <?php foreach ( array_slice( (array) ( $dash['engines'] ?? array() ), 0, 9 ) as $engine ) : $tone=$tone_from_status($engine['status']); ?>
                                <div><span class="k30-status-dot <?php echo esc_attr($tone); ?>"></span><div><b><?php echo esc_html($engine['label']); ?></b><small><?php echo esc_html($engine['description']); ?></small></div><span class="k30-pill <?php echo esc_attr($tone); ?>"><?php echo esc_html($status_text((string)$engine['status'])); ?></span></div>
                            <?php endforeach; ?>
                        </div>
                        <a class="k30-text-link" href="<?php echo esc_url(admin_url('admin.php?page=k20-ai-press&workspace=control-tower')); ?>">مشاهده همه موتورها <span class="dashicons dashicons-arrow-left-alt2"></span></a>
                    <?php $card_close(); ?>
                </div>
                <div class="k30-grid k30-grid-2-1">
                    <?php $card_open( 'اولویت‌های اصلی سایت', 'dashicons-chart-bar', '', 'ضعیف‌ترین موجودیت‌های تحلیل‌شده با امتیاز چندبعدی واقعی.' ); ?>
                        <div class="k30-table-wrap"><table class="k30-table"><thead><tr><th>موجودیت</th><th>نوع</th><th>امتیاز</th><th>ریسک</th><th>اقدام</th></tr></thead><tbody>
                        <?php foreach ( array_slice( (array) ( $dash['priority_queue'] ?? array() ), 0, 10 ) as $row ) : ?><tr><td><strong><?php echo esc_html($row['entity_title'] ?: $row['title']); ?></strong><small><?php echo esc_html($row['title']); ?></small></td><td><?php echo esc_html($row['entity_kind']); ?></td><td><span class="k30-score <?php echo esc_attr($score_class($row['score_total']??null)); ?>"><?php echo esc_html($row['score_total']??'—'); ?></span></td><td><?php $status_pill( $row['priority'], $row['priority']==='critical'?'danger':($row['priority']==='high'?'warning':'success') ); ?></td><td><button class="k30-mini-button" data-entity-open="<?php echo esc_attr($row['entity_kind']); ?>" data-entity-id="<?php echo esc_attr($row['entity_id']); ?>">جزئیات</button></td></tr><?php endforeach; ?>
                        </tbody></table></div>
                    <?php $card_close(); ?>
                    <?php $card_open( 'روند سلامت ارگانیک', 'dashicons-chart-line', '', 'روند از اسکن‌های واقعی افزونه ساخته می‌شود؛ وقتی اسکن تاریخی نداریم خط مصنوعی نمایش داده نمی‌شود.' ); ?>
                        <div class="k30-chart" data-line-chart='<?php echo esc_attr( wp_json_encode( $dash['trend'] ?? array() ) ); ?>' data-value-key="score" data-label-key="date"><canvas width="600" height="260"></canvas><div class="k30-chart-empty">برای تشکیل روند، حداقل دو اسکن کامل نیاز است.</div></div>
                    <?php $card_close(); ?>
                </div>

            <?php elseif ( 'products' === $workspace ) : $summary=$data['summary']??array(); ?>
                <section class="k30-kpi-grid k30-kpi-grid-6">
                    <?php foreach (array(
                        array('label'=>'میانگین سلامت محصولات','value'=>$summary['avg_score']??null,'suffix'=>'/100','tone'=>$score_class($summary['avg_score']??null),'icon'=>'dashicons-products','hint'=>'از محصولات تحلیل‌شده'),
                        array('label'=>'فنی','value'=>$summary['technical']??null,'suffix'=>'٪','tone'=>$score_class($summary['technical']??null),'icon'=>'dashicons-admin-tools','hint'=>'Title / Canonical / Indexability'),
                        array('label'=>'محتوا','value'=>$summary['content']??null,'suffix'=>'٪','tone'=>$score_class($summary['content']??null),'icon'=>'dashicons-text-page','hint'=>'متن و Meta'),
                        array('label'=>'اسکیما','value'=>$summary['schema']??null,'suffix'=>'٪','tone'=>$score_class($summary['schema']??null),'icon'=>'dashicons-editor-code','hint'=>'Product / Offer readiness'),
                        array('label'=>'تصویر','value'=>$summary['media']??null,'suffix'=>'٪','tone'=>$score_class($summary['media']??null),'icon'=>'dashicons-format-image','hint'=>'Gallery و ALT'),
                        array('label'=>'تجارت','value'=>$summary['commerce']??null,'suffix'=>'٪','tone'=>$score_class($summary['commerce']??null),'icon'=>'dashicons-cart','hint'=>'SKU / Brand / Category / Stock'),
                    ) as $m) $metric_card($m); ?>
                </section>
                <div class="k30-grid k30-grid-2-1">
                    <?php $card_open('برج کنترل هوشمند محصولات','dashicons-products','', 'کم‌امتیازترین محصولات بر اساس داده واقعی WooCommerce و Rule Engine مرتب می‌شوند.'); ?>
                        <?php if (empty($data['items'])): $empty_state('هنوز محصولی تحلیل نشده است','اسکن محصولات یا اسکن کامل را اجرا کنید.','dashicons-products'); else: ?>
                        <form class="k30-filter-bar" method="get"><input type="hidden" name="page" value="k20-ai-press"><input type="hidden" name="workspace" value="products"><label><span>جست‌وجو</span><input name="query" value="<?php echo esc_attr($data['query']??''); ?>" placeholder="نام یا SKU"></label><label><span>دسته</span><select name="category_id"><option value="0">همه دسته‌ها</option><?php foreach((array)($data['categories']??array()) as $cat): ?><option value="<?php echo esc_attr($cat['id']); ?>" <?php selected((int)($data['category_id']??0),(int)$cat['id']); ?>><?php echo esc_html($cat['label'].' · '.$cat['count']); ?></option><?php endforeach; ?></select></label><label><span>وضعیت</span><select name="status"><option value="all">همه</option><option value="critical" <?php selected($data['status']??'all','critical'); ?>>بحرانی</option><option value="improve" <?php selected($data['status']??'all','improve'); ?>>نیاز به بهبود</option><option value="healthy" <?php selected($data['status']??'all','healthy'); ?>>سالم</option><option value="unmeasured" <?php selected($data['status']??'all','unmeasured'); ?>>اندازه‌گیری‌نشده</option></select></label><button class="k30-button secondary" type="submit">اعمال فیلتر</button><button class="k30-button secondary" type="button" data-run-scan="product"><span class="dashicons dashicons-update"></span> اسکن محصولات</button></form><div class="k30-filter-group"><?php foreach(array('all'=>'همه','critical'=>'بحرانی','improve'=>'نیاز به بهبود','healthy'=>'سالم','unmeasured'=>'اندازه‌گیری‌نشده') as $key=>$label): ?><a class="k30-chip <?php echo ($data['status']??'all')===$key?'is-active':''; ?>" href="<?php echo esc_url($workspace_url(array('status'=>'all'===$key?null:$key,'paged'=>null))); ?>"><?php echo esc_html($label.' · '.number_format_i18n((int)($data['counts'][$key]??0))); ?></a><?php endforeach; ?></div>
                        <div class="k30-table-wrap tall"><table class="k30-table k30-product-table"><thead><tr><th>محصول</th><th>SKU</th><th>برند</th><th>امتیاز</th><th>تصاویر</th><th>قیمت/موجودی</th><th>خطا</th><th>اقدام</th></tr></thead><tbody>
                        <?php foreach($data['items'] as $row): $tone=$score_class($row['score']); ?><tr data-tone="<?php echo esc_attr($tone); ?>" data-product-missing="<?php echo esc_attr(implode(' ',(array)($row['missing']??array()))); ?>"><td><strong><?php echo esc_html($row['title']); ?></strong><small>#<?php echo esc_html($row['id']); ?></small></td><td><?php echo esc_html($row['sku']?:'—'); ?></td><td><?php echo esc_html($row['brand']?:'—'); ?></td><td><span class="k30-score <?php echo esc_attr($tone); ?>"><?php echo null===($row['score']??null)?'—':esc_html($row['score']); ?></span></td><td><span class="k30-image-ratio <?php echo $row['images'] && $row['alt'] >= $row['images']?'success':'warning'; ?>"><?php echo esc_html($row['alt'].'/'.$row['images']); ?></span></td><td><small><?php echo esc_html($row['price']!==''?$row['price']:'—'); ?> · <?php echo esc_html($row['stock']?:'—'); ?></small></td><td><?php $status_pill((string)$row['issues'].' مورد',$row['issues']?'warning':'success'); ?></td><td><button class="k30-mini-button primary" data-entity-open="product" data-entity-id="<?php echo esc_attr($row['id']); ?>">مشاهده و اصلاح</button></td></tr><?php endforeach; ?>
                        </tbody></table></div><?php $render_pager((array)($data['pagination']??array())); endif; ?>
                    <?php $card_close(); ?>
                    <?php $card_open('نقشه فیلدهای کاتالوگ','dashicons-database','', 'هر درصد از فیلدهای واقعی محصولات تحلیل‌شده محاسبه می‌شود.'); ?><div class="k30-field-map"><?php foreach((array)($data['field_coverage']??array()) as $field): $tone=$score_class($field['percent']); ?><button type="button" class="k30-field-tile <?php echo esc_attr($tone); ?>" data-product-field-filter="<?php echo esc_attr($field['key']); ?>" aria-pressed="false"><span><?php echo esc_html($field['label']); ?></span><strong><?php echo null===$field['percent']?'—':esc_html($field['percent'].'%'); ?></strong><small><?php echo esc_html($field['filled'].' از '.$field['total']); ?></small></button><?php endforeach; ?></div><?php $card_close(); ?>
                </div>
                <?php $card_open('نقشه کامل بودن اطلاعات محصول','dashicons-chart-pie','', 'هشت گروه اصلی از Payload واقعی محصولات تحلیل‌شده محاسبه می‌شوند؛ مقدار خالی قرمز، نیازمند بازبینی زرد و پوشش مناسب سبز نمایش داده می‌شود.'); ?>
                    <div class="k30-completeness-grid">
                        <?php foreach((array)($data['completeness_groups']??array()) as $group): $gtone=$score_class($group['percent']); ?>
                            <article class="k30-completion <?php echo esc_attr($gtone); ?>"><div><span><?php echo esc_html($group['label']); ?></span><strong><?php echo null===$group['percent']?'—':esc_html($group['percent'].'٪'); ?></strong></div><div class="k30-progress"><i style="width:<?php echo esc_attr((string)max(0,min(100,(int)($group['percent']??0)))); ?>%"></i></div><small><?php echo esc_html(number_format_i18n((int)$group['filled']).' از '.number_format_i18n((int)$group['total']).' سیگنال تکمیل'); ?></small></article>
                        <?php endforeach; ?>
                    </div>
                <?php $card_close(); ?>
                <div class="k30-grid k30-grid-2">
                    <?php $variant=$data['variant_health']??array(); $card_open('سلامت واریانت‌های WooCommerce','dashicons-networking','', 'سلامت واریانت از قیمت و وضعیت موجودی واقعی product_variationها محاسبه می‌شود؛ عدد نمونه یا تصادفی نمایش داده نمی‌شود.'); ?>
                        <?php if(empty($variant['total'])): $empty_state('واریانت قابل سنجش پیدا نشد','اگر محصول Variable وجود داشته باشد، سلامت واریانت‌ها بعد از اسکن اینجا نمایش داده می‌شود.','dashicons-networking'); else: ?>
                            <div class="k30-gauge-row"><div class="k30-gauge <?php echo esc_attr($score_class($variant['health'])); ?>" style="--score:<?php echo esc_attr((string)(int)$variant['health']); ?>"><span><?php echo esc_html($variant['health'].'٪'); ?></span></div><div><b><?php echo esc_html(number_format_i18n((int)$variant['ready']).' / '.number_format_i18n((int)$variant['total'])); ?></b><span>واریانت دارای قیمت و وضعیت موجودی</span><small><?php echo esc_html(number_format_i18n((int)$variant['parents']).' محصول متغیر'); ?></small></div></div>
                            <div class="k30-table-wrap compact"><table class="k30-table"><thead><tr><th>محصول</th><th>کل</th><th>آماده</th><th>ناقص</th><th>سلامت</th></tr></thead><tbody><?php foreach(array_slice((array)($variant['rows']??array()),0,8) as $v): ?><tr><td><button class="k30-link-button" data-entity-open="product" data-entity-id="<?php echo esc_attr($v['product_id']); ?>"><?php echo esc_html($v['title']?:('#'.$v['product_id'])); ?></button></td><td><?php echo esc_html($v['total']); ?></td><td><?php echo esc_html($v['ready']); ?></td><td><?php echo esc_html($v['missing']); ?></td><td><span class="k30-score <?php echo esc_attr($score_class($v['health'])); ?>"><?php echo esc_html($v['health'].'٪'); ?></span></td></tr><?php endforeach; ?></tbody></table></div>
                        <?php endif; ?>
                    <?php $card_close(); ?>
                    <?php $evidence=$data['evidence_coverage']??array(); $card_open('پوشش شواهد محصولات','dashicons-shield-alt','', 'فقط محصولاتی پوشش‌دار شمرده می‌شوند که برای post:{ID} Claim با وضعیت VERIFIED یا PARTIAL در جدول شواهد واقعی داشته باشند. نبود Evidence به صورت صفر نمایش داده می‌شود، نه امتیاز ساختگی.'); ?>
                        <?php if(null===($evidence['percent']??null)): $empty_state('هنوز محصولی تحلیل نشده است','بعد از اسکن محصولات، نسبت محصولاتی که Claim دارای Evidence دارند نمایش داده می‌شود.','dashicons-shield-alt'); else: ?>
                            <div class="k30-gauge-row"><div class="k30-gauge <?php echo esc_attr($score_class($evidence['percent'])); ?>" style="--score:<?php echo esc_attr((string)(int)$evidence['percent']); ?>"><span><?php echo esc_html($evidence['percent'].'٪'); ?></span></div><div><b><?php echo esc_html(number_format_i18n((int)$evidence['supported']).' / '.number_format_i18n((int)$evidence['total'])); ?></b><span>محصول دارای Claim تأییدشده/نیمه‌تأیید</span><small><?php echo (int)$evidence['supported']===0?'Evidence واقعی هنوز برای محصولات ثبت نشده است.':'Coverage از جدول شواهد خود افزونه خوانده شده است.'; ?></small></div></div>
                            <div class="k30-evidence-note"><span class="dashicons dashicons-info-outline"></span><p>این کادر «وجود شواهد ثبت‌شده» را می‌سنجد؛ کیفیت یا صحت ادعای فنی فقط با بازبینی Claim و منبع مربوط مشخص می‌شود.</p></div>
                        <?php endif; ?>
                    <?php $card_close(); ?>
                </div>
                <?php $card_open('صف اصلاح و غنی‌سازی','dashicons-superhero','', 'Autofix فقط برای تغییراتی که کم‌ریسک و قابل اثبات‌اند Proposal می‌سازد؛ برند، GTIN و داده فنی حدس زده نمی‌شوند.'); ?>
                    <div class="k30-rec-grid"><?php foreach((array)($data['queue']??array()) as $rec): ?><article><div><span class="k30-pill <?php echo esc_attr($rec['priority']==='critical'?'danger':'warning'); ?>"><?php echo esc_html($rec['priority']); ?></span><small><?php echo esc_html($rec['engine']); ?></small></div><h3><?php echo esc_html($rec['entity_title']?:$rec['title']); ?></h3><p><?php echo esc_html($rec['reason']); ?></p><footer><span>SEO <?php echo esc_html($rec['seo_score']); ?></span><span>اعتماد داده <?php echo esc_html($rec['source_trust']); ?>٪</span><button data-entity-open="<?php echo esc_attr($rec['entity_kind']); ?>" data-entity-id="<?php echo esc_attr($rec['entity_id']); ?>">باز کردن</button></footer></article><?php endforeach; ?></div>
                <?php $card_close(); ?>

            <?php elseif ( 'categories-links' === $workspace ) : ?>
                <section class="k30-kpi-grid k30-kpi-grid-5">
                    <?php $tax_total=array_sum(array_map(static fn($r)=>(int)$r['total'],(array)($data['taxonomy']??array()))); $orphans=(int)($data['orphans_total']??count((array)($data['orphans']??array()))); foreach(array(
                        array('label'=>'Taxonomyهای بررسی‌شده','value'=>$tax_total,'tone'=>'success','icon'=>'dashicons-category','hint'=>'دسته، برچسب و ساختار فروشگاه'),
                        array('label'=>'لینک داخلی ثبت‌شده','value'=>$data['links']['total']??0,'tone'=>'success','icon'=>'dashicons-admin-links','hint'=>'از محتوای واقعی'),
                        array('label'=>'صفحات منبع','value'=>$data['links']['sources']??0,'tone'=>'info','icon'=>'dashicons-media-text','hint'=>'دارای لینک داخلی'),
                        array('label'=>'مقصدهای مرتبط','value'=>$data['links']['targets']??0,'tone'=>'info','icon'=>'dashicons-randomize','hint'=>'URLهای مقصد شناسایی‌شده'),
                        array('label'=>'صفحات یتیم','value'=>$orphans,'tone'=>$orphans?'warning':'success','icon'=>'dashicons-unlink','hint'=>'بدون لینک ورودی ثبت‌شده'),
                    ) as $m)$metric_card($m); ?>
                </section>
                <div class="k30-grid k30-grid-3">
                    <?php foreach((array)($data['taxonomy']??array()) as $tax): $card_open($tax['label'],'dashicons-category','', 'سلامت بر اساس تعداد Termهای خالی/کم‌محتوا و محصول متصل محاسبه می‌شود.'); ?><div class="k30-gauge-row"><div class="k30-gauge <?php echo esc_attr($score_class($tax['health'])); ?>" style="--score:<?php echo esc_attr($tax['health']); ?>"><span><?php echo esc_html($tax['health']); ?>%</span></div><div><b><?php echo esc_html($num($tax['total'])); ?></b><span>Term</span><small><?php echo esc_html($num($tax['thin'])); ?> مورد کم‌پوشش</small></div></div><?php $card_close(); endforeach; ?>
                    <?php $card_open('فرصت‌های لینک‌سازی','dashicons-admin-links','', 'صفحات یتیم از Link Graph واقعی سایت استخراج می‌شوند.'); ?><div class="k30-mini-list"><?php foreach(array_slice((array)($data['orphans']??array()),0,8) as $row): ?><button data-entity-open="<?php echo esc_attr($row['entity_kind']??'content_post'); ?>" data-entity-id="<?php echo esc_attr($row['entity_id']); ?>"><span><?php echo esc_html($row['title']); ?></span><b><?php echo esc_html($row['score_total']); ?></b></button><?php endforeach; ?></div><button class="k30-button secondary full" data-run-scan="links">بازسازی گراف لینک داخلی</button><?php $card_close(); ?>
                </div>
                <?php $card_open('صفحات یتیم و نیازمند لینک داخلی','dashicons-networking','', 'این جدول فقط از لینک‌های کشف‌شده داخل محتوای سایت ساخته شده است.'); ?><div class="k30-table-wrap"><table class="k30-table"><thead><tr><th>صفحه</th><th>امتیاز</th><th>URL</th><th>اقدام</th></tr></thead><tbody><?php foreach((array)($data['orphans']??array()) as $row): ?><tr><td><strong><?php echo esc_html($row['title']); ?></strong></td><td><span class="k30-score <?php echo esc_attr($score_class($row['score_total'])); ?>"><?php echo esc_html($row['score_total']); ?></span></td><td><code><?php echo esc_html(wp_parse_url($row['url'],PHP_URL_PATH)?:$row['url']); ?></code></td><td><a class="k30-mini-button" href="<?php echo esc_url(get_edit_post_link((int)$row['entity_id'])); ?>">ویرایش صفحه</a></td></tr><?php endforeach; ?></tbody></table></div><?php $render_pager((array)($data['pagination']??array())); $card_close(); ?>

            <?php elseif ( 'keywords-content' === $workspace ) : ?>
                <div class="k30-grid k30-grid-2-1">
                    <?php $card_open('کلمات کلیدی و داده جست‌وجو','dashicons-editor-spellcheck','', 'رتبه، Impression و CTR فقط از داده Import شده یا Provider متصل نمایش داده می‌شود.'); ?>
                        <?php if(empty($data['keywords'])): $empty_state('داده کلمات کلیدی هنوز وارد نشده است','برای جلوگیری از عدد جعلی، تا اتصال Search Console یا Import معتبر، این بخش خالی می‌ماند.','dashicons-chart-line'); ?><button class="k30-button primary" data-open-keyword-import>Import CSV / JSON</button><?php else: ?><div class="k30-table-wrap tall"><table class="k30-table"><thead><tr><th>کلمه</th><th>رتبه</th><th>Impression</th><th>Click</th><th>CTR</th><th>منبع</th></tr></thead><tbody><?php foreach($data['keywords'] as $row): ?><tr><td><strong><?php echo esc_html($row['phrase']); ?></strong><small><?php echo esc_html($row['target_url']?:'بدون صفحه هدف'); ?></small></td><td><?php echo null===$row['current_position']?'—':esc_html($row['current_position']); ?></td><td><?php echo null===$row['impressions']?'—':esc_html($num($row['impressions'])); ?></td><td><?php echo null===$row['clicks']?'—':esc_html($num($row['clicks'])); ?></td><td><?php echo null===$row['ctr']?'—':esc_html($row['ctr'].'%'); ?></td><td><?php $status_pill($row['source'],'info'); ?></td></tr><?php endforeach; ?></tbody></table></div><?php $render_pager((array)($data['keyword_pagination']??array()),'keyword_paged'); endif; ?>
                    <?php $card_close(); ?>
                    <?php $card_open('پوشش محتوایی','dashicons-chart-pie','', 'ضعیف‌ترین محتوا بر اساس امتیاز Content و تازه‌بودن مرتب می‌شود.'); ?><div class="k30-mini-list stacked"><?php foreach(array_slice((array)($data['content']??array()),0,10) as $row): ?><button data-entity-open="<?php echo esc_attr($row['entity_kind']??'content_post'); ?>" data-entity-id="<?php echo esc_attr($row['entity_id']); ?>"><span><b><?php echo esc_html($row['title']); ?></b><small><?php echo esc_html($row['word_count'].' کلمه · '.$row['stale_days'].' روز'); ?></small></span><i class="k30-score <?php echo esc_attr($score_class($row['score_content'])); ?>"><?php echo esc_html($row['score_content']); ?></i></button><?php endforeach; ?></div><?php $card_close(); ?>
                </div>
                <?php $card_open('چک‌لیست محتوای سایت','dashicons-list-view','', 'این وضعیت از محتوای واقعی موجودیت‌های تحلیل‌شده ساخته می‌شود.'); ?><div class="k30-table-wrap"><table class="k30-table"><thead><tr><th>محتوا</th><th>امتیاز</th><th>تعداد کلمه</th><th>تازگی</th><th>اقدام</th></tr></thead><tbody><?php foreach((array)($data['content']??array()) as $row): ?><tr><td><strong><?php echo esc_html($row['title']); ?></strong></td><td><span class="k30-score <?php echo esc_attr($score_class($row['score_content'])); ?>"><?php echo esc_html($row['score_content']); ?></span></td><td><?php echo esc_html($num($row['word_count'])); ?></td><td><?php echo esc_html($row['stale_days']); ?> روز</td><td><button class="k30-mini-button" data-entity-open="<?php echo esc_attr($row['entity_kind']??'content_post'); ?>" data-entity-id="<?php echo esc_attr($row['entity_id']); ?>">بازبینی</button></td></tr><?php endforeach; ?></tbody></table></div><?php $render_pager((array)($data['content_pagination']??array()),'content_paged'); $card_close(); ?>
                <?php $card_open('پژوهش زنده وب','dashicons-search','', 'این ابزار از OpenAI Web Search متصل استفاده می‌کند و فقط Sourceهای واقعی برگشتی را نمایش می‌دهد. خروجی آن Top 5 قطعی Google نیست.'); ?><form class="k30-serp-research-form" data-serp-research><label><span>عبارت پژوهش</span><input name="query" required maxlength="180" placeholder="مثلاً خرید نوار تیپ"></label><button type="submit" class="k30-button primary"><span class="dashicons dashicons-search"></span> پژوهش زنده</button></form><div class="k30-serp-research-result" data-serp-research-result><p class="k30-note">رتبه‌های قطعی Google فقط از Search Console/Rank Provider منبع‌دار در جدول بالا نمایش داده می‌شوند.</p></div><?php $card_close(); ?>

            <?php elseif ( 'technical-health' === $workspace ) : $codes=$data['codes']??array(); ?>
                <section class="k30-kpi-grid k30-kpi-grid-5">
                    <?php $critical=(int)($data['issues_critical_total']??count(array_filter((array)($data['issues']??array()),static fn($r)=>($r['severity']??'')==='critical'))); $warnings=max(0,(int)($data['issues_total']??count((array)($data['issues']??array())))-$critical); $crawled=array_sum(array_map('intval',$codes)); foreach(array(
                        array('label'=>'URLهای خزش‌شده','value'=>$crawled,'tone'=>'info','icon'=>'dashicons-visibility','hint'=>'مشاهده واقعی HTTP'),
                        array('label'=>'2xx سالم','value'=>$codes['2xx']??0,'tone'=>'success','icon'=>'dashicons-yes-alt','hint'=>'Response موفق'),
                        array('label'=>'4xx','value'=>$codes['4xx']??0,'tone'=>($codes['4xx']??0)?'danger':'success','icon'=>'dashicons-dismiss','hint'=>'خطای Client'),
                        array('label'=>'5xx','value'=>$codes['5xx']??0,'tone'=>($codes['5xx']??0)?'danger':'success','icon'=>'dashicons-warning','hint'=>'خطای Server'),
                        array('label'=>'Issue فنی باز','value'=>(int)($data['issues_total']??count((array)($data['issues']??array()))),'tone'=>$critical?'danger':($warnings?'warning':'success'),'icon'=>'dashicons-admin-tools','hint'=>$critical.' بحرانی'),
                    ) as $m)$metric_card($m); ?>
                </section>
                <?php if ( ! empty( $data['pagespeed']['available'] ) ) : ?>
                    <div class="k30-source-banner"><span class="dashicons dashicons-performance"></span><div><b>PageSpeed Insights متصل است</b><small>امتیاز Performance موبایل آخرین Sync: <?php echo null !== ( $data['pagespeed']['score'] ?? null ) ? esc_html( (string) $data['pagespeed']['score'] ) . '/100' : '—'; ?> · <?php echo esc_html( $short_date( $data['pagespeed']['at'] ?? null ) ); ?></small></div><a href="<?php echo esc_url( admin_url( 'admin.php?page=k20-ai-press&workspace=connections' ) ); ?>">Sync / تنظیمات</a></div>
                <?php endif; ?>
                <div class="k30-grid k30-grid-2-1">
                    <?php $card_open('روند سلامت فنی','dashicons-chart-line','', 'روند از Scan history واقعی محاسبه می‌شود.'); ?><div class="k30-chart" data-line-chart='<?php echo esc_attr(wp_json_encode($data['trend']??array())); ?>' data-value-key="score" data-label-key="date"><canvas width="750" height="280"></canvas><div class="k30-chart-empty">برای نمودار روند چند اسکن کامل نیاز است.</div></div><?php $card_close(); ?>
                    <?php $card_open('بررسی‌های کلیدی','dashicons-shield-alt','', 'وضعیت محلی از تنظیمات WordPress خوانده می‌شود؛ robots.txt و Sitemap فقط بعد از مشاهده واقعی Crawl تأیید می‌شوند.'); ?><div class="k30-check-list"><?php foreach((array)($data['checks']??array()) as $check): $tone=$tone_from_status($check['status']); ?><div><span class="k30-status-dot <?php echo esc_attr($tone); ?>"></span><b><?php echo esc_html($check['label']); ?></b><small><?php echo esc_html($check['detail']); ?></small></div><?php endforeach; ?></div><?php $card_close(); ?>
                </div>
                <?php $card_open('مشکلات فنی نیازمند اقدام','dashicons-warning','', 'Issueها با Evidence ذخیره شده‌اند و بعد از رفع در اسکن بعدی Resolve می‌شوند.'); ?><div class="k30-table-wrap tall"><table class="k30-table"><thead><tr><th>شدت</th><th>مشکل</th><th>صفحه</th><th>Component</th><th>آخرین مشاهده</th><th>اقدام</th></tr></thead><tbody><?php foreach((array)($data['issues']??array()) as $row): ?><tr><td><?php $status_pill($row['severity'],$issue_tone($row['severity'])); ?></td><td><strong><?php echo esc_html($row['title']); ?></strong><small><?php echo esc_html($row['rule_code']); ?></small></td><td><?php echo esc_html($row['entity_title']?:('#'.$row['entity_id'])); ?></td><td><?php echo esc_html($row['component']); ?></td><td><?php echo esc_html($short_date($row['last_seen_at'])); ?></td><td><button class="k30-mini-button" data-entity-open="<?php echo esc_attr($row['entity_kind']); ?>" data-entity-id="<?php echo esc_attr($row['entity_id']); ?>">جزئیات</button></td></tr><?php endforeach; ?></tbody></table></div><?php $render_pager((array)($data['pagination']??array())); $card_close(); ?>

            <?php elseif ( 'schema-preview' === $workspace ) : $entity=(array)($data['entity']??array()); $schema=(array)($data['schema']??array()); ?>
                <?php $card_open('انتخاب موجودیت برای پیش‌نمایش','dashicons-search','', 'فهرست از موجودیت‌های واقعی WordPress/WooCommerce ساخته می‌شود؛ موارد اسکن‌نشده هم قابل انتخاب‌اند.'); ?>
                    <form class="k30-filter-bar" method="get">
                        <input type="hidden" name="page" value="k20-ai-press"><input type="hidden" name="workspace" value="schema-preview">
                        <label><span>نوع</span><select name="kind"><?php foreach(array('product'=>'محصول','content_post'=>'نوشته','page'=>'برگه','news'=>'خبر') as $key=>$label): ?><option value="<?php echo esc_attr($key); ?>" <?php selected((string)($data['selected']['kind']??'product'),$key); ?>><?php echo esc_html($label); ?></option><?php endforeach; ?></select></label>
                        <label><span>جست‌وجو</span><input name="query" value="<?php echo esc_attr((string)($data['query']??'')); ?>" placeholder="نام محصول یا نوشته"></label>
                        <button class="k30-button secondary" type="submit"><span class="dashicons dashicons-filter"></span> اعمال</button>
                    </form>
                    <div class="k30-schema-picker">
                        <?php foreach((array)($data['candidates']??array()) as $candidate): $active=((string)($data['selected']['kind']??'')===(string)$candidate['kind'] && (int)($data['selected']['id']??0)===(int)$candidate['id']); $score=$candidate['score_total']??null; ?>
                            <a class="k30-mini-button <?php echo $active?'primary':''; ?>" href="<?php echo esc_url($workspace_url(array('kind'=>(string)$candidate['kind'],'id'=>(int)$candidate['id'],'paged'=>(int)($data['pagination']['paged']??1)))); ?>" title="<?php echo esc_attr((string)$candidate['title']); ?>"><?php echo esc_html(wp_html_excerpt((string)$candidate['title'],46,'…').' · '.(null===$score?'اندازه‌گیری‌نشده':((int)$score.'/100'))); ?></a>
                        <?php endforeach; ?>
                    </div>
                    <?php $render_pager((array)($data['pagination']??array())); ?>
                <?php $card_close(); ?>
                <div class="k30-grid k30-grid-1-2">
                    <?php $card_open('امتیاز و Eligibility','dashicons-editor-code','', 'امتیاز فقط از تحلیل واقعی همین موجودیت نمایش داده می‌شود.'); ?>
                        <?php if(!$entity): $empty_state('موجودیتی برای پیش‌نمایش نیست','نوع یا جست‌وجو را تغییر دهید.'); else: $p=$entity['profile']; ?>
                            <div class="k30-big-score <?php echo esc_attr($score_class($p['score_schema'])); ?>" style="--score:<?php echo esc_attr((string)max(0,min(100,(int)$p['score_schema']))); ?>"><strong><?php echo esc_html($p['score_schema']); ?></strong><span>از 100</span></div>
                            <ul class="k30-validation-list"><?php foreach((array)$entity['issues'] as $issue): if(($issue['component']??'')!=='schema') continue; ?><li class="<?php echo esc_attr($issue_tone($issue['severity'])); ?>"><span class="dashicons dashicons-warning"></span><?php echo esc_html($issue['title']); ?></li><?php endforeach; ?><li class="success"><span class="dashicons dashicons-yes-alt"></span> داده از موجودیت واقعی سایت</li></ul>
                        <?php endif; ?>
                    <?php $card_close(); ?>
                    <?php $card_open('پیش‌نمایش داده ساختاریافته','dashicons-editor-code','', 'JSON-LD از داده فعلی موجودیت ساخته می‌شود و برای بررسی است.'); ?>
                        <?php if($schema): ?><div class="k30-schema-layout"><div class="k30-schema-types"><?php foreach((array)($entity['evidence']['schema_types']??array()) as $type): ?><span><?php echo esc_html($type); ?><i class="dashicons dashicons-yes-alt"></i></span><?php endforeach; ?></div><pre class="k30-code k30-code-scroll"><code><?php echo esc_html(wp_json_encode($schema,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)); ?></code></pre></div><?php else: $empty_state('اسکیما قابل ساخت نیست','برای موجودیت انتخاب‌شده داده کافی وجود ندارد.'); endif; ?>
                    <?php $card_close(); ?>
                </div>
                <?php if($entity): $se=$entity['evidence']; $sp=$entity['profile']; ?>
                    <?php $card_open('اصلاح و ذخیره همین موجودیت','dashicons-edit','', 'ذخیره از Entity API کنترل‌شده انجام و سپس تحلیل مجدد می‌شود.'); ?>
                    <form class="k30-live-form compact" data-live-editor data-kind="<?php echo esc_attr($sp['entity_kind']); ?>" data-id="<?php echo esc_attr($sp['entity_id']); ?>">
                        <label><span>عنوان سئو</span><input name="seo_title" value="<?php echo esc_attr($se['seo_title']??''); ?>"></label>
                        <label><span>توضیحات متا</span><textarea name="meta_description" rows="3"><?php echo esc_textarea($se['meta_description']??''); ?></textarea></label>
                        <label><span>عبارت کلیدی</span><input name="focus_keyword" value="<?php echo esc_attr($se['focus_keyword']??''); ?>"></label>
                        <button type="submit" class="k30-button primary"><span class="dashicons dashicons-saved"></span> ذخیره تغییرات</button>
                    </form>
                    <?php $card_close(); ?>
                    <?php $card_open('پیش‌نمایش SERP / Social','dashicons-visibility','', 'پیش‌نمایش محلی است و تضمین نمی‌کند گوگل دقیقاً همین نمایش را انتخاب کند.'); $e=$entity['evidence']; $share_id=(int)($e['featured_image_id']??($e['image_ids'][0]??0)); $share_url=$share_id?wp_get_attachment_image_url($share_id,'medium'):''; ?>
                    <div class="k30-preview-grid"><article class="k30-serp-preview"><small><?php echo esc_html(home_url()); ?></small><h3><?php echo esc_html($e['seo_title']??$e['title']??''); ?></h3><p><?php echo esc_html(($e['meta_description']??'') ?: 'توضیح متا ثبت نشده است.'); ?></p></article><article class="k30-social-preview"><div class="k30-social-image"><?php if($share_url): ?><img src="<?php echo esc_url($share_url); ?>" alt=""><?php else:?><span class="dashicons dashicons-format-image"></span><small>تصویر اشتراک پیدا نشد.</small><?php endif; ?></div><b><?php echo esc_html($e['title']??''); ?></b><small><?php echo esc_html(wp_parse_url($e['url']??'',PHP_URL_HOST)); ?></small></article></div>
                    <div class="k30-modal-actions"><a class="k30-button primary" href="<?php echo esc_url(admin_url('admin.php?page=k20-ai-press&workspace=live-editor&kind='.rawurlencode((string)$sp['entity_kind']).'&id='.(int)$sp['entity_id'])); ?>">باز کردن در ویرایشگر زنده</a></div>
                    <?php $card_close(); ?>
                <?php endif; ?>

            <?php elseif ( 'images-alt' === $workspace ) : $summary=$data['summary']??array(); ?>
                <section class="k30-kpi-grid k30-kpi-grid-6"><?php foreach(array(
                    array('label'=>'میانگین سلامت تصویر','value'=>$summary['media']??null,'suffix'=>'٪','tone'=>$score_class($summary['media']??null),'icon'=>'dashicons-format-image','hint'=>'از رسانه‌های فیلترشده'),
                    array('label'=>'رسانه','value'=>$summary['total']??0,'tone'=>'info','icon'=>'dashicons-images-alt2','hint'=>'Attachment واقعی'),
                    array('label'=>'ALT ناقص','value'=>$summary['missing_alt']??0,'tone'=>($summary['missing_alt']??0)?'warning':'success','icon'=>'dashicons-warning','hint'=>'کل نتیجه فیلتر'),
                    array('label'=>'تصویر بزرگ >500KB','value'=>$summary['large_files']??0,'tone'=>($summary['large_files']??0)?'warning':'success','icon'=>'dashicons-performance','hint'=>'کل نتیجه فیلتر'),
                    array('label'=>'ابعاد ناقص','value'=>$summary['missing_dimensions']??0,'tone'=>($summary['missing_dimensions']??0)?'warning':'success','icon'=>'dashicons-editor-expand','hint'=>'کل نتیجه فیلتر'),
                    array('label'=>'گروه تکراری','value'=>$data['duplicates']['group_count']??0,'tone'=>($data['duplicates']['group_count']??0)?'warning':'success','icon'=>'dashicons-images-alt','hint'=>'SHA-256 واقعی'),
                ) as $m)$metric_card($m); ?></section>
                <form class="k30-filter-bar" method="get"><input type="hidden" name="page" value="k20-ai-press"><input type="hidden" name="workspace" value="images-alt"><label><span>جست‌وجو</span><input name="query" value="<?php echo esc_attr($data['query']??''); ?>" placeholder="نام یا ALT تصویر"></label><label><span>وضعیت ALT</span><select name="status"><option value="all">همه</option><option value="missing-alt" <?php selected($data['status']??'all','missing-alt'); ?>>ALT ناقص</option><option value="with-alt" <?php selected($data['status']??'all','with-alt'); ?>>دارای ALT</option></select></label><button class="k30-button secondary" type="submit">اعمال فیلتر</button><a class="k30-mini-button" href="<?php echo esc_url(admin_url('admin.php?page=k20-ai-press&workspace=images-alt')); ?>">پاک‌کردن</a></form>
                <div class="k30-grid k30-grid-3-1">
                    <?php $card_open('مدیریت تصاویر و ALT','dashicons-images-alt2','', 'ALT مستقیماً از Media Library خوانده و همان‌جا ذخیره می‌شود.'); ?>
                    <?php if(empty($data['items'])):$empty_state('رسانه‌ای با این فیلتر پیدا نشد','فیلتر را تغییر دهید یا اسکن Media را اجرا کنید.');else:?><div class="k30-media-table"><?php foreach($data['items'] as $item): ?><article data-alt-row data-id="<?php echo esc_attr($item['id']); ?>"><div class="k30-thumb"><?php if($item['url']): ?><img src="<?php echo esc_url($item['url']); ?>" alt=""><?php else:?><span class="dashicons dashicons-format-image"></span><?php endif; ?></div><div class="k30-media-name"><strong><?php echo esc_html($item['title']); ?></strong><small><?php echo esc_html('#'.$item['id'].' · '.($item['filename']??'').' · '.$item['mime_type'].' · '.$item['width'].'×'.$item['height']); ?> · <?php echo $item['filesize']?esc_html(size_format($item['filesize'])):'—'; ?></small><?php if(!empty($item['parent_title'])):?><a href="<?php echo esc_url($item['parent_url']); ?>"><?php echo esc_html('استفاده در: '.$item['parent_title'].' · #'.$item['parent_id']); ?></a><?php else:?><small>محل: کتابخانه رسانه · بدون والد مستقیم</small><?php endif; ?></div><form class="k30-alt-inline <?php echo empty($item['alt'])?'danger':'success'; ?>" data-alt-editor data-id="<?php echo esc_attr($item['id']); ?>"><label><span>ALT</span><input name="alt" value="<?php echo esc_attr($item['alt']); ?>" placeholder="متن جایگزین دقیق تصویر"></label><button class="k30-mini-button primary" type="submit">ذخیره</button></form><span class="k30-score <?php echo esc_attr($score_class($item['score'])); ?>"><?php echo esc_html($item['score']); ?></span><button class="k30-mini-button" data-entity-open="media" data-entity-id="<?php echo esc_attr($item['id']); ?>">جزئیات</button></article><?php endforeach; ?></div><?php $render_pager((array)($data['pagination']??array())); endif; ?><?php $card_close(); ?>
                    <?php $card_open('ابزارهای تصویر','dashicons-admin-tools','', 'اسکن ALT/ابعاد/حجم سبک است؛ Hash فقط برای Duplicate اجرا می‌شود.'); ?><div class="k30-tool-cards"><button data-run-scan="media"><span class="dashicons dashicons-update"></span><b>اسکن رسانه</b><small>ALT، ابعاد و حجم</small></button><a href="<?php echo esc_url(admin_url('plugins.php')); ?>"><span class="dashicons dashicons-format-image"></span><b>WebP/AVIF</b><small>افزونه تبدیل تصویر سایت</small></a><button data-run-scan="media-duplicates"><span class="dashicons dashicons-images-alt"></span><b>تشخیص تکراری</b><small>SHA-256</small></button></div><?php $card_close(); ?>
                </div>
                <?php $dups=$data['duplicates']??array(); if(!empty($dups['groups'])): $card_open('تصاویر تکراری واقعی','dashicons-images-alt','', 'گروه فقط با SHA-256 یکسان قطعی می‌شود.'); ?><div class="k30-duplicate-grid" id="k30-duplicate-media"><?php foreach((array)$dups['groups'] as $group): ?><article><strong><?php echo esc_html(count($group).' فایل یکسان'); ?></strong><?php foreach($group as $item): ?><button class="k30-mini-button" data-entity-open="media" data-entity-id="<?php echo esc_attr($item['id']); ?>"><?php echo esc_html($item['title']?:('#'.$item['id'])); ?></button><?php endforeach; ?></article><?php endforeach; ?></div><?php $card_close(); endif; ?>

            <?php elseif ( 'rank-tracking' === $workspace ) : $metrics=$data['metrics']??array(); ?>
                <section class="k30-kpi-grid k30-kpi-grid-6"><?php foreach(array(
                    array('label'=>'کلمات رهگیری‌شده','value'=>$metrics['tracked']??0,'tone'=>'info','icon'=>'dashicons-search','hint'=>'دارای داده منبع‌دار'),
                    array('label'=>'میانگین رتبه','value'=>$metrics['avg_position']??null,'tone'=>'info','icon'=>'dashicons-chart-line','hint'=>'مقادیر موجود'),
                    array('label'=>'Top 10','value'=>$metrics['top10']??0,'tone'=>'success','icon'=>'dashicons-awards','hint'=>'رتبه ≤ 10'),
                    array('label'=>'بهبود یافته','value'=>$metrics['improved']??0,'tone'=>'success','icon'=>'dashicons-arrow-up-alt','hint'=>'نسبت به مقدار قبلی'),
                    array('label'=>'افت کرده','value'=>$metrics['declined']??0,'tone'=>($metrics['declined']??0)?'danger':'success','icon'=>'dashicons-arrow-down-alt','hint'=>'نسبت به مقدار قبلی'),
                    array('label'=>'Impressions','value'=>$metrics['impressions']??0,'tone'=>'info','icon'=>'dashicons-visibility','hint'=>'از منبع واردشده'),
                ) as $m)$metric_card($m); ?></section>
                <?php $card_open('ردیابی کلمات کلیدی','dashicons-chart-line','', 'این جدول هیچ رتبه‌ای را حدس نمی‌زند. هر ردیف باید Source داشته باشد.'); ?><?php if(empty($data['keywords'])):$empty_state('داده رتبه معتبر نداریم','Search Console را متصل کنید یا CSV/JSON خروجی Rank Tracker را Import کنید.','dashicons-chart-line'); ?><button class="k30-button primary" data-open-keyword-import>Import داده رتبه</button><?php else:?><div class="k30-table-wrap tall"><table class="k30-table"><thead><tr><th>کلمه</th><th>صفحه هدف</th><th>رتبه فعلی</th><th>قبلی</th><th>تغییر</th><th>Impression</th><th>CTR</th><th>Source</th></tr></thead><tbody><?php foreach($data['keywords'] as $row): $delta=null;if(null!==$row['current_position']&&null!==$row['previous_position'])$delta=(float)$row['previous_position']-(float)$row['current_position']; ?><tr><td><strong><?php echo esc_html($row['phrase']); ?></strong></td><td><code><?php echo esc_html(wp_parse_url($row['target_url']??'',PHP_URL_PATH)?:'—'); ?></code></td><td><?php echo null===$row['current_position']?'—':esc_html($row['current_position']); ?></td><td><?php echo null===$row['previous_position']?'—':esc_html($row['previous_position']); ?></td><td><?php if(null===$delta):?>—<?php elseif($delta>0):?><span class="delta up">↑ <?php echo esc_html($delta); ?></span><?php elseif($delta<0):?><span class="delta down">↓ <?php echo esc_html(abs($delta)); ?></span><?php else:?>—<?php endif; ?></td><td><?php echo null===$row['impressions']?'—':esc_html($num($row['impressions'])); ?></td><td><?php echo null===$row['ctr']?'—':esc_html($row['ctr'].'%'); ?></td><td><?php $status_pill($row['source'],'info'); ?></td></tr><?php endforeach; ?></tbody></table></div><?php $render_pager((array)($data['pagination']??array())); endif; ?><?php $card_close(); ?>

            <?php elseif ( 'competitors-serp' === $workspace ) : ?>
                <section class="k30-kpi-grid k30-kpi-grid-4"><?php foreach(array(
                    array('label'=>'رقبای ثبت‌شده','value'=>count((array)($data['competitors']??array())),'tone'=>'info','icon'=>'dashicons-groups','hint'=>'دامنه‌های منبع‌دار'),
                    array('label'=>'کلمات دارای داده','value'=>(int)($data['keywords_total']??count((array)($data['keywords']??array()))),'tone'=>'info','icon'=>'dashicons-editor-spellcheck','hint'=>'برای مقایسه SERP'),
                    array('label'=>'SERP زنده','value'=>null,'tone'=>('connected'===($data['serpapi_status']??''))?'success':'warning','icon'=>'dashicons-cloud','hint'=>('connected'===($data['serpapi_status']??''))?'SerpApi متصل':'SerpApi نیازمند اتصال'),
                    array('label'=>'داده ساختگی','value'=>0,'tone'=>'success','icon'=>'dashicons-shield-alt','hint'=>'Fail-closed'),
                ) as $m)$metric_card($m); ?></section>
                <div class="k30-grid k30-grid-2-1">
                    <?php $card_open('رقبا و داده‌های مقایسه','dashicons-groups','', 'Metrics فقط زمانی نمایش داده می‌شود که همراه Source وارد شده یا Provider متصل باشد.'); ?><?php if(empty($data['competitors'])):$empty_state('هنوز رقیبی ثبت نشده است','دامنه رقیب را اضافه کنید؛ Metrics اختیاری و منبع‌دار هستند.','dashicons-groups'); ?><button class="k30-button primary" data-open-competitor>افزودن رقیب</button><?php else:?><div class="k30-competitor-grid"><?php foreach($data['competitors'] as $row): ?><article><div class="k30-domain-avatar"><?php echo esc_html(strtoupper(substr($row['domain'],0,1))); ?></div><div><strong><?php echo esc_html($row['label']?:$row['domain']); ?></strong><small><?php echo esc_html($row['domain']); ?> · <?php echo esc_html($row['source']); ?></small></div><span class="k30-pill <?php echo $row['enabled']?'success':'neutral'; ?>"><?php echo $row['enabled']?'فعال':'خاموش'; ?></span></article><?php endforeach; ?></div><?php endif; ?><?php $card_close(); ?>
                    <?php $card_open('موتورهای تحلیل','dashicons-superhero','', 'بخش رقبا تا دریافت داده بیرونی معتبر در حالت Waiting Data می‌ماند.'); ?><div class="k30-engine-list compact"><div><span class="k30-status-dot success"></span><div><b>Gap Rule Engine</b><small>تحلیل کلمات موجود</small></div></div><div><span class="k30-status-dot <?php echo 'connected'===($data['serpapi_status']??'')?'success':'warning'; ?>"></span><div><b>SERP Provider</b><small><?php echo 'connected'===($data['serpapi_status']??'')?'SerpApi متصل':'نیازمند اتصال SerpApi'; ?></small></div></div><div><span class="k30-status-dot success"></span><div><b>Competitor Store</b><small>دامنه و snapshot منبع‌دار</small></div></div></div><?php $card_close(); ?>
                </div>
                <?php $card_open('شکاف‌های قابل بررسی','dashicons-chart-bar','', 'فرصت‌ها از Keyword dataset موجود استخراج می‌شوند؛ اگر داده رتبه نداریم Empty state نمایش داده می‌شود.'); ?><?php if(empty($data['keywords'])):$empty_state('SERP dataset نداریم','Import رتبه یا اتصال Search Console/Provider لازم است.');else:?><div class="k30-table-wrap"><table class="k30-table"><thead><tr><th>کلمه</th><th>رتبه سایت</th><th>Impression</th><th>منبع</th><th>صفحه هدف</th></tr></thead><tbody><?php foreach((array)$data['keywords'] as $row): ?><tr><td><strong><?php echo esc_html($row['phrase']); ?></strong></td><td><?php echo null===$row['current_position']?'—':esc_html($row['current_position']); ?></td><td><?php echo null===$row['impressions']?'—':esc_html($num($row['impressions'])); ?></td><td><?php echo esc_html($row['source']); ?></td><td><code><?php echo esc_html(wp_parse_url($row['target_url']??'',PHP_URL_PATH)?:'—'); ?></code></td></tr><?php endforeach; ?></tbody></table></div><?php $render_pager((array)($data['pagination']??array())); endif; ?><?php $card_close(); ?>

            <?php elseif ( 'content-refresh' === $workspace ) : ?>
                <section class="k30-kpi-grid k30-kpi-grid-4"><?php foreach(array(
                    array('label'=>'محتوای نیازمند به‌روزرسانی','value'=>$data['stale_count']??0,'tone'=>($data['stale_count']??0)?'warning':'success','icon'=>'dashicons-update','hint'=>'قدیمی‌تر از ۱۸۰ روز'),
                    array('label'=>'محتوای کم‌امتیاز','value'=>$data['low_content']??0,'tone'=>($data['low_content']??0)?'danger':'success','icon'=>'dashicons-warning','hint'=>'Content score < 60'),
                    array('label'=>'تقویم آینده','value'=>count((array)($data['calendar']??array())),'tone'=>'info','icon'=>'dashicons-calendar-alt','hint'=>'Draft / Pending / Future'),
                    array('label'=>'پیشنهادهای باز','value'=>count((array)($data['queue']??array())),'tone'=>'info','icon'=>'dashicons-lightbulb','hint'=>'Rule Engine'),
                ) as $m)$metric_card($m); ?></section>
                <div class="k30-grid k30-grid-2-1">
                    <?php $card_open('موتور به‌روزرسانی محتوا','dashicons-update','', 'تازگی، امتیاز محتوا و حجم متن از صفحات واقعی سایت خوانده می‌شود.'); ?><div class="k30-table-wrap tall"><table class="k30-table"><thead><tr><th>محتوا</th><th>امتیاز</th><th>کلمه</th><th>سن به‌روزرسانی</th><th>اقدام</th></tr></thead><tbody><?php foreach((array)($data['items']??array()) as $row): ?><tr><td><strong><?php echo esc_html($row['title']); ?></strong><small><?php echo esc_html($row['kind']); ?></small></td><td><span class="k30-score <?php echo esc_attr($score_class($row['score'])); ?>"><?php echo esc_html($row['score']); ?></span></td><td><?php echo esc_html($num($row['word_count'])); ?></td><td><?php $status_pill($row['stale_days'].' روز',$row['stale_days']>=365?'danger':($row['stale_days']>=180?'warning':'success')); ?></td><td><button class="k30-mini-button" data-entity-open="<?php echo esc_attr($row['kind']); ?>" data-entity-id="<?php echo esc_attr($row['id']); ?>">بازبینی</button></td></tr><?php endforeach; ?></tbody></table></div><?php $render_pager((array)($data['pagination']??array())); $card_close(); ?>
                    <?php $card_open('تقویم شمسی انتشار','dashicons-calendar-alt','', 'روزها به تقویم جلالی نمایش داده می‌شوند؛ زمان نهایی از timezone خود WordPress ذخیره می‌شود.'); ?><div class="k30-jalali-calendar" data-jalali-calendar='<?php echo esc_attr(wp_json_encode((array)($data['calendar']??array()))); ?>'><header><button class="k30-mini-button" type="button" data-jcal-prev>ماه قبل</button><strong data-jcal-title>تقویم شمسی</strong><button class="k30-mini-button" type="button" data-jcal-next>ماه بعد</button></header><div class="k30-jcal-week"><span>ش</span><span>ی</span><span>د</span><span>س</span><span>چ</span><span>پ</span><span>ج</span></div><div class="k30-jcal-grid" data-jcal-grid></div></div><form class="k30-schedule-form" data-calendar-schedule><label><span>محتوا</span><select name="id" required><option value="">انتخاب Draft/Pending/Future</option><?php foreach((array)($data['calendar']??array()) as $row): ?><option value="<?php echo esc_attr($row['id']); ?>"><?php echo esc_html($row['title'].' · '.$row['type'].' · '.$row['status']); ?></option><?php endforeach; ?></select></label><label><span>روز انتخاب‌شده</span><input data-jcal-selected-label readonly placeholder="یک روز از تقویم را انتخاب کنید"><input type="hidden" name="date" data-jcal-selected-date></label><label><span>ساعت</span><input type="time" name="time" required value="09:00"></label><button class="k30-button primary" type="submit">زمان‌بندی انتشار</button></form><?php $card_close(); ?>
                </div>

            <?php elseif ( 'crawl-monitoring' === $workspace ) : $codes=$data['codes']??array(); ?>
                <section class="k30-kpi-grid k30-kpi-grid-5"><?php $total=array_sum(array_map('intval',$codes)); foreach(array(
                    array('label'=>'URL خزش‌شده','value'=>$total,'tone'=>'info','icon'=>'dashicons-visibility','hint'=>'Observationهای ذخیره‌شده'),
                    array('label'=>'موفق 2xx','value'=>$codes['2xx']??0,'tone'=>'success','icon'=>'dashicons-yes-alt','hint'=>'پاسخ سالم'),
                    array('label'=>'Redirect 3xx','value'=>$codes['3xx']??0,'tone'=>'warning','icon'=>'dashicons-randomize','hint'=>'نیازمند بررسی در صورت زنجیره'),
                    array('label'=>'Client 4xx','value'=>$codes['4xx']??0,'tone'=>($codes['4xx']??0)?'danger':'success','icon'=>'dashicons-dismiss','hint'=>'URL مشکل‌دار'),
                    array('label'=>'Server 5xx','value'=>$codes['5xx']??0,'tone'=>($codes['5xx']??0)?'danger':'success','icon'=>'dashicons-warning','hint'=>'خطای سرور'),
                ) as $m)$metric_card($m); ?></section>
                <div class="k30-grid k30-grid-3-1">
                    <?php $card_open('آخرین URLهای خزش‌شده','dashicons-visibility','', 'wp_safe_remote_get فقط URLهای همان دامنه را بررسی می‌کند و SSRF را محدود می‌کند.'); ?><div class="k30-table-wrap tall"><table class="k30-table"><thead><tr><th>URL</th><th>Status</th><th>زمان</th><th>Indexable</th><th>Canonical</th><th>Schema</th></tr></thead><tbody><?php foreach((array)($data['observations']??array()) as $row): $http=(int)$row['http_status'];$tone=$http>=500?'danger':($http>=400?'danger':($http>=300?'warning':'success')); ?><tr><td><code><?php echo esc_html(wp_parse_url($row['url'],PHP_URL_PATH)?:'/'); ?></code></td><td><?php $status_pill((string)$http,$tone); ?></td><td><?php echo esc_html($row['response_time_ms'].'ms'); ?></td><td><?php $status_pill($row['indexable']?'بله':'خیر',$row['indexable']?'success':'danger'); ?></td><td><small><?php echo esc_html(wp_parse_url($row['canonical'],PHP_URL_PATH)?:'—'); ?></small></td><td><small><?php echo esc_html($row['schema_types']?:'—'); ?></small></td></tr><?php endforeach; ?></tbody></table></div><?php $render_pager((array)($data['pagination']??array())); $card_close(); ?>
                    <?php $card_open('عملیات سریع Crawl','dashicons-admin-tools','', 'خزش کامل به صورت Batch اجرا می‌شود تا به هاست فشار وارد نشود.'); ?><div class="k30-tool-cards vertical"><button data-run-scan="crawl"><span class="dashicons dashicons-update"></span><b>شروع Crawl جدید</b><small>تمام صفحات منتشرشده</small></button><button data-crawl-url-prompt><span class="dashicons dashicons-search"></span><b>بررسی URL</b><small>فقط دامنه همین سایت</small></button><a href="<?php echo esc_url(home_url('/robots.txt')); ?>" target="_blank"><span class="dashicons dashicons-media-text"></span><b>robots.txt</b><small>باز کردن فایل فعلی</small></a></div><?php $card_close(); ?>
                </div>
                <?php $card_open('تاریخچه Crawl','dashicons-backup','', 'هر Run وضعیت، تعداد پردازش و خطاهای خودش را نگه می‌دارد.'); ?><div class="k30-scan-history"><?php foreach((array)($data['runs']??array()) as $run): ?><article><div><strong>#<?php echo esc_html($run['id']); ?> · <?php echo esc_html($run['scope']); ?></strong><small><?php echo esc_html($short_date($run['created_at'])); ?></small></div><?php $status_pill($run['status'],$tone_from_status($run['status'])); ?><span><?php echo esc_html($run['processed'].' / '.$run['total']); ?></span><span><?php echo esc_html($run['issues_found']); ?> ایراد</span></article><?php endforeach; ?></div><?php $card_close(); ?>

            <?php elseif ( 'control-tower' === $workspace ) : $cc=(array)($data['command_center']??array()); $ccm=(array)($cc['metrics']??array()); ?>
                <section class="k30-kpi-grid k30-kpi-grid-5"><?php foreach(array(
                    array('label'=>'سلامت سایت','value'=>$ccm['site_health']??null,'suffix'=>'/100','tone'=>$score_class($ccm['site_health']??null),'icon'=>'dashicons-heart','hint'=>'میانگین تحلیل‌شده؛ نبود داده = —'),
                    array('label'=>'دیده‌شدن در AI','value'=>$ccm['ai_visibility']??null,'suffix'=>'%','tone'=>$score_class($ccm['ai_visibility']??null),'icon'=>'dashicons-visibility','hint'=>'Mention/Citation اندازه‌گیری‌شده'),
                    array('label'=>'فرصت تجاری','value'=>$ccm['commerce_opportunities']??0,'tone'=>'info','icon'=>'dashicons-cart','hint'=>'محصول با شکاف اندازه‌گیری‌شده ≥15'),
                    array('label'=>'نیازمند تأیید','value'=>$ccm['awaiting_approval']??0,'tone'=>($ccm['awaiting_approval']??0)?'warning':'success','icon'=>'dashicons-yes-alt','hint'=>'Agent + Action proposal'),
                    array('label'=>'Agent فعال','value'=>$ccm['active_agents']??0,'tone'=>'info','icon'=>'dashicons-superhero','hint'=>'Runهای در حال اجرا'),
                ) as $m)$metric_card($m); ?></section>
                <?php if(!empty($cc['priority_queue'])): $card_open('Priority Queue عملیاتی','dashicons-list-view','', 'فقط Issue/Agent/Product/Visibility دارای داده واقعی وارد این صف می‌شود.'); ?><div class="k30-rec-list"><?php foreach(array_slice((array)$cc['priority_queue'],0,10) as $item): ?><article><div><?php $status_pill((string)($item['priority']??'medium'),($item['priority']??'')==='critical'?'danger':(($item['priority']??'')==='high'?'warning':'info')); ?><b><?php echo esc_html((string)($item['title']??$item['action']??'')); ?></b><small><?php echo esc_html((string)($item['source']??'')); ?></small></div><span><?php echo esc_html((string)($item['action']??'')); ?></span></article><?php endforeach; ?></div><?php $card_close(); endif; ?>
                <div class="k30-grid k30-grid-2-1">
                    <?php $card_open('Agent Runtime','dashicons-superhero','', 'Agent ابتدا با Structured Planner روی Provider متصل برنامه می‌سازد؛ اگر Provider در دسترس نباشد deterministic fallback استفاده می‌شود. Stepهای write تا Approval صریح اجرا نمی‌شوند.'); ?><form data-agent-plan-form class="k30-settings-form"><label><span>هدف Agent</span><textarea name="objective" rows="3" required maxlength="2000" placeholder="مثلاً: محصولات با آمادگی پایین AI را پیدا کن و برای محصول 123 اصلاح امن پیشنهاد بده"></textarea></label><label><span>Mode</span><select name="mode"><option value="read_only">Read only</option><option value="assisted" selected>Assisted</option><option value="autonomous_low_risk">Autonomous low-risk</option></select></label><label><span>Product ID (اختیاری)</span><input type="number" min="1" name="product_id"></label><button class="k30-button primary" type="submit">ساخت Plan</button></form><div data-agent-plan-result></div><?php $card_close(); ?>
                    <?php $card_open('Agent Runهای اخیر','dashicons-backup','', 'Execute فقط بعد از Approval و از مسیر Abilityهای ثبت‌شده انجام می‌شود.'); ?><div class="k30-agent-list"><?php foreach((array)($cc['agents']['recent']??array()) as $run): ?><article data-agent-run="<?php echo esc_attr($run['run_key']); ?>"><div class="k30-agent-icon"><span class="dashicons dashicons-superhero-alt"></span></div><div><strong><?php echo esc_html((string)$run['objective']); ?></strong><small><?php echo esc_html((string)$run['run_key']); ?></small></div><?php $status_pill((string)$run['status'],$tone_from_status((string)$run['status'])); ?><button type="button" class="k30-mini-button" data-agent-open="<?php echo esc_attr($run['run_key']); ?>">جزئیات</button></article><?php endforeach; ?></div><?php $card_close(); ?>
                </div>

            <?php elseif ( 'product-intelligence' === $workspace ) : $items=(array)($data['items']??array()); ?>
                <section class="k30-kpi-grid k30-kpi-grid-5"><?php foreach(array(
                    array('label'=>'کل محصولات','value'=>$data['products_total']??0,'tone'=>'info','icon'=>'dashicons-products','hint'=>'کل دامنه جست‌وجو/دسته فعلی','href'=>$workspace_url(array('status'=>'all','paged'=>null))),
                    array('label'=>'اسکن‌شده','value'=>$data['products_scanned']??0,'tone'=>'info','icon'=>'dashicons-visibility','hint'=>'دارای امتیاز واقعی ذخیره‌شده','href'=>$workspace_url(array('status'=>'measured','paged'=>null))),
                    array('label'=>'میانگین آمادگی','value'=>$data['average_readiness']??null,'suffix'=>'/100','tone'=>$score_class($data['average_readiness']??null),'icon'=>'dashicons-chart-area','hint'=>'فقط محصولات اندازه‌گیری‌شده','href'=>$workspace_url(array('status'=>'measured','paged'=>null))),
                    array('label'=>'پوشش داده ≥75٪','value'=>$data['coverage_75']??0,'tone'=>'success','icon'=>'dashicons-yes-alt','hint'=>'داده زنده WooCommerce','href'=>$workspace_url(array('status'=>'coverage75','paged'=>null))),
                    array('label'=>'Backlog باز','value'=>$data['open_backlog']??0,'tone'=>($data['open_backlog']??0)?'warning':'success','icon'=>'dashicons-lightbulb','hint'=>'امتیاز <85 یا هنوز اسکن نشده','href'=>$workspace_url(array('status'=>'backlog','paged'=>null))),
                ) as $m)$metric_card($m); ?></section>
                <form class="k30-filter-bar" method="get"><input type="hidden" name="page" value="k20-ai-press"><input type="hidden" name="workspace" value="product-intelligence"><label><span>جست‌وجو</span><input name="query" value="<?php echo esc_attr($data['query']??''); ?>" placeholder="نام یا SKU"></label><label><span>دسته</span><select name="category_id"><option value="0">همه دسته‌ها</option><?php foreach((array)($data['categories']??array()) as $cat): ?><option value="<?php echo esc_attr($cat['id']); ?>" <?php selected((int)($data['category_id']??0),(int)$cat['id']); ?>><?php echo esc_html($cat['label']); ?></option><?php endforeach; ?></select></label><label><span>وضعیت</span><select name="status"><option value="all">همه</option><option value="critical" <?php selected($data['status']??'all','critical'); ?>>بحرانی</option><option value="improve" <?php selected($data['status']??'all','improve'); ?>>نیاز به بهبود</option><option value="healthy" <?php selected($data['status']??'all','healthy'); ?>>سالم</option><option value="unmeasured" <?php selected($data['status']??'all','unmeasured'); ?>>اندازه‌گیری‌نشده</option><option value="measured" <?php selected($data['status']??'all','measured'); ?>>اسکن‌شده</option><option value="coverage75" <?php selected($data['status']??'all','coverage75'); ?>>پوشش ≥75٪</option><option value="backlog" <?php selected($data['status']??'all','backlog'); ?>>Backlog باز</option></select></label><button class="k30-button secondary" type="submit">اعمال فیلتر</button><button class="k30-button secondary" type="button" data-run-scan="product"><span class="dashicons dashicons-update"></span> اسکن/بازخوانی محصولات</button></form>
                <?php $card_open('Product Intelligence Backlog','dashicons-analytics','', 'Coverage از داده جاری WooCommerce می‌آید؛ Overall فقط وقتی اسکن واقعی موجود باشد نمایش داده می‌شود.'); ?>
                    <?php if(!$items): $empty_state('محصولی با این فیلتر پیدا نشد','فیلتر را تغییر دهید یا محصولات را اسکن کنید.','dashicons-products'); else: ?><div class="k30-table-wrap tall"><table class="k30-table"><thead><tr><th>محصول</th><th>وضعیت</th><th>Overall</th><th>Coverage</th><th>Opportunity</th><th>شکاف اصلی</th><th></th></tr></thead><tbody><?php foreach($items as $row): ?><tr><td><strong><?php echo esc_html((string)($row['title']??'#'.$row['product_id'])); ?></strong><small><?php echo esc_html(($row['sku']??'')?('SKU: '.$row['sku']):('#'.$row['product_id'])); ?></small></td><td><?php $status_pill((string)$row['status_label'], 'unmeasured'===$row['status_key']?'neutral':('critical'===$row['status_key']?'danger':('improve'===$row['status_key']?'warning':'success'))); ?></td><td><?php echo null===($row['overall']??null)?'—':esc_html((string)$row['overall'].'/100'); ?></td><td><?php echo esc_html((string)($row['coverage']??0).'%'); ?></td><td><?php echo null===($row['opportunity']??null)?'—':esc_html((string)$row['opportunity']); ?></td><td><small><?php echo esc_html((string)($row['main_issue']??'—')); ?></small></td><td><a class="k30-mini-button primary" href="<?php echo esc_url($row['editor_url']); ?>">بررسی و اصلاح</a></td></tr><?php endforeach; ?></tbody></table></div><?php $render_pager((array)($data['pagination']??array())); endif; ?>
                <?php $card_close(); ?>

            <?php elseif ( 'ai-visibility' === $workspace ) : $current=(array)($data['current']??array()); $engines=(array)($data['engine_totals']??array()); ?>
                <section class="k30-kpi-grid k30-kpi-grid-5"><?php $samples=array_sum(array_map(static fn($x)=>(int)($x['samples']??0),$engines)); $mentions=array_sum(array_map(static fn($x)=>(int)($x['mentions']??0),$engines)); $citations=array_sum(array_map(static fn($x)=>(int)($x['citations']??0),$engines)); foreach(array(
                    array('label'=>'Observation','value'=>$samples,'tone'=>'info','icon'=>'dashicons-visibility','hint'=>'نمونه اندازه‌گیری‌شده'),
                    array('label'=>'Mention rate','value'=>$samples?round(100*$mentions/$samples,1):null,'suffix'=>'%','tone'=>'info','icon'=>'dashicons-megaphone','hint'=>'بر اساس Observation'),
                    array('label'=>'Citation rate','value'=>$samples?round(100*$citations/$samples,1):null,'suffix'=>'%','tone'=>'success','icon'=>'dashicons-admin-links','hint'=>'بر اساس Observation'),
                    array('label'=>'Citation loss','value'=>count(array_filter($current,static fn($r)=>($r['change']??'')==='citation_loss')),'tone'=>'warning','icon'=>'dashicons-arrow-down-alt','hint'=>'در مقایسه با مشاهده قبلی'),
                    array('label'=>'Query فعال','value'=>count((array)($data['queries']??array())),'tone'=>'neutral','icon'=>'dashicons-search','hint'=>'Queryهای Observatory'),
                ) as $m)$metric_card($m); ?></section>
                <div class="k30-grid k30-grid-2-1">
                    <?php $card_open('AI Visibility Observatory','dashicons-visibility','', 'هیچ نتیجه AI ساخته یا حدس زده نمی‌شود؛ فقط Observation دارای source/evidence ذخیره می‌شود.'); ?><div class="k30-table-wrap tall"><table class="k30-table"><thead><tr><th>Query</th><th>Engine</th><th>Mention</th><th>Citation</th><th>Change</th><th>منبع</th></tr></thead><tbody><?php foreach($current as $row): ?><tr><td><?php echo esc_html((string)($row['query_text']??'')); ?></td><td><?php echo esc_html((string)($row['engine']??'')); ?></td><td><?php $status_pill(!empty($row['mentioned'])?'بله':'خیر',!empty($row['mentioned'])?'success':'neutral'); ?></td><td><?php $status_pill(!empty($row['cited'])?'بله':'خیر',!empty($row['cited'])?'success':'neutral'); ?></td><td><?php echo esc_html((string)($row['change']??'')); ?></td><td><?php if(!empty($row['source_url'])):?><a href="<?php echo esc_url($row['source_url']); ?>" target="_blank" rel="noopener">Evidence</a><?php else: ?>—<?php endif; ?></td></tr><?php endforeach; ?></tbody></table></div><?php if(!$current)$empty_state('هنوز Observation اندازه‌گیری‌شده‌ای نداریم','Query اضافه کنید و Observation را فقط از Collector معتبر وارد کنید.','dashicons-visibility'); $card_close(); ?>
                    <?php $card_open('افزودن Query پایش','dashicons-search','', 'ثبت Query به‌تنهایی امتیاز تولید نمی‌کند؛ تا Observation واقعی وارد نشود وضعیت Not measured است.'); ?><form class="k30-settings-form" data-visibility-query-form><label><span>Query</span><input name="query" required maxlength="500"></label><label><span>Locale</span><input name="locale" value="<?php echo esc_attr(determine_locale()); ?>"></label><label><span>Country</span><input name="country" maxlength="2" placeholder="IR"></label><button class="k30-button primary" type="submit">افزودن Query</button></form><?php $card_close(); ?>
                </div>

            <?php elseif ( 'setup-commercial' === $workspace ) : $on=(array)($data['onboarding']??array()); $lic=(array)($data['license']??array()); $diag=(array)($data['diagnostics']??array()); ?>
                <section class="k30-kpi-grid k30-kpi-grid-5"><?php foreach(array(
                    array('label'=>'Onboarding','value'=>$on['completed']??0,'suffix'=>'/'.(string)($on['total']??5),'tone'=>!empty($on['ready'])?'success':'warning','icon'=>'dashicons-welcome-learn-more','hint'=>'مراحل آماده‌سازی'),
                    array('label'=>'License','value'=>null,'tone'=>($lic['status']??'')==='active'?'success':'neutral','icon'=>'dashicons-lock','hint'=>(string)($lic['status']??'unconfigured')),
                    array('label'=>'Abilities','value'=>$diag['abilities']??0,'tone'=>'info','icon'=>'dashicons-admin-generic','hint'=>'قابلیت‌های ثبت‌شده'),
                    array('label'=>'DB','value'=>null,'tone'=>'success','icon'=>'dashicons-database','hint'=>(string)($diag['db_version']??K20AI_Database::DB_VERSION)),
                    array('label'=>'PHP','value'=>null,'tone'=>'success','icon'=>'dashicons-editor-code','hint'=>(string)($diag['php']??PHP_VERSION)),
                ) as $m)$metric_card($m); ?></section>
                <div class="k30-grid k30-grid-2-1">
                    <?php $card_open('Onboarding','dashicons-welcome-learn-more','', 'راه‌اندازی فقط state ذخیره می‌کند؛ Migration یا تغییر داده بدون تأیید جدا اجرا نمی‌شود.'); ?><div class="k30-action-history"><?php foreach((array)($on['steps']??array()) as $key=>$done): ?><div><span><?php echo esc_html(str_replace('_',' ',$key)); ?></span><?php $status_pill($done?'کامل':'باز',$done?'success':'warning'); ?></div><?php endforeach; ?></div><p><b>SEO source:</b> <?php echo esc_html((string)($on['state']['seo_source']??'—')); ?></p><?php $card_close(); ?>
                    <?php $card_open('License & Updates','dashicons-lock','', 'License service در این build فقط در صورت تعریف endpoint و Ed25519 public key فعال می‌شود؛ هیچ Secret فروشنده داخل افزونه وجود ندارد.'); ?><p><b>Status:</b> <?php echo esc_html((string)($lic['status']??'unconfigured')); ?></p><p><b>Plan:</b> <?php echo esc_html((string)($lic['plan']??'—')); ?></p><p><b>Expiry:</b> <?php echo esc_html((string)($lic['expires_at']??'—')); ?></p><form data-license-form class="k30-settings-form"><label><span>License key</span><input name="license_key" type="password" autocomplete="off"></label><button class="k30-button primary" type="submit">فعال‌سازی</button><button class="k30-button secondary" type="button" data-license-deactivate>غیرفعال‌سازی</button></form><?php $card_close(); ?>
                </div>
                <?php $card_open('Migration Tool','dashicons-migrate','', 'Preview → Backup → Import → Verify → Rollback. داده افزونه منبع حذف نمی‌شود.'); ?><form data-migration-preview class="k30-settings-form"><label><span>Source</span><select name="source"><option value="yoast">Yoast</option><option value="rank_math">Rank Math</option><option value="aioseo">AIOSEO</option><option value="seopress">SEOPress</option></select></label><button class="k30-button secondary" type="submit">پیش‌نمایش Migration</button></form><div data-migration-result></div><?php $card_close(); ?>
                <?php $card_open('Support Diagnostics','dashicons-sos','', 'این خروجی Secret/API key/License key را شامل نمی‌شود.'); ?><pre class="k30-code-block"><?php echo esc_html(wp_json_encode($diag,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)); ?></pre><?php $card_close(); ?>

            <?php elseif ( 'live-editor' === $workspace ) : $entity=(array)($data['entity']??array()); ?>
                <form class="k30-filter-bar k30-live-selector" method="get">
                    <input type="hidden" name="page" value="k20-ai-press"><input type="hidden" name="workspace" value="live-editor">
                    <label><span>نوع موجودیت</span><select name="kind"><?php foreach((array)($data['available_kinds']??array('product','content_post','page','news')) as $kind_opt): $kv=is_array($kind_opt)?($kind_opt['value']??''):$kind_opt; ?><option value="<?php echo esc_attr($kv); ?>" <?php selected((string)($data['selected']['kind']??'product'),(string)$kv); ?>><?php echo esc_html(is_array($kind_opt)?($kind_opt['label']??$kv):$kv); ?></option><?php endforeach; ?></select></label>
                    <label><span>جست‌وجوی محصول/محتوا</span><input name="entity_query" value="<?php echo esc_attr((string)($data['entity_query']??'')); ?>" placeholder="نام، عنوان یا بخشی از آن"></label>
                    <label><span>انتخاب موجودیت</span><select name="id"><option value="0">انتخاب خودکار</option><?php foreach((array)($data['entity_options']??array()) as $opt): $score=$opt['score_total']??null; ?><option value="<?php echo esc_attr($opt['id']); ?>" <?php selected((int)($entity['profile']['entity_id']??0),(int)$opt['id']); ?>><?php echo esc_html($opt['title'].' · '.(null===$score?'اندازه‌گیری‌نشده':((int)$score.'/100'))); ?></option><?php endforeach; ?></select></label>
                    <button class="k30-button secondary" type="submit"><span class="dashicons dashicons-search"></span> باز کردن</button>
                </form>
                <?php $render_pager((array)($data['entity_pagination']??array()),'entity_paged'); ?>
                <div class="k30-editor-shell">
                    <?php $card_open('ویرایشگر زنده سئو','dashicons-edit','k30-editor-card', 'تغییرات قبل از ثبت با همان Rule Engine سمت سرور پیش‌نمایش می‌شوند؛ ذخیره فقط با دکمه انجام می‌شود.'); ?>
                        <?php if(!$entity): $empty_state('موجودیتی انتخاب نشده است','از فهرست بالا یک محصول یا محتوا را انتخاب کنید.','dashicons-edit'); else: $e=$entity['evidence'];$p=$entity['profile']; ?>
                            <form class="k30-live-form" data-live-editor data-kind="<?php echo esc_attr($p['entity_kind']); ?>" data-id="<?php echo esc_attr($p['entity_id']); ?>">
                                <nav class="k30-editor-tabs" aria-label="میانبرهای ویرایش"><a class="is-active" href="<?php echo esc_url(admin_url('admin.php?page=k20-ai-press&workspace=live-editor&kind='.rawurlencode((string)$p['entity_kind']).'&id='.(int)$p['entity_id'])); ?>">محتوا و متا</a><a href="<?php echo esc_url(admin_url('admin.php?page=k20-ai-press&workspace=categories-links')); ?>">ساختار</a><a href="<?php echo esc_url(admin_url('admin.php?page=k20-ai-press&workspace=products')); ?>">محصول</a><a href="<?php echo esc_url(admin_url('admin.php?page=k20-ai-press&workspace=images-alt&id='.(int)$p['entity_id'].'&kind='.rawurlencode((string)$p['entity_kind']))); ?>">تصویر</a></nav>
                                <label><span>عنوان صفحه</span><input name="title" value="<?php echo esc_attr($e['title']??''); ?>"><small data-live-count="title"><?php echo esc_html(mb_strlen((string)($e['title']??''))); ?> نویسه</small></label>
                                <label><span>عنوان سئو</span><input name="seo_title" value="<?php echo esc_attr($e['seo_title']??''); ?>"><small data-live-count="seo_title"><?php echo esc_html(mb_strlen((string)($e['seo_title']??''))); ?> نویسه</small></label>
                                <label><span>توضیحات متا</span><textarea name="meta_description" rows="4"><?php echo esc_textarea($e['meta_description']??''); ?></textarea><small data-live-count="meta_description"><?php echo esc_html(mb_strlen((string)($e['meta_description']??''))); ?> نویسه</small></label>
                                <label><span>عبارت کلیدی اصلی</span><input name="focus_keyword" value="<?php echo esc_attr($e['focus_keyword']??''); ?>" placeholder="از داده و پژوهش واقعی انتخاب کنید"></label>
                                <?php if('product'===$p['entity_kind']): ?><div class="k30-form-grid"><label><span>SKU</span><input name="sku" value="<?php echo esc_attr($e['sku']??''); ?>"></label><label><span>GTIN واقعی</span><input name="gtin" value="<?php echo esc_attr($e['gtin']??''); ?>"></label><label><span>MPN</span><input name="mpn" value="<?php echo esc_attr($e['mpn']??''); ?>"></label><label><span>قیمت</span><input name="price" value="<?php echo esc_attr($e['price']??''); ?>"></label><label><span>وضعیت موجودی</span><select name="stock_status"><?php foreach((array)($entity['edit']['stock_statuses']??array()) as $opt): ?><option value="<?php echo esc_attr($opt['value']); ?>" <?php selected($e['stock_status']??'',$opt['value']); ?>><?php echo esc_html($opt['label']); ?></option><?php endforeach; ?></select></label><label><span>برند</span><select name="brand_id"><option value="">انتخاب برند</option><?php foreach((array)($entity['edit']['brands']??array()) as $opt): ?><option value="<?php echo esc_attr($opt['id']); ?>" <?php selected($e['brand']??'',$opt['label']); ?>><?php echo esc_html($opt['label']); ?></option><?php endforeach; ?></select></label></div><?php endif; ?>
                                <div class="k30-editor-actions"><button type="submit" class="k30-button primary"><span class="dashicons dashicons-saved"></span> ذخیره و تحلیل مجدد</button><button type="button" class="k30-button secondary" data-safe-fix-kind="<?php echo esc_attr($p['entity_kind']); ?>" data-safe-fix-id="<?php echo esc_attr($p['entity_id']); ?>"><span class="dashicons dashicons-superhero"></span> پیشنهاد اصلاح امن</button><span class="k30-live-preview-state" data-live-preview-state>پیش‌نمایش سرور آماده است</span></div>
                            </form>
                        <?php endif; ?>
                    <?php $card_close(); ?>
                    <aside class="k30-editor-aside">
                        <?php $card_open('تحلیل زنده','dashicons-chart-pie','', 'پس از هر تغییر، پیش‌نمایش بدون ذخیره از Rule Engine سمت سرور به‌روزرسانی می‌شود.'); ?><?php if($entity): ?><div class="k30-big-score <?php echo esc_attr($score_class($p['score_total'])); ?>" style="--score:<?php echo esc_attr((string)max(0,min(100,(int)$p['score_total']))); ?>" data-live-total><strong><?php echo esc_html($p['score_total']); ?></strong><span>از 100</span></div><div class="k30-score-bars" data-live-score-bars><?php foreach(array('technical'=>'فنی','content'=>'محتوا','schema'=>'اسکیما','media'=>'رسانه','commerce'=>'تجارت') as $key=>$label): $v=(int)$p['score_'.$key]; ?><div data-score-key="<?php echo esc_attr($key); ?>"><span><?php echo esc_html($label); ?></span><i><b style="width:<?php echo esc_attr($v); ?>%"></b></i><strong><?php echo esc_html($v); ?></strong></div><?php endforeach; ?></div><?php endif; ?><?php $card_close(); ?>
                        <?php $card_open('راهنمای رفع ایراد','dashicons-lightbulb','', 'هر موردی که در پیش‌نمایش سرور رفع شود، پیش از ثبت از این کادر حذف می‌شود.'); ?><div class="k30-issue-list" data-live-issue-list><?php foreach((array)($entity['issues']??array()) as $issue): ?><article class="<?php echo esc_attr($issue_tone($issue['severity'])); ?>"><span class="dashicons dashicons-<?php echo $issue['severity']==='critical'?'dismiss':'warning'; ?>"></span><div><b><?php echo esc_html($issue['title']); ?></b><small><?php echo esc_html($issue['description']); ?></small></div></article><?php endforeach; ?></div><?php $card_close(); ?>
                    </aside>
                </div>
                <?php if($entity): ?>
                    <?php $card_open('جست‌وجوی زنده گوگل و پیشنهاد کلمات مرتبط','dashicons-google','', 'نتایج زنده فقط از Provider معتبر SERP نمایش داده می‌شوند؛ رتبه تاریخی Search Console جدا نگه داشته می‌شود.'); ?>
                    <form class="k30-serp-live-form" data-live-serp data-kind="<?php echo esc_attr($p['entity_kind']); ?>" data-id="<?php echo esc_attr($p['entity_id']); ?>"><label><span>عبارت جست‌وجو</span><input name="query" maxlength="180" required value="<?php echo esc_attr(($e['focus_keyword']??'') ?: ($e['title']??'')); ?>"></label><button class="k30-button primary" type="submit"><span class="dashicons dashicons-search"></span> جست‌وجوی زنده</button><a class="k30-button secondary" href="<?php echo esc_url(admin_url('admin.php?page=k20-ai-press&workspace=connections')); ?>">مرکز اتصال</a></form>
                    <div class="k30-live-serp-result" data-live-serp-result><p class="k30-note">برای نمایش نتیجه واقعی باید SerpApi در مرکز اتصال متصل باشد. در نبود Provider هیچ نتیجه یا رتبه‌ای ساخته نمی‌شود.</p></div>
                    <?php $card_close(); ?>
                <?php endif; ?>

            <?php elseif ( 'market-radar' === $workspace ) : ?>
                <section class="k30-kpi-grid k30-kpi-grid-4"><?php foreach(array(
                    array('label'=>'RSSهای متصل','value'=>$data['source_count']??0,'tone'=>($data['source_count']??0)?'success':'warning','icon'=>'dashicons-rss','hint'=>'منابع تنظیم‌شده'),
                    array('label'=>'سیگنال بیرونی ذخیره‌شده','value'=>count((array)($data['signals']??array())),'tone'=>'info','icon'=>'dashicons-megaphone','hint'=>'با URL و زمان مشاهده'),
                    array('label'=>'سیگنال داخلی','value'=>count((array)($data['local']??array())),'tone'=>'success','icon'=>'dashicons-chart-area','hint'=>'موجودی و محتوای سایت'),
                    array('label'=>'رقبای فعال','value'=>count((array)($data['competitors']??array())),'tone'=>'info','icon'=>'dashicons-groups','hint'=>'دامنه‌های ثبت‌شده'),
                ) as $m)$metric_card($m); ?></section>
                <div class="k30-grid k30-grid-2-1">
                    <?php $card_open('رادار خبر و بازار','dashicons-megaphone','', 'فقط RSSهای تنظیم‌شده و سیگنال‌های واقعی سایت خوانده می‌شوند. خبر ساختگی تولید نمی‌شود.'); ?><div class="k30-signal-list"><?php foreach(array_merge((array)($data['signals']??array()),(array)($data['local']??array())) as $signal): ?><article><div class="k30-signal-icon"><span class="dashicons <?php echo ($signal['signal_type']??$signal['type']??'')==='news'?'dashicons-megaphone':'dashicons-chart-area'; ?>"></span></div><div><strong><?php echo esc_html($signal['subject']??$signal['title']??''); ?></strong><small><?php echo esc_html($signal['source']??$signal['type']??'local'); ?> · <?php echo esc_html($short_date($signal['observed_at']??'')); ?></small></div><?php if(!empty($signal['source_url'])||!empty($signal['url'])):?><a href="<?php echo esc_url($signal['source_url']??$signal['url']); ?>" target="_blank" rel="noopener">منبع</a><?php endif; ?></article><?php endforeach; ?></div><?php $card_close(); ?>
                    <?php $card_open('مدیریت منابع','dashicons-rss','', 'برای هر منبع RSS URL معتبر در تنظیمات وارد کنید.'); ?><p class="k30-note"><?php echo esc_html($data['note']??''); ?></p><button class="k30-button primary full" data-radar-refresh><span class="dashicons dashicons-update"></span> به‌روزرسانی رادار</button><a class="k30-button secondary full" href="<?php echo esc_url(admin_url('admin.php?page=k20-ai-press&workspace=settings')); ?>">مدیریت RSSها</a><?php $card_close(); ?>
                </div>

            <?php elseif ( 'content-engines' === $workspace ) :
                $engine_profile = (array) ( $data['profile'] ?? array() );
                $engine_rows = (array) ( $data['engines'] ?? array() );
                $engine_runs = (array) ( $data['runs'] ?? array() );
                $engine_settings = (array) ( $data['settings'] ?? array() );
                $ready_count = count( array_filter( $engine_rows, static fn( $row ) => ! empty( $row['ready'] ) ) );
                $enabled_count = count( array_filter( $engine_rows, static fn( $row ) => ! empty( $row['enabled'] ) ) );
                $completed_count = count( array_filter( $engine_runs, static fn( $row ) => 'completed' === (string) ( $row['status'] ?? '' ) ) );
                $failed_count = count( array_filter( $engine_runs, static fn( $row ) => in_array( (string) ( $row['status'] ?? '' ), array( 'failed','error' ), true ) ) );
            ?>
                <section class="k30-kpi-grid k30-kpi-grid-4">
                    <?php foreach ( array(
                        array('label'=>$tr('موتورهای فعال','Enabled engines'),'value'=>$enabled_count,'tone'=>$enabled_count?'success':'warning','icon'=>'dashicons-controls-play','hint'=>$tr('خبر و مقاله مستقل','Independent News + Article')),
                        array('label'=>$tr('آماده اجرا','Ready to run'),'value'=>$ready_count,'tone'=>$ready_count===2?'success':'warning','icon'=>'dashicons-yes-alt','hint'=>$tr('Provider یا GitHub معتبر','Verified provider or GitHub')),
                        array('label'=>$tr('اجرای موفق','Successful runs'),'value'=>$completed_count,'tone'=>'success','icon'=>'dashicons-saved','hint'=>$tr('تاریخچه واقعی موتور','Real engine history')),
                        array('label'=>$tr('اجرای ناموفق','Failed runs'),'value'=>$failed_count,'tone'=>$failed_count?'danger':'success','icon'=>'dashicons-warning','hint'=>$tr('خطاها مخفی نمی‌شوند','Errors are never hidden')),
                    ) as $m ) $metric_card($m); ?>
                </section>
                <div class="k30-engine-hero">
                    <div class="k30-engine-hero-copy"><span class="dashicons dashicons-superhero-alt"></span><div><strong><?php echo esc_html( $tr( 'موتور محتوای کسب‌وکارمحور', 'Business-aware Content Engine' ) ); ?></strong><p><?php echo esc_html( $tr( 'موضوع سایت از داده واقعی WordPress/WooCommerce، دسته‌ها، محصولات و محتوای اخیر ساخته می‌شود؛ موتور هیچ حوزه‌ای را از قبل فرض نمی‌کند.', 'The site domain is inferred from real WordPress/WooCommerce categories, products and recent content. No industry is hard-coded.' ) ); ?></p></div></div>
                    <div class="k30-engine-mode"><span><?php echo esc_html( $tr( 'حوزه تشخیص‌داده‌شده', 'Detected business context' ) ); ?></span><b><?php echo esc_html( (string) ( $engine_profile['summary'] ?? $engine_profile['site_name'] ?? $site_name ) ); ?></b><small><?php echo ! empty( $engine_profile['sensitive_domain'] ) ? esc_html( $tr( 'حوزه حساس: بازبینی انسانی اجباری', 'Sensitive domain: human review required' ) ) : esc_html( $tr( 'انتشار فقط به‌صورت پیش‌نویس/در انتظار بازبینی', 'Draft/pending output with human review' ) ); ?></small></div>
                </div>
                <form class="k30-engine-settings" data-content-engine-settings>
                    <div class="k30-engine-globalbar"><label><span><?php echo esc_html( $tr( 'فعال‌سازی خودکار بعد از اتصال معتبر', 'Auto-enable after a verified connection' ) ); ?></span><input type="checkbox" name="auto_enable_on_ready" <?php checked( ! empty( $engine_settings['auto_enable_on_ready'] ) ); ?>></label><label><span><?php echo esc_html( $tr( 'Runner پیش‌فرض', 'Default runner' ) ); ?></span><select name="default_runner"><option value="auto" <?php selected((string)($engine_settings['default_runner']??'auto'),'auto'); ?>>Auto</option><option value="local" <?php selected((string)($engine_settings['default_runner']??''),'local'); ?>>Local WordPress</option><option value="github" <?php selected((string)($engine_settings['default_runner']??''),'github'); ?>>GitHub Actions</option></select></label><button class="k30-button primary" type="submit"><span class="dashicons dashicons-saved"></span><?php echo esc_html( $tr( 'ذخیره تنظیمات موتور', 'Save engine settings' ) ); ?></button></div>
                    <div class="k30-engine-config-grid">
                    <?php foreach ( array( 'news' => array( 'fa'=>'موتور خبر','en'=>'News Engine','icon'=>'megaphone' ), 'article' => array( 'fa'=>'موتور نوشته','en'=>'Article Engine','icon'=>'media-document' ) ) as $engine_key => $engine_label ) : $row=(array)($engine_rows[$engine_key]??array()); $cfg=(array)($engine_settings[$engine_key]??array()); ?>
                        <article class="k30-engine-config <?php echo !empty($row['ready'])?'is-ready':'is-waiting'; ?>" data-engine-card="<?php echo esc_attr($engine_key); ?>">
                            <header><div class="k30-engine-title"><span class="dashicons dashicons-<?php echo esc_attr($engine_label['icon']); ?>"></span><div><strong><?php echo esc_html( 'en'===$ui_language?$engine_label['en']:$engine_label['fa'] ); ?></strong><small><?php echo esc_html( strtoupper((string)($row['runner']??'local')).' · '.((string)($row['provider']??'')?:'NO AI PROVIDER') ); ?></small></div></div><?php $status_pill(!empty($row['ready'])?$tr('آماده','Ready'):$tr('نیازمند اتصال','Needs connection'),!empty($row['ready'])?'success':'warning'); ?></header>
                            <div class="k30-engine-fields">
                                <label class="is-switch"><span><?php echo esc_html($tr('فعال','Enabled')); ?></span><input type="checkbox" name="<?php echo esc_attr($engine_key); ?>[enabled]" <?php checked(!empty($cfg['enabled'])); ?>></label>
                                <label><span><?php echo esc_html($tr('ساعت روزانه','Daily time')); ?></span><input type="time" name="<?php echo esc_attr($engine_key); ?>[time]" value="<?php echo esc_attr((string)($cfg['time']??'')); ?>"></label>
                                <label><span>Runner</span><select name="<?php echo esc_attr($engine_key); ?>[runner]"><option value="auto" <?php selected((string)($cfg['runner']??'auto'),'auto'); ?>>Auto</option><option value="local" <?php selected((string)($cfg['runner']??''),'local'); ?>>Local</option><option value="github" <?php selected((string)($cfg['runner']??''),'github'); ?>>GitHub</option></select></label>
                                <label><span><?php echo esc_html($tr('Provider هوش مصنوعی','AI provider')); ?></span><input type="text" name="<?php echo esc_attr($engine_key); ?>[provider]" value="<?php echo esc_attr((string)($cfg['provider']??'auto')); ?>" placeholder="auto / openai / gemini / ..."></label>
                                <label class="wide"><span><?php echo esc_html($tr('Workflow گیت‌هاب (اختیاری)','GitHub workflow (optional)')); ?></span><input type="text" name="<?php echo esc_attr($engine_key); ?>[workflow]" value="<?php echo esc_attr((string)($cfg['workflow']??'')); ?>" placeholder="workflow.yml"></label>
                                <label><span><?php echo esc_html($tr('نوع نوشته مقصد','Target post type')); ?></span><input type="text" name="<?php echo esc_attr($engine_key); ?>[post_type]" value="<?php echo esc_attr((string)($cfg['post_type']??($engine_key==='news'?'auto':'post'))); ?>"></label>
                                <label><span><?php echo esc_html($tr('وضعیت خروجی','Output status')); ?></span><select name="<?php echo esc_attr($engine_key); ?>[status]"><option value="draft" <?php selected((string)($cfg['status']??'draft'),'draft'); ?>>Draft</option><option value="pending" <?php selected((string)($cfg['status']??''),'pending'); ?>>Pending review</option></select></label>
                                <label><span><?php echo esc_html($tr('بازه تحقیق (ساعت)','Research lookback (hours)')); ?></span><input type="number" min="1" max="720" name="<?php echo esc_attr($engine_key); ?>[lookback_hours]" value="<?php echo esc_attr((string)($cfg['lookback_hours']??24)); ?>"></label>
                                <label class="is-switch"><span><?php echo esc_html($tr('تحقیق وب','Web research')); ?></span><input type="checkbox" name="<?php echo esc_attr($engine_key); ?>[web_research]" <?php checked(!empty($cfg['web_research'])); ?>></label>
                            </div>
                            <footer><div><span><?php echo esc_html($tr('اجرای بعدی','Next run')); ?></span><b><?php echo !empty($row['next_run'])?esc_html(wp_date('Y/m/d H:i',(int)$row['next_run'])):'—'; ?></b></div><div><span><?php echo esc_html($tr('مقصد','Target')); ?></span><b><?php echo esc_html((string)($row['post_type']??'post')); ?></b></div><button type="button" class="k30-button secondary" data-engine-run="<?php echo esc_attr($engine_key); ?>" <?php disabled(empty($row['ready'])); ?>><span class="dashicons dashicons-controls-play"></span><?php echo esc_html($tr('اجرای اکنون','Run now')); ?></button></footer>
                        </article>
                    <?php endforeach; ?>
                    </div>
                </form>
                <div class="k30-grid k30-grid-2-1">
                    <?php $card_open($tr('پروفایل واقعی کسب‌وکار','Live business profile'),'dashicons-store','', $tr('این داده‌ها از همین سایت خوانده می‌شوند و پایه انتخاب موضوع‌اند.','These values are read from this site and drive topic selection.')); ?>
                        <div class="k30-profile-facts"><div><span><?php echo esc_html($tr('سایت','Site')); ?></span><b><?php echo esc_html((string)($engine_profile['site_name']??$site_name)); ?></b></div><div><span><?php echo esc_html($tr('زبان/Locale','Locale')); ?></span><b><?php echo esc_html((string)($engine_profile['locale']??determine_locale())); ?></b></div><div><span><?php echo esc_html($tr('دسته محصول','Product categories')); ?></span><b><?php echo esc_html(count((array)($engine_profile['product_categories']??array()))); ?></b></div><div><span><?php echo esc_html($tr('نمونه محصول','Product samples')); ?></span><b><?php echo esc_html(count((array)($engine_profile['sample_products']??array()))); ?></b></div></div>
                        <div class="k30-chip-cloud"><?php foreach(array_slice((array)($engine_profile['product_categories']??array()),0,12) as $cat): ?><span><?php echo esc_html((string)($cat['name']??'')); ?></span><?php endforeach; ?><?php foreach(array_slice((array)($engine_profile['post_categories']??array()),0,8) as $cat): ?><span><?php echo esc_html((string)($cat['name']??'')); ?></span><?php endforeach; ?></div>
                    <?php $card_close(); ?>
                    <?php $card_open($tr('وابستگی‌ها و ایمنی','Dependencies & safety'),'dashicons-shield-alt','', $tr('موتور بدون Provider معتبر یا Workflow معتبر اجرا نمی‌شود.','The engine stays fail-closed without a valid provider or workflow.')); ?><div class="k30-engine-deps"><article><span class="k30-status-dot <?php echo !empty($data['ai_providers'])?'success':'warning'; ?>"></span><div><b>AI Provider</b><small><?php echo esc_html(count((array)($data['ai_providers']??array())).' '.$tr('متصل','connected')); ?></small></div></article><article><span class="k30-status-dot <?php echo 'connected'===(string)($data['github']['status']??'')?'success':'warning'; ?>"></span><div><b>GitHub</b><small><?php echo esc_html((string)($data['github']['repository']??'')?:$tr('اختیاری / متصل نیست','Optional / not connected')); ?></small></div></article><article><span class="k30-status-dot success"></span><div><b><?php echo esc_html($tr('بازبینی انسانی','Human review')); ?></b><small><?php echo esc_html($tr('اجباری پیش از انتشار عمومی','Required before public publishing')); ?></small></div></article></div><?php $card_close(); ?>
                </div>
                <?php $card_open($tr('تاریخچه اجرا و شواهد','Run history & evidence'),'dashicons-backup','', $tr('هر اجرا منبع، Provider، خروجی و خطا را ثبت می‌کند.','Every run records sources, provider, output and errors.')); ?>
                    <?php if(empty($engine_runs)): $empty_state($tr('هنوز اجرایی ثبت نشده','No runs recorded yet'),$tr('بعد از اجرای موتور، موضوع، منابع، خروجی و خطاهای واقعی اینجا نمایش داده می‌شود.','After a run, its topic, sources, output and real errors appear here.'),'dashicons-backup'); else: ?><div class="k30-table-wrap tall"><table class="k30-table"><thead><tr><th><?php echo esc_html($tr('زمان','Time')); ?></th><th><?php echo esc_html($tr('موتور','Engine')); ?></th><th>Runner</th><th><?php echo esc_html($tr('وضعیت','Status')); ?></th><th><?php echo esc_html($tr('موضوع/خروجی','Topic / output')); ?></th><th><?php echo esc_html($tr('منابع','Sources')); ?></th><th><?php echo esc_html($tr('نتیجه','Result')); ?></th></tr></thead><tbody><?php foreach($engine_runs as $run): $rtone=$tone_from_status((string)($run['status']??'')); ?><tr><td><?php echo esc_html($short_date($run['created_at']??'')); ?></td><td><strong><?php echo esc_html((string)($run['engine']??'')); ?></strong><small><?php echo esc_html((string)($run['provider']??'')); ?></small></td><td><?php echo esc_html((string)($run['runner']??'')); ?></td><td><?php $status_pill((string)($run['status']??''),$rtone); ?></td><td><strong><?php echo esc_html((string)($run['topic']??'—')); ?></strong><?php if(!empty($run['post_id'])):?><small>#<?php echo esc_html((string)$run['post_id']); ?></small><?php endif; ?></td><td><button class="k30-mini-button" type="button" data-engine-sources='<?php echo esc_attr(wp_json_encode((array)($run['sources']??array()),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)); ?>'><?php echo esc_html((string)($run['source_count']??count((array)($run['sources']??array())))); ?> <?php echo esc_html($tr('منبع','sources')); ?></button></td><td><?php if(!empty($run['error'])):?><span class="k30-engine-error"><?php echo esc_html((string)$run['error']); ?></span><?php elseif(!empty($run['post_id'])):?><a class="k30-mini-button" href="<?php echo esc_url(get_edit_post_link((int)$run['post_id'])); ?>"><?php echo esc_html($tr('باز کردن پیش‌نویس','Open draft')); ?></a><?php else: ?>—<?php endif; ?></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?>
                <?php $card_close(); ?>

            <?php elseif ( 'reports' === $workspace ) : $summary=$data['summary']??array(); ?>
                <section class="k30-kpi-grid k30-kpi-grid-5"><?php foreach(array(
                    array('label'=>'سلامت کل','value'=>$summary['health']['score']??null,'suffix'=>'/100','tone'=>$score_class($summary['health']['score']??null),'icon'=>'dashicons-heart','hint'=>'میانگین موجودیت‌ها'),
                    array('label'=>'Issue باز','value'=>$summary['issues']['open']??0,'tone'=>($summary['issues']['critical']??0)?'danger':'warning','icon'=>'dashicons-warning','hint'=>($summary['issues']['critical']??0).' بحرانی'),
                    array('label'=>'Recommendation باز','value'=>$summary['recommendations']['open']??0,'tone'=>'info','icon'=>'dashicons-lightbulb','hint'=>'پیشنهادهای اولویت‌دار'),
                    array('label'=>'Action منتظر تأیید','value'=>$summary['actions']['proposed']??0,'tone'=>'warning','icon'=>'dashicons-clock','hint'=>'Governance queue'),
                    array('label'=>'موجودیت تحلیل‌شده','value'=>$summary['health']['analyzed']??0,'tone'=>'success','icon'=>'dashicons-database','hint'=>'پوشش فعلی'),
                ) as $m)$metric_card($m); ?></section>
                <div class="k30-grid k30-grid-2-1">
                    <?php $card_open('گزارش عملکرد به تفکیک نوع','dashicons-chart-bar','', 'میانگین هر مؤلفه از Profileهای واقعی ذخیره‌شده محاسبه می‌شود.'); ?><div class="k30-table-wrap"><table class="k30-table"><thead><tr><th>نوع</th><th>تعداد</th><th>کل</th><th>فنی</th><th>محتوا</th><th>اسکیما</th><th>رسانه</th><th>تجارت</th></tr></thead><tbody><?php foreach((array)($data['by_kind']??array()) as $row): ?><tr><td><strong><?php echo esc_html($row['entity_kind']); ?></strong></td><td><?php echo esc_html($num($row['total'])); ?></td><?php foreach(array('avg_score','technical','content','schema','media','commerce') as $key): ?><td><span class="k30-score <?php echo esc_attr($score_class($row[$key])); ?>"><?php echo esc_html($row[$key]); ?></span></td><?php endforeach; ?></tr><?php endforeach; ?></tbody></table></div><?php $card_close(); ?>
                    <?php $card_open('سازنده خروجی','dashicons-media-document','', 'CSV/JSON مستقیم از دیتابیس افزونه تولید می‌شود؛ PDF با Print view مرورگر تهیه می‌شود.'); ?><div class="k30-report-actions"><button data-export-format="csv"><span class="dashicons dashicons-media-spreadsheet"></span><b>CSV</b><small>برای Excel و تحلیل</small></button><button data-export-format="json"><span class="dashicons dashicons-editor-code"></span><b>JSON</b><small>برای API و آرشیو</small></button><button onclick="window.print()"><span class="dashicons dashicons-pdf"></span><b>PDF / Print</b><small>نمای چاپی بهینه</small></button></div><?php $card_close(); ?>
                </div>
                <?php $card_open('پرتکرارترین مشکلات','dashicons-list-view','', 'تعداد Issueهای باز به تفکیک Rule code.'); ?><div class="k30-table-wrap"><table class="k30-table"><thead><tr><th>Rule</th><th>شدت</th><th>Component</th><th>تعداد</th></tr></thead><tbody><?php foreach((array)($data['top_issues']??array()) as $row): ?><tr><td><code><?php echo esc_html($row['rule_code']); ?></code></td><td><?php $status_pill($row['severity'],$issue_tone($row['severity'])); ?></td><td><?php echo esc_html($row['component']); ?></td><td><strong><?php echo esc_html($num($row['total'])); ?></strong></td></tr><?php endforeach; ?></tbody></table></div><?php $card_close(); ?>

            <?php elseif ( 'connections' === $workspace ) : ?>
                <?php
                $connection_rows = (array) ( $data['connections'] ?? array() );
                $connection_groups = (array) ( $data['groups'] ?? array() );
                $connected_count = count( array_filter( $connection_rows, static fn( $row ) => 'connected' === (string) ( $row['status'] ?? '' ) ) );
                $ai_count = count( array_filter( $connection_rows, static fn( $row ) => 'ai' === (string) ( $row['category'] ?? '' ) && 'connected' === (string) ( $row['status'] ?? '' ) ) );
                $data_count = count( array_filter( $connection_rows, static fn( $row ) => 'data' === (string) ( $row['category'] ?? '' ) && 'connected' === (string) ( $row['status'] ?? '' ) ) );
                ?>
                <section class="k30-kpi-grid k30-kpi-grid-4">
                    <?php foreach(array(
                        array('label'=>'اتصال‌های تست‌شده','value'=>$connected_count,'tone'=>$connected_count?'success':'warning','icon'=>'dashicons-admin-links','hint'=>'فقط بعد از Live Test موفق Connected می‌شود'),
                        array('label'=>'منابع داده متصل','value'=>$data_count,'tone'=>$data_count?'success':'warning','icon'=>'dashicons-database','hint'=>'Google / Bing / PageSpeed'),
                        array('label'=>'موتور AI متصل','value'=>$ai_count,'tone'=>$ai_count?'success':'warning','icon'=>'dashicons-superhero-alt','hint'=>'برای «تکمیل با AI» حداقل یک Provider لازم است'),
                        array('label'=>'ذخیره امن Secrets','value'=>!empty($data['security']['encrypted_at_rest'])?1:0,'tone'=>'success','icon'=>'dashicons-lock','hint'=>'Credentialها به مرورگر برگردانده نمی‌شوند'),
                    ) as $m)$metric_card($m); ?>
                </section>
                <div class="k30-connection-hero">
                    <div><span class="dashicons dashicons-admin-links"></span><div><strong><?php echo esc_html( $tr( 'مرکز اتصال سیستم', 'System Connection Center' ) ); ?></strong><p><?php echo esc_html( $tr( 'داده‌های جست‌وجو، تحلیل، کد و موتورهای AI از اینجا با تست زنده، همگام‌سازی و خطای واقعی مدیریت می‌شوند.', 'Manage search data, analytics, code delivery and AI engines here with live tests, sync and real error reporting.' ) ); ?></p></div></div>
                    <div class="k30-connection-guard"><span class="dashicons dashicons-shield-alt"></span><div><b>Fail-closed</b><small><?php echo esc_html( $tr( 'تا API واقعاً پاسخ موفق ندهد، اتصال سبز نمی‌شود.', 'A connection never turns green until the API returns a verified successful response.' ) ); ?></small></div></div>
                </div>
                <div class="k30-section-heading"><div><h2><?php echo esc_html( $tr( 'هسته‌های محلی سایت', 'Local site cores' ) ); ?></h2><p><?php echo esc_html( $tr( 'WordPress، WooCommerce، Yoast، Bridge 3.3 و IndexNow؛ بدون ارسال Secret به مرورگر.', 'WordPress, WooCommerce, Yoast, Bridge 3.3 and IndexNow — without exposing secrets to the browser.' ) ); ?></p></div></div>
                <div class="k30-local-connection-grid">
                    <?php foreach ( (array) ( $data['local_integrations'] ?? array() ) as $local ) : $ltone=$tone_from_status((string)($local['status']??'')); ?><article><span class="k30-status-dot <?php echo esc_attr($ltone); ?>"></span><div><strong><?php echo esc_html((string)$local['label']); ?></strong><small><?php echo esc_html((string)($local['detail']?:$local['status'])); ?></small></div><?php $status_pill((string)$local['status'],$ltone); ?></article><?php endforeach; ?>
                </div>
                <?php $connection_group_en = array( 'data'=>array('label'=>'Data & Search','description'=>'Search Console, GA4, Merchant, Bing and PageSpeed'), 'ai'=>array('label'=>'AI engines','description'=>'Verified providers for analysis and AI completion'), 'delivery'=>array('label'=>'Code & Delivery','description'=>'GitHub Repository and Actions runners') ); ?>
                <?php foreach ( array( 'data','ai','delivery' ) as $connection_group_key ) : $group_info = $connection_groups[ $connection_group_key ] ?? array(); $group_en = $connection_group_en[ $connection_group_key ] ?? array(); ?>
                    <div class="k30-section-heading"><div><h2><?php echo esc_html( 'en' === $ui_language ? (string)($group_en['label']??$connection_group_key) : (string)($group_info['label']??$connection_group_key) ); ?></h2><p><?php echo esc_html( 'en' === $ui_language ? (string)($group_en['description']??'') : (string)($group_info['description']??'') ); ?></p></div></div>
                    <div class="k30-connection-grid">
                        <?php foreach ( $connection_rows as $connection ) : if ( $connection_group_key !== (string) ( $connection['category'] ?? '' ) ) continue; $ctone = $tone_from_status( (string) ( $connection['status'] ?? 'disconnected' ) ); ?>
                            <article class="k30-connection-card <?php echo esc_attr( $ctone ); ?>" data-connection-card="<?php echo esc_attr( (string) $connection['key'] ); ?>">
                                <header>
                                    <div class="k30-connection-icon"><span class="dashicons dashicons-<?php echo esc_attr( (string) ( $connection['icon'] ?? 'admin-links' ) ); ?>"></span></div>
                                    <div class="k30-connection-copy"><div><strong><?php echo esc_html( (string) $connection['label'] ); ?></strong><?php $status_pill( (string) $connection['status'], $ctone ); ?></div><p><?php echo esc_html( (string) $connection['description'] ); ?></p></div>
                                </header>
                                <form class="k30-connection-form" data-connection-form="<?php echo esc_attr( (string) $connection['key'] ); ?>">
                                    <div class="k30-connection-fields">
                                        <?php foreach ( (array) ( $connection['fields'] ?? array() ) as $field ) : ?>
                                            <label class="<?php echo 'checkbox' === (string) $field['type'] ? 'is-checkbox' : ''; ?>">
                                                <span><?php echo esc_html( (string) $field['label'] ); ?><?php if ( ! empty( $field['configured'] ) ) : ?><em><?php echo esc_html( $tr( 'ثبت شده', 'Saved' ) ); ?></em><?php endif; ?></span>
                                                <?php if ( 'checkbox' === (string) $field['type'] ) : ?>
                                                    <input type="checkbox" name="<?php echo esc_attr( (string) $field['key'] ); ?>" value="1" <?php checked( ! empty( $field['value'] ) ); ?>>
                                                <?php elseif ( ! empty( $field['options'] ) && empty( $field['secret'] ) ) : ?>
                                                    <select name="<?php echo esc_attr( (string) $field['key'] ); ?>">
                                                        <option value=""><?php echo esc_html( $tr( 'انتخاب کنید', 'Select' ) ); ?></option>
                                                        <?php if ( '' !== (string) $field['value'] && ! in_array( (string) $field['value'], array_column( (array) $field['options'], 'value' ), true ) ) : ?><option value="<?php echo esc_attr( (string) $field['value'] ); ?>" selected><?php echo esc_html( (string) $field['value'] ); ?></option><?php endif; ?>
                                                        <?php foreach ( (array) $field['options'] as $option ) : ?><option value="<?php echo esc_attr( (string) $option['value'] ); ?>" <?php selected( (string) $field['value'], (string) $option['value'] ); ?>><?php echo esc_html( (string) $option['label'] ); ?></option><?php endforeach; ?>
                                                    </select>
                                                <?php else : ?>
                                                    <input type="<?php echo ! empty( $field['secret'] ) ? 'password' : 'text'; ?>" name="<?php echo esc_attr( (string) $field['key'] ); ?>" value="<?php echo ! empty( $field['secret'] ) ? '' : esc_attr( (string) $field['value'] ); ?>" placeholder="<?php echo ! empty( $field['secret'] ) && ! empty( $field['configured'] ) ? $tr( '•••••••• (بدون تغییر نگه دارید)', '•••••••• (leave unchanged)' ) : ''; ?>" autocomplete="off">
                                                <?php endif; ?>
                                            </label>
                                        <?php endforeach; ?>
                                    </div>
                                    <?php if ( ! empty( $connection['requirements'] ) ) : ?><details class="k30-connection-requirements"><summary><?php echo esc_html( $tr( 'پیش‌نیازهای اتصال', 'Connection requirements' ) ); ?></summary><ul><?php foreach ( (array) $connection['requirements'] as $requirement ) : ?><li><?php echo esc_html( (string) $requirement ); ?></li><?php endforeach; ?></ul></details><?php endif; ?>
                                    <?php if ( ! empty( $connection['redirect_uri'] ) ) : ?><div class="k30-oauth-uri"><span><?php echo esc_html( $tr( 'Redirect URI برای ثبت در Provider', 'Redirect URI to register with the provider' ) ); ?></span><code><?php echo esc_html( (string) $connection['redirect_uri'] ); ?></code></div><?php endif; ?>
                                    <?php if ( ! empty( $connection['note'] ) ) : ?><p class="k30-connection-note"><span class="dashicons dashicons-info-outline"></span><?php echo esc_html( (string) $connection['note'] ); ?></p><?php endif; ?>
                                    <?php if ( ! empty( $connection['last_error'] ) ) : ?><p class="k30-connection-error"><span class="dashicons dashicons-warning"></span><?php echo esc_html( (string) $connection['last_error'] ); ?></p><?php endif; ?>
                                    <div class="k30-connection-meta"><span><?php echo esc_html( $tr( 'آخرین تست:', 'Last test:' ) ); ?> <b><?php echo esc_html( $short_date( $connection['last_test_at'] ?? null ) ); ?></b></span><span><?php echo esc_html( $tr( 'آخرین Sync:', 'Last sync:' ) ); ?> <b><?php echo esc_html( $short_date( $connection['last_sync_at'] ?? null ) ); ?></b></span></div>
                                    <div class="k30-connection-actions">
                                        <button class="k30-button primary" type="submit"><span class="dashicons dashicons-saved"></span> <?php echo esc_html( $tr( 'ذخیره', 'Save' ) ); ?></button>
                                        <button class="k30-button secondary" type="button" data-connection-test="<?php echo esc_attr( (string) $connection['key'] ); ?>"><span class="dashicons dashicons-yes-alt"></span> <?php echo esc_html( $tr( 'تست اتصال', 'Test connection' ) ); ?></button>
                                        <?php if ( in_array( (string) $connection['key'], array( 'google','bing','pagespeed' ), true ) ) : ?><button class="k30-button secondary" type="button" data-connection-sync="<?php echo esc_attr( (string) $connection['key'] ); ?>"><span class="dashicons dashicons-update"></span> Sync</button><?php endif; ?>
                                        <?php if ( ! empty( $connection['oauth_url'] ) ) : ?><a class="k30-button secondary" href="<?php echo esc_url( (string) $connection['oauth_url'] ); ?>"><span class="dashicons dashicons-admin-users"></span> <?php echo esc_html( $tr( 'اتصال OAuth', 'Connect OAuth' ) ); ?></a><?php endif; ?>
                                        <?php if ( 'github' === (string) $connection['key'] && 'connected' === (string) $connection['status'] ) : ?><button class="k30-button secondary" type="button" data-github-dispatch><span class="dashicons dashicons-controls-play"></span> <?php echo esc_html( $tr( 'اجرای Workflow', 'Run Workflow' ) ); ?></button><?php endif; ?>
                                        <button class="k30-button ghost danger" type="button" data-connection-disconnect="<?php echo esc_attr( (string) $connection['key'] ); ?>"><span class="dashicons dashicons-dismiss"></span> <?php echo esc_html( $tr( 'قطع', 'Disconnect' ) ); ?></button>
                                    </div>
                                </form>
                                <?php $discovery = (array) ( $connection['meta']['discovery'] ?? array() ); if ( $discovery ) : ?>
                                    <details class="k30-connection-discovery"><summary><?php echo esc_html( $tr( 'نتیجه آخرین تست / منابع کشف‌شده', 'Latest test / discovered resources' ) ); ?></summary><pre><?php echo esc_html( wp_json_encode( $discovery, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT ) ); ?></pre></details>
                                <?php endif; ?>
                            </article>
                        <?php endforeach; ?>
                    </div>
                <?php endforeach; ?>
                <?php $bridge_contract=(array)($data['bridge']??array()); $bridge_actions=(array)($bridge_contract['actions']??array()); ?>
                <div class="k30-section-heading"><div><h2><?php echo esc_html($tr('Bridge 3.3 داخلی','Embedded Bridge 3.3')); ?></h2><p><?php echo esc_html($tr('کنترل‌پلن عمومی و allow-listed برای WordPress/WooCommerce، SEO، محتوا، رسانه، Snapshot، Rollback، Audit و موتورهای محتوا.','A generic allow-listed control plane for WordPress/WooCommerce, SEO, content, media, snapshots, rollback, audit and content engines.')); ?></p></div><span class="k30-pill success">Contract <?php echo esc_html((string)($bridge_contract['contract']??'3.3')); ?></span></div>
                <section class="k30-bridge-console">
                    <div class="k30-bridge-summary">
                        <article><span><?php echo esc_html($tr('Execute endpoint','Execute endpoint')); ?></span><code><?php echo esc_html(rest_url(ltrim((string)($bridge_contract['execute_endpoint']??'/k20-ai/v3/bridge/execute'),'/'))); ?></code></article>
                        <article><span><?php echo esc_html($tr('Asset endpoint','Asset endpoint')); ?></span><code><?php echo esc_html(rest_url(ltrim((string)($bridge_contract['asset_endpoint']??'/k20-ai/v3/bridge/asset'),'/'))); ?></code></article>
                        <article><span><?php echo esc_html($tr('اکشن مجاز','Allow-listed actions')); ?></span><b><?php echo esc_html(count($bridge_actions)); ?></b><small><?php echo esc_html($tr('همه عملیات ثبت Audit دارند','All operations are audited')); ?></small></article>
                    </div>
                    <div class="k30-bridge-main">
                        <div class="k30-bridge-capabilities"><h3><?php echo esc_html($tr('قابلیت‌ها','Capabilities')); ?></h3><div class="k30-chip-cloud"><?php foreach($bridge_actions as $action): ?><span><?php echo esc_html((string)$action); ?></span><?php endforeach; ?></div></div>
                        <div class="k30-bridge-guards"><h3><?php echo esc_html($tr('Hard guardها','Hard guards')); ?></h3><?php foreach((array)($bridge_contract['hard_guards']??array()) as $guard): ?><p><span class="dashicons dashicons-lock"></span><?php echo esc_html((string)$guard); ?></p><?php endforeach; ?></div>
                    </div>
                    <div class="k30-bridge-tool"><label><span><?php echo esc_html($tr('اکشن','Action')); ?></span><select data-bridge-action><?php foreach($bridge_actions as $action): ?><option value="<?php echo esc_attr((string)$action); ?>" <?php selected((string)$action,'selftest.run'); ?>><?php echo esc_html((string)$action); ?></option><?php endforeach; ?></select></label><label class="grow"><span><?php echo esc_html($tr('Request JSON','Request JSON')); ?></span><textarea rows="4" data-bridge-payload spellcheck="false">{"action":"selftest.run","request_id":"ui-selftest"}</textarea></label><div class="k30-bridge-actions"><button type="button" class="k30-button primary" data-bridge-selftest><span class="dashicons dashicons-yes-alt"></span><?php echo esc_html($tr('Self-test','Self-test')); ?></button><button type="button" class="k30-button secondary" data-bridge-execute><span class="dashicons dashicons-controls-play"></span><?php echo esc_html($tr('اجرای درخواست امن','Execute safe request')); ?></button></div></div>
                    <pre class="k30-bridge-result" data-bridge-result hidden></pre>
                </section>
                <?php $card_open('چطور «تکمیل با AI» کار می‌کند؟','dashicons-superhero-alt','k30-ai-guard-card','AI قبل از اعمال تغییر، Preview می‌سازد؛ قیمت، موجودی و شناسه‌های حساس بدون شواهد معتبر ساخته نمی‌شوند.'); ?>
                    <div class="k30-ai-flow"><span><?php echo esc_html($tr('۱. داده واقعی WordPress/WooCommerce','1. Real WordPress/WooCommerce data')); ?></span><i>←</i><span><?php echo esc_html($tr('۲. Provider متصل','2. Connected provider')); ?></span><i>←</i><span><?php echo esc_html($tr('۳. پیشنهاد JSON ساختاریافته','3. Structured JSON proposal')); ?></span><i>←</i><span><?php echo esc_html($tr('۴. Preview تغییرات','4. Change preview')); ?></span><i>←</i><span><?php echo esc_html($tr('۵. تأیید انسانی و Apply','5. Human approval & apply')); ?></span></div>
                    <p class="k30-note"><?php echo esc_html($tr('GitHub به‌عنوان مسیر Repository/Actions استفاده می‌شود. برای inference، موتورهای OpenAI، Gemini، Anthropic، DeepSeek یا Provider سازگار مستقیماً متصل می‌شوند؛ اتصال GitHub به‌تنهایی «Copilot API عمومی» ایجاد نمی‌کند.','GitHub is used as a Repository/Actions delivery path. OpenAI, Gemini, Anthropic, DeepSeek or compatible providers connect directly for inference; a GitHub connection alone does not create a public Copilot API.')); ?></p>
                <?php $card_close(); ?>

            <?php elseif ( 'settings' === $workspace ) : ?>
                <div class="k30-settings-tabs" aria-label="Settings sections"><button type="button" class="is-active" data-settings-jump="governance" aria-pressed="true">قوانین و اتوماسیون</button><button type="button" data-settings-jump="integrations" aria-pressed="false">اتصال‌ها</button><button type="button" data-settings-jump="engines" aria-pressed="false">موتورها</button><button type="button" data-settings-jump="bots" aria-pressed="false">Bot Control</button><button type="button" data-settings-jump="system" aria-pressed="false">سیستم</button></div>
                <div class="k30-grid k30-grid-3" id="k30-settings-governance">
                    <?php $card_open('قوانین اجرا و Governance','dashicons-shield-alt','', 'تغییرات کم‌ریسک هم قابل Approval هستند و تغییرات پرریسک بدون تأیید اجرا نمی‌شوند.'); ?><form class="k30-settings-form" data-settings-form><label><span>اسکن خودکار</span><input type="checkbox" name="auto_scan" <?php checked(!empty($data['settings']['auto_scan'])); ?>></label><label><span>اصلاح امن خودکار</span><input type="checkbox" name="auto_safe_fixes" <?php checked(!empty($data['settings']['auto_safe_fixes'])); ?>></label><label><span>الزام تأیید انسانی</span><input type="checkbox" name="require_approval" <?php checked(!empty($data['settings']['require_approval'])); ?>></label><label><span>Batch اسکن</span><input type="number" min="5" max="100" name="scan_batch_size" value="<?php echo esc_attr($data['settings']['scan_batch_size']); ?>"></label><label><span>Batch Crawl</span><input type="number" min="2" max="20" name="crawl_batch_size" value="<?php echo esc_attr($data['settings']['crawl_batch_size']); ?>"></label><button class="k30-button primary" type="submit">ذخیره تنظیمات</button></form><?php $card_close(); ?>
                    <?php $privacy=(array)($data['legacy_settings']??array()); $card_open('حریم خصوصی و نگهداری داده','dashicons-privacy','', 'Retentionها با job روزانه اجرا می‌شوند؛ حداقل ۱ روز است. Diagnostic Logging پیش‌فرض خاموش است و داده حساس Redact می‌شود.'); ?><form class="k30-settings-form" data-settings-form><label><span>Prompt logs (روز)</span><input type="number" min="1" max="3650" name="prompt_log_retention" value="<?php echo esc_attr((string)($privacy['prompt_log_retention']??30)); ?>"></label><label><span>IP hash (روز)</span><input type="number" min="1" max="3650" name="ip_retention" value="<?php echo esc_attr((string)($privacy['ip_retention']??7)); ?>"></label><label><span>Bot logs (روز)</span><input type="number" min="1" max="3650" name="bot_log_retention" value="<?php echo esc_attr((string)($privacy['bot_log_retention']??90)); ?>"></label><label><span>Provider usage (روز)</span><input type="number" min="1" max="3650" name="provider_log_retention" value="<?php echo esc_attr((string)($privacy['provider_log_retention']??90)); ?>"></label><label><span>Audit log (روز)</span><input type="number" min="1" max="3650" name="audit_log_retention" value="<?php echo esc_attr((string)($privacy['audit_log_retention']??365)); ?>"></label><label><span>Events/Webhooks (روز)</span><input type="number" min="1" max="3650" name="event_log_retention" value="<?php echo esc_attr((string)($privacy['event_log_retention']??90)); ?>"></label><label><span>Webhook logs (روز)</span><input type="number" min="1" max="3650" name="webhook_log_retention" value="<?php echo esc_attr((string)($privacy['webhook_log_retention']??30)); ?>"></label><label><span>Engine runs (روز)</span><input type="number" min="1" max="3650" name="engine_run_retention" value="<?php echo esc_attr((string)($privacy['engine_run_retention']??180)); ?>"></label><label><span>Supplier records (روز)</span><input type="number" min="1" max="3650" name="supplier_submission_retention" value="<?php echo esc_attr((string)($privacy['supplier_submission_retention']??730)); ?>"></label><label><span>Agent runs (روز)</span><input type="number" min="1" max="3650" name="agent_run_retention" value="<?php echo esc_attr((string)($privacy['agent_run_retention']??180)); ?>"></label><label><span>AI Visibility history (روز)</span><input type="number" min="1" max="3650" name="visibility_retention" value="<?php echo esc_attr((string)($privacy['visibility_retention']??730)); ?>"></label><label><span>Migration snapshots (روز)</span><input type="number" min="1" max="3650" name="migration_snapshot_retention" value="<?php echo esc_attr((string)($privacy['migration_snapshot_retention']??365)); ?>"></label><label><span>MCP authenticated tools</span><input type="checkbox" name="mcp_authenticated_tools_enabled" <?php checked(!empty($privacy['mcp_authenticated_tools_enabled'])); ?>></label><label><span>AI Visibility auto collect</span><input type="checkbox" name="visibility_auto_collect" <?php checked(!empty($privacy['visibility_auto_collect'])); ?>></label><label><span>Diagnostic logging</span><input type="checkbox" name="diagnostic_logging_enabled" <?php checked(!empty($privacy['diagnostic_logging_enabled'])); ?>></label><button class="k30-button primary" type="submit">ذخیره سیاست نگهداری</button></form><?php $card_close(); ?>
                    <span class="k30-jump-anchor" id="k30-settings-integrations"></span><?php $card_open('اتصال‌ها و Providerها','dashicons-admin-links','', 'Provider بیرونی فقط وقتی Credential محیطی یا Import معتبر وجود داشته باشد Connected نشان داده می‌شود.'); ?><div class="k30-integration-list"><?php foreach((array)($data['integrations']??array()) as $integration): $tone=$tone_from_status($integration['status']); ?><article><span class="k30-status-dot <?php echo esc_attr($tone); ?>"></span><div><strong><?php echo esc_html($integration['label']); ?></strong><small><?php echo esc_html($integration['detail']?:'بدون Credential/Import'); ?></small></div><span class="k30-pill <?php echo esc_attr($tone); ?>"><?php echo esc_html($status_text((string)$integration['status'])); ?></span></article><?php endforeach; ?></div><?php $card_close(); ?>
                    <span class="k30-jump-anchor" id="k30-settings-engines"></span><?php $card_open('موتورهای فعال','dashicons-superhero-alt','', 'هسته محلی می‌تواند «آماده» باشد؛ فقط اجرای واقعی Active محسوب می‌شود. موتور داده خارجی بدون اتصال در Waiting Data می‌ماند.'); ?><div class="k30-engine-list compact"><?php foreach((array)($data['engines']??array()) as $engine): $tone=$tone_from_status($engine['status']); ?><div><span class="k30-status-dot <?php echo esc_attr($tone); ?>"></span><div><b><?php echo esc_html($engine['label']); ?></b><small><?php echo esc_html($engine['source']); ?></small></div><span class="k30-pill <?php echo esc_attr($tone); ?>"><?php echo esc_html($status_text((string)$engine['status'])); ?></span></div><?php endforeach; ?></div><?php $card_close(); ?>
                </div>
                <?php $bot=(array)($data['bot_control']??array()); $bot_policy=(array)($bot['policy']??array()); $bot_entries=(array)($bot['entries']??array()); ?>
                <span class="k30-jump-anchor" id="k30-settings-bots"></span>
                <?php $card_open('مرکز کنترل موتورهای جست‌وجو و ربات‌های هوش مصنوعی','dashicons-admin-site-alt3','k30-bot-control-card','کلیدها فقط روی User-Agentهایی که robots.txt واقعاً می‌تواند کنترل کند اعمال می‌شوند؛ موارد بدون robots token صرفاً مانیتور می‌شوند.'); ?>
                    <div class="k30-bot-toolbar">
                        <form class="k30-bot-policy" data-bot-policy-form>
                            <label><span>Search crawlerها</span><input type="checkbox" name="SEARCH_ALLOWED" <?php checked(!empty($bot_policy['SEARCH_ALLOWED'])); ?>></label>
                            <label><span>Training crawlerها</span><input type="checkbox" name="TRAINING_ALLOWED" <?php checked(!empty($bot_policy['TRAINING_ALLOWED'])); ?>></label>
                            <label><span>User-triggered / Assistant</span><input type="checkbox" name="USER_FETCH_ALLOWED" <?php checked(!empty($bot_policy['USER_FETCH_ALLOWED'])); ?>></label>
                            <label><span>Analytics/API crawlerها</span><input type="checkbox" name="API_ALLOWED" <?php checked(!empty($bot_policy['API_ALLOWED'])); ?>></label>
                            <button class="k30-button secondary" type="submit"><span class="dashicons dashicons-saved"></span> ذخیره سیاست</button>
                        </form>
                        <div class="k30-bot-summary"><span><?php echo esc_html($num($bot['families']??count($bot_entries))); ?> خانواده</span><span><?php echo esc_html($num($bot['controllable']??0)); ?> قابل کنترل</span><span><?php echo esc_html($num($bot['monitorable']??0)); ?> قابل رصد</span><?php $status_pill(!empty($bot['virtual_active'])?'robots فعال':'پیش‌نمایش',!empty($bot['virtual_active'])?'success':'warning'); ?></div>
                    </div>
                    <div class="k30-bot-grid" data-bot-grid>
                        <?php foreach($bot_entries as $entry): $allowed=!empty($entry['allowed']); $controllable=!empty($entry['controllable']); ?>
                            <article class="k30-bot-item <?php echo $allowed?'is-allowed':'is-blocked'; ?>">
                                <div class="k30-bot-copy"><strong><?php echo esc_html($entry['display_name']??$entry['provider']??$entry['id']); ?></strong><small><?php echo esc_html(($entry['provider']??'').' · '.($entry['category']??'')); ?></small></div>
                                <div class="k30-bot-state"><?php if($controllable): ?><label class="k30-switch"><input type="checkbox" data-bot-override="<?php echo esc_attr($entry['id']); ?>" <?php checked($allowed); ?>><i></i></label><?php else: ?><span class="k30-pill neutral">فقط رصد</span><?php endif; ?></div>
                            </article>
                        <?php endforeach; ?>
                    </div>
                    <div class="k30-bot-actions"><button class="k30-button primary" type="button" data-bot-apply><span class="dashicons dashicons-yes-alt"></span> اعمال سیاست روی robots مجازی</button><button class="k30-button secondary" type="button" data-bot-rollback><span class="dashicons dashicons-undo"></span> Rollback robots</button><a class="k30-button secondary" target="_blank" rel="noopener" href="<?php echo esc_url(home_url('/robots.txt')); ?>"><span class="dashicons dashicons-media-text"></span> مشاهده robots.txt</a></div>
                <?php $card_close(); ?>
                <span class="k30-jump-anchor" id="k30-settings-system"></span>
                <div class="k30-grid k30-grid-2-1">
                    <?php $card_open('رادار منابع خبری','dashicons-rss','', 'هر URL باید RSS/Atom معتبر و مورد اعتماد باشد. افزونه بدون اجازه منبع پیش‌فرض اضافه نمی‌کند.'); ?><form class="k30-radar-settings" data-radar-settings><textarea rows="7" name="radar_sources" aria-label="<?php echo esc_attr( $tr( 'منابع RSS/Atom خبری', 'News RSS/Atom sources' ) ); ?>" placeholder="https://example.com/feed/\nhttps://another.example/rss.xml"><?php echo esc_textarea(implode("\n",(array)($data['settings']['radar_sources']??array()))); ?></textarea><button class="k30-button primary" type="submit">ذخیره منابع</button></form><?php $card_close(); ?>
                    <?php $card_open('وضعیت دیتابیس و نسخه','dashicons-database','', 'نسخه دیتابیس 3.0 جداول SEO OS را به صورت additive ایجاد می‌کند و داده‌های نسخه 2.0 را حذف نمی‌کند.'); ?><div class="k30-system-facts"><div><span>Plugin</span><b><?php echo esc_html(K20AI_PRESS_VERSION); ?></b></div><div><span>DB</span><b><?php echo esc_html(K20AI_Database::DB_VERSION); ?></b></div><div><span>PHP</span><b><?php echo esc_html(PHP_VERSION); ?></b></div><div><span>WordPress</span><b><?php echo esc_html(get_bloginfo('version')); ?></b></div><div><span>WooCommerce</span><b><?php echo defined('WC_VERSION')?esc_html(WC_VERSION):'—'; ?></b></div></div><?php $card_close(); ?>
                </div>

            <?php else : ?>
                <?php $empty_state('این Workspace در حال آماده‌سازی است','ساختار ثبت شده اما نمای تخصصی هنوز تعریف نشده است.'); ?>
            <?php endif; ?>
        </div>
    </main>

    <div class="k30-modal-backdrop" data-modal-backdrop hidden></div>
    <dialog class="k30-modal" data-modal aria-labelledby="k30-modal-title">
        <button class="k30-modal-close" type="button" data-modal-close aria-label="بستن"><span class="dashicons dashicons-no-alt"></span></button>
        <div class="k30-modal-head"><div><small data-modal-kicker>K20 AI Press</small><h2 id="k30-modal-title" data-modal-title>جزئیات</h2></div><span class="k30-modal-status" data-modal-status></span></div>
        <div class="k30-modal-body" data-modal-body></div>
    </dialog>

    <div class="k30-toast-stack" data-toast-stack aria-live="polite"></div>
</div>
