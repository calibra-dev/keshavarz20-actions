# Privacy and data lifecycle

K20 AI Press follows data-minimization and bounded-retention principles for plugin-owned operational records.

## Personal-data controls

- WordPress personal-data exporter and eraser callbacks are registered.
- User references in audit/review/scan/action/snapshot records are anonymized during erasure while non-personal operational evidence can be retained for integrity. Agent objectives/context/step payloads and user-authored AI Visibility query text are erased when they belong to the requesting user.
- Supplier payload erasure removes personal/contact/billing/shipping fields without deleting product, brand, model or technical evidence fields.
- Diagnostic logging is disabled by default and redacts credentials and common personal identifiers when enabled.

## Retention

Retention windows for prompt, IP, bot, provider, audit, event, webhook, engine, supplier, Agent run, AI Visibility observation and migration snapshot records are configurable from 0 to 3650 days. A retention value of 0 means matching records are immediately eligible for cleanup on the next scheduled cleanup run. Cleanup runs in bounded batches to reduce database load and avoid long database locks.

## External services

External AI/search/source-control services are optional and administrator-configured. Data is sent only through an explicitly configured workflow. Administrators are responsible for reviewing the selected provider's terms, privacy policy and data-location requirements before use.

## Uninstall

Operational data is preserved by default. Complete removal is opt-in through the K20AI_PRESS_REMOVE_DATA_ON_UNINSTALL constant so accidental plugin deletion does not destroy audit or recovery data.

## Agent and AI Visibility governance

- Agent plans reject credential-like inputs and execute only through the central Ability/Services permission boundary.
- AI Visibility observations require source/evidence and are not fabricated when no measurement exists.
- Sensitive Agent execution/approval tools are not exposed as MCP-public tools by default.

## Commercial licensing

Commercial licensing is disabled unless the site owner supplies an HTTPS license service URL and an Ed25519 public key through environment/config constants. License keys are encrypted locally. Responses must carry a raw base64 payload plus a detached Ed25519 signature; unsigned or malformed responses fail closed.


## Optional live SERP provider

When an administrator explicitly configures and invokes the SerpApi connection, the plugin sends the requested search query plus configured locale/location parameters to SerpApi in order to retrieve live Google organic result data. Product content, customer data, credentials and unrelated site records are not sent by this feature. The API key is stored through the plugin's encrypted connection store. Review SerpApi's current legal/privacy terms before enabling this optional connection.
