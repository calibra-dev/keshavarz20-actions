(() => {
  'use strict';
  window.K20AI31Workflows = (ctx) => {
    const { $, $$, api, shell, toast, errorText, icon, el, openModal, runAbility, uiText } = ctx;
  // Business-aware content engines.
  $('[data-content-engine-settings]')?.addEventListener('submit', async (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    const submit = $('button[type=submit]', form);
    const value = (name) => form.querySelector(`[name="${name}"]`)?.value ?? '';
    const checkedValue = (name) => Boolean(form.querySelector(`[name="${name}"]`)?.checked);
    const engineBody = (engine) => ({
      enabled: checkedValue(`${engine}[enabled]`),
      time: value(`${engine}[time]`),
      runner: value(`${engine}[runner]`),
      provider: value(`${engine}[provider]`),
      workflow: value(`${engine}[workflow]`),
      post_type: value(`${engine}[post_type]`),
      status: value(`${engine}[status]`),
      lookback_hours: Number(value(`${engine}[lookback_hours]`) || 24),
      web_research: checkedValue(`${engine}[web_research]`),
    });
    const body = {
      auto_enable_on_ready: checkedValue('auto_enable_on_ready'),
      default_runner: value('default_runner'),
      news: engineBody('news'),
      article: engineBody('article'),
    };
    if (submit) submit.disabled = true;
    try {
      await api('/content-engines/settings', { method: 'PATCH', body });
      toast(shell?.dataset.language === 'en' ? 'Engine settings saved' : 'تنظیمات موتور ذخیره شد');
      setTimeout(() => location.reload(), 650);
    } catch (error) {
      toast(shell?.dataset.language === 'en' ? 'Engine settings failed' : 'ذخیره تنظیمات موتور ناموفق بود', errorText(error), 'error');
      if (submit) submit.disabled = false;
    }
  });
  $$('[data-engine-run]').forEach((button) => button.addEventListener('click', async () => {
    const engine = button.dataset.engineRun;
    button.disabled = true;
    const originalNodes = Array.from(button.childNodes).map((node) => node.cloneNode(true));
    const spinner = icon('update'); spinner.classList.add('k30-spin');
    button.replaceChildren(spinner, document.createTextNode(shell?.dataset.language === 'en' ? 'Running…' : 'در حال اجرا…'));
    try {
      const result = await api(`/content-engines/${encodeURIComponent(engine)}/run`, { method: 'POST', body: {} });
      const detail = result?.post_id ? `#${result.post_id} · ${result.title || ''}` : (result?.workflow || result?.status || 'accepted');
      toast(shell?.dataset.language === 'en' ? 'Engine run accepted' : 'اجرای موتور پذیرفته شد', detail);
      setTimeout(() => location.reload(), 900);
    } catch (error) {
      toast(shell?.dataset.language === 'en' ? 'Engine run failed' : 'اجرای موتور ناموفق بود', errorText(error), 'error');
      button.disabled = false;
      button.replaceChildren(...originalNodes.map((node) => node.cloneNode(true)));
    }
  }));
  $$('[data-engine-sources]').forEach((button) => button.addEventListener('click', () => {
    let sources = [];
    try { sources = JSON.parse(button.dataset.engineSources || '[]'); } catch { sources = []; }
    const wrap = el('div', 'k30-source-modal');
    if (!sources.length) {
      wrap.append(el('p', 'k30-note', shell?.dataset.language === 'en' ? 'No source URLs were stored for this run.' : 'برای این اجرا منبعی ثبت نشده است.'));
    } else {
      sources.forEach((source, index) => {
        const row = el('article', 'k30-source-row');
        const rawUrl = typeof source === 'string' ? source : (source?.url || source?.source_url || '');
        const label = typeof source === 'string' ? source : (source?.title || source?.source || rawUrl || `Source ${index + 1}`);
        row.append(el('span', 'k30-source-number', String(index + 1)), el('div', 'k30-source-copy', label));
        if (/^https?:\/\//i.test(String(rawUrl))) {
          const link = el('a', 'k30-mini-button', shell?.dataset.language === 'en' ? 'Open' : 'باز کردن');
          link.href = rawUrl; link.target = '_blank'; link.rel = 'noopener noreferrer'; row.append(link);
        }
        wrap.append(row);
      });
    }
    openModal(shell?.dataset.language === 'en' ? 'Run sources' : 'منابع اجرای موتور', wrap, { status: `${sources.length} sources`, tone: sources.length ? 'success' : 'warning' });
  }));

  // 3.1 Agent runtime, AI visibility, migration and commercial workflows.
  $('[data-agent-plan-form]')?.addEventListener('submit', async (event) => {
    event.preventDefault();
    const form = event.currentTarget; const button = $('button[type="submit"]', form); if (button) button.disabled = true;
    try {
      const fd = new FormData(form); const productId = Number(fd.get('product_id') || 0);
      const context = productId > 0 ? { product_id: productId } : {};
      const result = await runAbility('agent.plan', { objective: String(fd.get('objective') || ''), mode: String(fd.get('mode') || 'assisted'), context, idempotency_key: `ui-${Date.now()}` });
      const host = $('[data-agent-plan-result]'); if (host) { host.replaceChildren(el('pre', 'k30-code', JSON.stringify(result, null, 2))); }
      toast(uiText('Plan ساخته شد', 'Agent plan created'), result?.run_key || '');
      setTimeout(() => location.reload(), 900);
    } catch (error) { toast(uiText('ساخت Plan ناموفق بود', 'Agent plan failed'), errorText(error), 'error'); if (button) button.disabled = false; }
  });

  const renderAgentRun = (run) => {
    const wrap = el('div', 'k30-agent-run-modal');
    wrap.append(el('p', 'k30-note', run?.objective || ''));
    wrap.append(el('pre', 'k30-code', JSON.stringify(run, null, 2)));
    const actions = el('div', 'k30-modal-actions');
    const waiting = (run?.steps || []).filter((step) => step?.requires_approval && step?.status === 'waiting_approval').map((step) => Number(step.id)).filter(Boolean);
    if (waiting.length) {
      const approve = el('button', 'k30-button secondary', uiText('تأیید Stepهای منتظر', 'Approve waiting steps')); approve.type = 'button';
      approve.addEventListener('click', async () => { approve.disabled = true; try { const updated = await runAbility('agent.approve', { run_key: run.run_key, step_ids: waiting }, true); openModal(uiText('Agent Run', 'Agent Run'), renderAgentRun(updated), { status: updated.status, tone: 'success' }); } catch (error) { toast(uiText('Approval ناموفق بود', 'Approval failed'), errorText(error), 'error'); approve.disabled = false; } });
      actions.append(approve);
    }
    if (!['completed','cancelled'].includes(String(run?.status || ''))) {
      const execute = el('button', 'k30-button primary', uiText('اجرا و Verify', 'Execute and verify')); execute.type = 'button';
      execute.addEventListener('click', async () => { execute.disabled = true; try { const updated = await runAbility('agent.execute', { run_key: run.run_key }, true); openModal(uiText('Agent Run', 'Agent Run'), renderAgentRun(updated), { status: updated.status, tone: updated.status === 'completed' ? 'success' : 'warning' }); } catch (error) { toast(uiText('اجرای Agent ناموفق بود', 'Agent execution failed'), errorText(error), 'error'); execute.disabled = false; } });
      const cancel = el('button', 'k30-button secondary', uiText('لغو Run', 'Cancel run')); cancel.type = 'button';
      cancel.addEventListener('click', async () => { cancel.disabled = true; try { const updated = await runAbility('agent.cancel', { run_key: run.run_key }, true); openModal(uiText('Agent Run', 'Agent Run'), renderAgentRun(updated), { status: updated.status, tone: 'warning' }); } catch (error) { toast(uiText('لغو ناموفق بود', 'Cancel failed'), errorText(error), 'error'); cancel.disabled = false; } });
      actions.append(execute, cancel);
    }
    wrap.append(actions); return wrap;
  };
  $$('[data-agent-open]').forEach((button) => button.addEventListener('click', async () => {
    button.disabled = true; try { const run = await runAbility('agent.status', { run_key: button.dataset.agentOpen }); openModal(uiText('Agent Run', 'Agent Run'), renderAgentRun(run), { status: run.status, tone: run.status === 'completed' ? 'success' : 'info' }); } catch (error) { toast(uiText('خواندن Run ناموفق بود', 'Could not read run'), errorText(error), 'error'); } finally { button.disabled = false; }
  }));

  $('[data-visibility-query-form]')?.addEventListener('submit', async (event) => {
    event.preventDefault(); const form = event.currentTarget; const button = $('button[type="submit"]', form); if (button) button.disabled = true;
    try { const fd = new FormData(form); await runAbility('visibility.query.upsert', { query: String(fd.get('query') || ''), locale: String(fd.get('locale') || ''), country: String(fd.get('country') || ''), enabled: true }, true); toast(uiText('Query اضافه شد', 'Visibility query added')); setTimeout(() => location.reload(), 700); } catch (error) { toast(uiText('ثبت Query ناموفق بود', 'Query failed'), errorText(error), 'error'); if (button) button.disabled = false; }
  });

  $('[data-license-form]')?.addEventListener('submit', async (event) => {
    event.preventDefault(); const form = event.currentTarget; const button = $('button[type="submit"]', form); if (button) button.disabled = true;
    try { const fd = new FormData(form); const result = await runAbility('license.activate', { license_key: String(fd.get('license_key') || '') }, true); form.reset(); toast(uiText('License همگام شد', 'License activated'), result?.status || ''); setTimeout(() => location.reload(), 800); } catch (error) { toast(uiText('فعال‌سازی License ناموفق بود', 'License activation failed'), errorText(error), 'error'); if (button) button.disabled = false; }
  });
  $('[data-license-deactivate]')?.addEventListener('click', async (event) => { const button = event.currentTarget; button.disabled = true; try { await runAbility('license.deactivate', {}, true); toast(uiText('License غیرفعال شد', 'License deactivated')); setTimeout(() => location.reload(), 700); } catch (error) { toast(uiText('غیرفعال‌سازی ناموفق بود', 'Deactivation failed'), errorText(error), 'error'); button.disabled = false; } });

  $('[data-migration-preview]')?.addEventListener('submit', async (event) => {
    event.preventDefault(); const form = event.currentTarget; const button = $('button[type="submit"]', form); const host = $('[data-migration-result]'); if (button) button.disabled = true;
    try {
      const fd = new FormData(form); const source = String(fd.get('source') || 'yoast'); const preview = await runAbility('migration.preview', { source, limit: 200, offset: 0 });
      const wrap = el('div', 'k30-migration-preview'); wrap.append(el('pre', 'k30-code', JSON.stringify(preview, null, 2)));
      const ids = (preview?.items || []).map((row) => Number(row.post_id)).filter(Boolean);
      if (ids.length) { const apply = el('button', 'k30-button primary', uiText(`Import ${ids.length} مورد با Backup`, `Import ${ids.length} items with backup`)); apply.type = 'button'; apply.addEventListener('click', async () => { apply.disabled = true; try { const result = await runAbility('migration.import', { source, post_ids: ids }, true); const pre = el('pre', 'k30-code', JSON.stringify(result, null, 2)); wrap.replaceChildren(pre); if (result?.snapshot_key) { const rollback = el('button', 'k30-button secondary', uiText('Rollback این Migration', 'Rollback this migration')); rollback.type = 'button'; rollback.addEventListener('click', async () => { rollback.disabled = true; try { const rb = await runAbility('migration.rollback', { snapshot_key: result.snapshot_key }, true); wrap.replaceChildren(el('pre', 'k30-code', JSON.stringify(rb, null, 2))); toast(uiText('Rollback تأیید شد', 'Rollback verified')); } catch (error) { toast(uiText('Rollback ناموفق بود', 'Rollback failed'), errorText(error), 'error'); rollback.disabled = false; } }); wrap.append(rollback); } toast(uiText('Migration و Verify انجام شد', 'Migration and verification completed')); } catch (error) { toast(uiText('Migration ناموفق بود', 'Migration failed'), errorText(error), 'error'); apply.disabled = false; } }); wrap.append(apply); }
      if (host) host.replaceChildren(wrap);
    } catch (error) { toast(uiText('پیش‌نمایش Migration ناموفق بود', 'Migration preview failed'), errorText(error), 'error'); } finally { if (button) button.disabled = false; }
  });

  };
})();
