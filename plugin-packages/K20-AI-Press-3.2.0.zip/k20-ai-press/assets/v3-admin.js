(() => {
  'use strict';

  const boot = window.K20AI_V3_BOOT || {};
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));
  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  const shell = $('.k30-shell');
  const syncThemeMarker = () => document.body.classList.toggle('k30-dark-mode', shell?.dataset.theme === 'dark');
  syncThemeMarker();
  const storageGet = (key) => { try { return window.localStorage?.getItem(key) ?? null; } catch (_) { return null; } };
  const storageSet = (key, value) => { try { window.localStorage?.setItem(key, String(value)); } catch (_) { /* Browser privacy/opaque-origin mode: persistence is optional. */ } };
  const UI_EN = Object.freeze({"مدیر سیستم":"System admin","مدیر فروشگاه":"Store manager","سایت فعال":"Active site","جست‌وجوی سریع":"Quick search","جستجو در محصولات، نوشته‌ها، URL و خطاها…":"Search products, posts, URLs and issues…","تنظیمات نمایش":"Display settings","تم شب و روز":"Day / night theme","تم روز":"Light theme","تم شب":"Dark theme","زبان رابط":"Interface language","آخرین اسکن":"Last scan","هنوز اجرا نشده":"Not run yet","اسکن کامل":"Full scan","مرکز فرمان":"Control Tower","داده واقعی سایت":"Real site data","داده زنده سرویس‌های متصل":"Live connected-service data","این اعداد از آخرین Sync واقعی Connection Center می‌آیند؛ در نبود Sync هیچ عدد فرضی ساخته نمی‌شود.":"These metrics come from the latest real Connection Center sync; no values are invented when sync data is unavailable.","سلامت کل سئو":"Overall SEO health","نیازمند اقدام":"Needs action","صفحات/موجودیت‌ها":"Pages / entities","خطاهای بحرانی":"Critical issues","اقدامات منتظر تأیید":"Awaiting approval","موجودیت تحلیل‌شده":"Analyzed entities","صف اول اقدامات هوشمند":"Top smart actions","اولویت بر پایه شدت خطا، امتیاز سئو، اثر تجاری، ریسک و اعتماد داده محلی محاسبه می‌شود؛ این عدد Domain Authority ساختگی نیست.":"Priority is calculated from issue severity, SEO score, commercial impact, risk and local data confidence; it is not a fabricated Domain Authority metric.","صف اقدام هنوز ساخته نشده":"No action queue yet","اسکن کامل را اجرا کنید تا مشکلات و پیشنهادهای واقعی از سایت استخراج شوند.":"Run a full scan to extract real issues and recommendations from the site.","بحرانی":"Critical","نیاز به بهبود":"Needs improvement","فرصت":"Opportunity","سلامت سیستم و موتورها":"System & engine health","وضعیت هر موتور نشان می‌دهد آیا تحلیل محلی فعال است یا برای داده خارجی هنوز اتصال لازم است.":"Each engine shows whether local analysis is active or an external connection is still required.","مشاهده همه موتورها":"View all engines","اولویت‌های اصلی سایت":"Top site priorities","ضعیف‌ترین موجودیت‌های تحلیل‌شده با امتیاز چندبعدی واقعی.":"Lowest-scoring analyzed entities based on real multi-dimensional scoring.","موجودیت":"Entity","نوع":"Type","امتیاز":"Score","ریسک":"Risk","اقدام":"Action","جزئیات":"Details","روند سلامت ارگانیک":"Organic health trend","روند از اسکن‌های واقعی افزونه ساخته می‌شود؛ وقتی اسکن تاریخی نداریم خط مصنوعی نمایش داده نمی‌شود.":"The trend is built from real plugin scans; no synthetic line is shown without historical scans.","برای تشکیل روند، حداقل دو اسکن کامل نیاز است.":"At least two full scans are required to build a trend.","معماری عملیاتی چهارلایه":"Four-layer operating model","هر تغییر از جمع‌آوری داده واقعی شروع می‌شود و بدون عبور از تشخیص، پیشنهاد و کنترل اجرا نمی‌شود.":"Every change starts with real data collection and must pass diagnosis, recommendation and governance before execution.","مشاهده و جمع‌آوری":"Observe & collect","تشخیص":"Diagnose","پیشنهاد":"Recommend","اجرا و کنترل":"Execute & govern","لایه":"Layer","میانگین سلامت محصولات":"Average product health","از محصولات تحلیل‌شده":"From analyzed products","فنی":"Technical","محتوا":"Content","متن و Meta":"Copy & meta","اسکیما":"Schema","تصویر":"Media","Gallery و ALT":"Gallery & ALT","تجارت":"Commerce","برج کنترل هوشمند محصولات":"Product Intelligence Tower","کم‌امتیازترین محصولات بر اساس داده واقعی WooCommerce و Rule Engine مرتب می‌شوند.":"Lowest-scoring products are ranked from real WooCommerce data and the rule engine.","هنوز محصولی تحلیل نشده است":"No products analyzed yet","اسکن محصولات یا اسکن کامل را اجرا کنید.":"Run a product scan or full scan.","مورد":"items","نقشه فیلدهای کاتالوگ":"Catalog field map","هر درصد از فیلدهای واقعی محصولات تحلیل‌شده محاسبه می‌شود.":"Each percentage is calculated from real fields of analyzed products.","از":"of","نقشه کامل بودن اطلاعات محصول":"Product data completeness map","هشت گروه اصلی از Payload واقعی محصولات تحلیل‌شده محاسبه می‌شوند؛ مقدار خالی قرمز، نیازمند بازبینی زرد و پوشش مناسب سبز نمایش داده می‌شود.":"Eight key groups are calculated from real product payloads: missing is red, review-required is amber, and sufficient coverage is green.","سیگنال تکمیل":"completion signals","سلامت واریانت‌های WooCommerce":"WooCommerce variation health","سلامت واریانت از قیمت و وضعیت موجودی واقعی product_variationها محاسبه می‌شود؛ عدد نمونه یا تصادفی نمایش داده نمی‌شود.":"Variation health is calculated from real product_variation price and stock state; no sample or random values are shown.","واریانت قابل سنجش پیدا نشد":"No measurable variations found","اگر محصول Variable وجود داشته باشد، سلامت واریانت‌ها بعد از اسکن اینجا نمایش داده می‌شود.":"When variable products exist, variation health appears here after scanning.","محصول متغیر":"variable products","پوشش شواهد محصولات":"Product evidence coverage","فقط محصولاتی پوشش‌دار شمرده می‌شوند که برای post:{ID} Claim با وضعیت VERIFIED یا PARTIAL در جدول شواهد واقعی داشته باشند. نبود Evidence به صورت صفر نمایش داده می‌شود، نه امتیاز ساختگی.":"A product counts as covered only when post:{ID} has VERIFIED or PARTIAL claims in the real evidence table. Missing evidence is shown as zero, never as a fabricated score.","بعد از اسکن محصولات، نسبت محصولاتی که Claim دارای Evidence دارند نمایش داده می‌شود.":"After scanning, the share of products with evidence-backed claims is shown here.","Evidence واقعی هنوز برای محصولات ثبت نشده است.":"No real product evidence has been recorded yet.","Coverage از جدول شواهد خود افزونه خوانده شده است.":"Coverage is read from the plugin evidence table.","صف اصلاح و غنی‌سازی":"Enrichment & remediation queue","Autofix فقط برای تغییراتی که کم‌ریسک و قابل اثبات‌اند Proposal می‌سازد؛ برند، GTIN و داده فنی حدس زده نمی‌شوند.":"Autofix only proposes low-risk, provable changes; brand, GTIN and technical facts are never guessed.","Taxonomyهای بررسی‌شده":"Audited taxonomies","دسته، برچسب و ساختار فروشگاه":"Categories, tags & store structure","لینک داخلی ثبت‌شده":"Recorded internal links","از محتوای واقعی":"From real content","صفحات منبع":"Source pages","دارای لینک داخلی":"With internal links","مقصدهای مرتبط":"Linked destinations","URLهای مقصد شناسایی‌شده":"Detected destination URLs","صفحات یتیم":"Orphan pages","بدون لینک ورودی ثبت‌شده":"No recorded inbound links","سلامت بر اساس تعداد Termهای خالی/کم‌محتوا و محصول متصل محاسبه می‌شود.":"Health is calculated from empty/thin terms and connected products.","فرصت‌های لینک‌سازی":"Internal-link opportunities","صفحات یتیم از Link Graph واقعی سایت استخراج می‌شوند.":"Orphan pages are derived from the real site link graph.","صفحات یتیم و نیازمند لینک داخلی":"Orphan pages needing internal links","این جدول فقط از لینک‌های کشف‌شده داخل محتوای سایت ساخته شده است.":"This table is built only from links discovered in site content.","کلمات کلیدی و داده جست‌وجو":"Keywords & search data","رتبه، Impression و CTR فقط از داده Import شده یا Provider متصل نمایش داده می‌شود.":"Rank, impressions and CTR are shown only from imported data or a connected provider.","داده کلمات کلیدی هنوز وارد نشده است":"No keyword data imported yet","برای جلوگیری از عدد جعلی، تا اتصال Search Console یا Import معتبر، این بخش خالی می‌ماند.":"To avoid fabricated metrics, this section stays empty until Search Console is connected or valid data is imported.","بدون صفحه هدف":"No target page","پوشش محتوایی":"Content coverage","ضعیف‌ترین محتوا بر اساس امتیاز Content و تازه‌بودن مرتب می‌شود.":"Weakest content is ranked by content score and freshness.","کلمه":"words","روز":"days","چک‌لیست محتوای سایت":"Site content checklist","این وضعیت از محتوای واقعی موجودیت‌های تحلیل‌شده ساخته می‌شود.":"This status is built from real content of analyzed entities.","URLهای خزش‌شده":"Crawled URLs","مشاهده واقعی HTTP":"Real HTTP observations","2xx سالم":"Healthy 2xx","Response موفق":"Successful response","خطای Client":"Client errors","خطای Server":"Server errors","Issue فنی باز":"Open technical issues","روند سلامت فنی":"Technical health trend","روند از Scan history واقعی محاسبه می‌شود.":"Trend is calculated from real scan history.","بررسی‌های کلیدی":"Key checks","این وضعیت از تنظیمات WordPress و قابلیت‌های نصب‌شده خوانده می‌شود.":"This status is read from WordPress settings and installed capabilities.","مشکلات فنی نیازمند اقدام":"Technical issues requiring action","Issueها با Evidence ذخیره شده‌اند و بعد از رفع در اسکن بعدی Resolve می‌شوند.":"Issues are stored with evidence and resolve on the next scan after they are fixed.","امتیاز و Eligibility":"Score & eligibility","پیش‌نمایش بر اساس داده واقعی Entity ساخته می‌شود و تزریق جعلی انجام نمی‌شود.":"Preview is built from real entity data; no synthetic data is injected.","موجودیتی برای پیش‌نمایش نیست":"No entity available for preview","ابتدا اسکن کامل را اجرا کنید.":"Run a full scan first.","پیش‌نمایش داده ساختاریافته":"Structured-data preview","JSON-LD پیشنهادی برای بررسی است؛ اگر Yoast/WooCommerce اسکیما می‌سازند از خروجی تکراری جلوگیری می‌شود.":"Proposed JSON-LD is for review; duplicate output is avoided when Yoast/WooCommerce already generates schema.","اسکیما قابل ساخت نیست":"Schema cannot be generated","برای موجودیت انتخاب‌شده داده کافی وجود ندارد.":"The selected entity does not have enough data.","پیش‌نمایش SERP / Social":"SERP / social preview","عنوان و توضیح از داده فعلی صفحه خوانده می‌شود؛ این پیش‌نمایش تضمین نمایش گوگل نیست.":"Title and description come from current page data; this preview does not guarantee Google display.","میانگین سلامت تصویر":"Average media health","از رسانه‌های تحلیل‌شده":"From analyzed media","رسانه تحلیل‌شده":"Analyzed media","Attachmentها":"Attachments","ALT ناقص":"Missing ALT","نیازمند متن جایگزین":"Needs alternative text","تصویر بزرگ >500KB":"Large image >500KB","بررسی حجم":"Size review","ابعاد ناقص":"Missing dimensions","ریسک Layout Shift":"Layout-shift risk","گروه تکراری":"Duplicate groups","بر پایه SHA-256 فایل":"Based on file SHA-256","مدیریت تصاویر و ALT":"Media & ALT management","ALT و مشخصات رسانه مستقیماً از Media Library خوانده می‌شود.":"ALT and media metadata are read directly from the Media Library.","رسانه تحلیل نشده است":"Media has not been analyzed","اسکن Media را اجرا کنید.":"Run the media scan.","ثبت نشده":"Not recorded","ابزارهای تصویر":"Media tools","اسکن رسانه ALT، ابعاد، حجم و SHA-256 فایل را بازخوانی می‌کند. تبدیل فرمت عمداً به افزونه تصویر سایت سپرده می‌شود تا دو موتور فشرده‌سازی با هم تداخل نکنند.":"Media scan reads ALT, dimensions, size and file SHA-256. Format conversion is intentionally delegated to the site image plugin to avoid competing optimization pipelines.","تصاویر تکراری واقعی":"Verified duplicate images","گروه تکراری فقط وقتی ساخته می‌شود که SHA-256 فایل‌های محلی یکسان باشد؛ نام مشابه به تنهایی Duplicate محسوب نمی‌شود.":"A duplicate group is created only when local files share the same SHA-256; similar filenames alone do not count.","Duplicate قطعی پیدا نشد":"No verified duplicates found","اگر رسانه‌ها تازه اسکن نشده‌اند، اسکن رسانه را اجرا کنید تا Hash فایل‌ها ساخته شود.":"If media was not scanned recently, run a media scan to generate file hashes.","فایل یکسان":"identical files","کلمات رهگیری‌شده":"Tracked keywords","دارای داده منبع‌دار":"With sourced data","میانگین رتبه":"Average position","مقادیر موجود":"Available values","رتبه ≤ 10":"Position ≤ 10","بهبود یافته":"Improved","نسبت به مقدار قبلی":"Versus previous value","افت کرده":"Declined","از منبع واردشده":"From imported source","ردیابی کلمات کلیدی":"Keyword tracking","این جدول هیچ رتبه‌ای را حدس نمی‌زند. هر ردیف باید Source داشته باشد.":"This table never guesses rankings. Every row must have a source.","داده رتبه معتبر نداریم":"No valid ranking data","Search Console را متصل کنید یا CSV/JSON خروجی Rank Tracker را Import کنید.":"Connect Search Console or import a Rank Tracker CSV/JSON export.","رقبای ثبت‌شده":"Registered competitors","دامنه‌های منبع‌دار":"Sourced domains","کلمات دارای داده":"Keywords with data","برای مقایسه SERP":"For SERP comparison","Provider خارجی":"External provider","تا اتصال رسمی عدد خارجی ساخته نمی‌شود":"No external metrics are fabricated before a valid connection","داده ساختگی":"Fabricated data","رقبا و داده‌های مقایسه":"Competitors & comparison data","Metrics فقط زمانی نمایش داده می‌شود که همراه Source وارد شده یا Provider متصل باشد.":"Metrics are shown only when imported with a source or supplied by a connected provider.","هنوز رقیبی ثبت نشده است":"No competitors registered yet","دامنه رقیب را اضافه کنید؛ Metrics اختیاری و منبع‌دار هستند.":"Add a competitor domain; metrics are optional and must be sourced.","فعال":"Active","خاموش":"Off","موتورهای تحلیل":"Analysis engines","بخش رقبا تا دریافت داده بیرونی معتبر در حالت Waiting Data می‌ماند.":"Competitor analysis stays in Waiting Data until valid external data is available.","شکاف‌های قابل بررسی":"Reviewable gaps","فرصت‌ها از Keyword dataset موجود استخراج می‌شوند؛ اگر داده رتبه نداریم Empty state نمایش داده می‌شود.":"Opportunities are derived from the available keyword dataset; without ranking data an empty state is shown.","SERP dataset نداریم":"No SERP dataset","Import رتبه یا اتصال Search Console/Provider لازم است.":"Ranking import or a Search Console/provider connection is required.","محتوای نیازمند به‌روزرسانی":"Content needing refresh","قدیمی‌تر از ۱۸۰ روز":"Older than 180 days","محتوای کم‌امتیاز":"Low-scoring content","تقویم آینده":"Upcoming calendar","پیشنهادهای باز":"Open recommendations","از Rule Engine":"From rule engine","موتور به‌روزرسانی محتوا":"Content refresh engine","تازگی، امتیاز محتوا و حجم متن از صفحات واقعی سایت خوانده می‌شود.":"Freshness, content score and word count are read from real site pages.","تقویم انتشار":"Publishing calendar","از وضعیت Future/Draft/Pending خود WordPress خوانده می‌شود.":"Read from native WordPress Future/Draft/Pending status.","مورد زمان‌بندی‌شده نداریم":"No scheduled items","نوشته‌های Draft/Pending/Future اینجا ظاهر می‌شوند.":"Draft/Pending/Future posts appear here.","URL خزش‌شده":"Crawled URLs","Observationهای ذخیره‌شده":"Stored observations","موفق 2xx":"Successful 2xx","پاسخ سالم":"Healthy response","نیازمند بررسی در صورت زنجیره":"Review if chained","URL مشکل‌دار":"Problem URLs","خطای سرور":"Server errors","آخرین URLهای خزش‌شده":"Latest crawled URLs","wp_safe_remote_get فقط URLهای همان دامنه را بررسی می‌کند و SSRF را محدود می‌کند.":"wp_safe_remote_get checks only same-domain URLs and limits SSRF risk.","بله":"Yes","خیر":"No","عملیات سریع Crawl":"Quick crawl actions","خزش کامل به صورت Batch اجرا می‌شود تا به هاست فشار وارد نشود.":"Full crawl runs in batches to avoid overloading hosting.","تاریخچه Crawl":"Crawl history","هر Run وضعیت، تعداد پردازش و خطاهای خودش را نگه می‌دارد.":"Each run records its status, processed count and errors.","موتورهای اصلی سیستم":"Core system engines","هر موتور دارای منبع داده، وضعیت و نقش مشخص است؛ External engine بدون داده به حالت Active جعلی نمی‌رود.":"Every engine has a defined data source, status and role; external engines never fake an Active state without data.","Agentهای عملیاتی":"Operational agents","Agentها تصمیم نهایی سیاسی/تجاری نمی‌گیرند؛ پیشنهاد می‌دهند و تغییرات پرریسک Approval می‌خواهند.":"Agents recommend actions rather than making final business decisions; high-risk changes require approval.","صف پیشنهادهای هوشمند":"Smart recommendation queue","پیشنهادها از Issueهای واقعی ساخته می‌شوند؛ «اعتماد داده» از کامل‌بودن Evidence محلی محاسبه می‌شود و امتیاز اعتبار دامنه ساختگی نیست.":"Recommendations come from real issues; data confidence is calculated from local evidence completeness, not a fabricated domain-authority score.","گردش کار تأیید و بازگشت":"Approval & rollback flow","Proposal → Approval → Apply → Rollback. تغییرات با snapshot قبل و بعد ثبت می‌شوند.":"Proposal → Approval → Apply → Rollback. Changes are recorded with before/after snapshots.","ویرایشگر زنده سئو":"Live SEO editor","تغییرات مستقیماً روی WordPress/WooCommerce ذخیره می‌شوند و سپس همان موجودیت دوباره تحلیل می‌شود.":"Changes are saved directly to WordPress/WooCommerce and the entity is re-analyzed afterward.","موجودیتی انتخاب نشده است":"No entity selected","بعد از اسکن، یک محصول یا نوشته برای ویرایش باز کنید.":"After scanning, open a product or post to edit.","تحلیل زنده":"Live analysis","امتیازها از Rule Engine محلی بعد از آخرین Analyze محاسبه شده‌اند.":"Scores are calculated by the local rule engine after the latest analysis.","رسانه":"Media","راهنمای رفع ایراد":"Remediation guide","Issueها همراه با Rule code و پیشنهاد قابل توضیح نمایش داده می‌شوند.":"Issues are shown with rule codes and explainable recommendations.","RSSهای متصل":"Connected RSS feeds","منابع تنظیم‌شده":"Configured sources","سیگنال بیرونی ذخیره‌شده":"Stored external signals","با URL و زمان مشاهده":"With URL and observation time","سیگنال داخلی":"Internal signals","موجودی و محتوای سایت":"Inventory & site content","رقبای فعال":"Active competitors","دامنه‌های ثبت‌شده":"Registered domains","رادار خبر و بازار":"News & Market Radar","فقط RSSهای تنظیم‌شده و سیگنال‌های واقعی سایت خوانده می‌شوند. خبر ساختگی تولید نمی‌شود.":"Only configured RSS feeds and real site signals are read. No fabricated news is generated.","مدیریت منابع":"Source management","برای هر منبع RSS URL معتبر در تنظیمات وارد کنید.":"Add a valid RSS URL for each source in Settings.","موتورهای فعال":"Active engines","خبر و مقاله مستقل":"Independent news & article engines","آماده اجرا":"Ready to run","Provider یا GitHub معتبر":"Valid provider or GitHub runner","اجرای موفق":"Successful runs","تاریخچه واقعی موتور":"Real engine history","اجرای ناموفق":"Failed runs","خطاها مخفی نمی‌شوند":"Errors are never hidden","موتور محتوای کسب‌وکارمحور":"Business-aware Content Engine","موضوع سایت از داده واقعی WordPress/WooCommerce، دسته‌ها، محصولات و محتوای اخیر ساخته می‌شود؛ موتور هیچ حوزه‌ای را از قبل فرض نمی‌کند.":"The site topic is inferred from real WordPress/WooCommerce data, categories, products and recent content; the engine does not assume a business domain.","حوزه تشخیص‌داده‌شده":"Detected business domain","حوزه حساس: بازبینی انسانی اجباری":"Sensitive domain: human review required","انتشار فقط به‌صورت پیش‌نویس/در انتظار بازبینی":"Output is limited to draft/pending review","فعال‌سازی خودکار بعد از اتصال معتبر":"Auto-enable after a valid connection","Runner پیش‌فرض":"Default runner","ذخیره تنظیمات موتور":"Save engine settings","موتور خبر":"News Engine","موتور نوشته":"Article Engine","آماده":"Ready","نیازمند اتصال":"Needs connection","ساعت روزانه":"Daily time","Provider هوش مصنوعی":"AI provider","Workflow گیت‌هاب (اختیاری)":"GitHub workflow (optional)","نوع نوشته مقصد":"Target post type","وضعیت خروجی":"Output status","بازه تحقیق (ساعت)":"Research window (hours)","تحقیق وب":"Web research","اجرای بعدی":"Next run","مقصد":"Target","اجرای اکنون":"Run now","پروفایل واقعی کسب‌وکار":"Real business profile","این داده‌ها از همین سایت خوانده می‌شوند و پایه انتخاب موضوع‌اند.":"This data is read from the current site and drives topic selection.","سایت":"Site","زبان/Locale":"Language / locale","دسته محصول":"Product categories","نمونه محصول":"Product sample","وابستگی‌ها و ایمنی":"Dependencies & safety","موتور بدون Provider معتبر یا Workflow معتبر اجرا نمی‌شود.":"The engine will not run without a valid provider or workflow.","متصل":"Connected","اختیاری / متصل نیست":"Optional / not connected","بازبینی انسانی":"Human review","اجباری پیش از انتشار عمومی":"Required before public publishing","تاریخچه اجرا و شواهد":"Run history & evidence","هر اجرا منبع، Provider، خروجی و خطا را ثبت می‌کند.":"Every run records sources, provider, output and errors.","هنوز اجرایی ثبت نشده":"No engine runs recorded yet","بعد از اجرای موتور، موضوع، منابع، خروجی و خطاهای واقعی اینجا نمایش داده می‌شود.":"After running an engine, the real topic, sources, output and errors appear here.","زمان":"Time","موتور":"Engine","وضعیت":"Status","موضوع/خروجی":"Topic / output","منابع":"Sources","نتیجه":"Result","منبع":"Source","باز کردن پیش‌نویس":"Open draft","سلامت کل":"Overall health","میانگین موجودیت‌ها":"Entity average","Issue باز":"Open issues","Recommendation باز":"Open recommendations","پیشنهادهای اولویت‌دار":"Prioritized recommendations","Action منتظر تأیید":"Actions awaiting approval","پوشش فعلی":"Current coverage","گزارش عملکرد به تفکیک نوع":"Performance by entity type","میانگین هر مؤلفه از Profileهای واقعی ذخیره‌شده محاسبه می‌شود.":"Each component average is calculated from stored real profiles.","سازنده خروجی":"Export builder","CSV/JSON مستقیم از دیتابیس افزونه تولید می‌شود؛ PDF با Print view مرورگر تهیه می‌شود.":"CSV/JSON is generated directly from the plugin database; PDF is produced using the browser print view.","پرتکرارترین مشکلات":"Most frequent issues","تعداد Issueهای باز به تفکیک Rule code.":"Open issue count grouped by rule code.","اتصال‌های تست‌شده":"Tested connections","فقط بعد از Live Test موفق Connected می‌شود":"Connected only after a successful live test","منابع داده متصل":"Connected data sources","موتور AI متصل":"Connected AI engines","برای «تکمیل با AI» حداقل یک Provider لازم است":"At least one provider is required for “Complete with AI”","ذخیره امن Secrets":"Secure secret storage","Credentialها به مرورگر برگردانده نمی‌شوند":"Credentials are never returned to the browser","نتیجه آخرین تست / منابع کشف‌شده":"Latest test / discovered resources","ثبت شده":"Saved","ذخیره":"Save","تست اتصال":"Test connection","قطع":"Disconnect","آخرین تست:":"Last test:","آخرین Sync:":"Last sync:","بدون تغییر نگه دارید":"Leave unchanged","Bridge 3.3 داخلی":"Embedded Bridge 3.3","کنترل‌پلن عمومی و allow-listed برای WordPress/WooCommerce، SEO، محتوا، رسانه، Snapshot، Rollback، Audit و موتورهای محتوا.":"A generic allow-listed control plane for WordPress/WooCommerce, SEO, content, media, snapshots, rollback, audit and content engines.","اکشن مجاز":"Allow-listed actions","همه عملیات ثبت Audit دارند":"All operations are audited","قابلیت‌ها":"Capabilities","Hard guardها":"Hard guards","اکشن":"Action","اجرای درخواست امن":"Execute safe request","چطور «تکمیل با AI» کار می‌کند؟":"How “Complete with AI” works","AI قبل از اعمال تغییر، Preview می‌سازد؛ قیمت، موجودی و شناسه‌های حساس بدون شواهد معتبر ساخته نمی‌شوند.":"AI builds a preview before applying changes; price, stock and sensitive identifiers are never invented without valid evidence.","قوانین اجرا و Governance":"Execution rules & governance","تغییرات کم‌ریسک هم قابل Approval هستند و تغییرات پرریسک بدون تأیید اجرا نمی‌شوند.":"Even low-risk changes can require approval; high-risk changes never execute without approval.","اتصال‌ها و Providerها":"Connections & providers","Provider بیرونی فقط وقتی Credential محیطی یا Import معتبر وجود داشته باشد Connected نشان داده می‌شود.":"An external provider is shown as Connected only when a valid environment credential or import exists.","بدون Credential/Import":"No credential / import","هسته‌های محلی بدون API بیرونی هم کار می‌کنند؛ موتور داده خارجی در صورت نبود اتصال به Waiting Data می‌رود.":"Local cores can work without external APIs; external-data engines move to Waiting Data when disconnected.","مرکز کنترل موتورهای جست‌وجو و ربات‌های هوش مصنوعی":"Search & AI bot control center","کلیدها فقط روی User-Agentهایی که robots.txt واقعاً می‌تواند کنترل کند اعمال می‌شوند؛ موارد بدون robots token صرفاً مانیتور می‌شوند.":"Switches apply only to User-Agents robots.txt can actually control; entries without a robots token are monitoring-only.","robots فعال":"robots active","پیش‌نمایش":"Preview","فقط رصد":"Monitor only","اعمال سیاست روی robots مجازی":"Apply policy to virtual robots","Rollback robots":"Rollback robots","مشاهده robots.txt":"View robots.txt","رادار منابع خبری":"News source radar","هر URL باید RSS/Atom معتبر و مورد اعتماد باشد. افزونه بدون اجازه منبع پیش‌فرض اضافه نمی‌کند.":"Every URL must be a valid trusted RSS/Atom source. The plugin does not add default sources without permission.","وضعیت دیتابیس و نسخه":"Database & version status","نسخه دیتابیس 3.0 جداول SEO OS را به صورت additive ایجاد می‌کند و داده‌های نسخه 2.0 را حذف نمی‌کند.":"The 3.0 database migration creates SEO OS tables additively and does not delete 2.0 data.","این Workspace در حال آماده‌سازی است":"This workspace is being prepared","ساختار ثبت شده اما نمای تخصصی هنوز تعریف نشده است.":"The workspace is registered, but its specialized view is not defined yet.","بستن":"Close","قوانین و اتوماسیون":"Rules & automation","اتصال‌ها":"Connections","موتورها":"Engines","سیستم":"System","اسکن خودکار":"Automatic scan","اصلاح امن خودکار":"Automatic safe fixes","الزام تأیید انسانی":"Require human approval","Batch اسکن":"Scan batch","Batch Crawl":"Crawl batch","ذخیره تنظیمات":"Save settings","Search crawlerها":"Search crawlers","Training crawlerها":"Training crawlers","User-triggered / Assistant":"User-triggered / Assistant","Analytics/API crawlerها":"Analytics / API crawlers","ذخیره سیاست":"Save policy","خانواده":"families","قابل کنترل":"controllable","قابل رصد":"monitorable","ذخیره منابع":"Save sources","هسته عملیاتی فعال":"Operational core active","ناوبری K20 AI Press":"K20 AI Press navigation","جمع کردن منو":"Collapse menu","باز کردن منو":"Open navigation","آماده":"Ready","اندازه‌گیری نشده":"Not measured","خطای ناشناخته":"Unknown error","میانگین موجودیت‌های تحلیل‌شده":"Average of analyzed entities","پیشنهادهای باز و واقعی":"Real open recommendations","محصول + نوشته + صفحه + خبر":"Products + posts + pages + news","Issueهای باز":"Open issues","پوشش ممیزی محلی":"Local audit coverage","داده موجود است اما برای نمایش تغییر معنی‌دار هنوز تاریخچه کافی نداریم.":"Data exists, but there is not enough history to show a meaningful change yet.","کل":"Overall","این فیلد خالی است و نیاز به تکمیل دارد.":"This field is empty and needs completion.","این مقدار نیازمند بازبینی است.":"This value needs review.","این مقدار ثبت شده است.":"This value is recorded.","انتخاب کنید":"Select","مقادیر انتخاب‌شده آماده ذخیره هستند.":"Selected values are ready to save.","هنوز مقداری انتخاب نشده است.":"Nothing selected yet.","گزینه‌ای در سایت پیدا نشد.":"No options were found on the site.","مقادیر فعلی از سایت خوانده شده‌اند.":"Current values were read from the site.","تصاویر محصول":"Product images","تصویری برای این محصول ثبت نشده است.":"No images are registered for this product.","ALT ثبت نشده":"ALT not set","قبل":"Before","بعد":"After","تغییر پیشنهادی قبل از اجرا با Snapshot فعلی مقایسه می‌شود. اگر موجودیت بعد از پیشنهاد تغییر کرده باشد، اجرا Fail-closed متوقف می‌شود.":"The proposed change is compared with the current snapshot before execution. If the entity changed after the proposal, execution stops fail-closed.","تأیید و اجرا":"Approve & apply","اقدام اجرا شد":"Action applied","تغییر ذخیره و Audit ثبت شد.":"The change was saved and audited.","اجرای اقدام ناموفق بود":"Action failed","رد پیشنهاد":"Reject proposal","پیشنهاد رد شد":"Proposal rejected","خطا":"Error","اجرا":"Apply","اجرا شد":"Applied","بازگشت به قبل":"Rollback","Rollback انجام شد":"Rollback completed","Rollback ناموفق بود":"Rollback failed","پیش‌نمایش اقدام":"Action preview","عنوان":"Title","عنوان سئو":"SEO title","توضیحات متا":"Meta description","توضیح کوتاه":"Short description","توضیح کامل":"Full description","خلاصه":"Excerpt","دسته‌بندی‌ها":"Categories","برند":"Brand","ویژگی‌ها":"Attributes","ALT تصاویر":"Image ALT","مدل":"Model","وزن":"Weight","طول":"Length","عرض":"Width","ارتفاع":"Height","ALT رسانه":"Media ALT","پیش‌نمایش تکمیل با AI":"AI completion preview","نیازمند تأیید انسانی":"Human approval required","منابع تحقیق وب":"Web research sources","اعمال فیلدهای انتخاب‌شده":"Apply selected fields","لغو":"Cancel","فیلدی انتخاب نشده":"No field selected","حداقل یک تغییر را انتخاب کنید.":"Select at least one change.","تکمیل با AI اعمال شد":"AI completion applied","اعمال تغییر ناموفق بود":"Failed to apply changes","تکمیل با AI":"Complete with AI","هیچ موتور AI با تست اتصال موفق فعال نیست.":"No AI engine with a verified connection is active.","موتور، دامنه تکمیل و حالت تحقیق را انتخاب کنید. هیچ تغییری قبل از Preview و تأیید شما ذخیره نمی‌شود.":"Choose the AI engine, completion scope and research mode. Nothing is saved before preview and your approval.","موتور AI":"AI engine","دامنه تکمیل":"Completion scope","فقط فیلدهای خالی":"Missing fields only","فیلدهای خالی + ضعیف":"Missing + weak fields","فقط SEO":"SEO only","فقط محتوا":"Content only","تحقیق وب منبع‌دار (در حال حاضر فقط OpenAI Web Search)":"Sourced web research (currently OpenAI Web Search only)","ساخت پیش‌نمایش AI":"Build AI preview","انتخاب موتور تکمیل با AI":"Choose AI completion engine","بدون عنوان":"Untitled","مشاهده صفحه":"View page","امتیاز چندبعدی":"Multi-dimensional score","ویرایش داده واقعی":"Edit real data","عنوان رسانه":"Media title","ALT فعلی ثبت شده است.":"Current ALT is recorded.","ALT خالی است؛ متن توصیفی و واقعی وارد کنید.":"ALT is empty; enter factual descriptive text.","عنوان صفحه":"Page title","توضیح کوتاه محصول":"Product short description","توضیح کامل محصول":"Product full description","GTIN واقعی":"Verified GTIN","شناسه موجود است.":"Identifier is present.","فقط GTIN واقعی سازنده/GS1 را وارد کنید؛ سیستم شناسه نمی‌سازد.":"Enter only a real manufacturer/GS1 GTIN; the system does not generate identifiers.","MPN موجود است.":"MPN is present.","در صورت وجود شناسه سازنده وارد شود.":"Enter the manufacturer identifier when available.","مدل محصول ثبت شده است.":"Product model is recorded.","اگر سازنده مدل مشخصی اعلام کرده وارد کنید؛ حدس نزنید.":"Enter a model only when the manufacturer specifies one; do not guess.","واحد همان واحد وزن تنظیم‌شده در WooCommerce است.":"Uses the weight unit configured in WooCommerce.","واحد همان واحد ابعاد تنظیم‌شده در WooCommerce است.":"Uses the dimension unit configured in WooCommerce.","ذخیره تغییرات":"Save changes","تغییرات ذخیره شد":"Changes saved","تحلیل مجدد انجام شد.":"Re-analysis completed.","ذخیره ناموفق بود":"Save failed","پیشنهاد امن ساخته نشد":"Safe proposal could not be created","تنظیمات ذخیره شد":"Settings saved","ذخیره تنظیمات ناموفق بود":"Failed to save settings","تنظیمات اتصال ذخیره شد":"Connection settings saved","برای سبزشدن اتصال، تست زنده را اجرا کنید.":"Run the live test to verify and activate the connection.","ذخیره اتصال ناموفق بود":"Failed to save connection","تست اتصال موفق بود":"Connection test passed","Provider با پاسخ واقعی API تأیید شد.":"Provider was verified with a real API response.","تست اتصال ناموفق بود":"Connection test failed","همگام‌سازی انجام شد":"Sync completed","Sync ناموفق بود":"Sync failed","اتصال قطع شد":"Disconnected","قطع اتصال ناموفق بود":"Disconnect failed","Workflow اجرا شد":"Workflow dispatched","اجرای Workflow ناموفق بود":"Workflow dispatch failed","سیاست ربات‌ها ذخیره شد":"Bot policy saved","برای اثر روی robots.txt، دکمه اعمال سیاست را بزنید.":"Use Apply policy to affect robots.txt.","ذخیره سیاست ناموفق بود":"Failed to save policy","سیاست robots اعمال شد":"robots policy applied","نسخه قبلی برای Rollback نگه‌داری شد.":"Previous version was retained for rollback.","اعمال robots ناموفق بود":"Failed to apply robots policy","منابع رادار ذخیره شد":"Radar sources saved","رادار به‌روزرسانی شد":"Radar refreshed","به‌روزرسانی رادار ناموفق بود":"Radar refresh failed","Import کلمات کلیدی / رتبه":"Import keywords / rankings","داده‌ای وارد نشده است.":"No data was provided.","هیچ ردیف قابل Import پیدا نشد.":"No importable rows found.","Import انجام شد":"Import completed","Import ناموفق بود":"Import failed","Import داده رتبه و Search Console":"Import ranking & Search Console data","افزودن رقیب":"Add competitor","دامنه":"Domain","نام نمایشی":"Display name","ذخیره رقیب":"Save competitor","رقیب ثبت شد":"Competitor saved","ثبت رقیب ناموفق بود":"Failed to save competitor","رقیب جدید":"New competitor","داده منبع‌دار":"Sourced data","بررسی URL داخلی":"Inspect internal URL","شروع بررسی":"Start inspection","زمان":"Time","نتیجه بررسی URL":"URL inspection result","Crawl ناموفق بود":"Crawl failed","خروجی ساخته شد":"Export created","فایل آماده شد.":"File ready.","خروجی ناموفق بود":"Export failed","اسکن کامل شد":"Full scan completed","اسکن متوقف شد":"Scan stopped","خطای نامشخص":"Unknown error","اسکن شروع شد":"Scan started","پردازش Batch است تا فشار ناگهانی روی سایت ایجاد نشود.":"Processing is batched to avoid sudden load on the site.","شروع اسکن ناموفق بود":"Failed to start scan","خزش داخلی و کنترل وضعیت HTTP":"Internal crawl & HTTP status checks","تحلیل فنی، محتوا و اسکیما":"Technical, content & schema analysis","اعتبارسنجی داده محصول":"Product data validation","ALT، ابعاد و حجم":"ALT, dimensions & size","Link graph و صفحات یتیم":"Link graph & orphan pages","رتبه، CTR و Impression":"Rank, CTR & impressions","SERP و رقبا":"SERP & competitors","شواهد و Citation readiness":"Evidence & citation readiness","داده خام از سایت و Providerها":"Raw data from the site and providers","Issue، شکاف و علت ریشه‌ای":"Issues, gaps & root causes","پیشنهاد قابل توضیح و کم‌ریسک":"Explainable, low-risk recommendations","Approval، Apply و Rollback":"Approval, apply & rollback"});
  const UI_EN_EXTRA = Object.freeze({"بازبینی":"Review","باز کردن":"Open","بررسی":"Review","مشاهده و اصلاح":"View & fix","ALT فعلی":"Current ALT","اصلاح":"Fix","ویرایش صفحه":"Edit page","یک یا چند فیلد مهم نیازمند تکمیل است.":"One or more important fields need completion.","توضیح قابل ممیزی درباره مشکل و مسیر اصلاح امن.":"Auditable explanation of the issue and safe remediation path.","Canonical نیازمند بازبینی":"Canonical needs review","عنوان سئو کوتاه است":"SEO title is too short","SKU ثبت نشده":"SKU is missing","صفحه خطای 404 دارد":"Page returns 404","ALT تصویر ناقص":"Image ALT is incomplete","همه":"All","سالم":"Healthy","اسکن محصولات":"Scan products","قیمت/موجودی":"Price / stock","نام محصول":"Product name","دسته‌بندی":"Category","قیمت":"Price","وضعیت موجودی":"Stock status","رتبه سایت":"Site rank","محتوا و متا":"Content & meta","ساختار":"Structure","محصول":"Product","میانبرهای ویرایش":"Editing shortcuts","هدف عملیاتی ۲۰ تا ۶۵ نویسه":"Operational target: 20–65 characters","ذخیره و تحلیل مجدد":"Save & re-analyze","پیشنهاد اصلاح امن":"Propose safe fix","رتبه":"Rank","تعداد کلمه":"Word count","تازگی":"Freshness","اسکن رسانه":"Scan media","ALT، ابعاد، حجم و Hash واقعی":"Real ALT, dimensions, size & hash","مدیریت افزونه تبدیل تصویر فعال سایت":"Manage the site’s active image-conversion plugin","تشخیص تکراری":"Find duplicates","بازسازی SHA-256 و گروه‌های Duplicate":"Rebuild SHA-256 and duplicate groups","داده از موجودیت واقعی سایت":"Data from a real site entity","دسته‌های محصول":"Product categories","برچسب‌ها":"Tags","بازسازی گراف لینک داخلی":"Rebuild internal-link graph","قابل دسترس":"Reachable","چند مورد نیازمند بازبینی":"Several items need review","کنترل شده":"Controlled","Rule Engine فعال":"Local rule engine","مشکل":"Issue","آخرین مشاهده":"Last observed","رتبه فعلی":"Current rank","قبلی":"Previous","تغییر":"Change","اولویت‌بندی فرصت‌ها":"Opportunity prioritization","اولویت‌بندی فرصت‌ها و شکاف‌ها":"Opportunity & gap prioritization","خزش و سلامت فنی":"Crawl & technical health","بهینه‌سازی محتوا":"Content optimization","تصاویر و ALT":"Images & ALT","لینک‌سازی داخلی":"Internal linking","رقبا و SERP":"Competitors & SERP","شواهد و GEO":"Evidence & GEO","تأیید":"Approval","برای Excel و تحلیل":"For Excel and analysis","برای API و آرشیو":"For API and archive","نمای چاپی بهینه":"Print-optimized view","سن به‌روزرسانی":"Age since update","شروع Crawl جدید":"Start new crawl","تمام صفحات منتشرشده":"All published pages","بررسی URL":"Inspect URL","فقط دامنه همین سایت":"This site domain only","باز کردن فایل فعلی":"Open current file","به‌روزرسانی رادار":"Refresh radar","مدیریت RSSها":"Manage RSS feeds","رادار محلی و RSSهای تأییدشده فعال هستند.":"Local radar and approved RSS feeds are active.","آخرین Import امروز":"Last import today","Property متصل":"Property connected","Feed فعال":"Feed active","API فعال":"API active","Rule Engine محلی":"Local rule engine","شدت":"Severity","تعداد":"Count","صفحه":"Page","صفحه هدف":"Target page","ایراد":"issues","از 100":"out of 100","تصاویر":"Images","ویرایش همه فیلدهای قابل‌ویرایش در یک فرم":"Edit all supported fields in one form","ذخیره تنظیمات":"Save settings","ذخیره منابع":"Save sources","اعمال سیاست روی robots مجازی":"Apply policy to virtual robots","اعتماد داده":"Data confidence","مورد کم‌پوشش":"thin items","مورد":"items","نویسه":"characters","روز":"days","کلمه":"words","خانواده":"families","قابل کنترل":"controllable","قابل رصد":"monitorable"});
  const translatePattern = (key) => {
    let match = String(key || '').match(/^(\d+)\s*٪$/u);
    if (match) return `${match[1]}%`;
    match = String(key || '').match(/^(\d+)\s+بحرانی$/u);
    if (match) return `${match[1]} critical`;
    match = String(key || '').match(/^(\d+)\s+مورد$/u);
    if (match) return `${match[1]} item${match[1] === '1' ? '' : 's'}`;
    match = String(key || '').match(/^(\d+)\s+مورد\s+کم‌پوشش$/u);
    if (match) return `${match[1]} thin item${match[1] === '1' ? '' : 's'}`;
    match = String(key || '').match(/^(\d+)\s+روز$/u);
    if (match) return `${match[1]} days`;
    match = String(key || '').match(/^(\d+)\s+نویسه$/u);
    if (match) return `${match[1]} characters`;
    match = String(key || '').match(/^(\d+)\s+کلمه\s*·\s*(\d+)\s+روز$/u);
    if (match) return `${match[1]} words · ${match[2]} days`;
    match = String(key || '').match(/^(\d+)\s+از\s+(\d+)$/u);
    if (match) return `${match[1]} of ${match[2]}`;
    match = String(key || '').match(/^اعتماد\s+داده\s+(\d+)٪$/u);
    if (match) return `Data confidence ${match[1]}%`;
    match = String(key || '').match(/^(\d+)\s+خانواده$/u);
    if (match) return `${match[1]} families`;
    match = String(key || '').match(/^(\d+)\s+قابل\s+کنترل$/u);
    if (match) return `${match[1]} controllable`;
    match = String(key || '').match(/^(\d+)\s+قابل\s+رصد$/u);
    if (match) return `${match[1]} monitorable`;
    return null;
  };
  const translateLookup = (key) => { const value = UI_EN[key] || UI_EN_EXTRA[key] || translatePattern(key); return value ? (window.wp?.i18n?.__(String(value), 'k20-ai-press') || value) : null; };


  const translateUiToEnglish = () => {
    if (!shell || boot.uiLanguage !== 'en') return;
    const skip = 'script,style,pre,code,textarea,[data-no-ui-translate]';
    const walker = document.createTreeWalker(shell, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        const parent = node.parentElement;
        if (!parent || parent.closest(skip)) return NodeFilter.FILTER_REJECT;
        const key = String(node.nodeValue || '').trim();
        if (!key) return NodeFilter.FILTER_REJECT;
        if (translateLookup(key) || /^لایه\s+[0-9۰-۹]+$/u.test(key)) return NodeFilter.FILTER_ACCEPT;
        return NodeFilter.FILTER_REJECT;
      }
    });
    const nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);
    nodes.forEach((node) => {
      const raw = String(node.nodeValue || '');
      const key = raw.trim();
      let translated = translateLookup(key);
      if (!translated && /^لایه\s+[0-9۰-۹]+$/u.test(key)) translated = key.replace(/^لایه\s+/u, 'Layer ');
      if (!translated) return;
      const lead = raw.match(/^\s*/)?.[0] || '';
      const tail = raw.match(/\s*$/)?.[0] || '';
      node.nodeValue = `${lead}${translated}${tail}`;
    });
    ['aria-label', 'title', 'placeholder', 'data-tip'].forEach((attr) => {
      shell.querySelectorAll(`[${attr}]`).forEach((node) => {
        const value = node.getAttribute(attr);
        if (value && translateLookup(value)) node.setAttribute(attr, translateLookup(value));
      });
    });
  };
  translateUiToEnglish();
  const translateUiValue = (value) => { const text = String(value ?? ''); return boot.uiLanguage === 'en' ? (translateLookup(text) || text) : text; };
  const wpTranslate = (text) => window.wp?.i18n?.__(String(text ?? ''), 'k20-ai-press') || String(text ?? '');
  const uiText = (fa, en) => boot.uiLanguage === 'en' ? wpTranslate(en) : fa;

  // 3.0.4 UI mirrors server-side capabilities: store managers may inspect system state,
  // but only administrators can change credentials, providers, engines, Bridge or governance.
  if (boot.user?.canSystem === false) {
    const systemSelectors = [
      '[data-connection-form]', '[data-content-engine-settings]', '[data-settings-form]',
      '[data-bot-policy-form]', '.k30-bridge-tool'
    ];
    systemSelectors.forEach((selector) => {
      $$(selector).forEach((root) => {
        $$('input,select,textarea,button', root).forEach((control) => { control.disabled = true; control.setAttribute('aria-disabled', 'true'); });
        $$('a', root).forEach((link) => { link.setAttribute('aria-disabled', 'true'); link.tabIndex = -1; link.addEventListener('click', (event) => event.preventDefault()); });
        root.classList.add('k30-system-readonly');
      });
    });
    $$('[data-run-scan]').forEach((button) => {
      button.disabled = true;
      button.setAttribute('aria-disabled', 'true');
      button.setAttribute('title', uiText('اجرای اسکن فقط برای مدیر سیستم مجاز است.', 'Only system administrators can run scans.'));
    });
  }

  const api = async (path, options = {}) => {
    const url = `${String(boot.restBase || '').replace(/\/$/, '')}${path.startsWith('/') ? path : `/${path}`}`;
    const headers = new Headers(options.headers || {});
    headers.set('X-WP-Nonce', boot.nonce || '');
    if (options.body && typeof options.body !== 'string') {
      headers.set('Content-Type', 'application/json');
      options.body = JSON.stringify(options.body);
    }
    const response = await fetch(url, { credentials: 'same-origin', ...options, headers });
    let data = null;
    const text = await response.text();
    if (text) {
      try { data = JSON.parse(text); } catch { data = { message: text }; }
    }
    if (!response.ok) {
      const error = new Error(data?.message || `HTTP ${response.status}`);
      error.status = response.status;
      error.code = data?.code || 'http_error';
      error.data = data;
      throw error;
    }
    return data;
  };

  const runAbility = async (name, input = {}, confirmed = false) => api(`/abilities/${encodeURIComponent(name)}`, { method: 'POST', body: { input, confirmed } });

  const el = (tag, className = '', text = '') => {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== '') node.textContent = translateUiValue(text);
    return node;
  };

  const icon = (name) => {
    const node = el('span', `dashicons dashicons-${name}`);
    node.setAttribute('aria-hidden', 'true');
    return node;
  };

  const toast = (title, message = '', type = 'success', timeout = 4200) => {
    const stack = $('[data-toast-stack]');
    if (!stack) return;
    const box = el('div', `k30-toast ${type === 'error' ? 'error' : ''}`);
    box.setAttribute('role', type === 'error' ? 'alert' : 'status');
    box.setAttribute('aria-atomic', 'true');
    box.append(icon(type === 'error' ? 'warning' : 'yes-alt'));
    const copy = el('div');
    copy.append(el('b', '', title));
    if (message) copy.append(el('p', '', message));
    box.append(copy);
    stack.append(box);
    window.setTimeout(() => box.remove(), timeout);
  };

  const errorText = (error) => error?.message || uiText('خطای ناشناخته', 'Unknown error');

  // Sidebar state.
  if (shell) {
    const saved = storageGet('k20ai_v3_sidebar');
    if (saved === 'collapsed' && window.innerWidth > 900) shell.classList.add('sidebar-collapsed');
  }
  const syncSidebarA11y = () => {
    if (!shell) return;
    const expanded = window.innerWidth <= 1000 ? shell.classList.contains('sidebar-open') : !shell.classList.contains('sidebar-collapsed');
    $$('[data-sidebar-toggle]').forEach((button) => button.setAttribute('aria-expanded', expanded ? 'true' : 'false'));
  };
  $$('[data-sidebar-toggle]').forEach((button) => button.addEventListener('click', () => {
    if (!shell) return;
    if (window.innerWidth <= 1000) shell.classList.toggle('sidebar-open');
    else {
      shell.classList.toggle('sidebar-collapsed');
      storageSet('k20ai_v3_sidebar', shell.classList.contains('sidebar-collapsed') ? 'collapsed' : 'open');
    }
    syncSidebarA11y();
  }));
  syncSidebarA11y();
  $$('.k30-nav-item').forEach((link) => link.addEventListener('click', () => {
    if (window.innerWidth <= 1000) shell?.classList.remove('sidebar-open');
  }));
  window.addEventListener('resize', () => { if (window.innerWidth > 1000) shell?.classList.remove('sidebar-open'); syncSidebarA11y(); });

  // Canvas line charts, intentionally dependency-free to keep wp-admin light.
  const drawLineChart = (host) => {
    const canvas = $('canvas', host);
    if (!canvas) return;
    let rows = [];
    try { rows = JSON.parse(host.dataset.lineChart || '[]'); } catch { rows = []; }
    const key = host.dataset.valueKey || 'score';
    const labelKey = host.dataset.labelKey || 'date';
    const points = rows.map((row) => ({ label: row?.[labelKey], value: Number(row?.[key]) })).filter((p) => Number.isFinite(p.value));
    const meaningful = points.length >= 2 && points.some((p, i) => i > 0 && p.value !== points[0].value);
    canvas.setAttribute('role', 'img');
    if (points.length) {
      const valuesForA11y = points.map((point) => point.value);
      const first = points[0]?.value; const last = points[points.length - 1]?.value;
      canvas.setAttribute('aria-label', uiText(`نمودار روند با ${points.length} نقطه؛ کمینه ${Math.min(...valuesForA11y)}، بیشینه ${Math.max(...valuesForA11y)}، ابتدا ${first} و انتها ${last}.`, `Trend chart with ${points.length} points; minimum ${Math.min(...valuesForA11y)}, maximum ${Math.max(...valuesForA11y)}, first ${first}, last ${last}.`));
    } else canvas.setAttribute('aria-label', uiText('نمودار روند بدون داده کافی.', 'Trend chart without enough data.'));
    if (points.length < 2) {
      host.classList.add('is-empty');
      return;
    }
    host.classList.remove('is-empty');
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const rect = host.getBoundingClientRect();
    const w = Math.max(300, rect.width);
    const h = Math.max(210, rect.height);
    canvas.width = Math.round(w * dpr);
    canvas.height = Math.round(h * dpr);
    canvas.style.width = `${w}px`;
    canvas.style.height = `${h}px`;
    const ctx = canvas.getContext('2d');
    ctx.scale(dpr, dpr);
    const pad = { t: 18, r: 24, b: 34, l: 54 };
    const iw = w - pad.l - pad.r;
    const ih = h - pad.t - pad.b;
    const values = points.map((p) => p.value);
    let min = Math.min(...values);
    let max = Math.max(...values);
    if (min === max) { min = Math.max(0, min - 10); max = Math.min(100, max + 10); }
    if (key === 'score') { min = Math.min(min, 40); max = Math.max(max, 100); }
    const x = (i) => pad.l + (points.length === 1 ? iw / 2 : (i * iw) / (points.length - 1));
    const y = (v) => pad.t + ih - ((v - min) / Math.max(1, max - min)) * ih;

    const dark = shell?.dataset.theme === 'dark';
    const gridColor = dark ? '#2a3140' : '#edf0f4';
    const labelColor = dark ? '#9aa5ba' : '#8d97a5';
    const lineColor = dark ? '#a98cff' : '#6736df';
    const pointFill = dark ? '#121620' : '#fff';
    ctx.strokeStyle = gridColor; ctx.lineWidth = 1;
    ctx.fillStyle = labelColor; ctx.font = '10px Tahoma, sans-serif';
    ctx.textAlign = 'right';
    ctx.textBaseline = 'middle';
    for (let i = 0; i <= 4; i++) {
      const yy = pad.t + (i * ih) / 4;
      ctx.beginPath(); ctx.moveTo(pad.l, yy); ctx.lineTo(w - pad.r, yy); ctx.stroke();
      const label = Math.round(max - (i * (max - min)) / 4);
      ctx.fillText(String(label), pad.l - 9, yy);
    }
    ctx.textBaseline = 'alphabetic';
    const gradient = ctx.createLinearGradient(0, pad.t, 0, h - pad.b);
    gradient.addColorStop(0, dark ? 'rgba(169,140,255,.22)' : 'rgba(93,46,232,.18)');
    gradient.addColorStop(1, 'rgba(93,46,232,0)');
    ctx.beginPath();
    points.forEach((p, i) => { const xx = x(i), yy = y(p.value); if (i === 0) ctx.moveTo(xx, yy); else ctx.lineTo(xx, yy); });
    ctx.lineTo(x(points.length - 1), h - pad.b); ctx.lineTo(x(0), h - pad.b); ctx.closePath();
    ctx.fillStyle = gradient; ctx.fill();
    ctx.beginPath();
    points.forEach((p, i) => { const xx = x(i), yy = y(p.value); if (i === 0) ctx.moveTo(xx, yy); else ctx.lineTo(xx, yy); });
    ctx.strokeStyle = lineColor; ctx.lineWidth = 2.2; ctx.lineJoin = 'round'; ctx.lineCap = 'round'; ctx.stroke();
    points.forEach((p, i) => {
      if (i % Math.max(1, Math.floor(points.length / 7)) !== 0 && i !== points.length - 1) return;
      const xx = x(i), yy = y(p.value);
      ctx.beginPath(); ctx.arc(xx, yy, 3, 0, Math.PI * 2); ctx.fillStyle = pointFill; ctx.fill(); ctx.strokeStyle = lineColor; ctx.lineWidth = 2; ctx.stroke();
      const date = String(p.label || '').slice(5);
      ctx.fillStyle = labelColor; ctx.font = '9px Tahoma'; ctx.textAlign = 'center'; ctx.fillText(date, xx, h - 9);
    });
    if (!meaningful) {
      const empty = $('.k30-chart-empty', host);
      if (empty) empty.textContent = 'داده موجود است اما برای نمایش تغییر معنی‌دار هنوز تاریخچه کافی نداریم.';
    }
  };
  const redrawCharts = () => $$('[data-line-chart]').forEach(drawLineChart);
  redrawCharts();
  let resizeTimer = null;
  window.addEventListener('resize', () => { clearTimeout(resizeTimer); resizeTimer = setTimeout(redrawCharts, 180); });

  // Modal.
  const modal = $('[data-modal]');
  const backdrop = $('[data-modal-backdrop]');
  const modalBody = $('[data-modal-body]');
  const modalTitle = $('[data-modal-title]');
  const modalKicker = $('[data-modal-kicker]');
  const modalStatus = $('[data-modal-status]');
  let modalReturnFocus = null;
  const closeModal = () => {
    if (modal?.open) modal.close();
    else modal?.removeAttribute('open');
    if (backdrop) backdrop.hidden = true;
    document.documentElement.style.overflow = '';
    if (modalReturnFocus instanceof HTMLElement && document.contains(modalReturnFocus)) modalReturnFocus.focus({ preventScroll: true });
    modalReturnFocus = null;
  };
  const openModal = (title, bodyNode, options = {}) => {
    if (!modal || !modalBody) return;
    modalTitle.textContent = translateUiValue(title);
    modalKicker.textContent = translateUiValue(options.kicker || 'K20 AI Press · SEO OS');
    modalStatus.textContent = '';
    modalStatus.className = 'k30-modal-status';
    if (options.status) {
      const pill = el('span', `k30-pill ${options.tone || 'neutral'}`, options.status);
      modalStatus.replaceChildren(pill);
    } else modalStatus.replaceChildren();
    modalBody.replaceChildren(bodyNode);
    modalReturnFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    backdrop.hidden = false;
    if (typeof modal.showModal === 'function') modal.showModal(); else modal.setAttribute('open', 'open');
    document.documentElement.style.overflow = 'hidden';
    window.requestAnimationFrame(() => $('[data-modal-close]', modal)?.focus({ preventScroll: true }));
  };
  $('[data-modal-close]')?.addEventListener('click', closeModal);
  backdrop?.addEventListener('click', closeModal);
  modal?.addEventListener('cancel', (event) => { event.preventDefault(); closeModal(); });

  const loadingNode = (message = 'در حال دریافت داده واقعی…') => {
    const wrap = el('div', 'k30-empty');
    wrap.append(icon('update-alt'));
    wrap.append(el('strong', '', message));
    return wrap;
  };

  const scoreTone = (value) => {
    const v = Number(value);
    if (!Number.isFinite(v)) return 'neutral';
    if (v >= 85) return 'success';
    if (v >= 60) return 'warning';
    return 'danger';
  };
  const severityTone = (severity) => severity === 'critical' ? 'danger' : severity === 'warning' ? 'warning' : 'info';

  const pill = (label, tone = 'neutral') => el('span', `k30-pill ${tone}`, label);

  const createMetrics = (profile) => {
    const grid = el('div', 'k30-modal-metrics');
    const metrics = [
      ['کل', profile.score_total], ['فنی', profile.score_technical], ['محتوا', profile.score_content], ['اسکیما', profile.score_schema], ['رسانه', profile.score_media], ['تجارت', profile.score_commerce],
    ];
    metrics.forEach(([label, value]) => {
      const box = el('div'); box.append(el('span', '', label));
      const strong = el('strong', `k30-score-text ${scoreTone(value)}`, value ?? '—'); box.append(strong); grid.append(box);
    });
    return grid;
  };

  const fieldState = (value, warning = false) => {
    const empty = value == null || value === '' || (Array.isArray(value) && value.length === 0);
    if (empty) return 'danger';
    if (warning) return 'warning';
    return 'success';
  };

  const inputField = (label, name, value = '', opts = {}) => {
    const labelNode = el('label', `k30-edit-field is-${fieldState(value, opts.warning)}`);
    labelNode.dataset.field = name;
    labelNode.append(el('span', 'k30-edit-label', label));
    let input;
    if (opts.type === 'textarea') {
      input = el('textarea'); input.rows = opts.rows || 3; input.value = value || '';
    } else if (opts.type === 'select') {
      input = el('select');
      (opts.options || []).forEach((option) => {
        const opt = el('option', '', option.label ?? option.value ?? '');
        opt.value = String(option.value ?? '');
        if (String(value ?? '') === opt.value) opt.selected = true;
        input.append(opt);
      });
    } else {
      input = el('input'); input.type = opts.type || 'text'; input.value = value ?? '';
    }
    input.name = name;
    if (opts.placeholder) input.placeholder = opts.placeholder;
    if (opts.disabled) { input.disabled = true; input.setAttribute('aria-disabled', 'true'); labelNode.classList.add('is-readonly'); }
    labelNode.append(input);
    const liveWarning = (current) => {
      const text = String(current ?? '').trim();
      if (name === 'seo_title') return text !== '' && (text.length < 20 || text.length > 65);
      if (name === 'meta_description') return text !== '' && (text.length < 70 || text.length > 180);
      return Boolean(opts.warning);
    };
    const note = el('small', 'k30-edit-note');
    const syncState = () => {
      const state = fieldState(input.value, liveWarning(input.value));
      labelNode.classList.remove('is-danger', 'is-warning', 'is-success');
      labelNode.classList.add(`is-${state}`);
      if (opts.note) note.textContent = opts.note;
      else if (state === 'danger') note.textContent = translateUiValue('این فیلد خالی است و نیاز به تکمیل دارد.');
      else if (state === 'warning') note.textContent = translateUiValue('این مقدار نیازمند بازبینی است.');
      else note.textContent = translateUiValue('این مقدار ثبت شده است.');
    };
    input.addEventListener('input', syncState);
    input.addEventListener('change', syncState);
    labelNode.append(note);
    syncState();
    return { node: labelNode, input };
  };

  const checkboxDropdown = (label, name, options = [], selected = [], note = '') => {
    const wrap = el('div', `k30-edit-field k30-dropdown-field is-${fieldState(selected)}`);
    wrap.dataset.field = name;
    wrap.append(el('span', 'k30-edit-label', label));
    const details = el('details', 'k30-check-dropdown');
    const summary = el('summary');
    const selectedSet = new Set((selected || []).map((x) => String(x)));
    const updateSummary = () => {
      const checked = $$('input:checked', details);
      summary.textContent = checked.length ? uiText(`${checked.length} مورد انتخاب شده`, `${checked.length} selected`) : translateUiValue('انتخاب کنید');
      wrap.classList.remove('is-danger', 'is-warning', 'is-success');
      wrap.classList.add(checked.length ? 'is-success' : 'is-danger');
      const hint = $('.k30-edit-note', wrap);
      if (hint) hint.textContent = note ? translateUiValue(note) : (checked.length ? translateUiValue('مقادیر انتخاب‌شده آماده ذخیره هستند.') : translateUiValue('هنوز مقداری انتخاب نشده است.'));
    };
    details.append(summary);
    const menu = el('div', 'k30-check-menu');
    if (!options.length) menu.append(el('p', 'k30-check-empty', 'گزینه‌ای در سایت پیدا نشد.'));
    options.forEach((option) => {
      const row = el('label'); const checkbox = el('input'); checkbox.type = 'checkbox'; checkbox.value = String(option.id ?? option.value ?? ''); checkbox.name = `${name}[]`;
      if (selectedSet.has(checkbox.value)) checkbox.checked = true;
      row.append(checkbox, el('span', '', option.label ?? option.name ?? option.value ?? ''));
      checkbox.addEventListener('change', updateSummary); menu.append(row);
    });
    details.append(menu); wrap.append(details);
    wrap.append(el('small', 'k30-edit-note', note || (selectedSet.size ? 'مقادیر فعلی از سایت خوانده شده‌اند.' : 'هنوز مقداری انتخاب نشده است.')));
    updateSummary();
    return { node: wrap, details, values: () => $$('input:checked', details).map((x) => Number(x.value)).filter(Boolean) };
  };

  const imageGallery = (items = []) => {
    const section = el('div', 'k30-modal-section'); section.append(el('h3', '', 'تصاویر محصول'));
    const grid = el('div', 'k30-modal-image-grid');
    if (!items.length) {
      grid.append(el('p', 'k30-check-empty', 'تصویری برای این محصول ثبت نشده است.'));
    }
    items.forEach((item) => {
      const card = el('article', `k30-modal-image ${item.alt ? 'is-ok' : 'is-danger'}`);
      const img = el('img'); img.src = item.thumbnail || item.url || ''; img.alt = ''; card.append(img);
      const meta = el('div'); meta.append(el('strong', '', item.title || `تصویر #${item.id}`)); meta.append(el('small', '', item.alt ? `ALT: ${item.alt}` : 'ALT ثبت نشده')); card.append(meta); grid.append(card);
    });
    section.append(grid); return section;
  };

  const showAction = (action) => {
    const wrap = el('div');
    const section = el('div', 'k30-modal-section');
    section.append(el('h3', '', `اقدام #${action.id} · ${action.action_type}`));
    const grid = el('div', 'k30-action-diff');
    const before = el('div'); before.append(el('b', '', 'قبل')); before.append(el('pre', '', JSON.stringify(action.before_payload || {}, null, 2)));
    const after = el('div'); after.append(el('b', '', 'بعد')); after.append(el('pre', '', JSON.stringify(action.after_payload || {}, null, 2)));
    grid.append(before, after); section.append(grid); wrap.append(section);
    const note = el('p', 'k30-note', 'تغییر پیشنهادی قبل از اجرا با Snapshot فعلی مقایسه می‌شود. اگر موجودیت بعد از پیشنهاد تغییر کرده باشد، اجرا Fail-closed متوقف می‌شود.'); wrap.append(note);
    const actions = el('div', 'k30-modal-actions');
    if (action.status === 'proposed') {
      const approve = el('button', 'k30-button primary', 'تأیید و اجرا'); approve.type = 'button'; approve.prepend(icon('yes-alt'));
      approve.addEventListener('click', async () => {
        approve.disabled = true;
        try {
          await api(`/actions/${action.id}/review`, { method: 'POST', body: { decision: 'approve' } });
          const applied = await api(`/actions/${action.id}/apply`, { method: 'POST', body: {} });
          toast('اقدام اجرا شد', 'تغییر ذخیره و Audit ثبت شد.'); closeModal(); setTimeout(() => location.reload(), 650);
        } catch (error) { toast('اجرای اقدام ناموفق بود', errorText(error), 'error'); approve.disabled = false; }
      });
      const reject = el('button', 'k30-button secondary', 'رد پیشنهاد'); reject.type = 'button';
      reject.addEventListener('click', async () => {
        try { await api(`/actions/${action.id}/review`, { method: 'POST', body: { decision: 'reject' } }); toast('پیشنهاد رد شد'); closeModal(); } catch (error) { toast('خطا', errorText(error), 'error'); }
      });
      actions.append(approve, reject);
    } else if (action.status === 'approved') {
      const apply = el('button', 'k30-button primary', 'اجرا'); apply.addEventListener('click', async () => { try { await api(`/actions/${action.id}/apply`, { method: 'POST', body: {} }); toast('اجرا شد'); closeModal(); setTimeout(() => location.reload(), 650); } catch (e) { toast('خطا', errorText(e), 'error'); } }); actions.append(apply);
    } else if (action.status === 'applied') {
      const rollback = el('button', 'k30-button secondary', 'بازگشت به قبل'); rollback.addEventListener('click', async () => { if (!confirm(uiText('این اقدام Rollback شود؟', 'Rollback this action?'))) return; try { await api(`/actions/${action.id}/rollback`, { method: 'POST', body: {} }); toast('Rollback انجام شد'); closeModal(); setTimeout(() => location.reload(), 650); } catch (e) { toast('Rollback ناموفق بود', errorText(e), 'error'); } }); actions.append(rollback);
    }
    wrap.append(actions);
    openModal('پیش‌نمایش اقدام', wrap, { status: action.status, tone: action.status === 'applied' ? 'success' : 'warning' });
  };

  const aiFieldLabels = {
    title: 'عنوان', seo_title: 'عنوان سئو', meta_description: 'توضیحات متا', short_description: 'توضیح کوتاه', description: 'توضیح کامل',
    excerpt: 'خلاصه', content: 'محتوا', categories: 'دسته‌بندی‌ها', brand_id: 'برند', attribute_terms: 'ویژگی‌ها', image_alts: 'ALT تصاویر',
    gtin: 'GTIN', mpn: 'MPN', model: 'مدل', weight: 'وزن', length: 'طول', width: 'عرض', height: 'ارتفاع', alt: 'ALT رسانه'
  };

  const showAIPreview = (preview) => {
    const wrap = el('div', 'k30-ai-preview');
    const hero = el('div', 'k30-ai-preview-hero');
    const copy = el('div'); copy.append(el('small', '', `${preview.provider || ''} · ${preview.model || ''}`)); copy.append(el('h3', '', 'پیش‌نمایش تکمیل با AI'));
    hero.append(copy, pill('نیازمند تأیید انسانی', 'warning')); wrap.append(hero);
    if (Array.isArray(preview.warnings) && preview.warnings.length) {
      const warningBox = el('div', 'k30-ai-warnings');
      preview.warnings.forEach((warning) => { const row = el('p'); row.append(icon('warning'), document.createTextNode(` ${warning}`)); warningBox.append(row); });
      wrap.append(warningBox);
    }
    const form = el('form', 'k30-ai-diff-form');
    (preview.diff || []).forEach((row) => {
      const item = el('label', 'k30-ai-diff-row');
      const check = el('input'); check.type = 'checkbox'; check.name = 'field'; check.value = row.field; check.checked = true;
      const head = el('div', 'k30-ai-diff-head'); head.append(el('strong', '', aiFieldLabels[row.field] || row.field), pill('پیشنهاد', 'info'));
      const cols = el('div', 'k30-ai-diff-cols');
      const before = el('div'); before.append(el('span', '', 'قبل'), el('pre', '', JSON.stringify(row.before ?? null, null, 2)));
      const after = el('div'); after.append(el('span', '', 'بعد'), el('pre', '', JSON.stringify(row.after ?? null, null, 2)));
      cols.append(before, after);
      const body = el('div', 'k30-ai-diff-body'); body.append(head, cols);
      item.append(check, body); form.append(item);
    });
    if (!(preview.diff || []).length) form.append(el('p', 'k30-check-empty', 'تغییر واقعی برای اعمال پیدا نشد.'));
    if (Array.isArray(preview.sources) && preview.sources.length) {
      const sources = el('div', 'k30-ai-sources'); sources.append(el('h4', '', 'منابع تحقیق وب'));
      preview.sources.forEach((source) => { const a = el('a', '', source.title || source.url || 'منبع'); a.href = source.url || '#'; a.target = '_blank'; a.rel = 'noopener'; sources.append(a); });
      form.append(sources);
    }
    const actions = el('div', 'k30-modal-actions');
    const apply = el('button', 'k30-button primary', 'اعمال فیلدهای انتخاب‌شده'); apply.type = 'submit'; apply.prepend(icon('yes-alt'));
    const cancel = el('button', 'k30-button secondary', 'لغو'); cancel.type = 'button'; cancel.addEventListener('click', closeModal);
    actions.append(apply, cancel); form.append(actions); wrap.append(form);
    form.addEventListener('submit', async (event) => {
      event.preventDefault();
      const fields = $$('input[name="field"]:checked', form).map((input) => input.value);
      if (!fields.length) { toast('فیلدی انتخاب نشده', 'حداقل یک تغییر را انتخاب کنید.', 'error'); return; }
      apply.disabled = true;
      try {
        await api('/ai/apply', { method: 'POST', body: { preview_id: preview.preview_id, fields } });
        toast('تکمیل با AI اعمال شد', uiText(`${fields.length} فیلد با تأیید شما ذخیره شد.`, `${fields.length} approved field(s) saved.`));
        closeModal(); setTimeout(() => location.reload(), 700);
      } catch (error) { toast('اعمال تغییر ناموفق بود', errorText(error), 'error'); apply.disabled = false; }
    });
    openModal('تکمیل با AI', wrap, { status: preview.provider || 'AI', tone: 'success' });
  };

  const requestAICompletion = async (kind, id) => {
    const hub = await api('/connections');
    const providers = (hub.ai_providers || []).filter((row) => row.status === 'connected');
    if (!providers.length) {
      const error = new Error('هیچ موتور AI با تست اتصال موفق فعال نیست.');
      error.code = 'ai_not_connected';
      throw error;
    }
    if (providers.length === 1) {
      return api(`/entity/${encodeURIComponent(kind)}/${id}/ai-complete`, { method: 'POST', body: { provider: providers[0].key, target: 'missing_and_weak', research: providers[0].key === 'openai' } });
    }
    return new Promise((resolve, reject) => {
      const wrap = el('div', 'k30-ai-provider-picker');
      wrap.append(el('p', 'k30-note', 'موتور، دامنه تکمیل و حالت تحقیق را انتخاب کنید. هیچ تغییری قبل از Preview و تأیید شما ذخیره نمی‌شود.'));
      const form = el('form', 'k30-modal-form');
      const providerField = inputField('موتور AI', 'provider', providers[0].key, { type: 'select', options: providers.map((row) => ({ value: row.key, label: `${row.label} · ${row.model || 'model'}` })) });
      const targetField = inputField('دامنه تکمیل', 'target', 'missing_and_weak', { type: 'select', options: [
        { value: 'missing_only', label: 'فقط فیلدهای خالی' },
        { value: 'missing_and_weak', label: 'فیلدهای خالی + ضعیف' },
        { value: 'seo_only', label: 'فقط SEO' },
        { value: 'content_only', label: 'فقط محتوا' },
      ] });
      const researchLabel = el('label', 'k30-ai-research-toggle');
      const research = el('input'); research.type = 'checkbox'; research.checked = providers[0].key === 'openai';
      researchLabel.append(research, el('span', '', 'تحقیق وب منبع‌دار (در حال حاضر فقط OpenAI Web Search)'));
      providerField.input.addEventListener('change', () => { research.checked = providerField.input.value === 'openai'; research.disabled = providerField.input.value !== 'openai'; });
      form.append(providerField.node, targetField.node, researchLabel);
      const actions = el('div', 'k30-modal-actions');
      const go = el('button', 'k30-button ai', 'ساخت پیش‌نمایش AI'); go.type = 'submit';
      const cancel = el('button', 'k30-button secondary', 'لغو'); cancel.type = 'button'; cancel.addEventListener('click', () => { closeModal(); reject(new Error('cancelled')); });
      actions.append(go, cancel); form.append(actions); wrap.append(form);
      form.addEventListener('submit', async (event) => {
        event.preventDefault(); go.disabled = true;
        try {
          const result = await api(`/entity/${encodeURIComponent(kind)}/${id}/ai-complete`, { method: 'POST', body: { provider: providerField.input.value, target: targetField.input.value, research: research.checked } });
          resolve(result);
        } catch (error) { reject(error); }
      });
      openModal('انتخاب موتور تکمیل با AI', wrap, { status: uiText(`${providers.length} موتور متصل`, `${providers.length} connected engine(s)`), tone: 'success' });
    });
  };

  const buildEntityModal = (detail, kind, id) => {
    const wrap = el('div');
    const profile = detail?.profile || {};
    const evidence = detail?.evidence || {};
    const issues = Array.isArray(detail?.issues) ? detail.issues : [];
    const edit = detail?.edit || {};

    const hero = el('div', 'k30-entity-hero');
    const heroCopy = el('div'); heroCopy.append(el('small', '', `${kind} · #${id}`)); heroCopy.append(el('h3', '', evidence.title || profile.title || 'بدون عنوان'));
    if (profile.url) { const link = el('a', '', 'مشاهده صفحه'); link.href = profile.url; link.target = '_blank'; link.rel = 'noopener'; heroCopy.append(link); }
    hero.append(heroCopy, pill(`${profile.score_total ?? '—'}/100`, scoreTone(profile.score_total))); wrap.append(hero);
    const scoreSection = el('div', 'k30-modal-section'); scoreSection.append(el('h3', '', 'امتیاز چندبعدی')); scoreSection.append(createMetrics(profile)); wrap.append(scoreSection);

    const formSection = el('div', 'k30-modal-section'); formSection.append(el('h3', '', 'ویرایش داده واقعی'));
    const form = el('form', 'k30-modal-form k30-entity-form');
    const controls = {};
    const add = (field) => { form.append(field.node); controls[field.input?.name || ''] = field; return field; };

    if (kind === 'media') {
      add(inputField('عنوان رسانه', 'title', evidence.title || ''));
      add(inputField('ALT', 'alt', evidence.alt || '', { note: evidence.alt ? 'ALT فعلی ثبت شده است.' : 'ALT خالی است؛ متن توصیفی و واقعی وارد کنید.' }));
    } else {
      add(inputField('عنوان صفحه', 'title', evidence.title || ''));
      add(inputField('عنوان سئو', 'seo_title', evidence.seo_title || '', { warning: String(evidence.seo_title || '').length > 65 || String(evidence.seo_title || '').length < 20 }));
      add(inputField('توضیحات متا', 'meta_description', evidence.meta_description || '', { type: 'textarea', rows: 3, warning: String(evidence.meta_description || '').length > 180 || String(evidence.meta_description || '').length < 70 }));
    }

    let categoriesCtl = null, brandCtl = null, attrControls = [];
    if (kind === 'product') {
      add(inputField('توضیح کوتاه محصول', 'short_description', evidence.short_description || '', { type: 'textarea', rows: 4 }));
      add(inputField('توضیح کامل محصول', 'description', evidence.description || '', { type: 'textarea', rows: 8 }));
      add(inputField('SKU', 'sku', evidence.sku || ''));
      add(inputField('GTIN واقعی', 'gtin', evidence.gtin || '', { note: evidence.gtin ? 'شناسه موجود است.' : 'فقط GTIN واقعی سازنده/GS1 را وارد کنید؛ سیستم شناسه نمی‌سازد.' }));
      add(inputField('MPN', 'mpn', evidence.mpn || '', { note: evidence.mpn ? 'MPN موجود است.' : 'در صورت وجود شناسه سازنده وارد شود.' }));
      add(inputField('مدل', 'model', evidence.model || '', { note: evidence.model ? 'مدل محصول ثبت شده است.' : 'اگر سازنده مدل مشخصی اعلام کرده وارد کنید؛ حدس نزنید.' }));
      add(inputField('وزن', 'weight', evidence.weight ?? '', { type: 'number', note: 'واحد همان واحد وزن تنظیم‌شده در WooCommerce است.' }));
      add(inputField('طول', 'length', evidence.length ?? '', { type: 'number', note: 'واحد همان واحد ابعاد تنظیم‌شده در WooCommerce است.' }));
      add(inputField('عرض', 'width', evidence.width ?? '', { type: 'number', note: 'واحد همان واحد ابعاد تنظیم‌شده در WooCommerce است.' }));
      add(inputField('ارتفاع', 'height', evidence.height ?? '', { type: 'number', note: 'واحد همان واحد ابعاد تنظیم‌شده در WooCommerce است.' }));
      add(inputField('قیمت (فقط خواندنی)', 'price', evidence.price ?? '', { type: 'number', disabled: true, note: 'محافظت‌شده: قیمت فقط در WooCommerce مدیریت می‌شود و AI/K20 آن را تغییر نمی‌دهد.' }));
      add(inputField('موجودی عددی (فقط خواندنی)', 'stock_quantity', evidence.stock_quantity ?? '', { type: 'number', disabled: true, note: 'محافظت‌شده: موجودی فقط در WooCommerce مدیریت می‌شود.' }));
      add(inputField('وضعیت موجودی (فقط خواندنی)', 'stock_status', evidence.stock_status || '', { type: 'select', disabled: true, options: [{value:'',label:'بدون وضعیت'}, ...(edit.stock_statuses || [])], note: 'محافظت‌شده: وضعیت موجودی از WooCommerce خوانده می‌شود.' }));
      const cats = checkboxDropdown('دسته‌بندی‌ها', 'categories', edit.categories || [], evidence.category_ids || [], 'بدون Ctrl؛ چند دسته را از فهرست بازشونده انتخاب کنید.'); categoriesCtl = cats; form.append(cats.node);
      const brandOptions = [{ id: '', label: 'بدون برند' }, ...(edit.brands || [])];
      const currentBrandId = Array.isArray(evidence.brand_term_ids) ? evidence.brand_term_ids[0] : '';
      const brand = inputField('برند', 'brand_id', currentBrandId || '', { type: 'select', options: brandOptions.map((x) => ({ value: x.id, label: x.label })), note: evidence.brand ? `فعلی: ${evidence.brand}` : 'برند معتبر انتخاب نشده است.' }); add(brand); brandCtl = brand;

      (edit.attributes || []).forEach((group) => {
        const current = (evidence.attribute_detail || []).find((a) => a.taxonomy === group.taxonomy);
        const selected = (current?.values || []).map((v) => v.id).filter(Boolean);
        const ctl = checkboxDropdown(`ویژگی: ${group.label}`, `attribute_${group.taxonomy}`, group.terms || [], selected, 'Termهای ثبت‌شده در WooCommerce؛ چند مورد قابل انتخاب است.');
        ctl.taxonomy = group.taxonomy; attrControls.push(ctl); form.append(ctl.node);
      });
    } else if (kind !== 'media') {
      add(inputField('خلاصه', 'excerpt', evidence.excerpt || '', { type: 'textarea', rows: 3 }));
      add(inputField('محتوا', 'content', evidence.content || '', { type: 'textarea', rows: 10 }));
    }
    formSection.append(form);
    const actions = el('div', 'k30-modal-actions');
    const save = el('button', 'k30-button primary', 'ذخیره و تحلیل مجدد'); save.type = 'submit'; save.prepend(icon('saved'));
    const safe = el('button', 'k30-button secondary', 'پیشنهاد اصلاح امن'); safe.type = 'button'; safe.prepend(icon('superhero'));
    const aiComplete = el('button', 'k30-button ai', 'تکمیل با AI'); aiComplete.type = 'button'; aiComplete.prepend(icon('star-filled'));
    actions.append(save, safe, aiComplete); formSection.append(actions); wrap.append(formSection);

    if (kind === 'product' && Array.isArray(evidence.image_items)) wrap.append(imageGallery(evidence.image_items));

    const issueSection = el('div', 'k30-modal-section'); issueSection.append(el('h3', '', `ایرادها و پیشنهادها · ${issues.length}`));
    const issueList = el('div', 'k30-modal-issues');
    if (!issues.length) issueList.append(el('p', 'k30-check-empty', 'Issue باز برای این موجودیت دیده نشد.'));
    issues.forEach((issue) => {
      const row = el('article', severityTone(issue.severity)); row.append(pill(issue.severity, severityTone(issue.severity)));
      const copy = el('div'); copy.append(el('b', '', issue.title)); copy.append(el('p', '', issue.description)); copy.append(el('code', '', issue.rule_code)); row.append(copy); issueList.append(row);
    });
    issueSection.append(issueList); wrap.append(issueSection);

    const schemaSection = el('div', 'k30-modal-section'); schemaSection.append(el('h3', '', 'پیش‌نمایش Schema')); schemaSection.append(el('pre', 'k30-code', JSON.stringify(detail?.schema || {}, null, 2))); wrap.append(schemaSection);

    form.addEventListener('submit', async (event) => {
      event.preventDefault(); save.disabled = true;
      try {
        const fields = {};
        new FormData(form).forEach((value, key) => { if (!key.endsWith('[]') && !key.startsWith('attribute_')) fields[key] = value; });
        if (categoriesCtl) fields.categories = categoriesCtl.values();
        if (attrControls.length) {
          fields.attribute_terms = {};
          attrControls.forEach((ctl) => { fields.attribute_terms[ctl.taxonomy] = ctl.values(); });
        }
        const updated = await api(`/entity/${encodeURIComponent(kind)}/${id}`, { method: 'PATCH', body: { fields } });
        toast('ذخیره شد', 'موجودیت دوباره تحلیل شد و امتیازها به‌روز شدند.');
        closeModal();
        setTimeout(() => location.reload(), 600);
      } catch (error) { toast('ذخیره ناموفق بود', errorText(error), 'error'); save.disabled = false; }
    });
    safe.addEventListener('click', async () => {
      safe.disabled = true;
      try {
        const action = await api(`/entity/${encodeURIComponent(kind)}/${id}/safe-fix`, { method: 'POST', body: {} });
        showAction(action);
      } catch (error) { toast('اصلاح امن ساخته نشد', errorText(error), 'error'); safe.disabled = false; }
    });
    aiComplete.addEventListener('click', async () => {
      aiComplete.disabled = true;
      try {
        const preview = await requestAICompletion(kind, id);
        showAIPreview(preview);
      } catch (error) {
        if (error?.message === 'cancelled') return;
        toast('تکمیل با AI اجرا نشد', errorText(error), 'error');
        if (error?.code === 'ai_not_connected') window.setTimeout(() => { if (confirm('به مرکز اتصال برویم؟')) location.href = `${boot.adminBase || 'admin.php?page=k20-ai-press'}&workspace=connections`; }, 250);
      } finally { aiComplete.disabled = false; }
    });

    return wrap;
  };

  const openEntity = async (kind, id) => {
    const placeholder = loadingNode('در حال خواندن پروفایل واقعی…');
    openModal('پروفایل داده و اصلاح', placeholder, { status: 'در حال خواندن', tone: 'info' });
    try {
      const detail = await api(`/entity/${encodeURIComponent(kind)}/${Number(id)}`);
      openModal(detail?.evidence?.title || 'پروفایل داده', buildEntityModal(detail, kind, Number(id)), { status: `${detail?.profile?.score_total ?? '—'}/100`, tone: scoreTone(detail?.profile?.score_total) });
    } catch (error) {
      const errorNode = el('div', 'k30-empty'); errorNode.append(icon('warning')); errorNode.append(el('strong', '', 'خواندن پروفایل ناموفق بود')); errorNode.append(el('p', '', errorText(error))); openModal('خطا', errorNode, { status: 'خطا', tone: 'danger' });
    }
  };

  document.addEventListener('click', (event) => {
    const target = event.target.closest('[data-entity-open]');
    if (!target) return;
    event.preventDefault(); openEntity(target.dataset.entityOpen, target.dataset.entityId);
  });

  // Existing action records.
  $$('[data-action-id]').forEach((button) => button.addEventListener('click', async () => {
    const id = Number(button.dataset.actionId);
    try {
      // action detail is currently carried by control-tower workspace; no direct GET route,
      // so refresh that workspace and locate it.
      const data = await api('/workspace/control-tower');
      const action = (data.actions || []).find((item) => Number(item.id) === id);
      if (!action) throw new Error('اقدام پیدا نشد.');
      showAction(action);
    } catch (error) { toast('خطا', errorText(error), 'error'); }
  }));

  // Scan orchestration.
  const progressBox = $('[data-scan-progress]');
  const scanButtons = $$('[data-run-scan]');
  const scanSurfaceActive = Boolean(progressBox || scanButtons.length);
  const scanTelemetry = new Map();
  const pollingScans = new Set();
  const showProgress = (scan) => {
    if (!progressBox) return;
    progressBox.hidden = false;
    const processed = Number(scan.processed ?? 0);
    const total = Math.max(0, Number(scan.total ?? 0));
    const exactPercent = total > 0 ? Math.min(100, (processed / total) * 100) : (scan.status === 'completed' ? 100 : 0);
    const percentLabel = exactPercent >= 10 ? exactPercent.toFixed(1).replace(/\.0$/, '') : exactPercent.toFixed(1);
    const now = Date.now();
    const previous = scanTelemetry.get(scan.id) || { processed, changedAt: now, observedAt: now, rate: 0 };
    let changedAt = previous.changedAt;
    let rate = Number(previous.rate || 0);
    if (processed !== previous.processed) {
      const seconds = Math.max(0.15, (now - previous.observedAt) / 1000);
      const instantRate = Math.max(0, (processed - previous.processed) / seconds);
      rate = rate > 0 ? (rate * 0.55 + instantRate * 0.45) : instantRate;
      changedAt = now;
    }
    scanTelemetry.set(scan.id, { processed, changedAt, observedAt: now, rate });
    const stalled = ['queued','running'].includes(scan.status) && (now - changedAt) > 5000;
    progressBox.classList.toggle('is-running', ['queued','running'].includes(scan.status));
    progressBox.classList.toggle('is-stalled', stalled);
    const stateFa = stalled ? 'در حال بیدار کردن Worker' : (scan.status === 'queued' ? 'در صف' : 'در حال پردازش');
    const stateEn = stalled ? 'waking worker' : (scan.status === 'queued' ? 'queued' : 'processing');
    const remaining = Math.max(0, total - processed);
    const etaSeconds = rate > 0.15 ? Math.ceil(remaining / rate) : null;
    const etaFa = etaSeconds === null ? '' : (etaSeconds < 60 ? ` · ${rate.toFixed(1)} مورد/ث · حدود ${etaSeconds}ث` : ` · ${rate.toFixed(1)} مورد/ث · حدود ${Math.ceil(etaSeconds/60)}د`);
    const etaEn = etaSeconds === null ? '' : (etaSeconds < 60 ? ` · ${rate.toFixed(1)}/s · ~${etaSeconds}s` : ` · ${rate.toFixed(1)}/s · ~${Math.ceil(etaSeconds/60)}m`);
    $('[data-scan-label]', progressBox).textContent = uiText(`اسکن ${scan.scan_type} · ${processed}/${total} · ${scan.issues_found} ایراد · ${stateFa}${etaFa}`, `Scan ${scan.scan_type} · ${processed}/${total} · ${scan.issues_found} issue(s) · ${stateEn}${etaEn}`);
    $('[data-scan-percent]', progressBox).textContent = boot.uiLanguage === 'en' ? `${percentLabel}%` : `${percentLabel}٪`;
    $('[data-scan-bar]', progressBox).style.width = `${exactPercent}%`;
  };
  const pollScan = async (scan) => {
    const scanId = Number(scan?.id || 0);
    if (!scanId || pollingScans.has(scanId)) return;
    pollingScans.add(scanId);
    let current = scan;
    let consecutiveErrors = 0;
    let lastProcessed = Number(current.processed || 0);
    // A freshly queued scan should not sit idle waiting for WP-Cron. When the admin page is
    // visible, make the first bounded server tick immediately; subsequent ticks happen only
    // when real progress has stopped.
    let lastProgressAt = (current.status === 'queued' && lastProcessed === 0) ? (Date.now() - 3000) : Date.now();
    let ticking = false;
    showProgress(current);
    try {
      while (!['completed','failed','cancelled'].includes(current.status)) {
        await sleep(document.hidden ? 3500 : 1200);
        try {
          current = await api(`/scans/${scanId}`);
          consecutiveErrors = 0;
          const currentProcessed = Number(current.processed || 0);
          if (currentProcessed !== lastProcessed) {
            lastProcessed = currentProcessed;
            lastProgressAt = Date.now();
          }
          showProgress(current);
          // If the host scheduler pauses, the open admin page performs one bounded batch.
          // This is a real server-side step guarded by the same scan lock, not fake UI progress.
          if (boot.user?.canSystem !== false && !document.hidden && !ticking && ['queued','running'].includes(current.status) && (Date.now() - lastProgressAt) > 3000) {
            ticking = true;
            try {
              const accelerated = await api(`/scans/${scanId}/tick`, { method: 'POST', body: {} });
              if (accelerated) {
                current = accelerated;
                const acceleratedProcessed = Number(current.processed || 0);
                if (acceleratedProcessed !== lastProcessed) { lastProcessed = acceleratedProcessed; lastProgressAt = Date.now(); }
                showProgress(current);
              }
            } finally { ticking = false; }
          }
        } catch (error) {
          consecutiveErrors += 1;
          if (consecutiveErrors >= 12) {
            toast('ارتباط با وضعیت اسکن موقتاً قطع شد', 'پردازش سرور متوقف نشده است؛ با بازگشت ارتباط، صفحه دوباره وضعیت را می‌خواند.', 'warning', 7000);
            await sleep(5000);
            consecutiveErrors = 0;
          }
        }
      }
      progressBox?.classList.remove('is-running','is-stalled');
      if (current.status === 'completed') { toast('اسکن کامل شد', uiText(`${current.processed} موجودیت بررسی شد و ${current.issues_found} Issue مشاهده شد.`, `${current.processed} entities checked; ${current.issues_found} issue(s) found.`)); setTimeout(() => location.reload(), 850); }
      else if (current.status === 'failed') toast('اسکن متوقف شد', current.last_error || 'خطای نامشخص', 'error', 8000);
    } finally {
      pollingScans.delete(scanId);
    }
  };
  scanButtons.forEach((button) => button.addEventListener('click', async () => {
    const type = button.dataset.runScan || 'full'; button.disabled = true;
    try {
      const scan = await api('/scans', { method: 'POST', body: { type, scope: 'manual' } });
      toast('اسکن شروع شد', 'پردازش در صف پس‌زمینه انجام می‌شود و صفحه را قفل نمی‌کند.');
      button.disabled = false;
      pollScan(scan).catch((error) => toast('خواندن وضعیت اسکن ناموفق بود', errorText(error), 'warning'));
    } catch (error) { toast('شروع اسکن ناموفق بود', errorText(error), 'error'); button.disabled = false; }
  }));
  if (scanSurfaceActive) {
    const serverScanId = Number(progressBox?.dataset.activeScanId || 0);
    if (serverScanId > 0) {
      api(`/scans/${serverScanId}`).then((active) => pollScan(active)).catch(() => {});
    } else {
      api('/scans').then((active) => { if (active?.id && ['queued','running'].includes(active.status)) pollScan(active).catch(() => {}); }).catch(() => {});
    }
  }

  // Table tone filter.
  $$('[data-table-filter]').forEach((button) => button.addEventListener('click', () => {
    const group = button.closest('.k30-card') || button.closest('.k30-card-body') || document;
    $$('[data-table-filter]', button.parentElement).forEach((b) => { b.classList.remove('is-active'); b.setAttribute('aria-pressed','false'); });
    button.classList.add('is-active'); button.setAttribute('aria-pressed','true');
    const tone = button.dataset.tableFilter;
    $$('tbody tr[data-tone]', group).forEach((row) => { row.hidden = tone !== 'all' && row.dataset.tone !== tone; });
  }));

  // Product field-map filter: every tile filters the currently rendered product table by a real missing field.
  $$('[data-product-field-filter]').forEach((button) => button.addEventListener('click', () => {
    const field = button.dataset.productFieldFilter || '';
    const active = button.classList.toggle('is-filtering'); button.classList.toggle('is-active', active);
    $$('[data-product-field-filter]').forEach((other) => {
      if (other !== button) { other.classList.remove('is-filtering','is-active'); other.setAttribute('aria-pressed', 'false'); }
    });
    button.setAttribute('aria-pressed', active ? 'true' : 'false');
    $$('tr[data-product-missing]').forEach((row) => {
      const missing = new Set((row.dataset.productMissing || '').split(/\s+/).filter(Boolean));
      row.hidden = active && field ? !missing.has(field) : false;
    });
  }));

  // Settings.
  $$('[data-settings-form]').forEach((form) => form.addEventListener('submit', async (event) => {
    event.preventDefault(); const currentForm = event.currentTarget; const button = $('button[type=submit]', currentForm); if (button) button.disabled = true;
    const body = {};
    $$('input', currentForm).forEach((input) => { if (input.name) body[input.name] = input.type === 'checkbox' ? input.checked : input.value; });
    try { await api('/settings', { method: 'PATCH', body }); toast('تنظیمات ذخیره شد'); } catch (e) { toast('ذخیره تنظیمات ناموفق بود', errorText(e), 'error'); } finally { if (button) button.disabled = false; }
  }));
  $$('[data-settings-jump]').forEach((button) => button.addEventListener('click', () => {
    const target = document.getElementById(`k30-settings-${button.dataset.settingsJump}`);
    if (!target) return;
    $$('[data-settings-jump]').forEach((item) => { item.classList.remove('is-active'); item.setAttribute('aria-pressed', 'false'); });
    button.classList.add('is-active'); button.setAttribute('aria-pressed', 'true');
    const reduceMotion = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
    target.scrollIntoView({ behavior: reduceMotion ? 'auto' : 'smooth', block: 'start' });
  }));

  // System > Connection Center. Secrets are sent only on save and are never rehydrated into inputs.
  $$('[data-connection-form]').forEach((form) => form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const provider = form.dataset.connectionForm;
    const button = $('button[type="submit"]', form);
    const body = {};
    $$('input[name],select[name]', form).forEach((input) => {
      if (input.type === 'checkbox') body[input.name] = input.checked;
      else if (input.value !== '' || input.type !== 'password') body[input.name] = input.value;
    });
    button.disabled = true;
    try {
      await api(`/connections/${encodeURIComponent(provider)}`, { method: 'PATCH', body });
      toast('تنظیمات اتصال ذخیره شد', 'برای سبزشدن اتصال، تست زنده را اجرا کنید.');
      setTimeout(() => location.reload(), 550);
    } catch (error) { toast('ذخیره اتصال ناموفق بود', errorText(error), 'error'); button.disabled = false; }
  }));
  $$('[data-connection-test]').forEach((button) => button.addEventListener('click', async () => {
    const provider = button.dataset.connectionTest; button.disabled = true;
    try {
      await api(`/connections/${encodeURIComponent(provider)}/test`, { method: 'POST', body: {} });
      toast('تست اتصال موفق بود', 'Provider با پاسخ واقعی API تأیید شد.'); setTimeout(() => location.reload(), 550);
    } catch (error) { toast('تست اتصال ناموفق بود', errorText(error), 'error', 7000); button.disabled = false; }
  }));
  $$('[data-connection-sync]').forEach((button) => button.addEventListener('click', async () => {
    const provider = button.dataset.connectionSync; button.disabled = true;
    try {
      const result = await api(`/connections/${encodeURIComponent(provider)}/sync`, { method: 'POST', body: {} });
      toast('همگام‌سازی انجام شد', JSON.stringify(result)); setTimeout(() => location.reload(), 650);
    } catch (error) { toast('Sync ناموفق بود', errorText(error), 'error', 7000); button.disabled = false; }
  }));
  $$('[data-connection-disconnect]').forEach((button) => button.addEventListener('click', async () => {
    const provider = button.dataset.connectionDisconnect;
    if (!confirm(uiText('Credential و وضعیت این اتصال از افزونه حذف شود؟', 'Remove the credential and connection state from this plugin?'))) return;
    button.disabled = true;
    try { await api(`/connections/${encodeURIComponent(provider)}`, { method: 'DELETE' }); toast('اتصال قطع شد'); setTimeout(() => location.reload(), 500); }
    catch (error) { toast('قطع اتصال ناموفق بود', errorText(error), 'error'); button.disabled = false; }
  }));
  $('[data-github-dispatch]')?.addEventListener('click', async (event) => {
    const button = event.currentTarget;
    if (!confirm(uiText('Workflow تنظیم‌شده روی GitHub Actions اجرا شود؟', 'Dispatch the configured GitHub Actions workflow?'))) return;
    button.disabled = true;
    try {
      const result = await api('/connections/github/dispatch', { method: 'POST', body: { inputs: { source: 'k20-ai-press', site: boot.site || '' } } });
      toast('Workflow اجرا شد', `${result.repository || ''} · ${result.workflow || ''}`);
    } catch (error) { toast('اجرای Workflow ناموفق بود', errorText(error), 'error', 7000); }
    finally { button.disabled = false; }
  });

  $$('[data-bot-override]').forEach((input) => input.addEventListener('change', () => {
    input.dataset.changed = '1';
    const card = input.closest('.k30-bot-item');
    card?.classList.toggle('is-allowed', input.checked);
    card?.classList.toggle('is-blocked', !input.checked);
  }));

  $('[data-bot-policy-form]')?.addEventListener('submit', async (event) => {
    event.preventDefault();
    const form = event.currentTarget; const button = $('button[type=submit]', form); button.disabled = true;
    const body = {};
    $$('input[type=checkbox][name]', form).forEach((input) => { body[input.name] = input.checked; });
    const overrides = {};
    $$('[data-bot-override][data-changed="1"]').forEach((input) => { overrides[input.dataset.botOverride] = input.checked; });
    if (Object.keys(overrides).length) body.overrides = overrides;
    try {
      await api('/bot-control/policy', { method: 'PATCH', body });
      toast('سیاست ربات‌ها ذخیره شد', 'برای اثر روی robots.txt، دکمه اعمال سیاست را بزنید.');
      $$('[data-bot-override][data-changed="1"]').forEach((input) => { delete input.dataset.changed; });
    } catch (e) { toast('ذخیره سیاست ناموفق بود', errorText(e), 'error'); }
    finally { button.disabled = false; }
  });

  $('[data-bot-apply]')?.addEventListener('click', async (event) => {
    const button = event.currentTarget;
    if (!confirm(uiText('سیاست فعلی روی robots.txt مجازی اعمال شود؟ فایل فیزیکی robots.txt بازنویسی نمی‌شود.', 'Apply the current policy to virtual robots.txt? The physical robots.txt file will not be rewritten.'))) return;
    button.disabled = true;
    try { await api('/bot-control/apply', { method: 'POST', body: {} }); toast('سیاست robots اعمال شد', 'نسخه قبلی برای Rollback نگه‌داری شد.'); setTimeout(() => location.reload(), 650); }
    catch (e) { toast('اعمال robots ناموفق بود', errorText(e), 'error'); button.disabled = false; }
  });

  $('[data-bot-rollback]')?.addEventListener('click', async (event) => {
    const button = event.currentTarget;
    if (!confirm(uiText('robots مجازی به Snapshot قبل بازگردد؟', 'Restore virtual robots.txt to the previous snapshot?'))) return;
    button.disabled = true;
    try { await api('/bot-control/rollback', { method: 'POST', body: {} }); toast('Rollback انجام شد'); setTimeout(() => location.reload(), 650); }
    catch (e) { toast('Rollback ناموفق بود', errorText(e), 'error'); button.disabled = false; }
  });

  $('[data-radar-settings]')?.addEventListener('submit', async (event) => {
    event.preventDefault(); const form = event.currentTarget; const button = $('button[type=submit]', form); button.disabled = true;
    try { await api('/settings', { method: 'PATCH', body: { radar_sources: form.radar_sources.value } }); toast('منابع رادار ذخیره شد'); } catch (e) { toast('خطا', errorText(e), 'error'); } finally { button.disabled = false; }
  });
  $('[data-radar-refresh]')?.addEventListener('click', async (event) => {
    const button = event.currentTarget; button.disabled = true;
    try { const result = await api('/radar/refresh', { method: 'POST', body: {} }); toast('رادار به‌روزرسانی شد', uiText(`${result.observed} سیگنال از ${result.sources} منبع مشاهده شد.`, `${result.observed} signal(s) observed from ${result.sources} source(s).`)); setTimeout(() => location.reload(), 700); } catch (e) { toast('به‌روزرسانی رادار ناموفق بود', errorText(e), 'error'); button.disabled = false; }
  });

  // Live editor: server-side preview uses the same rule engine as saved analysis.
  const liveForm = $('[data-live-editor]');
  let livePreviewTimer = null;
  let livePreviewController = null;
  const severityClass = (severity) => severity === 'critical' ? 'danger' : (severity === 'warning' ? 'warning' : 'info');
  const updateLivePreview = (result) => {
    if (!result?.profile) return;
    const profile = result.profile;
    const total = $('[data-live-total]');
    if (total) {
      const value = Number(profile.score_total || 0);
      total.style.setProperty('--score', String(Math.max(0, Math.min(100, value))));
      const strong = $('strong', total); if (strong) strong.textContent = String(value);
    }
    const keys = { technical: 'score_technical', content: 'score_content', schema: 'score_schema', media: 'score_media', commerce: 'score_commerce' };
    Object.entries(keys).forEach(([key, prop]) => {
      const row = $(`[data-score-key="${key}"]`);
      if (!row) return;
      const value = Math.max(0, Math.min(100, Number(profile[prop] || 0)));
      const bar = $('i b', row); if (bar) bar.style.width = `${value}%`;
      const strong = $('strong', row); if (strong) strong.textContent = String(value);
    });
    const issueList = $('[data-live-issue-list]');
    if (issueList) {
      issueList.replaceChildren();
      const issues = Array.isArray(result.issues) ? result.issues : [];
      if (!issues.length) {
        const item = el('article', 'success');
        const icon = el('span', 'dashicons dashicons-yes-alt');
        const copy = el('div'); copy.append(el('b', '', 'در پیش‌نمایش فعلی ایراد قابل اندازه‌گیری باقی نمانده است.'));
        item.append(icon, copy); issueList.append(item);
      } else {
        issues.forEach((issue) => {
          const item = el('article', severityClass(String(issue.severity || 'info')));
          item.append(el('span', `dashicons dashicons-${issue.severity === 'critical' ? 'dismiss' : 'warning'}`));
          const copy = el('div'); copy.append(el('b', '', String(issue.title || issue.rule_code || 'Issue')));
          if (issue.description) copy.append(el('small', '', String(issue.description)));
          item.append(copy); issueList.append(item);
        });
      }
    }
  };
  const collectLiveFields = (form) => {
    const fields = {};
    new FormData(form).forEach((value, key) => { fields[key] = value; });
    return fields;
  };
  const requestLivePreview = async (form) => {
    const state = $('[data-live-preview-state]', form);
    if (livePreviewController) livePreviewController.abort();
    livePreviewController = new AbortController();
    if (state) state.textContent = 'در حال تحلیل بدون ذخیره…';
    try {
      const result = await api(`/entity/${encodeURIComponent(form.dataset.kind)}/${Number(form.dataset.id)}/preview`, { method: 'POST', body: { fields: collectLiveFields(form) }, signal: livePreviewController.signal });
      updateLivePreview(result);
      if (state) state.textContent = 'پیش‌نمایش زنده به‌روز شد؛ هنوز ذخیره نشده';
    } catch (e) {
      if (e?.name === 'AbortError') return;
      if (state) state.textContent = `پیش‌نمایش: ${errorText(e)}`;
    }
  };
  if (liveForm) {
    $$('input[name],textarea[name],select[name]', liveForm).forEach((control) => {
      const schedule = () => {
        const count = $(`[data-live-count="${control.name}"]`, liveForm);
        if (count && typeof control.value === 'string') count.textContent = `${Array.from(control.value).length} نویسه`;
        clearTimeout(livePreviewTimer);
        livePreviewTimer = setTimeout(() => requestLivePreview(liveForm), 450);
      };
      control.addEventListener('input', schedule);
      control.addEventListener('change', schedule);
    });
    liveForm.addEventListener('submit', async (event) => {
      event.preventDefault();
      const submit = $('button[type=submit]', liveForm); if (submit) submit.disabled = true;
      try {
        await api(`/entity/${encodeURIComponent(liveForm.dataset.kind)}/${Number(liveForm.dataset.id)}`, { method: 'PATCH', body: { fields: collectLiveFields(liveForm) } });
        toast('ذخیره شد', 'تغییرات ثبت و تحلیل مجدد انجام شد.');
        setTimeout(() => location.reload(), 650);
      } catch (e) {
        toast('ذخیره ناموفق بود', errorText(e), 'error');
        if (submit) submit.disabled = false;
      }
    });
  }

  $$('[data-safe-fix-kind]').forEach((button) => button.addEventListener('click', async () => {
    button.disabled = true;
    try { const action = await api(`/entity/${encodeURIComponent(button.dataset.safeFixKind)}/${Number(button.dataset.safeFixId)}/safe-fix`, { method: 'POST', body: {} }); showAction(action); } catch (e) { toast('پیشنهاد امن ساخته نشد', errorText(e), 'error'); button.disabled = false; }
  }));

  const renderLiveSerp = (host, report) => {
    host.replaceChildren();
    const summary = el('div', 'k30-serp-live-summary');
    const live = el('article'); live.append(el('span', '', 'رتبه مشاهده‌شده زنده'), el('strong', '', report.observed_live_position == null ? 'در ۱۰ نتیجه اول دیده نشد' : `#${report.observed_live_position}`));
    const history = report.historical_search_console || {};
    const historical = el('article'); historical.append(el('span', '', 'Search Console تاریخی'), el('strong', '', history.available && history.position != null ? String(history.position) : 'داده متناظر نداریم'));
    if (history.available) historical.append(el('small', '', `${history.impressions ?? 0} impression · ${history.clicks ?? 0} click · CTR ${history.ctr ?? 0}% · ${history.source || 'source'}`));
    summary.append(live, historical); host.append(summary);

    const serpBox = el('div', 'k30-google-serp');
    const serpHead = el('div', 'k30-google-serp-head'); serpHead.append(el('strong', '', 'Google Live SERP'), el('small', '', `${report.query || ''} · ${report.serp?.observed_at || ''}`)); serpBox.append(serpHead);
    const rows = Array.isArray(report.serp?.organic_results) ? report.serp.organic_results : [];
    if (!rows.length) serpBox.append(el('p', 'k30-note', 'نتیجه ارگانیک از Provider برنگشت.'));
    rows.forEach((row) => {
      const item = el('article', `k30-google-result${row.is_site ? ' is-site' : ''}`);
      const top = el('div', 'k30-google-result-source');
      top.append(el('b', '', `#${row.position || '—'}`), el('span', '', String(row.displayed_link || row.link || '')));
      const title = el('a', 'k30-google-result-title', String(row.title || row.link || 'نتیجه'));
      if (row.link) { title.href = row.link; title.target = '_blank'; title.rel = 'noopener'; }
      item.append(top, title);
      if (row.snippet) item.append(el('p', '', String(row.snippet)));
      if (row.is_site) item.append(el('small', 'k30-own-result', 'نتیجه متعلق به keshavarz20.com'));
      serpBox.append(item);
    });
    host.append(serpBox);

    const ai = report.ai || {};
    const suggestions = Array.isArray(ai.suggestions) ? ai.suggestions : [];
    const rec = el('div', 'k30-serp-suggestions');
    rec.append(el('h4', '', 'پیشنهادهای مرتبط بر پایه ۵ نتیجه اول'));
    if (!suggestions.length) rec.append(el('p', 'k30-note', ai.status === 'not_connected' ? 'Provider هوش مصنوعی متصل نیست؛ پیشنهاد ساختگی نمایش داده نمی‌شود.' : String(ai.status || 'پیشنهادی برنگشت.')));
    suggestions.forEach((row) => {
      const item = el('article');
      const copy = el('div'); copy.append(el('strong', '', String(row.keyword || ''))); if (row.reason) copy.append(el('small', '', String(row.reason)));
      const apply = el('button', 'k30-mini-button primary', 'انتخاب برای عبارت کلیدی'); apply.type = 'button';
      apply.addEventListener('click', () => {
        const focus = $('[data-live-editor] [name="focus_keyword"]');
        if (!focus) { toast('ویرایشگر باز نیست', 'همین موجودیت را در ویرایشگر زنده باز کنید.', 'error'); return; }
        focus.value = String(row.keyword || ''); focus.dispatchEvent(new Event('input', { bubbles: true })); focus.focus();
        toast('عبارت انتخاب شد', 'برای ثبت نهایی دکمه «ذخیره و تحلیل مجدد» را بزنید.');
      });
      item.append(copy, apply); rec.append(item);
    });
    host.append(rec);
  };
  $$('[data-live-serp]').forEach((form) => form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const host = $('[data-live-serp-result]');
    const submit = $('button[type=submit]', form); if (submit) submit.disabled = true;
    if (host) { host.replaceChildren(el('p', 'k30-note', 'در حال دریافت نتیجه زنده از Provider…')); }
    try {
      const report = await api('/serp/live', { method: 'POST', body: { query: String(form.query?.value || '').trim(), kind: form.dataset.kind || '', id: Number(form.dataset.id || 0) } });
      if (host) renderLiveSerp(host, report);
    } catch (e) {
      if (host) host.replaceChildren(el('p', 'k30-note error', errorText(e)));
      toast('جست‌وجوی زنده انجام نشد', errorText(e), 'error');
    } finally { if (submit) submit.disabled = false; }
  }));

  // Import keyword/rank data.
  const parseDelimited = (raw) => {
    const lines = raw.trim().split(/\r?\n/).filter(Boolean);
    if (!lines.length) return [];
    const sep = lines[0].includes('\t') ? '\t' : ',';
    const split = (line) => {
      if (sep === '\t') return line.split('\t');
      const cells = []; let cell = '', quote = false;
      for (let i = 0; i < line.length; i++) { const ch = line[i]; if (ch === '"') { if (quote && line[i+1] === '"') { cell += '"'; i++; } else quote = !quote; } else if (ch === ',' && !quote) { cells.push(cell); cell=''; } else cell += ch; } cells.push(cell); return cells;
    };
    const headers = split(lines.shift()).map((x) => x.trim().toLowerCase().replace(/\s+/g, '_'));
    return lines.map((line) => { const cells = split(line); const row = {}; headers.forEach((h, i) => row[h] = cells[i] ?? ''); return row; });
  };
  const openKeywordImport = () => {
    const wrap = el('div'); const section = el('div', 'k30-modal-section'); section.append(el('h3', '', 'Import کلمات کلیدی / رتبه'));
    const note = el('p', 'k30-note', 'JSON array یا CSV/TSV با ستون‌های phrase/query, current_position, previous_position, impressions, clicks, ctr, target_url. Source برای provenance ذخیره می‌شود.'); section.append(note);
    const textarea = el('textarea', 'k30-import-box'); textarea.rows = 14; textarea.placeholder = 'phrase,current_position,previous_position,impressions,clicks,ctr,target_url\nنوار تیپ,4,6,1200,75,6.25,https://example.com/...'; section.append(textarea);
    const source = el('input', 'k30-import-source'); source.value = 'manual'; source.placeholder = 'source: gsc-import / wincher / manual'; section.append(source);
    const actions = el('div', 'k30-modal-actions'); const submit = el('button', 'k30-button primary', 'Import'); actions.append(submit); section.append(actions); wrap.append(section);
    submit.addEventListener('click', async () => {
      submit.disabled = true;
      try {
        const raw = textarea.value.trim(); let rows;
        if (!raw) throw new Error('داده‌ای وارد نشده است.');
        if (raw.startsWith('[') || raw.startsWith('{')) { const parsed = JSON.parse(raw); rows = Array.isArray(parsed) ? parsed : parsed.rows || []; } else rows = parseDelimited(raw);
        if (!rows.length) throw new Error('هیچ ردیف قابل Import پیدا نشد.');
        const result = await api('/keywords/import', { method: 'POST', body: { rows, source: source.value.trim() || 'manual' } });
        toast('Import انجام شد', uiText(`${result.imported} ردیف با منبع ${result.source} ذخیره شد.`, `${result.imported} row(s) saved with source ${result.source}.`)); closeModal(); setTimeout(() => location.reload(), 700);
      } catch (e) { toast('Import ناموفق بود', errorText(e), 'error'); submit.disabled = false; }
    });
    openModal('Import داده رتبه و Search Console', wrap, { status: 'Fail-closed', tone: 'success' });
  };
  $$('[data-open-keyword-import]').forEach((button) => button.addEventListener('click', openKeywordImport));

  // Competitor dialog.
  $('[data-open-competitor]')?.addEventListener('click', () => {
    const wrap = el('div'); const section = el('div', 'k30-modal-section'); section.append(el('h3', '', 'افزودن رقیب'));
    const form = el('form', 'k30-modal-form');
    const domain = inputField('دامنه', 'domain', '', { placeholder: 'example.com' }); const label = inputField('عنوان', 'label', '', { placeholder: 'نام نمایشی' }); form.append(domain.node, label.node); section.append(form);
    const actions = el('div', 'k30-modal-actions'); const save = el('button', 'k30-button primary', 'ذخیره رقیب'); save.type='submit'; actions.append(save); section.append(actions); wrap.append(section);
    form.addEventListener('submit', async (e) => { e.preventDefault(); save.disabled=true; try { await api('/competitors', { method:'POST', body:{ domain:domain.input.value, label:label.input.value, source:'manual' } }); toast('رقیب ثبت شد'); closeModal(); setTimeout(()=>location.reload(),650); } catch(err){toast('ثبت رقیب ناموفق بود',errorText(err),'error');save.disabled=false;} });
    openModal('رقیب جدید', wrap, { status:'داده منبع‌دار', tone:'info' });
  });

  // Crawl a single URL.
  $('[data-crawl-url-prompt]')?.addEventListener('click', () => {
    const wrap = el('div'); const section = el('div','k30-modal-section'); section.append(el('h3','','بررسی URL داخلی'));
    const form = el('form','k30-modal-form'); const url = inputField('URL','url',boot.site || '',{placeholder:`${boot.site || ''}/...`}); form.append(url.node); section.append(form); const actions=el('div','k30-modal-actions'); const go=el('button','k30-button primary','شروع بررسی'); go.type='submit'; actions.append(go); section.append(actions); wrap.append(section);
    form.addEventListener('submit',async(e)=>{e.preventDefault();go.disabled=true;try{const result=await api('/crawl/url',{method:'POST',body:{url:url.input.value}});const out=el('div');const metrics=el('div','k30-modal-metrics');[['HTTP',result.http_status],['زمان',`${result.response_time_ms}ms`],['Indexable',result.indexable?'بله':'خیر'],['Schema',result.schema_types||'—']].forEach(([a,b])=>{const d=el('div');d.append(el('span','',a),el('strong','',b));metrics.append(d)});out.append(metrics);out.append(el('pre','k30-code',JSON.stringify(result,null,2)));openModal('نتیجه بررسی URL',out,{status:String(result.http_status),tone:Number(result.http_status)>=400?'danger':'success'});}catch(err){toast('Crawl ناموفق بود',errorText(err),'error');go.disabled=false;}});
    openModal('URL Inspection',wrap,{status:'Same-host only',tone:'success'});
  });

  // Reports export.
  $$('[data-export-format]').forEach((button) => button.addEventListener('click', async () => {
    const format = button.dataset.exportFormat; button.disabled = true;
    try {
      const result = await api(`/report/export?format=${encodeURIComponent(format)}`);
      const blob = new Blob([result.body || ''], { type: result.mime || 'text/plain;charset=utf-8' });
      const href = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = href; a.download = result.filename || `seo-report.${format}`; document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(href), 1500); toast('خروجی ساخته شد', result.filename || 'فایل آماده شد.');
    } catch (e) { toast('خروجی ناموفق بود', errorText(e), 'error'); } finally { button.disabled = false; }
  }));

  // Global quick search filters currently rendered tables/cards without sending private terms offsite.
  const globalSearch = $('[data-global-search]');
  const applyGlobalSearch = () => {
    const q = (globalSearch?.value || '').trim().toLocaleLowerCase('fa');
    $$('tbody tr,.k30-media-table article,.k30-rec-grid article,.k30-rec-list article,.k30-signal-list article').forEach((node) => {
      if (!q) { node.hidden = false; return; }
      node.hidden = !node.textContent.toLocaleLowerCase('fa').includes(q);
    });
  };
  globalSearch?.addEventListener('input', applyGlobalSearch);
  document.addEventListener('keydown', (event) => {
    if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') { event.preventDefault(); globalSearch?.focus(); }
    if (event.key === 'Escape' && modal?.open) closeModal();
  });

  $('[data-command-palette]')?.addEventListener('click', () => globalSearch?.focus());
  $('[data-open-control]')?.addEventListener('click', () => { window.location.href = `${boot.adminUrl}&workspace=control-tower`; });

  // Close checkbox dropdowns when clicking away.
  document.addEventListener('click', (event) => {
    $$('details.k30-check-dropdown[open]').forEach((details) => { if (!details.contains(event.target)) details.removeAttribute('open'); });
  });

  // 3.0.3 display preferences: instant theme, persisted language.
  $$('[data-theme-value]').forEach((button) => button.addEventListener('click', async () => {
    const theme = button.dataset.themeValue;
    if (!shell || !['light', 'dark'].includes(theme) || shell.dataset.theme === theme) return;
    const previous = shell.dataset.theme || 'light';
    shell.dataset.theme = theme;
    syncThemeMarker();
    redrawCharts();
    $$('[data-theme-value]').forEach((node) => {
      const active = node.dataset.themeValue === theme;
      node.classList.toggle('is-active', active);
      node.setAttribute('aria-pressed', active ? 'true' : 'false');
    });
    try {
      await api('/ui-preferences', { method: 'PATCH', body: { theme } });
      storageSet('k20ai_v302_theme', theme);
    } catch (error) {
      shell.dataset.theme = previous;
      syncThemeMarker();
      redrawCharts();
      $$('[data-theme-value]').forEach((node) => node.classList.toggle('is-active', node.dataset.themeValue === previous));
      toast('Theme was not saved', errorText(error), 'error');
    }
  }));
  $$('[data-language-value]').forEach((button) => button.addEventListener('click', async () => {
    const language = button.dataset.languageValue;
    if (!['fa', 'en'].includes(language) || shell?.dataset.language === language) return;
    button.disabled = true;
    try {
      await api('/ui-preferences', { method: 'PATCH', body: { language } });
      storageSet('k20ai_v302_language', language);
      location.reload();
    } catch (error) {
      toast('Language was not saved', errorText(error), 'error');
      button.disabled = false;
    }
  }));

  // 3.1 feature workflows live in a separate bounded module.
  window.K20AI31Workflows?.({ $, $$, api, shell, toast, errorText, icon, el, openModal, runAbility, uiText });

  // Embedded Bridge 3.3 console. Requests still pass the server allow-list and hard guards.
  const bridgeAction = $('[data-bridge-action]');
  const bridgePayload = $('[data-bridge-payload]');
  const bridgeResult = $('[data-bridge-result]');
  const renderBridgeResult = (value) => {
    if (!bridgeResult) return;
    bridgeResult.hidden = false;
    bridgeResult.textContent = JSON.stringify(value, null, 2);
  };
  bridgeAction?.addEventListener('change', () => {
    if (!bridgePayload) return;
    const action = bridgeAction.value;
    const examples = {
      'api.contract': { action: 'api.contract' },
      'system.info': { action: 'system.info' },
      'selftest.run': { action: 'selftest.run' },
      'observability.status': { action: 'observability.status' },
      'cache.status': { action: 'cache.status' },
      'audit.tail': { action: 'audit.tail', payload: { limit: 20 } },
      'engine.status': { action: 'engine.status', engine: 'news' },
      'engine.run': { action: 'engine.run', engine: 'news' },
      'seo.read': { action: 'seo.read', id: 123 },
      'content.search': { action: 'content.search', payload: { post_id: 123, field: 'post_content', pattern: 'exact text' } },
    };
    bridgePayload.value = JSON.stringify(examples[action] || { action, request_id: `ui-${Date.now()}` }, null, 2);
  });
  $('[data-bridge-selftest]')?.addEventListener('click', async (event) => {
    const button = event.currentTarget; button.disabled = true;
    try {
      const result = await api('/bridge/execute', { method: 'POST', body: { action: 'selftest.run', request_id: `ui-selftest-${Date.now()}` } });
      renderBridgeResult(result);
      toast(shell?.dataset.language === 'en' ? 'Bridge self-test completed' : 'Self-test بریدج اجرا شد', result?.ok ? 'Contract 3.3' : '');
    } catch (error) {
      renderBridgeResult(error?.data || { error: errorText(error) });
      toast(shell?.dataset.language === 'en' ? 'Bridge self-test failed' : 'Self-test بریدج ناموفق بود', errorText(error), 'error');
    } finally { button.disabled = false; }
  });
  $('[data-bridge-execute]')?.addEventListener('click', async (event) => {
    const button = event.currentTarget; button.disabled = true;
    try {
      let body = JSON.parse(bridgePayload?.value || '{}');
      if (!body || Array.isArray(body) || typeof body !== 'object') throw new Error('Request JSON must be an object.');
      if (bridgeAction?.value) body.action = bridgeAction.value;
      if (!body.request_id) body.request_id = `ui-${Date.now()}`;
      const result = await api('/bridge/execute', { method: 'POST', body });
      renderBridgeResult(result);
      toast(shell?.dataset.language === 'en' ? 'Bridge request completed' : 'درخواست Bridge انجام شد', body.action || 'OK');
    } catch (error) {
      renderBridgeResult(error?.data || { error: errorText(error) });
      toast(shell?.dataset.language === 'en' ? 'Bridge request failed' : 'درخواست Bridge ناموفق بود', errorText(error), 'error');
    } finally { button.disabled = false; }
  });

})();

/* K20 AI Press 3.2.0: inline ALT editing + Jalali scheduling. */
(() => {
  'use strict';
  const boot = window.K20AI_V3_BOOT || {};
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));
  const request = async (path, options = {}) => {
    const url = `${String(boot.restBase || '').replace(/\/$/, '')}${path.startsWith('/') ? path : `/${path}`}`;
    const headers = new Headers(options.headers || {});
    headers.set('X-WP-Nonce', boot.nonce || '');
    if (options.body && typeof options.body !== 'string') {
      headers.set('Content-Type', 'application/json');
      options.body = JSON.stringify(options.body);
    }
    const response = await fetch(url, { credentials: 'same-origin', ...options, headers });
    const raw = await response.text();
    let data = null;
    try { data = raw ? JSON.parse(raw) : null; } catch (_) { data = { message: raw }; }
    if (!response.ok) throw new Error(data?.message || `HTTP ${response.status}`);
    return data;
  };
  const notify = (title, message = '', tone = 'success') => {
    const stack = $('[data-toast-stack]');
    if (!stack) return;
    const toast = document.createElement('div');
    toast.className = `k30-toast ${tone}`;
    const strong = document.createElement('strong'); strong.textContent = title; toast.append(strong);
    if (message) { const small = document.createElement('small'); small.textContent = message; toast.append(small); }
    stack.append(toast); setTimeout(() => toast.remove(), 4200);
  };

  $$('[data-alt-editor]').forEach((form) => form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const button = $('button[type="submit"]', form);
    const input = $('input[name="alt"]', form);
    if (!input) return;
    if (button) button.disabled = true;
    try {
      await request(`/entity/media/${Number(form.dataset.id)}`, { method: 'PATCH', body: { fields: { alt: input.value.trim() } } });
      form.classList.toggle('danger', !input.value.trim());
      form.classList.toggle('success', Boolean(input.value.trim()));
      notify('ALT ذخیره شد', 'Media Library با مقدار جدید به‌روزرسانی شد.');
      const params = new URLSearchParams(location.search);
      if (params.get('status') === 'missing-alt' && input.value.trim()) form.closest('[data-alt-row]')?.remove();
    } catch (error) {
      notify('ذخیره ALT ناموفق بود', error.message || 'خطای ناشناخته', 'error');
    } finally { if (button) button.disabled = false; }
  }));

  const calendar = $('[data-jalali-calendar]');
  if (calendar && typeof Intl !== 'undefined') {
    const grid = $('[data-jcal-grid]', calendar);
    const title = $('[data-jcal-title]', calendar);
    const selectedDate = $('[data-jcal-selected-date]');
    const selectedLabel = $('[data-jcal-selected-label]');
    const events = (() => { try { return JSON.parse(calendar.dataset.jalaliCalendar || '[]'); } catch (_) { return []; } })();
    const partsFmt = new Intl.DateTimeFormat('en-US-u-ca-persian', { year: 'numeric', month: 'numeric', day: 'numeric' });
    const labelFmt = new Intl.DateTimeFormat('fa-IR-u-ca-persian', { year: 'numeric', month: 'long', day: 'numeric' });
    const monthFmt = new Intl.DateTimeFormat('fa-IR-u-ca-persian', { year: 'numeric', month: 'long' });
    const dateParts = (date) => {
      const out = {};
      partsFmt.formatToParts(date).forEach((part) => { if (['year','month','day'].includes(part.type)) out[part.type] = Number(part.value); });
      return out;
    };
    const isoLocal = (date) => `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}-${String(date.getDate()).padStart(2,'0')}`;
    const eventMap = new Map();
    events.forEach((item) => {
      const key = String(item.date || '').slice(0, 10);
      if (!key) return;
      if (!eventMap.has(key)) eventMap.set(key, []);
      eventMap.get(key).push(item);
    });
    let anchor = new Date();
    anchor.setHours(12,0,0,0);
    const render = () => {
      if (!grid || !title) return;
      const target = dateParts(anchor);
      title.textContent = monthFmt.format(anchor);
      grid.replaceChildren();
      const candidates = [];
      for (let offset = -45; offset <= 45; offset += 1) {
        const d = new Date(anchor); d.setDate(anchor.getDate() + offset); d.setHours(12,0,0,0);
        const p = dateParts(d);
        if (p.year === target.year && p.month === target.month) candidates.push({ date: d, p });
      }
      candidates.sort((a,b) => a.date - b.date);
      if (!candidates.length) return;
      const firstOffset = (candidates[0].date.getDay() + 1) % 7;
      for (let i = 0; i < firstOffset; i += 1) { const blank = document.createElement('span'); blank.className = 'is-blank'; grid.append(blank); }
      candidates.forEach(({ date, p }) => {
        const button = document.createElement('button'); button.type = 'button'; button.className = 'k30-jcal-day';
        const iso = isoLocal(date); button.dataset.date = iso;
        const day = document.createElement('b'); day.textContent = String(p.day); button.append(day);
        const dayEvents = eventMap.get(iso) || [];
        if (dayEvents.length) {
          button.classList.add('has-events');
          const dot = document.createElement('small'); dot.textContent = `${dayEvents.length} مورد`; button.append(dot);
          button.title = dayEvents.map((item) => item.title).join(' • ');
        }
        button.addEventListener('click', () => {
          $$('.k30-jcal-day.is-selected', grid).forEach((node) => node.classList.remove('is-selected'));
          button.classList.add('is-selected');
          if (selectedDate) selectedDate.value = iso;
          if (selectedLabel) selectedLabel.value = labelFmt.format(date);
        });
        grid.append(button);
      });
    };
    $('[data-jcal-prev]', calendar)?.addEventListener('click', () => { anchor = new Date(anchor.getTime()); anchor.setDate(anchor.getDate() - 32); render(); });
    $('[data-jcal-next]', calendar)?.addEventListener('click', () => { anchor = new Date(anchor.getTime()); anchor.setDate(anchor.getDate() + 32); render(); });
    render();
  }

  $('[data-calendar-schedule]')?.addEventListener('submit', async (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    const id = Number(form.elements.id?.value || 0);
    const date = String(form.elements.date?.value || '');
    const time = String(form.elements.time?.value || '');
    const button = $('button[type="submit"]', form);
    if (!id || !date || !time) { notify('اطلاعات زمان‌بندی ناقص است', 'محتوا، روز شمسی و ساعت را انتخاب کنید.', 'error'); return; }
    if (button) button.disabled = true;
    try {
      await request('/calendar/schedule', { method: 'POST', body: { id, datetime: `${date}T${time}` } });
      notify('زمان‌بندی ذخیره شد', 'وضعیت محتوا در WordPress به Future به‌روزرسانی شد.');
      setTimeout(() => location.reload(), 650);
    } catch (error) {
      notify('زمان‌بندی ناموفق بود', error.message || 'خطای ناشناخته', 'error');
      if (button) button.disabled = false;
    }
  });
})();

/* 3.2.0 sourced web-research surface. */
(() => {
  'use strict';
  const form = document.querySelector('[data-serp-research]');
  const target = document.querySelector('[data-serp-research-result]');
  if (!form || !target) return;
  const boot = window.K20AI_V3_BOOT || {};
  const api = async (path, body) => {
    const response = await fetch(`${String(boot.restBase || '').replace(/\/$/, '')}${path}`, { method: 'POST', credentials: 'same-origin', headers: { 'X-WP-Nonce': boot.nonce || '', 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    const raw = await response.text(); let data = null; try { data = raw ? JSON.parse(raw) : null; } catch (_) { data = { message: raw }; }
    if (!response.ok) throw new Error(data?.message || `HTTP ${response.status}`);
    return data;
  };
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const button = form.querySelector('button[type="submit"]');
    const query = String(form.elements.query?.value || '').trim();
    if (!query) return;
    if (button) button.disabled = true;
    target.replaceChildren();
    const loading = document.createElement('p'); loading.className = 'k30-note'; loading.textContent = 'در حال پژوهش زنده و دریافت Sourceهای واقعی…'; target.append(loading);
    try {
      const data = await api('/serp/research', { query });
      target.replaceChildren();
      const note = document.createElement('div'); note.className = 'k30-source-banner';
      const noteIcon = document.createElement('span'); noteIcon.className = 'dashicons dashicons-info-outline'; note.append(noteIcon);
      const noteCopy = document.createElement('div'); const noteTitle = document.createElement('b'); noteTitle.textContent = 'Web Search منبع‌دار'; const noteSmall = document.createElement('small'); noteSmall.textContent = data.note || ''; noteCopy.append(noteTitle,noteSmall); note.append(noteCopy); target.append(note);
      const list = document.createElement('div'); list.className = 'k30-google-like-results';
      (data.results || []).forEach((row, index) => {
        const article = document.createElement('article');
        const meta = document.createElement('small'); meta.textContent = `${index + 1} · ${new URL(row.url).hostname}`;
        const link = document.createElement('a'); link.href = row.url; link.target = '_blank'; link.rel = 'noopener noreferrer'; link.textContent = row.title || row.url;
        article.append(meta,link); list.append(article);
      });
      if (!(data.results || []).length) { const empty = document.createElement('p'); empty.className = 'k30-note'; empty.textContent = 'Web Search اجرا شد اما Source قابل نمایش برنگشت.'; list.append(empty); }
      target.append(list);
      if (data.summary) { const summary = document.createElement('p'); summary.className = 'k30-note'; summary.textContent = data.summary; target.append(summary); }
      if ((data.recommendations || []).length) {
        const ul = document.createElement('ul'); ul.className = 'k30-research-recommendations';
        data.recommendations.forEach((item) => { const li = document.createElement('li'); li.textContent = item; ul.append(li); }); target.append(ul);
      }
    } catch (error) {
      target.replaceChildren(); const p = document.createElement('p'); p.className = 'k30-connection-error'; p.textContent = error.message || 'پژوهش زنده ناموفق بود.'; target.append(p);
    } finally { if (button) button.disabled = false; }
  });
})();
