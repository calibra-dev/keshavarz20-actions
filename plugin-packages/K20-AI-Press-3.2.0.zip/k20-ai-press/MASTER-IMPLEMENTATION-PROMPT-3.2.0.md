# K20 AI Press 3.2.0 — Final Implementation Contract

## Mission
Build K20 AI Press 3.2.0 from the verified 3.1.4 codebase. The release must replace the existing stable plugin path `k20-ai-press/`, preserve real WordPress/WooCommerce data, remove decorative/non-functional UI, and make every control in scope perform an actual read/write or explicitly fail closed when an external provider is not connected.

## Non-negotiable truth rules
1. Never invent product scores, rankings, Google results, Search Console metrics, AI visibility, competitor data, or media health.
2. A value that is not measured is `—` / Not measured, never synthetic zero unless zero is the actual measured value.
3. Search Console data is historical/aggregated performance and must not be labeled as a live Google SERP result.
4. Live Google-like organic results require a configured SERP provider. Default provider for this release is optional SerpApi; when it is not configured, show a clear connection-required state. Do not scrape google.com directly.
5. OpenAI web search may analyze sourced web results but must not be presented as a definitive Google Top-5 ranking.
6. Every write must use WordPress/WooCommerce APIs, plugin REST abilities, or guarded data access with capability checks, sanitization, escaping, audit logging, and rollback/proposal governance where applicable.

## Release/version contract
- Release version: 3.2.0.
- Main directory/slug: `k20-ai-press` only.
- Main file: `k20-ai-press/k20-ai-press.php`.
- Synchronize Plugin Header Version, `K20AI_PRESS_VERSION`, readme Stable tag, changelog, POT project version, and asset cache version.
- No install ZIP may contain a versioned root directory.
- Existing changelog history may mention prior versions; runtime/source version declarations must be 3.2.0.

## Acceptance requirements from the 12 user screenshots

### A. Charts / layout / RTL
- Axis labels and large numeric values must not clip in RTL or LTR.
- Increase chart left gutter and right-align Y-axis labels.
- Remove the unnecessary lower architecture/operating-model card and other red-highlighted decorative cards identified by the user.
- Fix mixed/overlapping Persian copy and dark/light contrast.
- Long titles, numbers and labels must wrap or fit; never hide critical values with ellipsis.

### B. Control Tower
- No fake dashes where a real local value is available.
- Every row identifies the exact entity (product/media/post/page), title, ID and source.
- Review opens a meaningful entity detail/editor, not a generic workspace.
- Fix/save actually updates the source entity, re-analyzes it, and resolved issues disappear after successful save/re-analysis.
- Product scans must be resumable, background/bounded, heartbeat-driven and recover stale locks.

### C. Universal collection UX
For every potentially long list/workspace:
- 20 items per page by default.
- Numeric page buttons + previous/next + total range/count.
- Preserve filters while changing pages.
- Real refresh/reload action in the section header; refresh invalidates/re-reads data and can discover newly added products/media/content/issues.
- No hard-coded first-50/first-100/first-120 data ceiling that silently hides site objects. If a source API itself paginates, iterate/page safely.

### D. Product Intelligence
- Enumerate the full WooCommerce product catalog, including all categories the current user can read.
- Category/search/status filters must work against the entire catalog.
- Show total catalog count, measured count, unmeasured count, coverage, backlog and average only from measured products.
- Run/refresh Product scan with real progress.
- 20-per-page numeric pagination.
- Review opens Product Control Tower/detail with exact gaps and safe edit paths.
- No product is assigned 0/100 merely because it has not been scanned.

### E. Images / ALT
- Enumerate all readable image attachments, not a first-page subset.
- Show image thumbnail, image title/filename, attachment ID, where used (post/product title and ID), dimensions/type/size, current ALT and health score.
- Inline ALT edit must persist to Media Library.
- When a missing-ALT row is fixed successfully, remove it immediately from the missing-ALT view and update counters.
- Pagination, numeric page buttons and real refresh.
- Duplicate groups paginated; empty/irrelevant lower card removed.

### F. Schema / previews
- Entity selector must cover all relevant readable entities with search/pagination, not only a tiny analyzed subset.
- SERP/social/schema previews must fit in modal/card without clipping.
- Provide a visible Save Changes action for editable SEO fields.
- Save -> re-analyze -> update preview and issues.

### G. Live SEO Editor
- Entity type selector plus searchable/paginated selector over real products/posts/pages/news/media, including entities not yet analyzed.
- Selecting an unmeasured entity triggers on-demand analysis/read, not omission.
- Issue guide updates live as fields change before save by using the same rule engine in preview mode; no made-up client-only score.
- Resolved live issues disappear immediately from the guide.
- Save button persists and re-analyzes.

### H. Live SERP + rank + AI keyword recommendations
- Add optional `serpapi` Connection Center provider with encrypted API key and configurable locale/location/domain parameters.
- `Live Google SERP` workspace/card: select/search a product/content entity, derive query from explicit user input or selected entity, call connected SerpApi, display Google-like organic result cards with positions 1–10 and clearly label source/time/location.
- Highlight the selected site's domain when it appears and report observed live SERP position from that response only.
- Separately show Search Console average position/clicks/impressions/CTR for the selected page/query when GSC data exists, labeled historical performance.
- Analyze the first five organic result titles/snippets/pages with the connected AI provider; return sourced keyword/topic/entity suggestions. The AI must receive the exact source list and produce recommendations, not rankings.
- Allow applying selected keyword suggestions to the selected entity through the guarded SEO editor.
- When SerpApi, AI provider or GSC is unavailable, show the missing connection and never fabricate results.

### I. Jalali publishing calendar
- Full month navigation in Persian/Jalali UI.
- Include all editable draft/pending/future posts, pages, news/article CPTs and WooCommerce coupons, not first 100 silently.
- Search/filter/page the scheduling queue where necessary.
- Scheduling writes WordPress-local date/time and `future` status so WordPress publishes at the scheduled time; verify post status/date after write.
- Coupon scheduling must respect WooCommerce coupon post type/capabilities and not invent discount data.

### J. Clickable KPI filters
- KPI cards that represent a subset/count must be buttons/links applying the corresponding real filter below.
- Active filter state visibly reflected.
- Reload icon must execute a real refresh/re-read, not animation only.

## Scan engine safety
- Never run a large synchronous full-catalog scan inside a single browser request.
- Workers use bounded wall-clock budget, small batches and per-item heartbeat/cursor persistence.
- Lock TTL <= 60s and stale running scans recover automatically.
- Product/media/content/crawl scan status endpoints return real processed/total/progress and a last heartbeat.
- Browser polling must not itself perform heavy synchronous work.
- Repeated click must attach to/reuse an active compatible scan rather than create duplicate workers.

## Security and reliability
- REST routes require explicit capabilities and nonces/authentication as appropriate.
- All IDs use absint; keys sanitize_key; text sanitize_text_field/sanitize_textarea_field; URLs esc_url_raw; output escaped by context.
- External HTTP requests use safe URLs, timeouts, bounded response size and no secret leakage.
- Provider secrets stored encrypted via existing crypto layer.
- Do not log API keys/tokens.
- No raw SQL mutation for WooCommerce/post data.
- Read SQL must be prepared where parameters exist and bounded/paginated.

## UI/UX quality bar
- Persian RTL primary, English switch remains functional.
- Dark/light mode readable in every card.
- No decorative card exists without actionable information.
- Empty states explain exactly which scan/connection is required.
- All controls have disabled/loading/error/success states.
- Mobile/tablet layout must not overflow horizontally except intentionally scrollable data tables.

## Verification gates
1. PHP lint every PHP file: PASS.
2. `node --check` every JS file: PASS.
3. Scan direct method calls for undefined class/trait methods: PASS or manually justified dynamic dispatch.
4. Scan database table references against `K20AI_Database::tables()`: PASS.
5. Search runtime code for stale `3.1.4` release declarations: none except historical changelog/readme narrative.
6. ZIP root exactly `k20-ai-press/`; no duplicate top-level plugin folder.
7. Static acceptance script confirms: no category `number=>50`, no live-editor `LIMIT 120`, no calendar `posts_per_page=>100`, numeric pager exists, SerpApi provider/route exists, live preview route exists, scan lock/batch safety present.
8. Build SHA-256 manifest.
9. Install/update on `https://keshavarz20.com` only after local gates pass.
10. Verify on live site: active stable slug is 3.2.0, duplicate versioned copy inactive/removed, REST health responds, admin assets are 3.2.0, no PHP fatal, main workspaces load.
11. Purge cache only if deployment path did not already perform a cache purge; do not double flush.

## Release deliverables
- `K20-AI-Press-3.2.0.zip` installable package.
- `K20-AI-Press-3.2.0-COMPLETE-BUNDLE.zip` containing install ZIP, full source, this master prompt, changelog, acceptance report and SHA-256 manifests.
- A concise live verification report stating what is proven, what requires a provider credential (especially live SERP), and no claim of functionality that was not tested.
