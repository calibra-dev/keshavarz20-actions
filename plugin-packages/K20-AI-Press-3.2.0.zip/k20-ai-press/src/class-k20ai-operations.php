<?php

defined( 'ABSPATH' ) || exit;

final class K20AI_Operations {
    private K20AI_Advanced $advanced;

    public function __construct( K20AI_Advanced $advanced ) {
        $this->advanced = $advanced;
    }

    public function graph_rebuild( int $limit = 300 ): array|WP_Error {
        if ( ! function_exists( 'wc_get_products' ) ) {
            return new WP_Error( 'woocommerce_missing', __( 'WooCommerce در دسترس نیست.', 'k20-ai-press' ), array( 'status' => 503 ) );
        }
        global $wpdb;
        $t = K20AI_Database::tables();
        $products = wc_get_products( array( 'status' => array( 'publish','draft','private' ), 'limit' => max( 1, min( 500, $limit ) ), 'return' => 'objects' ) );
        $entities = 0; $edges = 0;
        foreach ( $products as $product ) {
            $product_key = 'product:' . $product->get_id();
            $product_entity = $this->upsert_entity( 'Product', $product_key, $product->get_name(), array( 'sku' => $product->get_sku(), 'status' => $product->get_status() ) );
            if ( ! $product_entity ) { continue; }
            ++$entities;
            $cats = wp_get_post_terms( $product->get_id(), 'product_cat', array( 'fields' => 'all' ) );
            if ( ! is_wp_error( $cats ) ) {
                foreach ( $cats as $term ) {
                    $cat_entity = $this->upsert_entity( 'Category', 'category:' . $term->term_id, $term->name, array( 'slug' => $term->slug ) );
                    if ( $cat_entity ) { $this->upsert_edge( $product_entity, $cat_entity, 'IN_CATEGORY', 'WooCommerce', 100.0 ); ++$edges; }
                }
            }
            foreach ( $product->get_attributes() as $name => $attribute ) {
                if ( ! is_object( $attribute ) || ! method_exists( $attribute, 'get_options' ) ) { continue; }
                foreach ( (array) $attribute->get_options() as $value ) {
                    $label = is_numeric( $value ) && taxonomy_exists( $attribute->get_name() ) ? get_term_field( 'name', (int) $value, $attribute->get_name() ) : (string) $value;
                    if ( is_wp_error( $label ) || '' === trim( (string) $label ) ) { continue; }
                    $key = 'attribute:' . sanitize_key( (string) $name ) . ':' . md5( (string) $label );
                    $attr_entity = $this->upsert_entity( 'Attribute', $key, (string) $label, array( 'attribute' => (string) $name ) );
                    if ( $attr_entity ) { $this->upsert_edge( $product_entity, $attr_entity, 'HAS_ATTRIBUTE', 'WooCommerce', 100.0 ); ++$edges; }
                }
            }
        }
        return array( 'products' => count( $products ), 'entities_touched' => $entities, 'edges_touched' => $edges );
    }

    private function upsert_entity( string $type, string $key, string $label, array $data ): int {
        global $wpdb;
        $t = K20AI_Database::tables();
        $id = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t['entities']} WHERE entity_key=%s", $key ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $row = array( 'entity_type' => $type, 'entity_key' => $key, 'label' => $label, 'data' => wp_json_encode( $data ), 'updated_at' => current_time( 'mysql', true ) );
        if ( $id ) { $wpdb->update( $t['entities'], $row, array( 'id' => $id ) ); return $id; }
        $row['created_at'] = current_time( 'mysql', true );
        $wpdb->insert( $t['entities'], $row );
        return (int) $wpdb->insert_id;
    }

    private function upsert_edge( int $source, int $target, string $relation, string $origin, float $confidence ): void {
        global $wpdb;
        $t = K20AI_Database::tables();
        $id = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t['edges']} WHERE source_entity=%d AND target_entity=%d AND relation=%s LIMIT 1", $source, $target, $relation ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $row = array( 'source_entity' => $source, 'target_entity' => $target, 'relation' => $relation, 'source' => $origin, 'confidence' => $confidence, 'review_status' => 'VERIFIED', 'updated_at' => current_time( 'mysql', true ) );
        if ( $id ) { $wpdb->update( $t['edges'], $row, array( 'id' => $id ) ); return; }
        $row['version'] = 1; $row['created_at'] = current_time( 'mysql', true );
        $wpdb->insert( $t['edges'], $row );
    }

    public function graph_query( string $entity_key ): array|WP_Error {
        global $wpdb;
        $t = K20AI_Database::tables();
        $entity = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t['entities']} WHERE entity_key=%s", sanitize_text_field( $entity_key ) ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        if ( ! $entity ) { return new WP_Error( 'entity_not_found', __( 'موجودیت پیدا نشد.', 'k20-ai-press' ), array( 'status' => 404 ) ); }
        $edges = $wpdb->get_results( $wpdb->prepare( "SELECT e.*,s.label source_label,tg.label target_label FROM {$t['edges']} e LEFT JOIN {$t['entities']} s ON s.id=e.source_entity LEFT JOIN {$t['entities']} tg ON tg.id=e.target_entity WHERE e.source_entity=%d OR e.target_entity=%d ORDER BY e.id DESC LIMIT 100", $entity['id'], $entity['id'] ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        return array( 'entity' => $entity, 'edges' => $edges ?: array() );
    }

    public function intent_parse( string $query ): array {
        $query = $this->advanced->normalize_persian( $query );
        $out = array( 'raw' => $query, 'crop' => null, 'area_ha' => null, 'flow_l_s' => null, 'pressure_bar' => null, 'water_source' => null, 'intent' => null, 'missing' => array() );
        $crops = array( 'گوجه' => 'tomato', 'گندم' => 'wheat', 'ذرت' => 'corn', 'سیب زمینی' => 'potato', 'سیب‌زمینی' => 'potato', 'پسته' => 'pistachio', 'خیار' => 'cucumber' );
        foreach ( $crops as $fa => $en ) { if ( false !== mb_stripos( $query, $fa ) ) { $out['crop'] = $en; break; } }
        if ( preg_match( '/([0-9۰-۹\.]+)\s*(هکتار|ha)/u', $query, $m ) ) { $out['area_ha'] = $this->number( $m[1] ); }
        if ( preg_match( '/([0-9۰-۹\.]+)\s*(لیتر\s*بر\s*ثانیه|l\/s)/ui', $query, $m ) ) { $out['flow_l_s'] = $this->number( $m[1] ); }
        if ( preg_match( '/([0-9۰-۹\.]+)\s*(بار|bar)/ui', $query, $m ) ) { $out['pressure_bar'] = $this->number( $m[1] ); }
        if ( false !== mb_stripos( $query, 'چاه' ) ) { $out['water_source'] = 'well'; }
        elseif ( false !== mb_stripos( $query, 'استخر' ) ) { $out['water_source'] = 'reservoir'; }
        if ( preg_match( '/سیستم|کامل|تجهیزات/u', $query ) ) { $out['intent'] = 'complete_system'; }
        elseif ( preg_match( '/مقایسه|فرق/u', $query ) ) { $out['intent'] = 'compare'; }
        elseif ( preg_match( '/خرید|قیمت/u', $query ) ) { $out['intent'] = 'purchase'; }
        else { $out['intent'] = 'information'; }
        foreach ( array( 'crop','area_ha' ) as $key ) { if ( null === $out[ $key ] ) { $out['missing'][] = $key; } }
        return $out;
    }

    private function number( string $value ): float {
        $value = strtr( $value, array( '۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9','٫'=>'.' ) );
        return (float) $value;
    }

    public function guided_sell( string $query ): array {
        $intent = $this->intent_parse( $query );
        if ( $intent['missing'] ) {
            return array( 'status' => 'NEEDS_CONTEXT', 'intent' => $intent, 'questions' => array_map( static fn( $k ) => 'لطفاً ' . $k . ' را مشخص کنید.', $intent['missing'] ), 'products' => array() );
        }
        $results = $this->advanced->rag_search( $query, 10 );
        return array( 'status' => $results ? 'CANDIDATES' : 'NO_EVIDENCE', 'intent' => $intent, 'products' => $results, 'ranking_policy' => 'evidence/relevance only; no hidden commercial boost' );
    }

    public function review_summary( int $product_id ): array|WP_Error {
        if ( 'product' !== get_post_type( $product_id ) ) { return new WP_Error( 'product_not_found', __( 'محصول پیدا نشد.', 'k20-ai-press' ), array( 'status' => 404 ) ); }
        $comments = get_comments( array( 'post_id' => $product_id, 'status' => 'approve', 'type' => 'review', 'number' => 100 ) );
        $ratings = array();
        foreach ( $comments as $c ) {
            $r = (int) get_comment_meta( $c->comment_ID, 'rating', true );
            if ( $r >= 1 && $r <= 5 ) { $ratings[] = $r; }
        }
        return array(
            'product_id' => $product_id,
            'review_count' => count( $comments ),
            'rated_count' => count( $ratings ),
            'average_rating' => $ratings ? round( array_sum( $ratings ) / count( $ratings ), 2 ) : null,
            'verified_purchase_summary' => null,
            'note' => 'هیچ Review ساختگی یا خلاصه AI بدون درخواست/Provider تولید نمی‌شود.',
        );
    }

    public function media_truth( int $product_id ): array|WP_Error {
        if ( ! function_exists( 'wc_get_product' ) ) { return new WP_Error( 'woocommerce_missing', __( 'WooCommerce در دسترس نیست.', 'k20-ai-press' ), array( 'status' => 503 ) ); }
        $p = wc_get_product( $product_id ); if ( ! $p ) { return new WP_Error( 'product_not_found', __( 'محصول پیدا نشد.', 'k20-ai-press' ), array( 'status' => 404 ) ); }
        $ids = array_values( array_unique( array_filter( array_merge( array( $p->get_image_id() ), $p->get_gallery_image_ids() ) ) ) );
        $assets = array();
        foreach ( $ids as $id ) {
            $path = get_attached_file( $id );
            $assets[] = array(
                'asset_id' => $id,
                'product_id' => $product_id,
                'source' => wp_get_attachment_url( $id ),
                'original_hash' => is_string( $path ) && is_readable( $path ) ? hash_file( 'sha256', $path ) : null,
                'real_or_AI' => get_post_meta( $id, '_k20ai_real_or_ai', true ) ?: 'UNKNOWN',
                'capture_date' => get_post_meta( $id, '_k20ai_capture_date', true ) ?: null,
                'license' => get_post_meta( $id, '_k20ai_license', true ) ?: null,
                'alt' => get_post_meta( $id, '_wp_attachment_image_alt', true ) ?: null,
                'caption' => wp_get_attachment_caption( $id ) ?: null,
                'evidence_level' => get_post_meta( $id, '_k20ai_evidence_level', true ) ?: 'unknown',
            );
        }
        return array( 'product_id' => $product_id, 'assets' => $assets );
    }

    public function statistical_noise( array $values ): array|WP_Error {
        $values = array_values( array_filter( array_map( 'floatval', $values ), static fn( $v ) => is_finite( $v ) ) );
        if ( count( $values ) < 3 ) { return new WP_Error( 'insufficient_sample', __( 'حداقل ۳ نمونه لازم است.', 'k20-ai-press' ), array( 'status' => 422 ) ); }
        $n = count( $values ); $mean = array_sum( $values ) / $n; $sum = 0.0;
        foreach ( $values as $v ) { $sum += ( $v - $mean ) ** 2; }
        $variance = $sum / max( 1, $n - 1 ); $sd = sqrt( $variance );
        $change = $values[ $n - 1 ] - $values[ $n - 2 ];
        $z = $sd > 0 ? abs( $change ) / $sd : 0.0;
        return array( 'sample_size' => $n, 'mean' => round( $mean, 4 ), 'variance' => round( $variance, 4 ), 'change' => round( $change, 4 ), 'change_significance_z' => round( $z, 3 ), 'likely_noise' => $z < 1.0, 'confidence' => $n >= 30 ? 'higher' : 'limited' );
    }

    public function prompt_bank( int $limit = 200 ): array {
        $intents = array( 'information','compare','purchase','troubleshooting','compatibility','calculation','support','citation' );
        $personas = array( 'farmer','greenhouse','gardener','buyer','engineer' );
        $funnels = array( 'awareness','consideration','decision','post_purchase','technical' );
        $templates = array(
            'چه اطلاعاتی برای {intent} درباره محصول یا مسئله کشاورزی لازم است؟',
            'برای {persona} یک پرسش {intent} با هدف {funnel} بساز.',
            'کدام Evidence برای پاسخ {intent} در مرحله {funnel} لازم است؟',
            'ریسک پاسخ بدون مدرک برای {persona} در سناریوی {intent} چیست؟',
            'چه داده‌ای برای تصمیم {intent} باید از Product Truth خوانده شود؟',
        );
        $out = array(); $i = 0;
        foreach ( $intents as $intent ) foreach ( $personas as $persona ) foreach ( $funnels as $funnel ) {
            $tpl = $templates[ $i % count( $templates ) ];
            $out[] = array( 'id' => 'baseline-' . str_pad( (string) ( $i + 1 ), 3, '0', STR_PAD_LEFT ), 'intent' => $intent, 'persona' => $persona, 'funnel' => $funnel, 'language' => 'fa', 'region' => null, 'importance' => 'baseline', 'target_entity' => null, 'run_date' => null, 'prompt' => strtr( $tpl, array( '{intent}'=>$intent, '{persona}'=>$persona, '{funnel}'=>$funnel ) ) );
            ++$i; if ( $i >= max( 1, min( 500, $limit ) ) ) { break 3; }
        }
        return $out;
    }

    public function robots_preview(): array {
        $policy = $this->advanced->bot_policy();
        $rules = array( 'User-agent: *', 'Disallow:' );
        $blocked = array();
        foreach ( $this->advanced->bot_registry() as $entry ) {
            if ( $this->advanced->bot_entry_allowed( $entry, $policy ) ) {
                continue;
            }
            foreach ( (array) ( $entry['robots_tokens'] ?? array() ) as $ua ) {
                $ua = trim( (string) $ua );
                if ( '' !== $ua ) {
                    $blocked[ $ua ] = true;
                }
            }
        }
        foreach ( array_keys( $blocked ) as $ua ) {
            $rules[] = '';
            $rules[] = 'User-agent: ' . $ua;
            $rules[] = 'Disallow: /';
        }
        return array(
            'virtual' => implode( "\n", $rules ) . "\n",
            'physical_exists' => file_exists( ABSPATH . 'robots.txt' ),
            'policy' => $policy,
            'blocked_tokens' => array_keys( $blocked ),
            'blocked_count' => count( $blocked ),
        );
    }

    public function robots_apply_virtual(): array|WP_Error {
        if ( file_exists( ABSPATH . 'robots.txt' ) ) { return new WP_Error( 'physical_robots_exists', __( 'robots.txt فیزیکی وجود دارد؛ افزونه آن را خودکار بازنویسی نمی‌کند.', 'k20-ai-press' ), array( 'status' => 409 ) ); }
        $previous = get_option( 'k20ai_virtual_robots', null );
        update_option( 'k20ai_virtual_robots_backup', $previous, false );
        $preview = $this->robots_preview();
        update_option( 'k20ai_virtual_robots', $preview['virtual'], false );
        return array( 'applied' => true, 'backup_available' => null !== $previous, 'content' => $preview['virtual'] );
    }

    public function robots_rollback(): array {
        $backup = get_option( 'k20ai_virtual_robots_backup', null );
        if ( null === $backup ) { delete_option( 'k20ai_virtual_robots' ); }
        else { update_option( 'k20ai_virtual_robots', $backup, false ); }
        delete_option( 'k20ai_virtual_robots_backup' );
        return array( 'rolled_back' => true );
    }

    public function filter_robots( string $output ): string {
        $virtual = get_option( 'k20ai_virtual_robots', '' );
        return is_string( $virtual ) && '' !== trim( $virtual ) ? $virtual : $output;
    }

    public function webhooks(): array {
        $hooks = $this->stored_webhooks();
        foreach ( $hooks as &$hook ) {
            $hook['has_secret'] = ! empty( $hook['secret_enc'] ) || ! empty( $hook['secret'] );
            unset( $hook['secret'], $hook['secret_enc'] );
        }
        unset( $hook );
        return array_values( $hooks );
    }

    public function webhook_register( string $url, array $events, string $provided_secret = '' ): array|WP_Error {
        $safe = $this->safe_external_url( $url ); if ( is_wp_error( $safe ) ) { return $safe; }
        $hooks = $this->stored_webhooks();
        $id = 'wh_' . strtolower( wp_generate_password( 12, false, false ) );
        $provided_secret = trim( $provided_secret );
        if ( '' !== $provided_secret && strlen( $provided_secret ) < 32 ) {
            return new WP_Error( 'weak_webhook_secret', __( 'Webhook secrets must contain at least 32 characters.', 'k20-ai-press' ), array( 'status' => 422 ) );
        }
        $secret = '' !== $provided_secret ? $provided_secret : wp_generate_password( 48, true, true );
        $encrypted = K20AI_Crypto::encrypt_string( $secret, 'webhook-secret' );
        if ( is_wp_error( $encrypted ) ) return $encrypted;
        $hooks[ $id ] = array( 'id'=>$id, 'url'=>$safe, 'events'=>array_values( array_unique( array_map( 'sanitize_key', $events ) ) ), 'secret_enc'=>$encrypted, 'created_at'=>gmdate( DATE_ATOM ), 'active'=>true );
        update_option( 'k20ai_webhooks', $hooks, false );
        $result = array( 'id'=>$id, 'url'=>$safe, 'events'=>$hooks[$id]['events'], 'active'=>true, 'secret_created'=>true );
        if ( '' === $provided_secret ) { $result['generated_secret_once'] = $secret; }
        return $result;
    }

    public function webhook_test( string $id ): array|WP_Error {
        $hooks = $this->stored_webhooks();
        if ( empty( $hooks[ $id ] ) ) { return new WP_Error( 'webhook_not_found', __( 'Webhook not found.', 'k20-ai-press' ), array( 'status'=>404 ) ); }
        return $this->deliver_webhook( $hooks[ $id ], 'k20ai.test', array( 'time'=>gmdate( DATE_ATOM ) ) );
    }

    public function deliver_event( string $event, array $payload ): array {
        $hooks = $this->stored_webhooks(); $results = array();
        foreach ( $hooks as $hook ) {
            if ( empty( $hook['active'] ) || ( ! empty( $hook['events'] ) && ! in_array( $event, (array) $hook['events'], true ) ) ) { continue; }
            $results[] = $this->deliver_webhook( $hook, $event, $payload );
        }
        return $results;
    }

    private function deliver_webhook( array $hook, string $event, array $payload ): array|WP_Error {
        $safe = $this->safe_external_url( (string) $hook['url'] ); if ( is_wp_error( $safe ) ) { return $safe; }
        $secret = $this->webhook_secret( $hook );
        if ( null === $secret || '' === $secret ) return new WP_Error( 'webhook_secret_unavailable', __( 'The webhook secret cannot be decrypted.', 'k20-ai-press' ), array( 'status'=>500 ) );
        $body = wp_json_encode( array( 'event'=>$event, 'payload'=>$payload, 'time'=>gmdate( DATE_ATOM ) ) );
        $sig = hash_hmac( 'sha256', (string) $body, $secret );
        $response = wp_safe_remote_post( $safe, array( 'timeout'=>10, 'redirection'=>0, 'reject_unsafe_urls'=>true, 'limit_response_size'=>64 * KB_IN_BYTES, 'headers'=>array( 'Content-Type'=>'application/json', 'X-K20AI-Signature'=>'sha256=' . $sig ), 'body'=>$body, 'data_format'=>'body' ) );
        $status = is_wp_error( $response ) ? 0 : (int) wp_remote_retrieve_response_code( $response );
        $excerpt = is_wp_error( $response ) ? $response->get_error_message() : wp_remote_retrieve_body( $response );
        $excerpt = K20AI_Data_Integrity::redact_sensitive_text( $excerpt, 500 );
        global $wpdb; $t=K20AI_Database::tables();
        $wpdb->insert( $t['webhook_deliveries'], array( 'webhook_id'=>$hook['id'], 'event_name'=>$event, 'destination_hash'=>hash('sha256',$safe), 'status'=>is_wp_error($response)?'ERROR':(($status>=200&&$status<300)?'DELIVERED':'FAILED'), 'http_status'=>$status ?: null, 'attempt'=>1, 'response_excerpt'=>$excerpt, 'created_at'=>current_time('mysql',true), 'updated_at'=>current_time('mysql',true) ) );
        if ( is_wp_error( $response ) ) { return $response; }
        return array( 'webhook_id'=>$hook['id'], 'status'=>$status, 'delivered'=>$status>=200&&$status<300 );
    }

    /** @return array<string,array<string,mixed>> */
    private function stored_webhooks(): array {
        $hooks = get_option( 'k20ai_webhooks', array() );
        if ( ! is_array( $hooks ) ) return array();
        $dirty = false;
        foreach ( $hooks as $id => &$hook ) {
            if ( ! is_array( $hook ) ) { unset( $hooks[ $id ] ); $dirty = true; continue; }
            if ( empty( $hook['secret_enc'] ) && ! empty( $hook['secret'] ) ) {
                $encrypted = K20AI_Crypto::encrypt_string( (string) $hook['secret'], 'webhook-secret' );
                if ( ! is_wp_error( $encrypted ) ) {
                    $hook['secret_enc'] = $encrypted;
                    unset( $hook['secret'] );
                    $dirty = true;
                }
            }
        }
        unset( $hook );
        if ( $dirty ) update_option( 'k20ai_webhooks', $hooks, false );
        return $hooks;
    }

    private function webhook_secret( array $hook ): ?string {
        if ( ! empty( $hook['secret_enc'] ) ) return K20AI_Crypto::decrypt_string( (string) $hook['secret_enc'], 'webhook-secret' );
        return ! empty( $hook['secret'] ) ? (string) $hook['secret'] : null;
    }

    private function safe_external_url( string $url ): string|WP_Error {
        $url = esc_url_raw( $url, array( 'https' ) );
        if ( ! $url || ! wp_http_validate_url( $url ) ) { return new WP_Error( 'invalid_url', __( 'Only a public HTTPS URL is allowed.', 'k20-ai-press' ), array( 'status'=>422 ) ); }
        $host = wp_parse_url( $url, PHP_URL_HOST ); if ( ! is_string($host) || ''===$host ) { return new WP_Error( 'invalid_host', __( 'Host معتبر نیست.', 'k20-ai-press' ),array('status'=>422)); }
        $ips = gethostbynamel( $host );
        if ( ! is_array( $ips ) || ! $ips ) { return new WP_Error( 'dns_resolution_failed', __( 'مقصد DNS معتبر و قابل بررسی ندارد.', 'k20-ai-press' ),array('status'=>422)); }
        foreach ( $ips as $ip ) {
            if ( ! filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) ) { return new WP_Error( 'ssrf_blocked', __( 'مقصد به IP خصوصی/رزرو‌شده resolve می‌شود.', 'k20-ai-press' ),array('status'=>403)); }
        }
        return $url;
    }

    public function budgets(): array {
        $defaults = array( 'daily'=>null, 'monthly'=>null, 'behavior'=>'admin_approval' );
        $saved = get_option( 'k20ai_budgets', array() ); return wp_parse_args( is_array($saved)?$saved:array(), $defaults );
    }

    public function save_budgets( array $input ): array {
        $b=$this->budgets();
        foreach(array('daily','monthly') as $k){ if(array_key_exists($k,$input)){ $v=$input[$k]; $b[$k]=null===$v||''===$v?null:max(0,(float)$v); } }
        if(isset($input['behavior'])&&in_array($input['behavior'],array('fallback','disable_expensive_task','admin_approval'),true)){$b['behavior']=$input['behavior'];}
        update_option('k20ai_budgets',$b,false); return $b;
    }

    public function budget_status(): array {
        global $wpdb; $t=K20AI_Database::tables(); $b=$this->budgets();
        $daily=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(cost),0) FROM {$t['provider_usage']} WHERE created_at >= %s",gmdate('Y-m-d 00:00:00'))); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $monthly=(float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(cost),0) FROM {$t['provider_usage']} WHERE created_at >= %s",gmdate('Y-m-01 00:00:00'))); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        return array('budget'=>$b,'daily_used'=>$daily,'monthly_used'=>$monthly,'daily_percent'=>$b['daily']?round(100*$daily/$b['daily'],2):null,'monthly_percent'=>$b['monthly']?round(100*$monthly/$b['monthly'],2):null);
    }

    public function slo(): array {
        $defaults=array('public_product_api_availability'=>99.9,'critical_parity_errors'=>0,'queue_stuck_jobs'=>0,'p0_security_errors'=>0,'feed_freshness_hours'=>24);
        $saved=get_option('k20ai_slo',array()); return wp_parse_args(is_array($saved)?$saved:array(),$defaults);
    }

    public function save_slo( array $input ): array {
        $s=$this->slo(); foreach($s as $k=>$v){ if(isset($input[$k])&&is_numeric($input[$k])){$s[$k]=(float)$input[$k];} } update_option('k20ai_slo',$s,false); return $s;
    }

    public function gs1_mapping( int $product_id ): array|WP_Error {
        if(!function_exists('wc_get_product')){return new WP_Error( 'woocommerce_missing', __( 'WooCommerce در دسترس نیست.', 'k20-ai-press' ),array('status'=>503));}
        $p=wc_get_product($product_id); if(!$p){return new WP_Error( 'product_not_found', __( 'محصول پیدا نشد.', 'k20-ai-press' ),array('status'=>404));}
        $gtin = method_exists($p,'get_global_unique_id') ? (string)$p->get_global_unique_id() : (string)get_post_meta($product_id,'_global_unique_id',true);
        $digits=K20AI_Data_Integrity::normalize_gtin($gtin);
        if(!$digits){return array('product_id'=>$product_id,'status'=>'UNKNOWN','gtin'=>$gtin?:null,'digital_link'=>null,'reason'=>'invalid_or_unassigned_gtin');}
        return array('product_id'=>$product_id,'status'=>'READY','gtin'=>$digits,'digital_link'=>'https://id.gs1.org/01/'.str_pad($digits,14,'0',STR_PAD_LEFT));
    }

    public function setup_status(): array {
        $steps=array(
            'environment'=>version_compare(PHP_VERSION,'8.3','>='),
            'existing_integrations'=>true,
            'conflict_scan'=>true,
            'product_truth'=>function_exists('wc_get_product'),
            'providers'=>function_exists('wp_ai_client_prompt'),
            'rag'=>true,
            'bot_policy'=>true,
            'agents'=>function_exists('wp_register_ability'),
            'commerce'=>function_exists('wc_get_products'),
            'validation'=>true,
        );
        $pass=count(array_filter($steps));
        return array('steps'=>$steps,'completed'=>$pass,'total'=>count($steps),'recommended_mode'=>$pass===count($steps)?'hybrid':'shadow','risk_report'=>array_values(array_keys(array_filter($steps,static fn($v)=>!$v))));
    }
}
