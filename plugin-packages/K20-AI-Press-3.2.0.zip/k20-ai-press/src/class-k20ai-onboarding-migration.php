<?php

defined( 'ABSPATH' ) || exit;

/** Guided setup plus reversible SEO metadata migration. */
final class K20AI_Onboarding_Migration {
    private const SOURCES = array( 'yoast', 'rank_math', 'aioseo', 'seopress' );

    /** @return array<string,mixed> */
    public function status(): array {
        $state = get_option( 'k20ai_onboarding_state', array() );
        $state = is_array( $state ) ? $state : array();
        $plugins = $this->detect_sources();
        $steps = array(
            'site_profile' => ! empty( $state['site_profile'] ),
            'seo_source'   => ! empty( $state['seo_source'] ) || ! array_filter( $plugins ),
            'connections'  => ! empty( $state['connections_acknowledged'] ),
            'baseline'     => ! empty( $state['baseline_acknowledged'] ),
            'complete'     => ! empty( $state['complete'] ),
        );
        return array(
            'state'       => K20AI_Logger::sanitize_context( $state ),
            'steps'       => $steps,
            'completed'   => count( array_filter( $steps ) ),
            'total'       => count( $steps ),
            'seo_sources' => $plugins,
            'ready'       => count( array_filter( $steps ) ) === count( $steps ),
        );
    }

    /** @return array<string,mixed>|WP_Error */
    public function update_status( array $input ): array|WP_Error {
        $state = get_option( 'k20ai_onboarding_state', array() );
        $state = is_array( $state ) ? $state : array();
        if ( isset( $input['site_profile'] ) ) {
            $profile = sanitize_key( (string) $input['site_profile'] );
            if ( ! in_array( $profile, array( 'store', 'content', 'service', 'mixed' ), true ) ) {
                return new WP_Error( 'invalid_site_profile', __( 'Site profile is invalid.', 'k20-ai-press' ), array( 'status' => 422 ) );
            }
            $state['site_profile'] = $profile;
        }
        if ( isset( $input['seo_source'] ) ) {
            $source = sanitize_key( (string) $input['seo_source'] );
            if ( '' !== $source && ! in_array( $source, self::SOURCES, true ) && 'none' !== $source ) {
                return new WP_Error( 'invalid_seo_source', __( 'SEO migration source is invalid.', 'k20-ai-press' ), array( 'status' => 422 ) );
            }
            $state['seo_source'] = $source;
        }
        foreach ( array( 'connections_acknowledged', 'baseline_acknowledged', 'complete' ) as $flag ) {
            if ( array_key_exists( $flag, $input ) ) $state[ $flag ] = (bool) $input[ $flag ];
        }
        if ( ! empty( $state['complete'] ) ) {
            $sources = $this->detect_sources();
            $source_ready = ! empty( $state['seo_source'] ) || ! array_filter( $sources );
            if ( empty( $state['site_profile'] ) || ! $source_ready || empty( $state['connections_acknowledged'] ) || empty( $state['baseline_acknowledged'] ) ) {
                $state['complete'] = false;
                return new WP_Error( 'onboarding_prerequisites_incomplete', __( 'Complete the site profile, SEO source decision, connections review, and baseline review before finishing onboarding.', 'k20-ai-press' ), array( 'status' => 409 ) );
            }
        }
        $state['updated_at'] = current_time( DATE_ATOM, true );
        update_option( 'k20ai_onboarding_state', $state, false );
        return $this->status();
    }

    /** @return array<string,bool> */
    public function detect_sources(): array {
        global $wpdb;
        $aioseo_table = $wpdb->prefix . 'aioseo_posts';
        return array(
            'yoast'     => defined( 'WPSEO_VERSION' ) || defined( 'WPSEO_PREMIUM_VERSION' ),
            'rank_math' => class_exists( 'RankMath' ) || defined( 'RANK_MATH_VERSION' ),
            'aioseo'    => class_exists( 'AIOSEO\\Plugin\\AIOSEO' ) || $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $aioseo_table ) ) === $aioseo_table,
            'seopress'  => defined( 'SEOPRESS_VERSION' ) || function_exists( 'seopress_init' ),
        );
    }

    /** @return array<string,mixed>|WP_Error */
    public function preview( string $source, int $limit = 100, int $offset = 0 ): array|WP_Error {
        $source = sanitize_key( $source );
        if ( ! in_array( $source, self::SOURCES, true ) ) return new WP_Error( 'invalid_migration_source', __( 'Unsupported migration source.', 'k20-ai-press' ), array( 'status' => 422 ) );
        $limit = max( 1, min( 500, $limit ) );
        $offset = max( 0, $offset );
        $ids = get_posts( array( 'post_type' => array( 'post', 'page', 'product' ), 'post_status' => array( 'publish', 'draft', 'private' ), 'fields' => 'ids', 'posts_per_page' => $limit, 'offset' => $offset, 'orderby' => 'ID', 'order' => 'ASC', 'no_found_rows' => true ) );
        $items = array();
        foreach ( array_map( 'absint', (array) $ids ) as $post_id ) {
            if ( ! K20AI_Entity_Access::can_read( get_post_type( $post_id ) ?: 'post', $post_id ) ) continue;
            $source_values = $this->read_source( $source, $post_id );
            if ( is_wp_error( $source_values ) ) return $source_values;
            if ( ! array_filter( $source_values, static fn( $v ) => '' !== trim( (string) $v ) ) ) continue;
            $current = $this->read_target( $post_id );
            $diff = array();
            foreach ( $source_values as $field => $value ) {
                if ( '' !== trim( (string) $value ) && trim( (string) ( $current[ $field ] ?? '' ) ) !== trim( (string) $value ) ) {
                    $diff[ $field ] = array( 'current' => $current[ $field ] ?? '', 'source' => $value );
                }
            }
            if ( $diff ) $items[] = array( 'post_id' => $post_id, 'post_type' => get_post_type( $post_id ), 'title' => get_the_title( $post_id ), 'changes' => $diff );
        }
        return array( 'source' => $source, 'items' => $items, 'count' => count( $items ), 'limit' => $limit, 'offset' => $offset, 'destructive' => false, 'note' => __( 'Preview never deletes source plugin metadata.', 'k20-ai-press' ) );
    }

    /** @return array<string,mixed>|WP_Error */
    public function import( string $source, array $post_ids ): array|WP_Error {
        global $wpdb;
        $source = sanitize_key( $source );
        if ( ! in_array( $source, self::SOURCES, true ) ) return new WP_Error( 'invalid_migration_source', __( 'Unsupported migration source.', 'k20-ai-press' ), array( 'status' => 422 ) );
        $ids = array_values( array_unique( array_filter( array_map( 'absint', array_slice( $post_ids, 0, 500 ) ) ) ) );
        if ( ! $ids ) return new WP_Error( 'migration_posts_required', __( 'At least one post is required for migration.', 'k20-ai-press' ), array( 'status' => 422 ) );
        $snapshot = array();
        $source_by_post = array();
        $source_field_count = 0;
        foreach ( $ids as $post_id ) {
            $type = get_post_type( $post_id ) ?: 'post';
            $access = K20AI_Entity_Access::edit_error( $type, $post_id );
            if ( is_wp_error( $access ) ) return $access;
            $values = $this->read_source( $source, $post_id );
            if ( is_wp_error( $values ) ) return $values;
            $source_by_post[ $post_id ] = $values;
            foreach ( $values as $value ) if ( '' !== trim( (string) $value ) ) ++$source_field_count;
            $snapshot[ $post_id ] = $this->read_target( $post_id );
        }
        if ( 0 === $source_field_count ) return new WP_Error( 'migration_source_empty', __( 'No source SEO metadata was found for the selected items.', 'k20-ai-press' ), array( 'status' => 422 ) );
        $snapshot_key = wp_generate_uuid4();
        $t = K20AI_Database::tables();
        $wpdb->insert( $t['migration_snapshots'], array( 'snapshot_key' => $snapshot_key, 'source' => $source, 'payload' => wp_json_encode( $snapshot, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ), 'created_by' => get_current_user_id() ?: null, 'created_at' => current_time( 'mysql', true ) ) );
        if ( ! $wpdb->insert_id ) return new WP_Error( 'migration_snapshot_failed', __( 'Migration backup could not be created.', 'k20-ai-press' ), array( 'status' => 500 ) );

        $changed = array();
        foreach ( $ids as $post_id ) {
            $values = $source_by_post[ $post_id ];
            $written = $this->write_target( $post_id, $values );
            if ( $written ) $changed[] = array( 'post_id' => $post_id, 'fields' => $written );
        }
        $verification = $this->verify_import_values( $source_by_post );
        if ( empty( $verification['pass'] ) ) return new WP_Error( 'migration_verify_failed', __( 'Migration writes did not fully match the source metadata. Use the returned snapshot to roll back.', 'k20-ai-press' ), array( 'status' => 500, 'snapshot_key' => $snapshot_key, 'verification' => $verification ) );
        return array( 'snapshot_key' => $snapshot_key, 'source' => $source, 'changed' => $changed, 'changed_count' => count( $changed ), 'source_deleted' => false, 'verified' => $verification );
    }

    /** @return array<string,mixed>|WP_Error */
    public function rollback( string $snapshot_key ): array|WP_Error {
        global $wpdb;
        $t = K20AI_Database::tables();
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t['migration_snapshots']} WHERE snapshot_key=%s LIMIT 1", sanitize_text_field( $snapshot_key ) ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        if ( ! $row ) return new WP_Error( 'migration_snapshot_not_found', __( 'Migration snapshot not found.', 'k20-ai-press' ), array( 'status' => 404 ) );
        if ( ! empty( $row['rolled_back_at'] ) ) return new WP_Error( 'migration_already_rolled_back', __( 'This migration snapshot was already rolled back.', 'k20-ai-press' ), array( 'status' => 409 ) );
        $payload = json_decode( (string) $row['payload'], true );
        if ( ! is_array( $payload ) ) return new WP_Error( 'migration_snapshot_invalid', __( 'Migration snapshot payload is invalid.', 'k20-ai-press' ), array( 'status' => 500 ) );
        $restored = array();
        foreach ( $payload as $post_id => $values ) {
            $post_id = absint( $post_id );
            $type = get_post_type( $post_id ) ?: 'post';
            $access = K20AI_Entity_Access::edit_error( $type, $post_id );
            if ( is_wp_error( $access ) ) return $access;
            if ( is_array( $values ) ) {
                $this->write_target( $post_id, $values, true );
                $restored[] = $post_id;
            }
        }
        $mismatches = array();
        foreach ( $payload as $post_id => $values ) {
            if ( ! is_array( $values ) ) continue;
            $current = $this->read_target( absint( $post_id ) );
            foreach ( array( 'title', 'description', 'canonical' ) as $field ) {
                if ( trim( (string) ( $current[ $field ] ?? '' ) ) !== trim( (string) ( $values[ $field ] ?? '' ) ) ) $mismatches[] = absint( $post_id ) . ':' . $field;
            }
        }
        if ( $mismatches ) return new WP_Error( 'migration_rollback_verify_failed', __( 'Rollback completed partially but readback verification found mismatches. The snapshot remains available for retry.', 'k20-ai-press' ), array( 'status' => 500, 'mismatches' => array_slice( $mismatches, 0, 50 ) ) );
        $now = current_time( 'mysql', true );
        $updated = $wpdb->update( $t['migration_snapshots'], array( 'rolled_back_at' => $now ), array( 'id' => (int) $row['id'] ) );
        if ( false === $updated ) return new WP_Error( 'migration_rollback_marker_failed', __( 'Rollback was verified but the snapshot completion marker could not be stored.', 'k20-ai-press' ), array( 'status' => 500 ) );
        return array( 'snapshot_key' => $snapshot_key, 'restored' => $restored, 'restored_count' => count( $restored ), 'verified' => true, 'rolled_back_at' => $now );
    }

    /** @return array<string,string>|WP_Error */
    private function read_source( string $source, int $post_id ): array|WP_Error {
        if ( 'aioseo' === $source ) return $this->read_aioseo( $post_id );
        $maps = array(
            'yoast' => array( 'title' => '_yoast_wpseo_title', 'description' => '_yoast_wpseo_metadesc', 'canonical' => '_yoast_wpseo_canonical' ),
            'rank_math' => array( 'title' => 'rank_math_title', 'description' => 'rank_math_description', 'canonical' => 'rank_math_canonical_url' ),
            'seopress' => array( 'title' => '_seopress_titles_title', 'description' => '_seopress_titles_desc', 'canonical' => '_seopress_robots_canonical' ),
        );
        $out = array();
        foreach ( $maps[ $source ] as $field => $key ) $out[ $field ] = (string) get_post_meta( $post_id, $key, true );
        return $out;
    }

    /** @return array<string,string>|WP_Error */
    private function read_aioseo( int $post_id ): array|WP_Error {
        global $wpdb;
        $table = $wpdb->prefix . 'aioseo_posts';
        if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) !== $table ) return array( 'title' => '', 'description' => '', 'canonical' => '' );
        $columns = array_map( 'strval', (array) $wpdb->get_col( "SHOW COLUMNS FROM `{$table}`", 0 ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $wanted = array_intersect( array( 'title', 'description', 'canonical_url' ), $columns );
        if ( ! in_array( 'post_id', $columns, true ) || ! $wanted ) return array( 'title' => '', 'description' => '', 'canonical' => '' );
        $select = implode( ',', array_map( static fn( $c ) => '`' . $c . '`', $wanted ) );
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT {$select} FROM `{$table}` WHERE post_id=%d LIMIT 1", $post_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        return array( 'title' => (string) ( $row['title'] ?? '' ), 'description' => (string) ( $row['description'] ?? '' ), 'canonical' => (string) ( $row['canonical_url'] ?? '' ) );
    }

    /** @return array<string,string> */
    private function read_target( int $post_id ): array {
        return array( 'title' => (string) get_post_meta( $post_id, '_k20ai_title', true ), 'description' => (string) get_post_meta( $post_id, '_k20ai_description', true ), 'canonical' => (string) get_post_meta( $post_id, '_k20ai_canonical', true ) );
    }

    /** @return array<int,string> */
    private function write_target( int $post_id, array $values, bool $allow_empty = false ): array {
        $map = array( 'title' => '_k20ai_title', 'description' => '_k20ai_description', 'canonical' => '_k20ai_canonical' );
        $written = array();
        foreach ( $map as $field => $key ) {
            if ( ! array_key_exists( $field, $values ) ) continue;
            $value = 'canonical' === $field ? esc_url_raw( (string) $values[ $field ] ) : sanitize_text_field( (string) $values[ $field ] );
            if ( '' === $value && ! $allow_empty ) continue;
            if ( '' === $value ) delete_post_meta( $post_id, $key ); else update_post_meta( $post_id, $key, $value );
            $written[] = $field;
        }
        return $written;
    }

    /** @param array<int,array<string,string>> $source_by_post @return array<string,mixed> */
    private function verify_import_values( array $source_by_post ): array {
        $checked = 0; $matching = 0;
        foreach ( $source_by_post as $post_id => $source_values ) {
            $target = $this->read_target( (int) $post_id );
            foreach ( $source_values as $field => $value ) {
                if ( '' === trim( (string) $value ) ) continue;
                ++$checked;
                if ( trim( (string) ( $target[ $field ] ?? '' ) ) === trim( (string) $value ) ) ++$matching;
            }
        }
        return array( 'checked_fields' => $checked, 'matching_fields' => $matching, 'pass' => $checked > 0 && $checked === $matching );
    }
}
