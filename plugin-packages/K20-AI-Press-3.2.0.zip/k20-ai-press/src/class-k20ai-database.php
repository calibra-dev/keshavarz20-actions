<?php

defined( 'ABSPATH' ) || exit;

final class K20AI_Database {
    public const DB_VERSION = '3.1.0';

    /**
     * @return array<string,string>
     */
    public static function tables(): array {
        global $wpdb;
        $p = $wpdb->prefix . 'k20ai_';
        return array(
            'claims'               => $p . 'claims',
            'evidence'             => $p . 'evidence',
            'entities'             => $p . 'entities',
            'edges'                => $p . 'edges',
            'compat_rules'         => $p . 'compat_rules',
            'vectors_meta'         => $p . 'vectors_meta',
            'bot_visits'           => $p . 'bot_visits',
            'events'               => $p . 'events',
            'jobs'                 => $p . 'jobs',
            'webhook_deliveries'   => $p . 'webhook_deliveries',
            'prompt_runs'          => $p . 'prompt_runs',
            'citations'            => $p . 'citations',
            'provider_usage'       => $p . 'provider_usage',
            'price_history'        => $p . 'price_history',
            'audit_log'            => $p . 'audit_log',
            'supplier_submissions' => $p . 'supplier_submissions',
            'eval_runs'             => $p . 'eval_runs',
            'feed_snapshots'        => $p . 'feed_snapshots',
            'channel_state'         => $p . 'channel_state',
            'seo_profiles'          => $p . 'seo_profiles',
            'seo_issues'            => $p . 'seo_issues',
            'seo_scans'             => $p . 'seo_scans',
            'seo_links'             => $p . 'seo_links',
            'seo_keywords'          => $p . 'seo_keywords',
            'seo_competitors'       => $p . 'seo_competitors',
            'seo_recommendations'   => $p . 'seo_recommendations',
            'seo_actions'           => $p . 'seo_actions',
            'seo_crawl'             => $p . 'seo_crawl',
            'seo_signals'           => $p . 'seo_signals',
            'engine_runs'            => $p . 'engine_runs',
            'bridge_snapshots'       => $p . 'bridge_snapshots',
            'agent_runs'             => $p . 'agent_runs',
            'agent_steps'            => $p . 'agent_steps',
            'visibility_queries'     => $p . 'visibility_queries',
            'visibility_observations'=> $p . 'visibility_observations',
            'migration_snapshots'    => $p . 'migration_snapshots',
        );
    }

    public static function activate(): void {
        self::migrate();
        self::ensure_schedules();
    }

    public static function ensure_schedules(): void {
        if ( ! wp_next_scheduled( 'k20ai_recovery_tick' ) ) {
            wp_schedule_event( time() + 300, 'hourly', 'k20ai_recovery_tick' );
        }
        if ( ! wp_next_scheduled( 'k20ai_v3_hourly_tick' ) ) {
            wp_schedule_event( time() + 600, 'hourly', 'k20ai_v3_hourly_tick' );
        }
        if ( ! wp_next_scheduled( 'k20ai_v3_daily_tick' ) ) {
            wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'k20ai_v3_daily_tick' );
        }
        if ( ! wp_next_scheduled( 'k20ai_privacy_cleanup' ) ) {
            wp_schedule_event( time() + 2 * HOUR_IN_SECONDS, 'daily', 'k20ai_privacy_cleanup' );
        }
        if ( ! wp_next_scheduled( 'k20ai_license_sync' ) ) {
            wp_schedule_event( time() + 3 * HOUR_IN_SECONDS, 'daily', 'k20ai_license_sync' );
        }
    }

    public static function migrate(): void {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $t = self::tables();

        $sql = array(
            "CREATE TABLE {$t['claims']} (
                id bigint unsigned NOT NULL AUTO_INCREMENT,
                claim_key varchar(191) NOT NULL,
                subject varchar(191) NOT NULL DEFAULT '',
                predicate varchar(191) NOT NULL DEFAULT '',
                value longtext NULL,
                unit varchar(64) NULL,
                confidence decimal(5,2) NULL,
                status varchar(32) NOT NULL DEFAULT 'UNKNOWN',
                reviewer bigint unsigned NULL,
                verified_at datetime NULL,
                valid_from datetime NULL,
                valid_until datetime NULL,
                supersedes bigint unsigned NULL,
                created_at datetime NOT NULL,
                updated_at datetime NOT NULL,
                PRIMARY KEY (id),
                UNIQUE KEY claim_key (claim_key),
                KEY status (status),
                KEY subject (subject)
            ) $charset;",
            "CREATE TABLE {$t['evidence']} (
                id bigint unsigned NOT NULL AUTO_INCREMENT,
                claim_id bigint unsigned NULL,
                source_url text NULL,
                source_type varchar(64) NOT NULL DEFAULT '',
                source_hash char(64) NULL,
                source_snapshot longtext NULL,
                title varchar(255) NOT NULL DEFAULT '',
                confidence decimal(5,2) NULL,
                status varchar(32) NOT NULL DEFAULT 'UNKNOWN',
                verified_at datetime NULL,
                valid_until datetime NULL,
                created_at datetime NOT NULL,
                updated_at datetime NOT NULL,
                PRIMARY KEY (id),
                KEY claim_id (claim_id),
                KEY status (status)
            ) $charset;",
            "CREATE TABLE {$t['entities']} (
                id bigint unsigned NOT NULL AUTO_INCREMENT,
                entity_type varchar(64) NOT NULL,
                entity_key varchar(191) NOT NULL,
                label varchar(255) NOT NULL DEFAULT '',
                data longtext NULL,
                created_at datetime NOT NULL,
                updated_at datetime NOT NULL,
                PRIMARY KEY (id),
                UNIQUE KEY entity_key (entity_key),
                KEY entity_type (entity_type)
            ) $charset;",
            "CREATE TABLE {$t['edges']} (
                id bigint unsigned NOT NULL AUTO_INCREMENT,
                source_entity bigint unsigned NOT NULL,
                target_entity bigint unsigned NOT NULL,
                relation varchar(128) NOT NULL,
                source varchar(255) NULL,
                confidence decimal(5,2) NULL,
                review_status varchar(32) NOT NULL DEFAULT 'PENDING',
                version int unsigned NOT NULL DEFAULT 1,
                created_at datetime NOT NULL,
                updated_at datetime NOT NULL,
                PRIMARY KEY (id),
                KEY source_entity (source_entity),
                KEY target_entity (target_entity),
                KEY relation (relation)
            ) $charset;",
            "CREATE TABLE {$t['compat_rules']} (
                id bigint unsigned NOT NULL AUTO_INCREMENT,
                rule_key varchar(191) NOT NULL,
                title varchar(255) NOT NULL,
                conditions longtext NOT NULL,
                result varchar(32) NOT NULL DEFAULT 'UNKNOWN',
                source text NULL,
                confidence decimal(5,2) NULL,
                exceptions longtext NULL,
                version int unsigned NOT NULL DEFAULT 1,
                reviewer bigint unsigned NULL,
                valid_from datetime NULL,
                valid_until datetime NULL,
                status varchar(32) NOT NULL DEFAULT 'PENDING',
                created_at datetime NOT NULL,
                updated_at datetime NOT NULL,
                PRIMARY KEY (id),
                UNIQUE KEY rule_key (rule_key),
                KEY status (status),
                KEY result (result)
            ) $charset;",
            "CREATE TABLE {$t['vectors_meta']} (
                id bigint unsigned NOT NULL AUTO_INCREMENT,
                source_id varchar(191) NOT NULL,
                content_type varchar(64) NOT NULL,
                entity_id bigint unsigned NULL,
                product_id bigint unsigned NULL,
                claim_ids longtext NULL,
                freshness datetime NULL,
                content_hash char(64) NULL,
                language varchar(12) NOT NULL DEFAULT 'fa',
                visibility varchar(32) NOT NULL DEFAULT 'public',
                evidence_level varchar(32) NOT NULL DEFAULT 'unknown',
                provider varchar(128) NULL,
                embedding_model varchar(191) NULL,
                status varchar(32) NOT NULL DEFAULT 'PENDING',
                content longtext NULL,
                chunk_index int unsigned NOT NULL DEFAULT 0,
                token_estimate int unsigned NULL,
                vector_ref varchar(191) NULL,
                updated_at datetime NOT NULL,
                PRIMARY KEY (id),
                KEY source_id (source_id),
                KEY product_id (product_id),
                KEY status (status)
            ) $charset;",
            "CREATE TABLE {$t['bot_visits']} (
                id bigint unsigned NOT NULL AUTO_INCREMENT,
                claimed_bot varchar(128) NULL,
                verified_bot varchar(128) NULL,
                provider varchar(128) NULL,
                user_agent text NULL,
                ip_hash char(64) NULL,
                verification_method varchar(64) NULL,
                url text NULL,
                http_status smallint unsigned NULL,
                response_time_ms int unsigned NULL,
                allowed tinyint(1) NOT NULL DEFAULT 0,
                blocked_reason varchar(255) NULL,
                created_at datetime NOT NULL,
                PRIMARY KEY (id),
                KEY provider (provider),
                KEY created_at (created_at)
            ) $charset;",
            "CREATE TABLE {$t['events']} (
                id bigint unsigned NOT NULL AUTO_INCREMENT,
                event_name varchar(191) NOT NULL,
                entity_type varchar(64) NULL,
                entity_id varchar(191) NULL,
                payload longtext NULL,
                trace_id char(36) NULL,
                created_at datetime NOT NULL,
                PRIMARY KEY (id),
                KEY event_name (event_name),
                KEY created_at (created_at)
            ) $charset;",
            "CREATE TABLE {$t['jobs']} (
                id bigint unsigned NOT NULL AUTO_INCREMENT,
                job_key varchar(191) NOT NULL,
                job_type varchar(128) NOT NULL,
                status varchar(32) NOT NULL DEFAULT 'QUEUED',
                progress decimal(5,2) NOT NULL DEFAULT 0,
                heartbeat datetime NULL,
                lease_until datetime NULL,
                checkpoint longtext NULL,
                payload longtext NULL,
                attempt smallint unsigned NOT NULL DEFAULT 0,
                last_error text NULL,
                next_retry datetime NULL,
                created_at datetime NOT NULL,
                updated_at datetime NOT NULL,
                PRIMARY KEY (id),
                UNIQUE KEY job_key (job_key),
                KEY status (status),
                KEY next_retry (next_retry),
                KEY status_lease (status,lease_until),
                KEY status_retry (status,next_retry)
            ) $charset;",
            "CREATE TABLE {$t['webhook_deliveries']} (
                id bigint unsigned NOT NULL AUTO_INCREMENT,
                webhook_id varchar(191) NOT NULL,
                event_name varchar(191) NOT NULL,
                destination_hash char(64) NOT NULL,
                status varchar(32) NOT NULL DEFAULT 'QUEUED',
                http_status smallint unsigned NULL,
                attempt smallint unsigned NOT NULL DEFAULT 0,
                response_excerpt text NULL,
                created_at datetime NOT NULL,
                updated_at datetime NOT NULL,
                PRIMARY KEY (id),
                KEY event_name (event_name),
                KEY status (status),
                KEY webhook_created (webhook_id,created_at)
            ) $charset;",
            "CREATE TABLE {$t['prompt_runs']} (
                id bigint unsigned NOT NULL AUTO_INCREMENT,
                prompt_key varchar(191) NOT NULL,
                intent varchar(128) NULL,
                persona varchar(128) NULL,
                funnel varchar(64) NULL,
                language varchar(12) NOT NULL DEFAULT 'fa',
                region varchar(64) NULL,
                target_entity varchar(191) NULL,
                model varchar(191) NULL,
                result_meta longtext NULL,
                created_at datetime NOT NULL,
                PRIMARY KEY (id),
                KEY prompt_key (prompt_key),
                KEY created_at (created_at)
            ) $charset;",
            "CREATE TABLE {$t['citations']} (
                id bigint unsigned NOT NULL AUTO_INCREMENT,
                url text NOT NULL,
                engine varchar(128) NOT NULL,
                topic varchar(191) NULL,
                intent varchar(128) NULL,
                cited tinyint(1) NOT NULL DEFAULT 0,
                position_label varchar(64) NULL,
                source_meta longtext NULL,
                sample_size int unsigned NULL,
                confidence decimal(5,2) NULL,
                observed_at datetime NOT NULL,
                PRIMARY KEY (id),
                KEY engine (engine),
                KEY observed_at (observed_at)
            ) $charset;",
            "CREATE TABLE {$t['provider_usage']} (
                id bigint unsigned NOT NULL AUTO_INCREMENT,
                provider varchar(128) NOT NULL,
                model varchar(191) NULL,
                module varchar(128) NULL,
                task varchar(128) NULL,
                units decimal(16,4) NULL,
                cost decimal(16,6) NULL,
                latency_ms int unsigned NULL,
                status varchar(32) NOT NULL DEFAULT 'OK',
                created_at datetime NOT NULL,
                PRIMARY KEY (id),
                KEY provider (provider),
                KEY created_at (created_at)
            ) $charset;",
            "CREATE TABLE {$t['price_history']} (
                id bigint unsigned NOT NULL AUTO_INCREMENT,
                product_id bigint unsigned NOT NULL,
                variant_id bigint unsigned NULL,
                price decimal(20,4) NULL,
                stock decimal(20,4) NULL,
                currency varchar(12) NULL,
                observed_at datetime NOT NULL,
                PRIMARY KEY (id),
                KEY product_id (product_id),
                KEY observed_at (observed_at)
            ) $charset;",
            "CREATE TABLE {$t['audit_log']} (
                id bigint unsigned NOT NULL AUTO_INCREMENT,
                actor_id bigint unsigned NULL,
                actor_type varchar(64) NOT NULL DEFAULT 'human',
                action_name varchar(191) NOT NULL,
                target_type varchar(64) NULL,
                target_id varchar(191) NULL,
                result varchar(32) NOT NULL,
                trace_id char(36) NULL,
                meta longtext NULL,
                created_at datetime NOT NULL,
                PRIMARY KEY (id),
                KEY action_name (action_name),
                KEY actor_id (actor_id),
                KEY created_at (created_at)
            ) $charset;",
            "CREATE TABLE {$t['supplier_submissions']} (
                id bigint unsigned NOT NULL AUTO_INCREMENT,
                supplier_id varchar(191) NULL,
                submission_type varchar(64) NOT NULL,
                product_ref varchar(191) NULL,
                payload longtext NULL,
                status varchar(32) NOT NULL DEFAULT 'PENDING',
                reviewer bigint unsigned NULL,
                created_at datetime NOT NULL,
                updated_at datetime NOT NULL,
                PRIMARY KEY (id),
                KEY status (status),
                KEY supplier_id (supplier_id),
                KEY created_at (created_at),
                KEY product_ref (product_ref)
            ) $charset;",
            "CREATE TABLE {$t['eval_runs']} (
                id bigint unsigned NOT NULL AUTO_INCREMENT,
                suite varchar(128) NOT NULL,
                result longtext NULL,
                pass_rate decimal(5,2) NULL,
                created_at datetime NOT NULL,
                PRIMARY KEY (id),
                KEY suite (suite),
                KEY created_at (created_at)
            ) $charset;",
            "CREATE TABLE {$t['feed_snapshots']} (
                id bigint unsigned NOT NULL AUTO_INCREMENT,
                channel varchar(64) NOT NULL,
                snapshot_hash char(64) NOT NULL,
                item_count int unsigned NOT NULL DEFAULT 0,
                error_count int unsigned NOT NULL DEFAULT 0,
                payload longtext NULL,
                created_at datetime NOT NULL,
                PRIMARY KEY (id),
                KEY channel (channel),
                KEY created_at (created_at),
                KEY channel_created (channel,created_at)
            ) $charset;",
            "CREATE TABLE {$t['channel_state']} (
                id bigint unsigned NOT NULL AUTO_INCREMENT,
                channel varchar(64) NOT NULL,
                entity_key varchar(191) NOT NULL,
                payload_hash char(64) NULL,
                freshness datetime NULL,
                status varchar(32) NOT NULL DEFAULT 'UNKNOWN',
                errors longtext NULL,
                updated_at datetime NOT NULL,
                PRIMARY KEY (id),
                UNIQUE KEY channel_entity (channel,entity_key),
                KEY status (status),
                KEY freshness (freshness)
            ) $charset;",
            "CREATE TABLE {$t['seo_profiles']} (
                id bigint unsigned NOT NULL AUTO_INCREMENT,
                entity_kind varchar(32) NOT NULL,
                entity_id bigint unsigned NOT NULL,
                entity_key varchar(191) NOT NULL,
                url text NULL,
                title text NULL,
                score_total smallint unsigned NOT NULL DEFAULT 0,
                score_technical smallint unsigned NOT NULL DEFAULT 0,
                score_content smallint unsigned NOT NULL DEFAULT 0,
                score_schema smallint unsigned NOT NULL DEFAULT 0,
                score_media smallint unsigned NOT NULL DEFAULT 0,
                score_commerce smallint unsigned NOT NULL DEFAULT 0,
                payload longtext NULL,
                content_hash char(64) NULL,
                analyzed_at datetime NOT NULL,
                updated_at datetime NOT NULL,
                PRIMARY KEY (id),
                UNIQUE KEY entity_identity (entity_kind,entity_id),
                UNIQUE KEY entity_key (entity_key),
                KEY score_total (score_total),
                KEY analyzed_at (analyzed_at),
                KEY kind_score_total (entity_kind,score_total,entity_id),
                KEY kind_score_schema (entity_kind,score_schema,entity_id),
                KEY kind_score_media (entity_kind,score_media,entity_id),
                KEY kind_content_analyzed (entity_kind,score_content,analyzed_at)
            ) $charset;",
            "CREATE TABLE {$t['seo_issues']} (
                id bigint unsigned NOT NULL AUTO_INCREMENT,
                issue_key char(64) NOT NULL,
                entity_kind varchar(32) NOT NULL,
                entity_id bigint unsigned NOT NULL,
                rule_code varchar(128) NOT NULL,
                severity varchar(16) NOT NULL DEFAULT 'info',
                component varchar(32) NOT NULL DEFAULT 'technical',
                title varchar(255) NOT NULL DEFAULT '',
                description text NULL,
                evidence longtext NULL,
                suggested_fix longtext NULL,
                status varchar(24) NOT NULL DEFAULT 'open',
                first_seen_at datetime NOT NULL,
                last_seen_at datetime NOT NULL,
                resolved_at datetime NULL,
                PRIMARY KEY (id),
                UNIQUE KEY issue_key (issue_key),
                KEY entity_lookup (entity_kind,entity_id),
                KEY entity_status (entity_kind,entity_id,status),
                KEY status_severity (status,severity),
                KEY status_component_seen (status,component,last_seen_at),
                KEY component (component)
            ) $charset;",
            "CREATE TABLE {$t['seo_scans']} (
                id bigint unsigned NOT NULL AUTO_INCREMENT,
                scan_type varchar(64) NOT NULL,
                scope varchar(64) NOT NULL DEFAULT 'all',
                status varchar(24) NOT NULL DEFAULT 'queued',
                total int unsigned NOT NULL DEFAULT 0,
                processed int unsigned NOT NULL DEFAULT 0,
                issues_found int unsigned NOT NULL DEFAULT 0,
                health_score smallint unsigned NULL,
                cursor_value bigint unsigned NOT NULL DEFAULT 0,
                payload longtext NULL,
                last_error text NULL,
                created_by bigint unsigned NULL,
                started_at datetime NULL,
                completed_at datetime NULL,
                created_at datetime NOT NULL,
                updated_at datetime NOT NULL,
                PRIMARY KEY (id),
                KEY status (status),
                KEY scan_status_type (status,scan_type),
                KEY completed_at (completed_at),
                KEY created_at (created_at)
            ) $charset;",
            "CREATE TABLE {$t['seo_links']} (
                id bigint unsigned NOT NULL AUTO_INCREMENT,
                source_kind varchar(32) NOT NULL,
                source_id bigint unsigned NOT NULL,
                target_url text NOT NULL,
                target_post_id bigint unsigned NULL,
                anchor_text varchar(255) NULL,
                relation varchar(32) NOT NULL DEFAULT 'existing',
                status varchar(24) NOT NULL DEFAULT 'active',
                discovered_at datetime NOT NULL,
                updated_at datetime NOT NULL,
                PRIMARY KEY (id),
                KEY source_entity (source_kind,source_id),
                KEY target_post_id (target_post_id),
                KEY relation (relation)
            ) $charset;",
            "CREATE TABLE {$t['seo_keywords']} (
                id bigint unsigned NOT NULL AUTO_INCREMENT,
                phrase varchar(255) NOT NULL,
                target_url text NULL,
                target_kind varchar(32) NULL,
                target_id bigint unsigned NULL,
                search_engine varchar(32) NOT NULL DEFAULT 'google',
                country varchar(8) NULL,
                device varchar(16) NULL,
                current_position decimal(8,2) NULL,
                previous_position decimal(8,2) NULL,
                impressions bigint unsigned NULL,
                clicks bigint unsigned NULL,
                ctr decimal(8,4) NULL,
                source varchar(64) NOT NULL DEFAULT 'manual',
                checked_at datetime NULL,
                created_at datetime NOT NULL,
                updated_at datetime NOT NULL,
                PRIMARY KEY (id),
                KEY target_id (target_id),
                KEY phrase (phrase(191)),
                KEY checked_at (checked_at)
            ) $charset;",
            "CREATE TABLE {$t['seo_competitors']} (
                id bigint unsigned NOT NULL AUTO_INCREMENT,
                domain varchar(191) NOT NULL,
                label varchar(191) NULL,
                enabled tinyint(1) NOT NULL DEFAULT 1,
                metrics longtext NULL,
                source varchar(64) NOT NULL DEFAULT 'manual',
                last_synced_at datetime NULL,
                created_at datetime NOT NULL,
                updated_at datetime NOT NULL,
                PRIMARY KEY (id),
                UNIQUE KEY domain (domain),
                KEY enabled (enabled)
            ) $charset;",
            "CREATE TABLE {$t['seo_recommendations']} (
                id bigint unsigned NOT NULL AUTO_INCREMENT,
                engine varchar(64) NOT NULL,
                entity_kind varchar(32) NULL,
                entity_id bigint unsigned NULL,
                recommendation_key char(64) NOT NULL,
                title varchar(255) NOT NULL,
                reason text NULL,
                priority varchar(16) NOT NULL DEFAULT 'medium',
                business_score smallint unsigned NULL,
                commerce_score smallint unsigned NULL,
                seo_score smallint unsigned NULL,
                source_trust smallint unsigned NULL,
                risk varchar(16) NOT NULL DEFAULT 'low',
                payload longtext NULL,
                status varchar(24) NOT NULL DEFAULT 'open',
                created_at datetime NOT NULL,
                updated_at datetime NOT NULL,
                PRIMARY KEY (id),
                UNIQUE KEY recommendation_key (recommendation_key),
                KEY status_priority (status,priority),
                KEY status_priority_id (status,priority,id),
                KEY entity_lookup (entity_kind,entity_id),
                KEY entity_status (entity_kind,entity_id,status)
            ) $charset;",
            "CREATE TABLE {$t['seo_actions']} (
                id bigint unsigned NOT NULL AUTO_INCREMENT,
                recommendation_id bigint unsigned NULL,
                action_type varchar(64) NOT NULL,
                entity_kind varchar(32) NULL,
                entity_id bigint unsigned NULL,
                risk varchar(16) NOT NULL DEFAULT 'low',
                status varchar(24) NOT NULL DEFAULT 'proposed',
                before_payload longtext NULL,
                after_payload longtext NULL,
                proposed_by bigint unsigned NULL,
                reviewed_by bigint unsigned NULL,
                applied_by bigint unsigned NULL,
                review_note text NULL,
                last_error text NULL,
                created_at datetime NOT NULL,
                reviewed_at datetime NULL,
                applied_at datetime NULL,
                rolled_back_at datetime NULL,
                updated_at datetime NOT NULL,
                PRIMARY KEY (id),
                KEY status (status),
                KEY entity_lookup (entity_kind,entity_id)
            ) $charset;",
            "CREATE TABLE {$t['seo_crawl']} (
                id bigint unsigned NOT NULL AUTO_INCREMENT,
                scan_id bigint unsigned NULL,
                url_hash char(64) NOT NULL,
                url text NOT NULL,
                http_status smallint unsigned NULL,
                response_time_ms int unsigned NULL,
                content_type varchar(128) NULL,
                title text NULL,
                canonical text NULL,
                robots varchar(255) NULL,
                schema_types text NULL,
                indexable tinyint(1) NULL,
                payload longtext NULL,
                fetched_at datetime NOT NULL,
                PRIMARY KEY (id),
                UNIQUE KEY url_hash (url_hash),
                KEY scan_id (scan_id),
                KEY http_status (http_status),
                KEY fetched_at (fetched_at)
            ) $charset;",
            "CREATE TABLE {$t['seo_signals']} (
                id bigint unsigned NOT NULL AUTO_INCREMENT,
                source varchar(64) NOT NULL,
                signal_type varchar(64) NOT NULL,
                subject varchar(255) NOT NULL DEFAULT '',
                source_url text NULL,
                fingerprint char(64) NOT NULL,
                payload longtext NULL,
                score smallint unsigned NULL,
                observed_at datetime NOT NULL,
                created_at datetime NOT NULL,
                PRIMARY KEY (id),
                UNIQUE KEY fingerprint (fingerprint),
                KEY signal_type (signal_type),
                KEY observed_at (observed_at)
            ) $charset;",
            "CREATE TABLE {$t['engine_runs']} (
                id bigint unsigned NOT NULL AUTO_INCREMENT,
                engine varchar(32) NOT NULL,
                runner varchar(32) NOT NULL DEFAULT 'local',
                status varchar(24) NOT NULL DEFAULT 'queued',
                trigger_type varchar(24) NOT NULL DEFAULT 'manual',
                provider varchar(64) NULL,
                topic varchar(255) NULL,
                post_id bigint unsigned NULL,
                source_count smallint unsigned NOT NULL DEFAULT 0,
                sources longtext NULL,
                result longtext NULL,
                error text NULL,
                started_at datetime NOT NULL,
                finished_at datetime NULL,
                created_at datetime NOT NULL,
                PRIMARY KEY (id),
                KEY engine_status (engine,status),
                KEY post_id (post_id),
                KEY started_at (started_at)
            ) $charset;",
            "CREATE TABLE {$t['bridge_snapshots']} (
                id bigint unsigned NOT NULL AUTO_INCREMENT,
                snapshot_key char(36) NOT NULL,
                action varchar(64) NOT NULL,
                object_type varchar(32) NOT NULL,
                object_id bigint unsigned NOT NULL,
                before_payload longtext NOT NULL,
                actor_id bigint unsigned NULL,
                created_at datetime NOT NULL,
                rolled_back_at datetime NULL,
                PRIMARY KEY (id),
                UNIQUE KEY snapshot_key (snapshot_key),
                KEY object_lookup (object_type,object_id),
                KEY created_at (created_at)
            ) $charset;",
            "CREATE TABLE {$t['agent_runs']} (
                id bigint unsigned NOT NULL AUTO_INCREMENT,
                run_key char(36) NOT NULL,
                objective text NOT NULL,
                mode varchar(32) NOT NULL DEFAULT 'assisted',
                status varchar(32) NOT NULL DEFAULT 'plan_ready',
                actor_id bigint unsigned NULL,
                context longtext NULL,
                provider varchar(64) NULL,
                estimated_cost decimal(14,6) NULL,
                idempotency_key char(64) NULL,
                last_error text NULL,
                created_at datetime NOT NULL,
                started_at datetime NULL,
                finished_at datetime NULL,
                updated_at datetime NOT NULL,
                PRIMARY KEY (id),
                UNIQUE KEY run_key (run_key),
                UNIQUE KEY idempotency_key (idempotency_key),
                KEY status (status),
                KEY actor_status (actor_id,status),
                KEY created_at (created_at)
            ) $charset;",
            "CREATE TABLE {$t['agent_steps']} (
                id bigint unsigned NOT NULL AUTO_INCREMENT,
                run_id bigint unsigned NOT NULL,
                position smallint unsigned NOT NULL,
                ability varchar(191) NOT NULL,
                risk_class varchar(32) NOT NULL DEFAULT 'READ',
                status varchar(32) NOT NULL DEFAULT 'planned',
                input_json longtext NULL,
                output_json longtext NULL,
                evidence_json longtext NULL,
                requires_approval tinyint(1) NOT NULL DEFAULT 0,
                approved_by bigint unsigned NULL,
                approved_at datetime NULL,
                attempt_count smallint unsigned NOT NULL DEFAULT 0,
                last_error text NULL,
                created_at datetime NOT NULL,
                updated_at datetime NOT NULL,
                PRIMARY KEY (id),
                KEY run_position (run_id,position),
                KEY status (status),
                KEY ability (ability)
            ) $charset;",
            "CREATE TABLE {$t['visibility_queries']} (
                id bigint unsigned NOT NULL AUTO_INCREMENT,
                query_key char(64) NOT NULL,
                query_text varchar(500) NOT NULL,
                locale varchar(32) NOT NULL DEFAULT '',
                country varchar(8) NOT NULL DEFAULT '',
                enabled tinyint(1) NOT NULL DEFAULT 1,
                tags text NULL,
                created_by bigint unsigned NULL,
                created_at datetime NOT NULL,
                updated_at datetime NOT NULL,
                PRIMARY KEY (id),
                UNIQUE KEY query_key (query_key),
                KEY enabled (enabled),
                KEY created_by (created_by)
            ) $charset;",
            "CREATE TABLE {$t['visibility_observations']} (
                id bigint unsigned NOT NULL AUTO_INCREMENT,
                query_id bigint unsigned NOT NULL,
                engine varchar(32) NOT NULL,
                mentioned tinyint(1) NOT NULL DEFAULT 0,
                cited tinyint(1) NOT NULL DEFAULT 0,
                cited_url text NULL,
                competitor varchar(255) NULL,
                position_label varchar(64) NULL,
                source_url text NULL,
                evidence longtext NULL,
                observed_at datetime NOT NULL,
                created_at datetime NOT NULL,
                PRIMARY KEY (id),
                KEY query_engine_time (query_id,engine,observed_at),
                KEY engine_time (engine,observed_at),
                KEY observed_at (observed_at)
            ) $charset;",
            "CREATE TABLE {$t['migration_snapshots']} (
                id bigint unsigned NOT NULL AUTO_INCREMENT,
                snapshot_key char(36) NOT NULL,
                source varchar(32) NOT NULL,
                payload longtext NOT NULL,
                created_by bigint unsigned NULL,
                created_at datetime NOT NULL,
                rolled_back_at datetime NULL,
                PRIMARY KEY (id),
                UNIQUE KEY snapshot_key (snapshot_key),
                KEY source (source),
                KEY created_by (created_by),
                KEY created_at (created_at)
            ) $charset;",
        );

        foreach ( $sql as $statement ) {
            dbDelta( $statement );
        }
        $previous_version = (string) get_option( 'k20ai_db_version', '0.0.0' );
        if ( version_compare( $previous_version, '3.0.4', '<' ) ) {
            self::repair_v304_public_seo_state( $t );
            self::repair_v304_recommendation_state( $t );
        }
        update_option( 'k20ai_db_version', self::DB_VERSION, false );
        if ( false === get_option( 'k20ai_settings', false ) ) {
            add_option(
                'k20ai_settings',
                array(
                    'mode'                  => 'shadow',
                    'prompt_log_retention'  => 30,
                    'ip_retention'          => 7,
                    'bot_log_retention'     => 90,
                    'provider_log_retention'=> 90,
                    'audit_log_retention'   => 365,
                    'event_log_retention'   => 90,
                    'webhook_log_retention' => 30,
                    'engine_run_retention'  => 180,
                    'supplier_submission_retention' => 730,
                    'agent_run_retention'    => 180,
                    'visibility_retention'   => 730,
                    'migration_snapshot_retention' => 365,
                    'diagnostic_logging_enabled' => false,
                    'feature_flags'         => array(),
                    'bridge_enabled'        => true,
                    'indexnow_reuse'        => true,
                    'fail_closed'           => true,
                    'mcp_public_readonly'    => true,
                    'mcp_authenticated_tools_enabled' => true,
                    'bot_logging_enabled'    => true,
                    'rag_local_index_enabled'=> true,
                    'commerce_feeds_enabled' => true,
                ),
                '',
                false
            );
        }
    }


    /**
     * 3.0.4 public-SEO truth repair. Old builds could score drafts and editor-only
     * templates as public pages. Resolve those stale records before the new scan.
     *
     * @param array<string,string> $t
     */
    private static function repair_v304_public_seo_state( array $t ): void {
        global $wpdb;
        $public_kinds = array( 'product', 'content_post', 'page', 'news' );
        $system_types = array( 'elementor_library', 'wp_template', 'wp_template_part', 'revision', 'nav_menu_item' );
        $kind_ph = implode( ',', array_fill( 0, count( $public_kinds ), '%s' ) );
        $type_ph = implode( ',', array_fill( 0, count( $system_types ), '%s' ) );
        $params = array_merge( $public_kinds, $system_types );
        $invalid = "p.entity_kind IN ($kind_ph) AND (po.ID IS NULL OR po.post_status<>'publish' OR po.post_type IN ($type_ph))";
        $now = current_time( 'mysql', true );

        // Set-based upgrade repair avoids thousands of per-entity queries on large catalogs.
        $issue_sql = $wpdb->prepare(
            "UPDATE {$t['seo_issues']} i INNER JOIN {$t['seo_profiles']} p ON p.entity_kind=i.entity_kind AND p.entity_id=i.entity_id LEFT JOIN {$wpdb->posts} po ON po.ID=p.entity_id SET i.status='resolved',i.resolved_at=%s,i.last_seen_at=%s WHERE i.status='open' AND $invalid",
            $now,
            $now,
            ...$params
        );
        $wpdb->query( $issue_sql ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared

        $recommendation_sql = $wpdb->prepare(
            "UPDATE {$t['seo_recommendations']} r INNER JOIN {$t['seo_profiles']} p ON p.entity_kind=r.entity_kind AND p.entity_id=r.entity_id LEFT JOIN {$wpdb->posts} po ON po.ID=p.entity_id SET r.status='resolved',r.updated_at=%s WHERE r.status='open' AND $invalid",
            $now,
            ...$params
        );
        $wpdb->query( $recommendation_sql ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared

        $delete_sql = $wpdb->prepare(
            "DELETE p FROM {$t['seo_profiles']} p LEFT JOIN {$wpdb->posts} po ON po.ID=p.entity_id WHERE $invalid",
            ...$params
        );
        $wpdb->query( $delete_sql ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared

        $media_rules = array( 'meta.title.missing', 'meta.title.length', 'meta.description.missing', 'meta.description.length', 'url.missing', 'canonical.missing' );
        $rule_ph = implode( ',', array_fill( 0, count( $media_rules ), '%s' ) );
        $media_sql = $wpdb->prepare(
            "UPDATE {$t['seo_issues']} SET status='resolved',resolved_at=%s,last_seen_at=%s WHERE entity_kind='media' AND rule_code IN ($rule_ph) AND status='open'",
            $now,
            $now,
            ...$media_rules
        );
        $wpdb->query( $media_sql ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
    }

    /**
     * 3.0.4 set-based recommendation reconciliation. Only recommendations with
     * a valid JSON rule_code are auto-resolved; unknown legacy payloads remain
     * open instead of being guessed closed.
     *
     * @param array<string,string> $t
     */
    private static function repair_v304_recommendation_state( array $t ): void {
        global $wpdb;
        if ( empty( $t['seo_recommendations'] ) || empty( $t['seo_issues'] ) ) return;
        $now = current_time( 'mysql', true );
        $sql = $wpdb->prepare(
            "UPDATE {$t['seo_recommendations']} r LEFT JOIN {$t['seo_issues']} i ON i.entity_kind=r.entity_kind AND i.entity_id=r.entity_id AND i.rule_code=JSON_UNQUOTE(JSON_EXTRACT(CASE WHEN JSON_VALID(r.payload) THEN r.payload ELSE '{}' END,'$.rule_code')) AND i.status='open' SET r.status='resolved',r.updated_at=%s WHERE r.status='open' AND JSON_VALID(r.payload)=1 AND COALESCE(JSON_UNQUOTE(JSON_EXTRACT(CASE WHEN JSON_VALID(r.payload) THEN r.payload ELSE '{}' END,'$.rule_code')),'')<>'' AND i.id IS NULL",
            $now
        );
        $wpdb->query( $sql ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
    }

    /**
     * 3.0.3 data-truth repair: old recommendations could stay open after their
     * underlying issue had been resolved. Reconcile them once during upgrade.
     * Unknown/legacy payloads are preserved instead of being guessed closed.
     *
     * @param array<string,string> $t
     */
    private static function repair_v303_recommendation_state( array $t ): void {
        self::repair_v304_recommendation_state( $t );
    }

}
