<?php

defined( 'ABSPATH' ) || exit;

trait K20AI_Advanced_Commerce_Trait {
    public function feed_acp( int $limit = 100 ): array {
        if ( ! function_exists( 'wc_get_products' ) ) {
            return array( 'format' => 'openai-stable-discovery', 'products' => array(), 'invalid_products' => array(), 'errors' => array( 'woocommerce_missing' ) );
        }

        $currency = function_exists( 'get_woocommerce_currency' ) ? strtoupper( trim( (string) get_woocommerce_currency() ) ) : '';
        $currency_catalog = function_exists( 'get_woocommerce_currencies' ) ? (array) get_woocommerce_currencies() : array();
        if ( ! preg_match( '/^[A-Z]{3}$/D', $currency ) || ( $currency_catalog && ! array_key_exists( $currency, $currency_catalog ) ) ) {
            return array(
                'format' => 'openai-stable-discovery',
                'api_version' => self::ACP_API_VERSION,
                'generated_at' => gmdate( DATE_ATOM ),
                'products' => array(),
                'invalid_products' => array(),
                'valid_count' => 0,
                'invalid_count' => 0,
                'errors' => array( 'currency_not_iso4217' ),
            );
        }

        $brand_truth = $this->brand_truth();
        $seller_name = trim( (string) ( $brand_truth['seller_identity'] ?: $brand_truth['name_fa'] ) );
        $seller_url = K20AI_Data_Integrity::valid_http_url( home_url( '/' ) );
        $parents = wc_get_products( array( 'status' => 'publish', 'limit' => max( 1, min( 500, $limit ) ), 'return' => 'objects' ) );
        $rows = array();
        $invalid = array();
        $parent_cache = array();

        foreach ( $parents as $parent ) {
            $parent_cache[ $parent->get_id() ] = $parent;
            $items = $parent->is_type( 'variable' ) ? array_filter( array_map( 'wc_get_product', $parent->get_children() ) ) : array( $parent );
            foreach ( $items as $p ) {
                $parent_id = $p->is_type( 'variation' ) ? $p->get_parent_id() : $p->get_id();
                $parent_obj = $parent_cache[ $parent_id ] ?? wc_get_product( $parent_id );
                if ( $parent_obj ) $parent_cache[ $parent_id ] = $parent_obj;

                $brand = $this->product_brand( $parent_id );
                $description = wp_strip_all_tags( $p->get_short_description() ?: $p->get_description() );
                if ( '' === trim( $description ) && $parent_obj && $parent_id !== $p->get_id() ) {
                    $description = wp_strip_all_tags( $parent_obj->get_short_description() ?: $parent_obj->get_description() );
                }

                $image_id = $p->get_image_id();
                if ( ! $image_id && $parent_obj && $parent_id !== $p->get_id() ) $image_id = $parent_obj->get_image_id();

                $regular_raw = (string) $p->get_regular_price();
                $active_raw = (string) $p->get_price();
                if ( '' === $regular_raw ) $regular_raw = $active_raw;
                $regular = is_numeric( $regular_raw ) ? (float) $regular_raw : null;
                $active = is_numeric( $active_raw ) ? (float) $active_raw : null;
                $sale = $p->is_on_sale() && null !== $active && null !== $regular && $active > 0 && $active < $regular ? $active : null;

                $status_map = array( 'instock' => 'in_stock', 'outofstock' => 'out_of_stock', 'onbackorder' => 'backorder' );
                $availability = $status_map[ $p->get_stock_status() ] ?? 'unknown';
                $item_id = $p->get_sku() ?: 'wc-' . $p->get_id();
                $variant_dict = array();
                if ( $p->is_type( 'variation' ) && method_exists( $p, 'get_attributes' ) ) {
                    foreach ( (array) $p->get_attributes() as $attribute => $value ) {
                        if ( '' !== (string) $value ) $variant_dict[ sanitize_key( $attribute ) ] = (string) $value;
                    }
                }

                $raw_gtin = method_exists( $p, 'get_global_unique_id' ) ? (string) $p->get_global_unique_id() : '';
                if ( '' === trim( $raw_gtin ) ) $raw_gtin = (string) get_post_meta( $p->get_id(), '_global_unique_id', true );
                $gtin = K20AI_Data_Integrity::normalize_gtin( $raw_gtin );
                $mpn = K20AI_Data_Integrity::normalize_mpn( get_post_meta( $p->get_id(), '_mpn', true ) );
                if ( ! $mpn && $parent_id !== $p->get_id() ) $mpn = K20AI_Data_Integrity::normalize_mpn( get_post_meta( $parent_id, '_mpn', true ) );

                $product_url = method_exists( $p, 'get_permalink' ) ? $p->get_permalink() : get_permalink( $p->get_id() );
                if ( ! $product_url && $parent_obj ) {
                    $product_url = method_exists( $parent_obj, 'get_permalink' ) ? $parent_obj->get_permalink() : get_permalink( $parent_id );
                }

                $additional_image_urls = array();
                $gallery_ids = $parent_obj && method_exists( $parent_obj, 'get_gallery_image_ids' ) ? (array) $parent_obj->get_gallery_image_ids() : array();
                foreach ( array_slice( array_values( array_unique( array_map( 'absint', $gallery_ids ) ) ), 0, 10 ) as $gallery_id ) {
                    if ( ! $gallery_id || $gallery_id === (int) $image_id ) {
                        continue;
                    }
                    $gallery_url = K20AI_Data_Integrity::valid_http_url( wp_get_attachment_url( $gallery_id ) );
                    if ( $gallery_url ) {
                        $additional_image_urls[] = $gallery_url;
                    }
                }

                $row = array(
                    'item_id' => (string) $item_id,
                    'title' => mb_substr( trim( (string) $p->get_name() ), 0, 150 ),
                    'description' => mb_substr( trim( $description ), 0, 5000 ),
                    'url' => K20AI_Data_Integrity::valid_http_url( $product_url ),
                    'brand' => $brand,
                    'seller_name' => $seller_name,
                    'seller_url' => $seller_url,
                    'image_url' => $image_id ? K20AI_Data_Integrity::valid_http_url( wp_get_attachment_url( $image_id ) ) : null,
                    'additional_image_urls' => $additional_image_urls ?: null,
                    'availability' => $availability,
                    'price' => null !== $regular && $regular > 0 ? number_format( $regular, 2, '.', '' ) . ' ' . $currency : null,
                    'sale_price' => null !== $sale ? number_format( $sale, 2, '.', '' ) . ' ' . $currency : null,
                    'condition' => 'new',
                    'group_id' => $p->is_type( 'variation' ) ? 'wc-' . $parent_id : null,
                    'listing_has_variations' => $p->is_type( 'variation' ) ? true : null,
                    'variant_dict' => $variant_dict ?: null,
                    'offer_id' => sanitize_key( (string) ( wp_parse_url( home_url(), PHP_URL_HOST ) ?: 'site' ) ) . '-' . $item_id,
                    'gtin' => $gtin,
                    'mpn' => $mpn,
                    'is_eligible_search' => true,
                    'is_eligible_checkout' => false,
                    'is_ads_eligible' => false,
                    'updated_at' => K20AI_Security::normalize_mysql_datetime_to_iso( get_post_field( 'post_modified_gmt', $p->get_id() ), get_post_field( 'post_modified', $p->get_id() ) ),
                );

                $missing = array();
                foreach ( array( 'item_id','title','description','url','brand','seller_name','image_url','availability','price' ) as $required ) {
                    if ( ! isset( $row[ $required ] ) || '' === trim( (string) $row[ $required ] ) ) $missing[] = $required;
                }
                if ( $missing ) {
                    $invalid[] = array( 'product_id' => $p->get_id(), 'item_id' => $item_id, 'missing' => $missing );
                    continue;
                }
                $rows[] = array_filter( $row, static fn( $v ) => null !== $v );
            }
        }

        return array(
            'format' => 'openai-stable-discovery',
            'api_version' => self::ACP_API_VERSION,
            'generated_at' => gmdate( DATE_ATOM ),
            'products' => $rows,
            'invalid_products' => $invalid,
            'valid_count' => count( $rows ),
            'invalid_count' => count( $invalid ),
            'checkout_enabled' => false,
            'ads_enabled' => false,
        );
    }

    public function save_feed_snapshot( string $channel, array $payload ): array|WP_Error {
        $channel = sanitize_key( $channel );
        if ( ! in_array( $channel, array( 'acp', 'ucp' ), true ) ) {
            return new WP_Error( 'invalid_channel', __( 'Channel فقط acp یا ucp است.', 'k20-ai-press' ), array( 'status' => 422 ) );
        }
        global $wpdb;
        $t = K20AI_Database::tables();
        $json = wp_json_encode( $payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
        if ( ! is_string( $json ) ) { return new WP_Error( 'snapshot_encode_failed', __( 'ساخت snapshot ناموفق بود.', 'k20-ai-press' ), array( 'status' => 500 ) ); }
        $count = 'acp' === $channel ? (int) ( $payload['valid_count'] ?? count( $payload['products'] ?? array() ) ) : (int) count( $payload['products'] ?? array() );
        $errors = 'acp' === $channel ? (int) ( $payload['invalid_count'] ?? 0 ) : (int) count( $payload['messages'] ?? array() );
        $ok = $wpdb->insert( $t['feed_snapshots'], array(
            'channel' => $channel,
            'snapshot_hash' => hash( 'sha256', $json ),
            'item_count' => max( 0, $count ),
            'error_count' => max( 0, $errors ),
            'payload' => $json,
            'created_at' => current_time( 'mysql', true ),
        ) );
        if ( false === $ok ) { return new WP_Error( 'snapshot_insert_failed', __( 'ذخیره snapshot ناموفق بود.', 'k20-ai-press' ), array( 'status' => 500 ) ); }
        update_option( 'k20ai_last_feed_snapshot', gmdate( 'c' ), false );
        return array( 'id' => (int) $wpdb->insert_id, 'channel' => $channel, 'hash' => hash( 'sha256', $json ), 'item_count' => $count, 'error_count' => $errors );
    }

    public function feed_health(): array {
        global $wpdb;
        $t = K20AI_Database::tables();
        $rows = $wpdb->get_results( "SELECT s.* FROM {$t['feed_snapshots']} s INNER JOIN (SELECT channel,MAX(id) max_id FROM {$t['feed_snapshots']} GROUP BY channel) x ON s.id=x.max_id ORDER BY s.channel", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $out = array();
        foreach ( is_array( $rows ) ? $rows : array() as $r ) {
            $created = strtotime( (string) $r['created_at'] );
            $out[ $r['channel'] ] = array(
                'snapshot_id' => (int) $r['id'],
                'hash' => $r['snapshot_hash'],
                'item_count' => (int) $r['item_count'],
                'error_count' => (int) $r['error_count'],
                'created_at' => $r['created_at'],
                'freshness_seconds' => $created ? max( 0, time() - $created ) : null,
                'healthy' => 0 === (int) $r['error_count'],
            );
        }
        return array( 'channels' => $out, 'freshness_target_hours' => 24 );
    }

    public function ucp_profile(): array {
        $version = self::UCP_VERSION;
        $base = untrailingslashit( rest_url( 'k20-ai/v1/ucp' ) );
        return array(
            'ucp' => array(
                'version' => $version,
                'services' => array(
                    'dev.ucp.shopping' => array(
                        array(
                            'version' => $version,
                            'spec' => 'https://ucp.dev/' . $version . '/specification/overview',
                            'transport' => 'rest',
                            'endpoint' => $base,
                            'schema' => 'https://ucp.dev/' . $version . '/services/shopping/rest.openapi.json',
                        ),
                    ),
                ),
                'capabilities' => array(
                    'dev.ucp.shopping.catalog.search' => array(
                        array(
                            'version' => $version,
                            'spec' => 'https://ucp.dev/' . $version . '/specification/shopping/catalog/search',
                            'schema' => 'https://ucp.dev/' . $version . '/schemas/shopping/catalog_search.json',
                        ),
                    ),
                    'dev.ucp.shopping.catalog.lookup' => array(
                        array(
                            'version' => $version,
                            'spec' => 'https://ucp.dev/' . $version . '/specification/shopping/catalog/lookup',
                            'schema' => 'https://ucp.dev/' . $version . '/schemas/shopping/catalog_lookup.json',
                        ),
                    ),
                ),
                'payment_handlers' => (object) array(),
            ),
        );
    }

    /**
     * UCP Catalog Search. Only public WooCommerce data is exposed.
     */
    public function ucp_catalog_search( array $input ): array|WP_Error {
        if ( ! function_exists( 'wc_get_products' ) ) {
            return new WP_Error( 'woocommerce_missing', __( 'WooCommerce در دسترس نیست.', 'k20-ai-press' ), array( 'status' => 503 ) );
        }
        $query = sanitize_text_field( (string) ( $input['query'] ?? '' ) );
        $filters = isset( $input['filters'] ) && is_array( $input['filters'] ) ? $input['filters'] : array();
        if ( '' === trim( $query ) && empty( $filters ) ) {
            return new WP_Error( 'invalid_catalog_search', __( 'حداقل query یا filters الزامی است.', 'k20-ai-press' ), array( 'status' => 400 ) );
        }
        $pagination = isset( $input['pagination'] ) && is_array( $input['pagination'] ) ? $input['pagination'] : array();
        $limit = max( 1, min( 50, absint( $pagination['limit'] ?? 20 ) ) );
        $page = $this->ucp_decode_cursor( (string) ( $pagination['cursor'] ?? '' ) );
        if ( is_wp_error( $page ) ) return $page;

        $args = array(
            'status' => 'publish',
            'limit' => $limit,
            'page' => $page,
            'paginate' => true,
            'return' => 'objects',
        );
        if ( '' !== $query ) $args['s'] = $query;
        if ( ! empty( $filters['categories'] ) && is_array( $filters['categories'] ) ) {
            $args['category'] = array_values( array_filter( array_map( 'sanitize_title', $filters['categories'] ) ) );
        }
        $result = wc_get_products( $args );
        $products = is_object( $result ) && isset( $result->products ) ? (array) $result->products : (array) $result;
        $total = is_object( $result ) && isset( $result->total ) ? (int) $result->total : count( $products );
        $max_pages = is_object( $result ) && isset( $result->max_num_pages ) ? (int) $result->max_num_pages : $page;

        $out = array();
        foreach ( $products as $product ) {
            $mapped = $this->ucp_product( $product );
            if ( ! is_wp_error( $mapped ) ) {
                if ( isset( $filters['price'] ) && is_array( $filters['price'] ) && ! $this->ucp_price_filter_passes( $mapped, $filters['price'] ) ) continue;
                $out[] = $mapped;
            }
        }
        $has_next = $page < $max_pages;
        return array(
            'ucp' => $this->ucp_response_meta( 'dev.ucp.shopping.catalog.search' ),
            'products' => $out,
            'pagination' => array_filter( array(
                'cursor' => $has_next ? $this->ucp_encode_cursor( $page + 1 ) : null,
                'has_next_page' => $has_next,
                'total_count' => max( 0, $total ),
            ), static fn( $v ) => null !== $v ),
            'messages' => array(),
        );
    }

    public function ucp_catalog_lookup( array $input ): array|WP_Error {
        if ( ! function_exists( 'wc_get_product' ) ) {
            return new WP_Error( 'woocommerce_missing', __( 'WooCommerce در دسترس نیست.', 'k20-ai-press' ), array( 'status' => 503 ) );
        }
        $ids = isset( $input['ids'] ) && is_array( $input['ids'] ) ? array_slice( $input['ids'], 0, 50 ) : array();
        if ( ! $ids ) {
            return new WP_Error( 'invalid_lookup', __( 'ids الزامی است.', 'k20-ai-press' ), array( 'status' => 400 ) );
        }
        $products = array(); $missing = array(); $seen = array();
        foreach ( $ids as $raw_id ) {
            $product = $this->resolve_ucp_product( $raw_id );
            if ( ! $product || 'publish' !== get_post_status( $product->get_id() ) ) {
                $missing[] = (string) $raw_id; continue;
            }
            $parent = $product->is_type( 'variation' ) ? wc_get_product( $product->get_parent_id() ) : $product;
            if ( ! $parent || isset( $seen[ $parent->get_id() ] ) ) { continue; }
            $mapped = $this->ucp_product( $parent, $product->is_type( 'variation' ) ? $product->get_id() : null );
            if ( ! is_wp_error( $mapped ) ) { $products[] = $mapped; $seen[ $parent->get_id() ] = true; }
        }
        $messages = array();
        foreach ( $missing as $id ) {
            $messages[] = array( 'type' => 'info', 'code' => 'not_found', 'content' => $id );
        }
        return array(
            'ucp' => $this->ucp_response_meta( 'dev.ucp.shopping.catalog.lookup' ),
            'products' => $products,
            'messages' => $messages,
        );
    }

    public function ucp_catalog_product( array $input ): array|WP_Error {
        if ( empty( $input['id'] ) ) {
            return new WP_Error( 'invalid_product_id', __( 'id الزامی است.', 'k20-ai-press' ), array( 'status' => 400 ) );
        }
        $requested_id = sanitize_text_field( (string) $input['id'] );
        $product = $this->resolve_ucp_product( $requested_id );
        if ( ! $product || 'publish' !== get_post_status( $product->get_id() ) ) {
            return $this->ucp_error_response(
                'dev.ucp.shopping.catalog.lookup',
                'not_found',
                'Product not found: ' . $requested_id
            );
        }
        $parent = $product->is_type( 'variation' ) ? wc_get_product( $product->get_parent_id() ) : $product;
        if ( ! $parent ) {
            return $this->ucp_error_response(
                'dev.ucp.shopping.catalog.lookup',
                'not_found',
                'Product not found: ' . $requested_id
            );
        }
        $selected = isset( $input['selected'] ) && is_array( $input['selected'] ) ? array_slice( $input['selected'], 0, 20 ) : array();
        $preferences = isset( $input['preferences'] ) && is_array( $input['preferences'] ) ? array_slice( $input['preferences'], 0, 20 ) : array();
        $mapped = $this->ucp_product( $parent, $product->is_type( 'variation' ) ? $product->get_id() : null, $selected, $preferences );
        if ( is_wp_error( $mapped ) ) {
            $status = (int) ( $mapped->get_error_data()['status'] ?? 500 );
            if ( $status >= 500 ) {
                return $mapped;
            }
            return $this->ucp_error_response(
                'dev.ucp.shopping.catalog.lookup',
                sanitize_key( $mapped->get_error_code() ?: 'product_unavailable' ),
                $mapped->get_error_message() ?: 'Product cannot be represented.'
            );
        }
        return array( 'ucp' => $this->ucp_response_meta( 'dev.ucp.shopping.catalog.lookup' ), 'product' => $mapped, 'messages' => array() );
    }

    private function ucp_error_response( string $capability, string $code, string $content ): array {
        $ucp = $this->ucp_response_meta( $capability );
        $ucp['status'] = 'error';
        return array(
            'ucp' => $ucp,
            'messages' => array(
                array(
                    'type' => 'error',
                    'code' => sanitize_key( $code ),
                    'content' => sanitize_text_field( $content ),
                    'severity' => 'unrecoverable',
                ),
            ),
        );
    }

    private function ucp_response_meta( string $capability ): array {
        return array(
            'version' => self::UCP_VERSION,
            'capabilities' => array( $capability => array( array( 'version' => self::UCP_VERSION ) ) ),
            'payment_handlers' => (object) array(),
        );
    }

    private function resolve_ucp_product( mixed $raw_id ): mixed {
        if ( ! function_exists( 'wc_get_product' ) ) { return null; }
        $value = sanitize_text_field( (string) $raw_id );
        $id = 0;
        if ( preg_match( '/^wc-(\d+)$/', $value, $m ) ) { $id = absint( $m[1] ); }
        elseif ( ctype_digit( $value ) ) { $id = absint( $value ); }
        elseif ( function_exists( 'wc_get_product_id_by_sku' ) ) { $id = absint( wc_get_product_id_by_sku( $value ) ); }
        return $id ? wc_get_product( $id ) : null;
    }

    private function ucp_product( mixed $product, ?int $featured_variant_id = null, array $selected_input = array(), array $preferences = array() ): array|WP_Error {
        if ( ! is_object( $product ) || ! method_exists( $product, 'get_id' ) ) {
            return new WP_Error( 'invalid_product', __( 'محصول معتبر نیست.', 'k20-ai-press' ), array( 'status' => 422 ) );
        }
        $product_id = (int) $product->get_id();
        $currency = function_exists( 'get_woocommerce_currency' ) ? strtoupper( (string) get_woocommerce_currency() ) : '';
        if ( ! preg_match( '/^[A-Z]{3}$/D', $currency ) ) return new WP_Error( 'currency_missing', __( 'واحد پول فروشگاه باید کد سه‌حرفی ISO 4217 باشد.', 'k20-ai-press' ), array( 'status' => 503 ) );

        $product_description = trim( wp_strip_all_tags( $product->get_short_description() ?: $product->get_description() ) );
        if ( '' === $product_description ) return new WP_Error( 'product_description_missing', __( 'محصول فاقد توضیح عمومی معتبر برای UCP است.', 'k20-ai-press' ), array( 'status' => 422 ) );

        $variants_raw = $product->is_type( 'variable' ) ? array_filter( array_map( 'wc_get_product', $product->get_children() ) ) : array( $product );
        if ( $featured_variant_id ) {
            usort( $variants_raw, static fn( $a, $b ) => ( (int) $a->get_id() === $featured_variant_id ? -1 : 0 ) <=> ( (int) $b->get_id() === $featured_variant_id ? -1 : 0 ) );
        }

        $variant_records = array();
        foreach ( $variants_raw as $variant ) {
            if ( ! $variant || 'publish' !== get_post_status( $variant->is_type( 'variation' ) ? $variant->get_parent_id() : $variant->get_id() ) ) continue;
            $options = $this->ucp_variant_options( $variant, $product );
            $variant_records[] = array( 'product' => $variant, 'options' => $options, 'map' => $this->ucp_option_map( $options ) );
        }
        if ( ! $variant_records ) return new WP_Error( 'product_variants_missing', __( 'محصول فاقد Variant عمومی قابل ارائه است.', 'k20-ai-press' ), array( 'status' => 422 ) );

        $effective_selected = $this->ucp_effective_selection( $variant_records, $selected_input, $preferences );
        $selected_map = $this->ucp_option_map( $effective_selected );
        $filtered_records = array_values( array_filter( $variant_records, fn( $record ) => ! $selected_map || $this->ucp_variant_matches( $record['map'], $selected_map ) ) );
        if ( ! $filtered_records ) $filtered_records = $variant_records;

        $variants = array();
        $amounts = array();
        $list_amounts = array();
        foreach ( $filtered_records as $record ) {
            $variant = $record['product'];
            $price = $this->money_minor( (string) $variant->get_price(), $currency );
            if ( null === $price ) continue;
            $amounts[] = $price['amount'];
            $regular = $this->money_minor( (string) $variant->get_regular_price(), $currency );
            $list_price = null;
            if ( null !== $regular && $regular['amount'] > $price['amount'] ) {
                $list_price = $regular;
                $list_amounts[] = $regular['amount'];
            }
            $variant_description = trim( wp_strip_all_tags( $variant->get_short_description() ?: $variant->get_description() ) );
            if ( '' === $variant_description ) $variant_description = $product_description;
            $image_id = $variant->get_image_id() ?: $product->get_image_id();
            $variants[] = array_filter( array(
                'id' => 'wc-' . $variant->get_id(),
                'sku' => $variant->get_sku() ?: null,
                'title' => $variant->get_name(),
                'description' => array( 'plain' => $variant_description ),
                'url' => K20AI_Data_Integrity::valid_http_url( get_permalink( $variant->get_id() ) ?: get_permalink( $product_id ) ),
                'price' => $price,
                'list_price' => $list_price,
                'availability' => array( 'available' => $variant->is_purchasable() && $variant->is_in_stock(), 'status' => $this->ucp_availability( $variant->get_stock_status() ) ),
                'options' => $record['options'] ?: null,
                'media' => $image_id ? array( array_filter( array( 'type' => 'image', 'url' => K20AI_Data_Integrity::valid_http_url( wp_get_attachment_url( $image_id ) ), 'alt_text' => trim( (string) get_post_meta( $image_id, '_wp_attachment_image_alt', true ) ) ?: null ) ) ) : null,
            ), static fn( $v ) => null !== $v && array() !== $v && '' !== $v );
        }
        if ( ! $variants || ! $amounts ) return new WP_Error( 'product_price_missing', __( 'محصول فاقد Variant قابل ارائه با قیمت معتبر است.', 'k20-ai-press' ), array( 'status' => 422 ) );

        $categories = array();
        $terms = wp_get_post_terms( $product_id, 'product_cat', array( 'fields' => 'all' ) );
        if ( ! is_wp_error( $terms ) ) foreach ( $terms as $term ) $categories[] = array( 'value' => (string) $term->name, 'taxonomy' => 'merchant' );
        $media = array();
        foreach ( array_filter( array_merge( array( $product->get_image_id() ), $product->get_gallery_image_ids() ) ) as $aid ) {
            $u = K20AI_Data_Integrity::valid_http_url( wp_get_attachment_url( $aid ) );
            if ( $u ) $media[] = array_filter( array( 'type' => 'image', 'url' => $u, 'alt_text' => trim( (string) get_post_meta( $aid, '_wp_attachment_image_alt', true ) ) ?: null ) );
        }

        $result = array(
            'id' => 'wc-' . $product_id,
            'handle' => get_post_field( 'post_name', $product_id ),
            'title' => $product->get_name(),
            'description' => array( 'plain' => $product_description ),
            'url' => K20AI_Data_Integrity::valid_http_url( get_permalink( $product_id ) ),
            'categories' => $categories ?: null,
            'price_range' => array( 'min' => array( 'amount' => min( $amounts ), 'currency' => $currency ), 'max' => array( 'amount' => max( $amounts ), 'currency' => $currency ) ),
            'list_price_range' => $list_amounts ? array( 'min' => array( 'amount' => min( $list_amounts ), 'currency' => $currency ), 'max' => array( 'amount' => max( $list_amounts ), 'currency' => $currency ) ) : null,
            'media' => $media ?: null,
            'options' => $this->ucp_product_options( $variant_records, $selected_map ),
            'selected' => $effective_selected ?: null,
            'variants' => $variants,
            'tags' => wp_get_post_terms( $product_id, 'product_tag', array( 'fields' => 'names' ) ) ?: null,
            'metadata' => array_filter( array( 'sku' => $product->get_sku() ?: null, 'brand' => $this->product_brand( $product_id ) ) ),
        );
        return array_filter( $result, static fn( $v ) => null !== $v && array() !== $v && '' !== $v );
    }

    private function ucp_variant_options( mixed $variant, mixed $parent ): array {
        $selected = array();
        if ( method_exists( $variant, 'get_attributes' ) ) {
            foreach ( (array) $variant->get_attributes() as $name => $value ) {
                if ( '' === (string) $value ) continue;
                $label = wc_attribute_label( $name, $parent );
                $display = (string) $value;
                if ( taxonomy_exists( $name ) ) {
                    $term = get_term_by( 'slug', (string) $value, $name );
                    if ( $term && ! is_wp_error( $term ) ) $display = (string) $term->name;
                }
                $selected[] = array( 'name' => (string) $label, 'label' => $display );
            }
        }
        return $selected;
    }

    private function ucp_option_map( array $options ): array {
        $map = array();
        foreach ( $options as $option ) {
            if ( ! is_array( $option ) ) continue;
            $name = mb_strtolower( trim( sanitize_text_field( (string) ( $option['name'] ?? '' ) ) ) );
            $label = trim( sanitize_text_field( (string) ( $option['label'] ?? $option['value'] ?? '' ) ) );
            if ( '' !== $name && '' !== $label ) $map[ $name ] = array( 'name' => (string) ( $option['name'] ?? '' ), 'label' => $label );
        }
        return $map;
    }

    private function ucp_variant_matches( array $variant_map, array $selected_map ): bool {
        foreach ( $selected_map as $key => $selection ) {
            if ( ! isset( $variant_map[ $key ] ) || 0 !== strcasecmp( (string) $variant_map[ $key ]['label'], (string) $selection['label'] ) ) return false;
        }
        return true;
    }

    private function ucp_effective_selection( array $records, array $selected_input, array $preferences ): array {
        $map = $this->ucp_option_map( $selected_input );
        if ( ! $map ) return array();
        $has_match = fn( $candidate ) => (bool) array_filter( $records, fn( $record ) => $this->ucp_variant_matches( $record['map'], $candidate ) );
        if ( $has_match( $map ) ) return array_values( $map );
        $pref = array_values( array_filter( array_map( static fn( $v ) => mb_strtolower( trim( sanitize_text_field( (string) $v ) ) ), $preferences ) ) );
        for ( $i = count( $pref ) - 1; $i >= 0; --$i ) {
            unset( $map[ $pref[ $i ] ] );
            if ( ! $map || $has_match( $map ) ) return array_values( $map );
        }
        while ( $map ) {
            array_pop( $map );
            if ( ! $map || $has_match( $map ) ) return array_values( $map );
        }
        return array();
    }

    private function ucp_product_options( array $records, array $selected_map ): ?array {
        $axes = array();
        foreach ( $records as $record ) {
            foreach ( $record['map'] as $key => $option ) {
                $axes[ $key ]['name'] = $option['name'];
                $axes[ $key ]['values'][ mb_strtolower( $option['label'] ) ] = $option['label'];
            }
        }
        if ( ! $axes ) return null;
        $out = array();
        foreach ( $axes as $key => $axis ) {
            $values = array();
            foreach ( (array) ( $axis['values'] ?? array() ) as $label ) {
                $candidate = $selected_map;
                $candidate[ $key ] = array( 'name' => $axis['name'], 'label' => $label );
                $exists = false; $available = false;
                foreach ( $records as $record ) {
                    if ( ! $this->ucp_variant_matches( $record['map'], $candidate ) ) continue;
                    $exists = true;
                    $v = $record['product'];
                    if ( $v->is_purchasable() && $v->is_in_stock() ) $available = true;
                }
                $values[] = array( 'label' => $label, 'available' => $available, 'exists' => $exists );
            }
            $out[] = array( 'name' => $axis['name'], 'values' => $values );
        }
        return $out;
    }

    private function ucp_encode_cursor( int $page ): string {
        return rtrim( strtr( base64_encode( wp_json_encode( array( 'page' => max( 1, $page ) ) ) ), '+/', '-_' ), '=' );
    }

    private function ucp_decode_cursor( string $cursor ): int|WP_Error {
        $cursor = trim( $cursor );
        if ( '' === $cursor ) return 1;
        if ( strlen( $cursor ) > 256 || ! preg_match( '/^[A-Za-z0-9_-]+$/D', $cursor ) ) return new WP_Error( 'invalid_cursor', __( 'Cursor نامعتبر است.', 'k20-ai-press' ), array( 'status' => 400 ) );
        $padded = strtr( $cursor, '-_', '+/' );
        $padded .= str_repeat( '=', ( 4 - strlen( $padded ) % 4 ) % 4 );
        $decoded = base64_decode( $padded, true );
        $data = is_string( $decoded ) ? json_decode( $decoded, true ) : null;
        if ( ! is_array( $data ) || empty( $data['page'] ) || ! is_numeric( $data['page'] ) ) return new WP_Error( 'invalid_cursor', __( 'Cursor نامعتبر است.', 'k20-ai-press' ), array( 'status' => 400 ) );
        $page = absint( $data['page'] );
        return $page > 0 && $page <= 10000 ? $page : new WP_Error( 'invalid_cursor', __( 'Cursor خارج از محدوده است.', 'k20-ai-press' ), array( 'status' => 400 ) );
    }

    private function money_minor( string $price, string $currency ): ?array {
        if ( '' === trim( $price ) || ! is_numeric( $price ) ) { return null; }
        $decimals = function_exists( 'wc_get_price_decimals' ) ? max( 0, min( 4, (int) wc_get_price_decimals() ) ) : 2;
        $factor = 10 ** $decimals;
        return array( 'amount' => (int) round( (float) $price * $factor ), 'currency' => $currency );
    }

    private function ucp_availability( string $status ): string {
        return match ( $status ) { 'instock' => 'in_stock', 'onbackorder' => 'backorder', 'outofstock' => 'out_of_stock', default => 'unknown' };
    }

    private function ucp_price_filter_passes( array $product, array $filter ): bool {
        $min = isset( $filter['min'] ) && is_numeric( $filter['min'] ) ? (int) $filter['min'] : null;
        $max = isset( $filter['max'] ) && is_numeric( $filter['max'] ) ? (int) $filter['max'] : null;
        $pmin = (int) ( $product['price_range']['min']['amount'] ?? 0 );
        $pmax = (int) ( $product['price_range']['max']['amount'] ?? 0 );
        if ( null !== $min && $pmax < $min ) { return false; }
        if ( null !== $max && $pmin > $max ) { return false; }
        return true;
    }

    private function product_brand( int $product_id ): ?string {
        foreach ( array( 'product_brand', 'pwb-brand' ) as $taxonomy ) {
            if ( taxonomy_exists( $taxonomy ) ) {
                $names = wp_get_post_terms( $product_id, $taxonomy, array( 'fields' => 'names' ) );
                if ( ! is_wp_error( $names ) && $names ) {
                    return (string) $names[0];
                }
            }
        }
        return null;
    }
}
