<?php

defined( 'ABSPATH' ) || exit;

trait K20AI_Advanced_Observability_Trait {
    public function visibility_series( int $days = 30 ): array {
        global $wpdb;
        $t = K20AI_Database::tables();
        $days = max( 1, min( 90, $days ) );
        $since = gmdate( 'Y-m-d 00:00:00', time() - ( $days - 1 ) * DAY_IN_SECONDS );
        $citation_rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT DATE(observed_at) d, SUM(CASE WHEN cited=1 THEN 1 ELSE 0 END) citations, COALESCE(SUM(sample_size),0) samples FROM {$t['citations']} WHERE observed_at >= %s GROUP BY DATE(observed_at) ORDER BY d ASC",
                $since
            ),
            ARRAY_A
        ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $bot_rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT DATE(created_at) d, COUNT(*) visits FROM {$t['bot_visits']} WHERE created_at >= %s GROUP BY DATE(created_at) ORDER BY d ASC",
                $since
            ),
            ARRAY_A
        ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $citations = array();
        foreach ( is_array( $citation_rows ) ? $citation_rows : array() as $row ) {
            $citations[ (string) $row['d'] ] = array( 'citations' => (int) $row['citations'], 'samples' => (int) $row['samples'] );
        }
        $bots = array();
        foreach ( is_array( $bot_rows ) ? $bot_rows : array() as $row ) {
            $bots[ (string) $row['d'] ] = (int) $row['visits'];
        }

        $fallback_updates = array();
        $fallback_audits  = array();
        if ( array_sum( array_map( static fn( $item ) => (int) ( $item['samples'] ?? 0 ), $citations ) ) <= 0 && array_sum( $bots ) <= 0 ) {
            $post_rows = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT DATE(post_modified_gmt) d, COUNT(*) total
                     FROM {$wpdb->posts}
                     WHERE post_type IN ('product','post') AND post_status IN ('publish','draft','private') AND post_modified_gmt >= %s
                     GROUP BY DATE(post_modified_gmt) ORDER BY d ASC",
                    $since
                ),
                ARRAY_A
            );
            foreach ( is_array( $post_rows ) ? $post_rows : array() as $row ) {
                $fallback_updates[ (string) $row['d'] ] = (int) ( $row['total'] ?? 0 );
            }

            $audit_rows = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT DATE(created_at) d, COUNT(*) total FROM {$t['audit_log']} WHERE created_at >= %s GROUP BY DATE(created_at) ORDER BY d ASC",
                    $since
                ),
                ARRAY_A
            ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            foreach ( is_array( $audit_rows ) ? $audit_rows : array() as $row ) {
                $fallback_audits[ (string) $row['d'] ] = (int) ( $row['total'] ?? 0 );
            }
        }

        $series = array();
        for ( $i = $days - 1; $i >= 0; --$i ) {
            $day = gmdate( 'Y-m-d', time() - $i * DAY_IN_SECONDS );
            $c = $citations[ $day ] ?? array( 'citations' => 0, 'samples' => 0 );
            $fallback_sample = (int) ( $fallback_updates[ $day ] ?? 0 );
            $fallback_health = (int) ( $fallback_audits[ $day ] ?? 0 );
            $series[] = array(
                'date' => $day,
                'citations' => (int) $c['citations'],
                'samples' => (int) $c['samples'],
                'citation_rate' => $c['samples'] > 0 ? round( 100 * $c['citations'] / $c['samples'], 2 ) : null,
                'bot_visits' => (int) ( $bots[ $day ] ?? 0 ),
                'fallback_updates' => $fallback_sample,
                'fallback_audits'  => $fallback_health,
            );
        }

        $has_measured = array_sum( array_column( $series, 'samples' ) ) > 0 || array_sum( array_column( $series, 'bot_visits' ) ) > 0;
        $has_fallback = array_sum( array_column( $series, 'fallback_updates' ) ) > 0 || array_sum( array_column( $series, 'fallback_audits' ) ) > 0;
        return array(
            'days' => $days,
            'series' => $series,
            'has_measured_data' => $has_measured,
            'has_fallback_data' => $has_fallback,
            'primary_label' => $has_measured ? 'Citationها' : 'به‌روزرسانی محتوا',
            'secondary_label' => $has_measured ? 'Bot Visitها / Sample' : 'رویدادهای Audit',
            'note' => $has_measured
                ? 'Citation و Bot از داده ثبت‌شده محاسبه می‌شوند؛ AI Referral بدون Analytics رسمی ساخته نمی‌شود.'
                : 'برای جلوگیری از نمودار خالی، روند بر پایه به‌روزرسانی واقعی محتوا و رویدادهای Audit همین سایت ترسیم شده است.',
        );
    }

    public function visibility_summary( int $days = 30 ): array {
        global $wpdb;
        $t = K20AI_Database::tables();
        $since = gmdate( 'Y-m-d H:i:s', time() - max( 1, min( 365, $days ) ) * DAY_IN_SECONDS );
        $citations = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t['citations']} WHERE observed_at >= %s AND cited=1", $since ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $samples = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(sample_size),0) FROM {$t['citations']} WHERE observed_at >= %s", $since ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $bot = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t['bot_visits']} WHERE created_at >= %s", $since ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $fallback_updates = 0;
        $fallback_audits  = 0;
        if ( 0 === $samples && 0 === $bot ) {
            $fallback_updates = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type IN ('product','post') AND post_status IN ('publish','draft','private') AND post_modified_gmt >= %s", $since ) );
            $fallback_audits = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t['audit_log']} WHERE created_at >= %s", $since ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        }
        return array(
            'period_days' => $days,
            'actual_citations' => $citations,
            'sample_size' => $samples,
            'citation_rate' => $samples > 0 ? round( 100 * $citations / $samples, 2 ) : null,
            'bot_visits' => $bot,
            'fallback_updates' => $fallback_updates,
            'fallback_audits' => $fallback_audits,
            'mode' => ( $samples > 0 || $bot > 0 ) ? 'measured' : 'fallback',
            'ai_referral' => null,
            'note' => ( $samples > 0 || $bot > 0 )
                ? 'AI referral فقط با داده Analytics رسمی محاسبه می‌شود.'
                : 'هنوز Citation یا Bot Visit اندازه‌گیری‌شده کافی ثبت نشده است؛ فعلاً از داده‌های واقعی به‌روزرسانی محتوا و Audit به عنوان شاخص جایگزین استفاده می‌شود.',
        );
    }

    public function ingest_citation( array $input ): array|WP_Error {
        global $wpdb;
        $url = esc_url_raw( (string) ( $input['url'] ?? '' ) );
        $engine = sanitize_text_field( (string) ( $input['engine'] ?? '' ) );
        if ( ! $url || ! $engine ) {
            return new WP_Error( 'invalid_input', __( 'url و engine الزامی است.', 'k20-ai-press' ), array( 'status' => 422 ) );
        }
        $t = K20AI_Database::tables();
        $wpdb->insert( $t['citations'], array(
            'url' => $url,
            'engine' => $engine,
            'topic' => sanitize_text_field( (string) ( $input['topic'] ?? '' ) ),
            'intent' => sanitize_text_field( (string) ( $input['intent'] ?? '' ) ),
            'cited' => ! empty( $input['cited'] ) ? 1 : 0,
            'position_label' => sanitize_text_field( (string) ( $input['position_label'] ?? '' ) ),
            'source_meta' => wp_json_encode( (array) ( $input['source_meta'] ?? array() ) ),
            'sample_size' => max( 1, absint( $input['sample_size'] ?? 1 ) ),
            'confidence' => isset( $input['confidence'] ) ? max( 0, min( 100, (float) $input['confidence'] ) ) : null,
            'observed_at' => current_time( 'mysql', true ),
        ) );
        return array( 'id' => (int) $wpdb->insert_id );
    }

    public function provider_matrix(): array {
        $matrix = array(
            'wordpress_ai_client' => array(
                'available' => function_exists( 'wp_ai_client_prompt' ),
                'chat' => function_exists( 'wp_ai_client_prompt' ),
                'vision' => function_exists( 'wp_ai_client_prompt' ),
                'embedding' => false,
                'structured_output' => function_exists( 'wp_ai_client_prompt' ),
                'source' => 'WordPress AI Client',
            ),
            'custom_embedding_filter' => array(
                'available' => (bool) apply_filters( 'k20ai_semantic_provider_available', false ),
                'embedding' => (bool) apply_filters( 'k20ai_semantic_provider_available', false ),
                'source' => 'k20ai_semantic_provider_available filter',
            ),
        );
        return apply_filters( 'k20ai_provider_matrix', $matrix );
    }

    public function provider_route( string $task ): array {
        $matrix = $this->provider_matrix();
        $task = sanitize_key( $task );
        if ( in_array( $task, array( 'chat','classification','reasoning','content' ), true ) && ! empty( $matrix['wordpress_ai_client']['chat'] ) ) {
            return array( 'task' => $task, 'provider' => 'wordpress_ai_client', 'status' => 'READY', 'reason' => 'WordPress AI Client provider discovery' );
        }
        if ( 'embedding' === $task && ! empty( $matrix['custom_embedding_filter']['embedding'] ) ) {
            return array( 'task' => $task, 'provider' => 'custom_embedding_filter', 'status' => 'READY', 'reason' => 'Semantic provider filter available' );
        }
        return array( 'task' => $task, 'provider' => null, 'status' => 'UNAVAILABLE', 'reason' => 'No configured provider with required capability' );
    }

    public function ai_generate_text( string $prompt ): array|WP_Error {
        if ( ! function_exists( 'wp_ai_client_prompt' ) ) {
            return new WP_Error( 'ai_client_unavailable', __( 'WordPress AI Client در دسترس نیست؛ WordPress 7.1+ و Connector پیکربندی‌شده لازم است.', 'k20-ai-press' ), array( 'status' => 503 ) );
        }
        $prompt = trim( wp_strip_all_tags( $prompt ) );
        if ( '' === $prompt || mb_strlen( $prompt ) > 12000 ) {
            return new WP_Error( 'invalid_prompt', __( 'Prompt باید بین ۱ تا ۱۲۰۰۰ نویسه باشد.', 'k20-ai-press' ), array( 'status' => 422 ) );
        }
        $started = microtime( true );
        $text = wp_ai_client_prompt( $prompt )->generate_text();
        $latency = (int) round( ( microtime( true ) - $started ) * 1000 );
        if ( is_wp_error( $text ) ) {
            $this->log_provider_usage( 'wordpress-ai-client', 'text', 'ai.generate_text', null, $latency, 'ERROR' );
            return $text;
        }
        $this->log_provider_usage( 'wordpress-ai-client', 'text', 'ai.generate_text', null, $latency, 'OK' );
        return array( 'text' => (string) $text, 'provider' => 'wordpress-ai-client', 'latency_ms' => $latency );
    }

    private function log_provider_usage( string $provider, string $module, string $task, ?float $cost, int $latency, string $status ): void {
        global $wpdb;
        $t = K20AI_Database::tables();
        $wpdb->insert( $t['provider_usage'], array(
            'provider' => sanitize_text_field( $provider ),
            'model' => null,
            'module' => sanitize_text_field( $module ),
            'task' => sanitize_text_field( $task ),
            'units' => null,
            'cost' => $cost,
            'latency_ms' => max( 0, $latency ),
            'status' => sanitize_key( $status ),
            'created_at' => current_time( 'mysql', true ),
        ) );
    }

    public function media_audit(): array {
        if ( ! function_exists( 'wc_get_products' ) ) {
            return array( 'products' => 0, 'images' => 0, 'missing_alt' => 0, 'coverage' => null );
        }
        $products = wc_get_products( array( 'status' => array( 'publish','draft','private' ), 'limit' => 200, 'return' => 'objects' ) );
        $images = array();
        foreach ( $products as $p ) {
            $images = array_merge( $images, array_filter( array_merge( array( $p->get_image_id() ), $p->get_gallery_image_ids() ) ) );
        }
        $images = array_values( array_unique( array_map( 'absint', $images ) ) );
        $missing = 0;
        foreach ( $images as $id ) {
            if ( '' === trim( (string) get_post_meta( $id, '_wp_attachment_image_alt', true ) ) ) { ++$missing; }
        }
        return array( 'products' => count( $products ), 'images' => count( $images ), 'missing_alt' => $missing, 'coverage' => count( $images ) ? round( 100 * ( count( $images ) - $missing ) / count( $images ), 2 ) : null );
    }

    public function taxonomy_audit(): array {
        if ( ! function_exists( 'wc_get_products' ) ) {
            return array( 'products' => 0, 'uncategorized' => 0, 'missing_brand' => 0, 'rows' => array() );
        }
        $products = wc_get_products( array( 'status' => array( 'publish','draft','private' ), 'limit' => 200, 'return' => 'objects' ) );
        $uncategorized = 0;
        $missing_brand = 0;
        $rows = array();
        foreach ( $products as $p ) {
            $cats = wp_get_post_terms( $p->get_id(), 'product_cat', array( 'fields' => 'names' ) );
            $has_categories = ! is_wp_error( $cats ) && ! empty( $cats );
            $brand = $this->product_brand( $p->get_id() );
            $missing = array();
            if ( ! $has_categories ) {
                ++$uncategorized;
                $missing[] = 'category';
            }
            if ( ! $brand ) {
                ++$missing_brand;
                $missing[] = 'brand';
            }
            if ( ! empty( $missing ) ) {
                $rows[] = array(
                    'productId'     => (int) $p->get_id(),
                    'name'          => (string) $p->get_name(),
                    'sku'           => (string) $p->get_sku(),
                    'missingFields' => $missing,
                    'missingText'   => implode( ' | ', array_map( static function( string $field ): string {
                        return 'category' === $field ? 'دسته‌بندی' : 'برند';
                    }, $missing ) ),
                    'priority'      => count( $missing ) > 1 ? 'بالا' : 'متوسط',
                    'currentBrand'  => $brand ?: '',
                    'currentCategory'=> $has_categories ? implode( '، ', (array) $cats ) : '',
                );
            }
        }
        return array(
            'products'       => count( $products ),
            'uncategorized'  => $uncategorized,
            'missing_brand'  => $missing_brand,
            'rows'           => array_slice( $rows, 0, 30 ),
        );
    }

    public function content_engines_status(): array {
        $cron = function_exists( '_get_cron_array' ) ? _get_cron_array() : array();
        $matches = array();
        foreach ( is_array( $cron ) ? $cron : array() as $timestamp => $hooks ) {
            foreach ( array_keys( (array) $hooks ) as $hook ) {
                if ( preg_match( '/(k20|article|news|question|product|content)/i', (string) $hook ) ) {
                    $matches[] = array( 'hook' => (string) $hook, 'next_run' => gmdate( DATE_ATOM, (int) $timestamp ) );
                }
            }
        }
        return array( 'scheduled' => $matches, 'count' => count( $matches ), 'note' => $matches ? 'Cron hooks discovered.' : 'No matching engine Cron hooks discovered in this site runtime.' );
    }

    public function support_workflows_status(): array {
        $cases = wp_count_posts( 'k20ai_case' );
        return array(
            'support_cases' => is_object( $cases ) ? array( 'private' => (int) ( $cases->private ?? 0 ), 'draft' => (int) ( $cases->draft ?? 0 ) ) : array(),
            'order_tracking' => function_exists( 'wc_get_order' ),
            'warranty' => function_exists( 'wc_get_product' ),
            'return_adapter' => (bool) apply_filters( 'k20ai_return_adapter_available', false ),
        );
    }

    public function channel_parity( int $product_id ): array|WP_Error {
        $schema = $this->schema_preview( $product_id );
        if ( is_wp_error( $schema ) ) { return $schema; }
        if ( ! function_exists( 'wc_get_product' ) ) { return new WP_Error( 'woocommerce_missing', __( 'WooCommerce در دسترس نیست.', 'k20-ai-press' ), array( 'status' => 503 ) ); }
        $p = wc_get_product( $product_id );
        if ( ! $p ) { return new WP_Error( 'product_not_found', __( 'محصول پیدا نشد.', 'k20-ai-press' ), array( 'status' => 404 ) ); }
        $checks = array(
            'sku' => array( 'woocommerce' => $p->get_sku() ?: null, 'schema' => $schema['sku'] ?? null ),
            'price' => array( 'woocommerce' => $p->get_price() ?: null, 'schema' => $schema['offers']['price'] ?? null ),
            'availability' => array( 'woocommerce' => $p->get_stock_status(), 'schema' => $schema['offers']['availability'] ?? null ),
        );
        $mismatches = array();
        foreach ( $checks as $field => $values ) {
            if ( 'availability' === $field ) {
                $expected = 'instock' === $values['woocommerce'] ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock';
                if ( $expected !== $values['schema'] ) { $mismatches[] = $field; }
            } elseif ( (string) $values['woocommerce'] !== (string) $values['schema'] ) { $mismatches[] = $field; }
        }
        return array( 'product_id' => $product_id, 'checks' => $checks, 'mismatches' => $mismatches, 'pass' => empty( $mismatches ) );
    }

    public function capture_product_state( int $product_id ): void {
        if ( ! function_exists( 'wc_get_product' ) ) { return; }
        $p = wc_get_product( $product_id );
        if ( ! $p ) { return; }
        global $wpdb;
        $t = K20AI_Database::tables();
        $wpdb->insert( $t['price_history'], array(
            'product_id' => $product_id,
            'variant_id' => $p->is_type( 'variation' ) ? $product_id : null,
            'price' => '' !== (string) $p->get_price() ? $p->get_price() : null,
            'stock' => null !== $p->get_stock_quantity() ? $p->get_stock_quantity() : null,
            'currency' => function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : null,
            'observed_at' => current_time( 'mysql', true ),
        ) );
        $wpdb->insert( $t['events'], array(
            'event_name' => 'ProductUpdated',
            'entity_type' => 'product',
            'entity_id' => (string) $product_id,
            'payload' => wp_json_encode( array( 'price' => $p->get_price(), 'stock_status' => $p->get_stock_status() ) ),
            'trace_id' => wp_generate_uuid4(),
            'created_at' => current_time( 'mysql', true ),
        ) );
    }

    public function mcp_status(): array {
        $adapter_class = class_exists( '\\WP\\MCP\\Core\\McpAdapter' );
        $adapter_plugin = false;
        if ( function_exists( 'is_plugin_active' ) ) {
            $adapter_plugin = is_plugin_active( 'mcp-adapter/mcp-adapter.php' );
        }
        $adapter = $adapter_class || $adapter_plugin;
        return array(
            'wordpress_abilities' => function_exists( 'wp_register_ability' ),
            'official_mcp_adapter' => $adapter,
            'adapter_class_loaded' => $adapter_class,
            'adapter_plugin_active' => $adapter_plugin,
            'protocol_target' => self::MCP_PROTOCOL,
            'ownership' => $adapter ? 'REUSE_OFFICIAL_ADAPTER' : 'NOT_AVAILABLE',
            'endpoint_hint' => $adapter ? rest_url( 'mcp/mcp-adapter-default-server' ) : null,
            'exposure_model' => 'PRIVATE_BY_DEFAULT_ALLOWLIST',
            'note' => $adapter ? 'Abilities are exposed only when the plugin MCP policy explicitly allows them; sensitive execution remains behind WordPress permissions and approval.' : 'Install and activate the official WordPress MCP Adapter. This plugin intentionally does not create a competing MCP server.',
        );
    }

    public function observability(): array {
        global $wpdb;
        $t = K20AI_Database::tables();
        $jobs = $wpdb->get_results( "SELECT status,COUNT(*) c FROM {$t['jobs']} GROUP BY status", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $out = array();
        foreach ( $jobs ?: array() as $r ) { $out[ $r['status'] ] = (int) $r['c']; }
        $feed_age = null;
        $last = get_option( 'k20ai_last_feed_snapshot', null );
        if ( is_string( $last ) && $last ) { $feed_age = max( 0, time() - strtotime( $last ) ); }
        return array(
            'trace_id' => wp_generate_uuid4(),
            'queue' => $out,
            'dead_letter' => (int) ( $out['DEAD_LETTER'] ?? 0 ),
            'stuck_jobs' => (int) ( $out['RUNNING'] ?? 0 ),
            'feed_age_seconds' => $feed_age,
            'mcp' => $this->mcp_status(),
            'providers' => $this->provider_matrix(),
        );
    }

    public function eval_run( bool $persist = true ): array {
        $tests = array();
        $unit = $this->normalize_persian( 'كشاورزي يک' ) === 'کشاورزی یک';
        $tests[] = array( 'name' => 'persian_normalization', 'pass' => $unit );
        $feed = $this->feed_acp( 10 );
        $tests[] = array( 'name' => 'feed_shape', 'pass' => isset( $feed['products'], $feed['invalid_products'] ) && is_array( $feed['products'] ) && is_array( $feed['invalid_products'] ) );
        $mcp = $this->mcp_status();
        $tests[] = array( 'name' => 'mcp_fail_closed', 'pass' => isset( $mcp['ownership'] ) );
        $passed = count( array_filter( $tests, static fn( $x ) => $x['pass'] ) );
        $result = array( 'tests' => $tests, 'passed' => $passed, 'total' => count( $tests ), 'pass_rate' => count( $tests ) ? round( 100 * $passed / count( $tests ), 2 ) : null, 'pass' => $passed === count( $tests ) );
        global $wpdb;
        $t = K20AI_Database::tables();
        if ( $persist && isset( $t['eval_runs'] ) ) {
            $wpdb->insert( $t['eval_runs'], array( 'suite' => 'builtin', 'result' => wp_json_encode( $result ), 'pass_rate' => $result['pass_rate'], 'created_at' => current_time( 'mysql', true ) ) );
        }
        return $result;
    }
}
