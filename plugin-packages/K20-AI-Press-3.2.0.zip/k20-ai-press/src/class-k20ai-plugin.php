<?php

defined( 'ABSPATH' ) || exit;

final class K20AI_Plugin {
    private static ?self $instance = null;
    private ?K20AI_Ability_Registry $registry = null;
    private ?K20AI_Services $services = null;
    private ?K20AI_Advanced $advanced = null;
    private ?K20AI_Operations $operations = null;
    private ?K20AI_SEO_Analyzer $seo_analyzer = null;
    private ?K20AI_SEO_OS $seo_os = null;
    private ?K20AI_Connection_Center $connection_center = null;
    private ?K20AI_AI_Orchestrator $ai_orchestrator = null;
    private ?K20AI_Content_Engines $content_engines = null;
    private ?K20AI_Bridge $bridge = null;
    private ?K20AI_Agent_Engine $agent_engine = null;
    private ?K20AI_Product_Intelligence $product_intelligence = null;
    private ?K20AI_AI_Visibility $ai_visibility = null;
    private ?K20AI_Onboarding_Migration $onboarding_migration = null;
    private ?K20AI_Commercial $commercial = null;
    private ?K20AI_Command_Center $command_center = null;
    private bool $booted = false;

    public static function instance(): self {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function boot(): void {
        if ( $this->booted ) {
            return;
        }
        $this->booted = true;
        $this->registry = new K20AI_Ability_Registry();
        $this->advanced = new K20AI_Advanced();
        $this->operations = new K20AI_Operations( $this->advanced );
        $this->services = new K20AI_Services( $this->registry, $this->advanced, $this->operations );
        $this->seo_analyzer = new K20AI_SEO_Analyzer();
        $this->seo_os = new K20AI_SEO_OS( $this->seo_analyzer, $this->services, $this->advanced );
        $this->product_intelligence = new K20AI_Product_Intelligence( $this->services, $this->advanced );
        $this->ai_visibility = new K20AI_AI_Visibility();
        $this->onboarding_migration = new K20AI_Onboarding_Migration();
        $this->commercial = new K20AI_Commercial();
        $this->connection_center = new K20AI_Connection_Center( $this->seo_os );
        $this->ai_visibility->set_connection_center( $this->connection_center );
        $this->agent_engine = new K20AI_Agent_Engine( $this->registry, $this->services, $this->connection_center );
        $this->command_center = new K20AI_Command_Center( $this->seo_os, $this->agent_engine, $this->ai_visibility, $this->product_intelligence, $this->commercial, $this->onboarding_migration );
        $this->services->set_platform_modules( $this->agent_engine, $this->product_intelligence, $this->ai_visibility, $this->onboarding_migration, $this->commercial, $this->command_center );
        $this->seo_os->set_connection_center( $this->connection_center );
        $this->ai_orchestrator = new K20AI_AI_Orchestrator( $this->seo_os, $this->connection_center );
        $this->content_engines = new K20AI_Content_Engines( $this->seo_os, $this->connection_center, $this->ai_orchestrator );
        $this->bridge = new K20AI_Bridge( $this->seo_os, $this->connection_center, $this->content_engines );
        $this->seo_os->set_content_engines( $this->content_engines );
        $this->seo_os->set_bridge( $this->bridge );
        K20AI_Privacy::register_hooks();
        $this->commercial->register_hooks();
        $this->connection_center->register_hooks();
        $this->content_engines->register_hooks();
        $rest  = new K20AI_REST( $this->services, $this->registry, $this->advanced );
        $seo_rest = new K20AI_SEO_REST( $this->seo_os, $this->connection_center, $this->ai_orchestrator, $this->content_engines, $this->bridge );
        $seo_frontend = new K20AI_SEO_Frontend( $this->seo_os );
        $seo_frontend->register();
        $admin = new K20AI_Admin( $this->services, $this->registry, $this->seo_os );

        add_action( 'init', array( $this, 'load_textdomain' ), 1 );
        add_action( 'init', array( $this, 'register_post_types' ) );
        add_action( 'plugins_loaded', array( $this, 'maybe_upgrade' ), 20 );
        add_action( 'template_redirect', array( $this, 'public_endpoints' ), 0 );
        add_action( 'template_redirect', array( $this, 'maybe_log_bot' ), 1 );
        add_filter( 'robots_txt', array( $this, 'filter_robots_txt' ), 99, 2 );
        add_action( 'admin_menu', array( $admin, 'menu' ) );
        add_action( 'admin_enqueue_scripts', array( $admin, 'assets' ) );
        add_action( 'admin_bar_menu', array( $admin, 'admin_bar_shortcuts' ), 100 );
        add_filter( 'admin_body_class', array( $admin, 'body_class' ) );
        add_action( 'rest_api_init', array( $rest, 'register' ) );
        add_action( 'rest_api_init', array( $seo_rest, 'register' ) );
        add_action( 'k20ai_process_job', array( $this, 'process_job' ) );
        add_action( 'k20ai_recovery_tick', array( $this, 'recovery_tick' ) );
        add_action( 'k20ai_v3_process_scan', array( $this, 'process_seo_scan' ), 10, 1 );
        add_action( 'k20ai_v3_hourly_tick', array( $this, 'seo_hourly_tick' ) );
        add_action( 'k20ai_v3_hourly_tick', array( $this, 'visibility_hourly_tick' ), 20 );
        add_action( 'k20ai_v3_daily_tick', array( $this, 'seo_daily_tick' ) );
        add_action( 'save_post', array( $this, 'invalidate_seo_entity' ), 40, 1 );
        add_action( 'edit_attachment', array( $this, 'invalidate_seo_entity' ), 40, 1 );
        add_action( 'woocommerce_update_product', array( $this, 'capture_product_state' ), 20, 1 );
        add_action( 'woocommerce_update_product', array( $this, 'invalidate_seo_entity' ), 45, 1 );
        add_action( 'woocommerce_product_set_stock', array( $this, 'capture_product_object_state' ), 20, 1 );

        // WordPress 6.9+ official Abilities API. Business logic remains in K20AI_Services.
        if ( class_exists( 'WP_Ability' ) || function_exists( 'wp_register_ability' ) ) {
            add_action( 'wp_abilities_api_categories_init', array( $this, 'register_wp_ability_category' ) );
            add_action( 'wp_abilities_api_init', array( $this, 'register_wp_abilities' ) );
        }
    }


    public function load_textdomain(): void {
        load_plugin_textdomain( 'k20-ai-press', false, dirname( plugin_basename( K20AI_PRESS_FILE ) ) . '/languages' );
    }

    public function register_post_types(): void {
        register_post_type(
            'k20ai_case',
            array(
                'label'        => 'K20 AI Cases',
                'public'       => false,
                'show_ui'      => false,
                'show_in_rest' => false,
                'supports'     => array( 'title', 'editor', 'author' ),
            )
        );
    }

    public function register_wp_ability_category(): void {
        if ( ! function_exists( 'wp_register_ability_category' ) ) {
            return;
        }
        wp_register_ability_category(
            'k20-ai-press',
            array(
                'label' => 'K20 AI Press',
                'description' => 'Product Truth, Evidence, RAG, Compatibility, Commerce and Operations abilities.',
            )
        );
    }

    public function register_wp_abilities(): void {
        if ( ! function_exists( 'wp_register_ability' ) || ! $this->registry || ! $this->services ) {
            return;
        }
        foreach ( $this->registry->visible() as $ability ) {
            $name = 'k20-ai-press/' . str_replace( '.', '-', $ability['name'] );
            $public_readonly = ! $ability['side_effect'] && K20AI_Security::ability_public_readonly( (string) $ability['name'] );
            $settings = $this->services->settings();
            $mcp_exposed = ! empty( $settings['mcp_authenticated_tools_enabled'] ) && K20AI_Security::ability_mcp_exposed( (string) $ability['name'], ! empty( $ability['side_effect'] ) );
            wp_register_ability(
                $name,
                array(
                    'label'               => $ability['name'],
                    'description'         => $ability['description'],
                    'category'            => 'k20-ai-press',
                    'input_schema'        => $ability['input_schema'],
                    'output_schema'       => $ability['output_schema'],
                    'execute_callback'    => function( $input = array() ) use ( $ability ) {
                        return $this->services->execute( $ability['name'], is_array( $input ) ? $input : array(), false );
                    },
                    'permission_callback' => fn() => K20AI_Security::ability_permission( $ability ),
                    'meta'                => array(
                        'public'       => $public_readonly,
                        'show_in_rest' => $public_readonly,
                        'annotations'  => array(
                            'readonly' => ! $ability['side_effect'],
                            'destructive' => 'DESTRUCTIVE' === $ability['risk_class'],
                            'idempotent' => (bool) $ability['idempotent'],
                        ),
                        'mcp'          => array( 'public' => $mcp_exposed || ( $public_readonly && ! empty( $settings['mcp_public_readonly'] ) ) ),
                    ),
                )
            );
        }
    }

    public function maybe_upgrade(): void {
        $previous_version = (string) get_option( 'k20ai_db_version', '0.0.0' );
        $upgraded = $previous_version !== K20AI_Database::DB_VERSION;
        $needs_v304_truth_rescan = version_compare( $previous_version, '3.0.4', '<' );
        if ( $upgraded ) {
            K20AI_Database::migrate();
            if ( $this->content_engines ) $this->content_engines->reconcile_upgrade( $previous_version );
        }
        // Replacement installs do not always re-run activation hooks, so repair schedules on every boot.
        K20AI_Database::ensure_schedules();
        if ( $upgraded && $needs_v304_truth_rescan && $this->seo_os ) {
            $this->seo_os->create_scan( 'full', 'upgrade-v304', null );
        }
    }

    public function public_endpoints(): void {
        if ( ! $this->advanced ) {
            return;
        }
        $request_uri = (string) ( $_SERVER['REQUEST_URI'] ?? '/' );
        $path = wp_parse_url( $request_uri, PHP_URL_PATH );
        if ( is_string( $path ) && str_ends_with( rtrim( $path, '/' ), '/.well-known/ucp' ) ) {
            nocache_headers();
            header( 'Content-Type: application/json; charset=utf-8' );
            echo wp_json_encode( $this->advanced->ucp_profile(), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
            exit;
        }
    }

    public function maybe_log_bot(): void {
        if ( is_admin() || wp_doing_ajax() || ! $this->advanced || ! $this->services ) {
            return;
        }
        if ( empty( $this->services->settings()['bot_logging_enabled'] ) ) {
            return;
        }
        $this->advanced->log_bot_visit();
    }

    public function filter_robots_txt( string $output, bool $public ): string {
        return $this->operations ? $this->operations->filter_robots( $output ) : $output;
    }

    public function capture_product_state( int $product_id ): void {
        if ( $this->advanced ) {
            $this->advanced->capture_product_state( $product_id );
            if ( $this->operations ) { $this->operations->deliver_event( 'product.updated', array( 'product_id' => $product_id ) ); }
        }
    }

    public function capture_product_object_state( $product ): void {
        if ( is_object( $product ) && method_exists( $product, 'get_id' ) ) {
            $this->capture_product_state( (int) $product->get_id() );
        }
    }

    public function process_job( int $job_id ): void {
        if ( $this->services ) {
            $this->services->process_job( $job_id );
        }
    }

    public function recovery_tick(): void {
        if ( $this->services ) {
            $this->services->recover_stalled_jobs();
        }
    }

    public function process_seo_scan( int $scan_id ): void {
        if ( $this->seo_os ) {
            $this->seo_os->process_scan( $scan_id );
        }
    }

    public function seo_hourly_tick(): void {
        if ( $this->seo_os ) {
            $this->seo_os->hourly_tick();
        }
    }

    public function visibility_hourly_tick(): void {
        if ( $this->ai_visibility && $this->services ) {
            $this->ai_visibility->scheduled_collect( $this->services->settings() );
        }
    }

    public function seo_daily_tick(): void {
        if ( $this->seo_os ) {
            $this->seo_os->daily_tick();
        }
    }

    public function invalidate_seo_entity( int $post_id ): void {
        if ( $this->seo_os ) {
            $this->seo_os->invalidate_entity( $post_id );
        }
    }

    public static function deactivate(): void {
        wp_clear_scheduled_hook( 'k20ai_recovery_tick' );
        wp_clear_scheduled_hook( 'k20ai_v3_hourly_tick' );
        wp_clear_scheduled_hook( 'k20ai_v3_daily_tick' );
        wp_clear_scheduled_hook( 'k20ai_content_engine_tick' );
        wp_clear_scheduled_hook( 'k20ai_v3_process_scan' );
        wp_clear_scheduled_hook( 'k20ai_v3_connection_sync' );
        wp_clear_scheduled_hook( 'k20ai_privacy_cleanup' );
        wp_clear_scheduled_hook( 'k20ai_license_sync' );
    }
}
