<?php

defined( 'ABSPATH' ) || exit;

/**
 * Privacy lifecycle: retention enforcement plus WordPress exporter/eraser hooks.
 *
 * Operational records are retained when they are part of an audit trail, but
 * WordPress user identifiers are anonymized and supplier-authored payloads have
 * common personal/contact fields removed during erasure.
 */
final class K20AI_Privacy {
    private const CLEANUP_BATCH = 500;
    private const CLEANUP_LOOPS = 5;
    private const EXPORT_BATCH  = 50;

    public static function register_hooks(): void {
        add_action( 'k20ai_privacy_cleanup', array( self::class, 'cleanup' ) );
        add_filter( 'wp_privacy_personal_data_exporters', array( self::class, 'register_exporter' ) );
        add_filter( 'wp_privacy_personal_data_erasers', array( self::class, 'register_eraser' ) );
        add_action( 'admin_init', array( self::class, 'add_privacy_policy_content' ) );
    }

    /** @param array<string,mixed> $exporters @return array<string,mixed> */
    public static function register_exporter( array $exporters ): array {
        $exporters['k20-ai-press'] = array(
            'exporter_friendly_name' => __( 'K20 AI Press', 'k20-ai-press' ),
            'callback'               => array( self::class, 'export_personal_data' ),
        );
        return $exporters;
    }

    /** @param array<string,mixed> $erasers @return array<string,mixed> */
    public static function register_eraser( array $erasers ): array {
        $erasers['k20-ai-press'] = array(
            'eraser_friendly_name' => __( 'K20 AI Press', 'k20-ai-press' ),
            'callback'             => array( self::class, 'erase_personal_data' ),
        );
        return $erasers;
    }

    public static function add_privacy_policy_content(): void {
        if ( ! function_exists( 'wp_add_privacy_policy_content' ) ) return;
        $content = '<p>' . esc_html__( 'K20 AI Press may store operational audit records, AI provider usage metadata, supplier submissions, and bot-visit security telemetry. API credentials are stored encrypted and are not included in privacy exports.', 'k20-ai-press' ) . '</p>';
        $content .= '<p>' . esc_html__( 'When an administrator connects an external AI, analytics, search, delivery, or repository provider, selected site data may be sent to that configured provider to perform the requested operation. Data retention periods are configurable and are enforced by a scheduled cleanup job.', 'k20-ai-press' ) . '</p>';
        $content .= '<p>' . esc_html__( 'When a WordPress personal-data erasure request is completed, operational records required for audit and rollback integrity may be retained after their WordPress user identifiers are anonymized. Supplier-authored payloads also have common personal contact fields removed.', 'k20-ai-press' ) . '</p>';
        wp_add_privacy_policy_content( 'K20 AI Press', wp_kses_post( wpautop( $content, false ) ) );
    }

    /** @return array<string,int> */
    public static function cleanup(): array {
        $t = K20AI_Database::tables();
        $settings = self::settings();
        $counts = array();

        $counts['ip_hashes_anonymized'] = self::anonymize_ip_hashes( $t['bot_visits'], (int) $settings['ip_retention'] );
        $counts['bot_visits'] = self::delete_older_than( $t['bot_visits'], 'created_at', (int) $settings['bot_log_retention'] );
        $counts['prompt_runs'] = self::delete_older_than( $t['prompt_runs'], 'created_at', (int) $settings['prompt_log_retention'] );
        $counts['provider_usage'] = self::delete_older_than( $t['provider_usage'], 'created_at', (int) $settings['provider_log_retention'] );
        $counts['audit_log'] = self::delete_older_than( $t['audit_log'], 'created_at', (int) $settings['audit_log_retention'] );
        $counts['events'] = self::delete_older_than( $t['events'], 'created_at', (int) $settings['event_log_retention'] );
        $counts['webhook_deliveries'] = self::delete_older_than( $t['webhook_deliveries'], 'created_at', (int) $settings['webhook_log_retention'] );
        $counts['engine_runs'] = self::delete_older_than( $t['engine_runs'], 'created_at', (int) $settings['engine_run_retention'] );
        $counts['supplier_submissions'] = self::delete_older_than( $t['supplier_submissions'], 'created_at', (int) $settings['supplier_submission_retention'] );
        $agent_deleted = self::delete_agent_history_older_than( $t['agent_steps'], $t['agent_runs'], (int) $settings['agent_run_retention'] );
        $counts['agent_steps'] = $agent_deleted['steps'];
        $counts['agent_runs'] = $agent_deleted['runs'];
        $counts['visibility_observations'] = self::delete_older_than( $t['visibility_observations'], 'observed_at', (int) $settings['visibility_retention'] );
        $counts['migration_snapshots'] = self::delete_older_than( $t['migration_snapshots'], 'created_at', (int) $settings['migration_snapshot_retention'] );

        K20AI_Logger::info( 'Privacy retention cleanup completed.', array( 'counts' => $counts ) );
        return $counts;
    }

    /** @return array<string,mixed> */
    public static function export_personal_data( string $email_address, int $page = 1 ): array {
        global $wpdb;
        $user = get_user_by( 'email', sanitize_email( $email_address ) );
        if ( ! $user instanceof WP_User ) return array( 'data' => array(), 'done' => true );

        $page = max( 1, $page );
        $offset = ( $page - 1 ) * self::EXPORT_BATCH;
        $t = K20AI_Database::tables();
        $data = array();
        $batch_counts = array();

        $audit_rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT id,action_name,target_type,target_id,result,created_at FROM {$t['audit_log']} WHERE actor_id=%d ORDER BY id ASC LIMIT %d OFFSET %d",
            $user->ID,
            self::EXPORT_BATCH,
            $offset
        ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $batch_counts[] = count( (array) $audit_rows );
        foreach ( (array) $audit_rows as $row ) {
            $data[] = self::export_item(
                'k20-ai-press-audit',
                __( 'K20 AI Press audit activity', 'k20-ai-press' ),
                'audit-' . (int) $row['id'],
                array(
                    __( 'Action', 'k20-ai-press' )      => (string) $row['action_name'],
                    __( 'Target type', 'k20-ai-press' ) => (string) $row['target_type'],
                    __( 'Target ID', 'k20-ai-press' )   => (string) $row['target_id'],
                    __( 'Result', 'k20-ai-press' )      => (string) $row['result'],
                    __( 'Created at', 'k20-ai-press' )  => (string) $row['created_at'],
                )
            );
        }

        $supplier_rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT id,supplier_id,submission_type,product_ref,payload,status,reviewer,created_at FROM {$t['supplier_submissions']} WHERE supplier_id=%s OR reviewer=%d ORDER BY id ASC LIMIT %d OFFSET %d",
            (string) $user->ID,
            $user->ID,
            self::EXPORT_BATCH,
            $offset
        ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $batch_counts[] = count( (array) $supplier_rows );
        foreach ( (array) $supplier_rows as $row ) {
            $is_supplier = (string) $row['supplier_id'] === (string) $user->ID;
            $values = array(
                __( 'Role', 'k20-ai-press' )              => $is_supplier ? __( 'Supplier', 'k20-ai-press' ) : __( 'Reviewer', 'k20-ai-press' ),
                __( 'Submission type', 'k20-ai-press' )   => (string) $row['submission_type'],
                __( 'Product reference', 'k20-ai-press' ) => (string) $row['product_ref'],
                __( 'Status', 'k20-ai-press' )            => (string) $row['status'],
                __( 'Created at', 'k20-ai-press' )        => (string) $row['created_at'],
            );
            // Do not expose another supplier's payload merely because this user reviewed it.
            if ( $is_supplier ) $values[ __( 'Submitted data', 'k20-ai-press' ) ] = self::safe_export_payload( $row['payload'] ?? '' );
            $data[] = self::export_item( 'k20-ai-press-supplier', __( 'K20 AI Press supplier submissions', 'k20-ai-press' ), 'supplier-' . (int) $row['id'], $values );
        }

        self::append_simple_reference_exports( $data, $batch_counts, $t['claims'], 'reviewer', $user->ID, $offset, 'claim', __( 'K20 AI Press claim reviews', 'k20-ai-press' ), 'id,claim_key,status,verified_at,created_at', array( 'claim_key', 'status', 'verified_at', 'created_at' ) );
        self::append_simple_reference_exports( $data, $batch_counts, $t['compat_rules'], 'reviewer', $user->ID, $offset, 'compatibility', __( 'K20 AI Press compatibility reviews', 'k20-ai-press' ), 'id,rule_key,title,status,updated_at', array( 'rule_key', 'title', 'status', 'updated_at' ) );
        self::append_simple_reference_exports( $data, $batch_counts, $t['seo_scans'], 'created_by', $user->ID, $offset, 'scan', __( 'K20 AI Press SEO scans', 'k20-ai-press' ), 'id,scan_type,scope,status,created_at,completed_at', array( 'scan_type', 'scope', 'status', 'created_at', 'completed_at' ) );
        self::append_simple_reference_exports( $data, $batch_counts, $t['bridge_snapshots'], 'actor_id', $user->ID, $offset, 'snapshot', __( 'K20 AI Press rollback snapshots', 'k20-ai-press' ), 'id,snapshot_key,action,object_type,object_id,created_at,rolled_back_at', array( 'snapshot_key', 'action', 'object_type', 'object_id', 'created_at', 'rolled_back_at' ) );
        self::append_simple_reference_exports( $data, $batch_counts, $t['agent_runs'], 'actor_id', $user->ID, $offset, 'agent-run', __( 'K20 AI Press agent runs', 'k20-ai-press' ), 'id,run_key,objective,mode,status,created_at,finished_at', array( 'run_key', 'objective', 'mode', 'status', 'created_at', 'finished_at' ) );
        self::append_simple_reference_exports( $data, $batch_counts, $t['visibility_queries'], 'created_by', $user->ID, $offset, 'visibility-query', __( 'K20 AI Press visibility queries', 'k20-ai-press' ), 'id,query_key,query_text,locale,country,enabled,created_at', array( 'query_key', 'query_text', 'locale', 'country', 'enabled', 'created_at' ) );
        self::append_simple_reference_exports( $data, $batch_counts, $t['migration_snapshots'], 'created_by', $user->ID, $offset, 'migration-snapshot', __( 'K20 AI Press migration snapshots', 'k20-ai-press' ), 'id,snapshot_key,source,created_at,rolled_back_at', array( 'snapshot_key', 'source', 'created_at', 'rolled_back_at' ) );

        $action_rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT id,action_type,entity_kind,entity_id,status,proposed_by,reviewed_by,applied_by,created_at,updated_at FROM {$t['seo_actions']} WHERE proposed_by=%d OR reviewed_by=%d OR applied_by=%d ORDER BY id ASC LIMIT %d OFFSET %d",
            $user->ID,
            $user->ID,
            $user->ID,
            self::EXPORT_BATCH,
            $offset
        ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $batch_counts[] = count( (array) $action_rows );
        foreach ( (array) $action_rows as $row ) {
            $roles = array();
            if ( (int) $row['proposed_by'] === $user->ID ) $roles[] = __( 'Proposer', 'k20-ai-press' );
            if ( (int) $row['reviewed_by'] === $user->ID ) $roles[] = __( 'Reviewer', 'k20-ai-press' );
            if ( (int) $row['applied_by'] === $user->ID ) $roles[] = __( 'Applier', 'k20-ai-press' );
            $data[] = self::export_item(
                'k20-ai-press-seo-actions',
                __( 'K20 AI Press SEO actions', 'k20-ai-press' ),
                'seo-action-' . (int) $row['id'],
                array(
                    __( 'Role', 'k20-ai-press' )        => implode( ', ', $roles ),
                    __( 'Action', 'k20-ai-press' )      => (string) $row['action_type'],
                    __( 'Target type', 'k20-ai-press' ) => (string) $row['entity_kind'],
                    __( 'Target ID', 'k20-ai-press' )   => (string) $row['entity_id'],
                    __( 'Status', 'k20-ai-press' )      => (string) $row['status'],
                    __( 'Created at', 'k20-ai-press' )  => (string) $row['created_at'],
                    __( 'Updated at', 'k20-ai-press' )  => (string) $row['updated_at'],
                )
            );
        }

        if ( 1 === $page ) {
            foreach ( array( 'k20ai_ui_language' => __( 'Interface language', 'k20-ai-press' ), 'k20ai_ui_theme' => __( 'Interface theme', 'k20-ai-press' ) ) as $meta_key => $label ) {
                $value = (string) get_user_meta( $user->ID, $meta_key, true );
                if ( '' === $value ) continue;
                $data[] = self::export_item( 'k20-ai-press-preferences', __( 'K20 AI Press preferences', 'k20-ai-press' ), 'preferences-' . $user->ID . '-' . $meta_key, array( $label => $value ) );
            }
        }

        $done = true;
        foreach ( $batch_counts as $count ) {
            if ( $count >= self::EXPORT_BATCH ) {
                $done = false;
                break;
            }
        }
        return array( 'data' => $data, 'done' => $done );
    }

    /** @return array<string,mixed> */
    public static function erase_personal_data( string $email_address, int $page = 1 ): array {
        global $wpdb;
        $user = get_user_by( 'email', sanitize_email( $email_address ) );
        if ( ! $user instanceof WP_User ) return array( 'items_removed' => false, 'items_retained' => false, 'messages' => array(), 'done' => true );

        $t = K20AI_Database::tables();
        $removed = false;
        $retained = false;
        $messages = array();

        $audit_ids = array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare( "SELECT id FROM {$t['audit_log']} WHERE actor_id=%d ORDER BY id ASC LIMIT %d", $user->ID, self::EXPORT_BATCH ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        if ( $audit_ids ) {
            $in = implode( ',', $audit_ids );
            $changed = $wpdb->query( "UPDATE {$t['audit_log']} SET actor_id=NULL,actor_type='erased-user' WHERE id IN ({$in})" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            if ( false !== $changed && $changed > 0 ) {
                $removed = true;
                $retained = true;
                $messages[] = __( 'Audit events were retained for integrity but the user identifier was anonymized.', 'k20-ai-press' );
            }
        }

        $supplier_rows = $wpdb->get_results( $wpdb->prepare( "SELECT id,supplier_id,payload,reviewer FROM {$t['supplier_submissions']} WHERE supplier_id=%s OR reviewer=%d ORDER BY id ASC LIMIT %d", (string) $user->ID, $user->ID, self::EXPORT_BATCH ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        foreach ( (array) $supplier_rows as $row ) {
            $updates = array();
            $formats = array();
            if ( (string) $row['supplier_id'] === (string) $user->ID ) {
                $updates['supplier_id'] = '';
                $updates['payload'] = self::erase_personal_fields_from_payload( $row['payload'] ?? '' );
                $formats[] = '%s';
                $formats[] = '%s';
            }
            if ( (int) $row['reviewer'] === $user->ID ) {
                $updates['reviewer'] = null;
                $formats[] = '%d';
            }
            if ( ! $updates ) continue;
            $changed = $wpdb->update( $t['supplier_submissions'], $updates, array( 'id' => (int) $row['id'] ), $formats, array( '%d' ) );
            if ( false !== $changed ) {
                $removed = true;
                $retained = true;
            }
        }
        if ( $supplier_rows ) $messages[] = __( 'Supplier records were retained for product-evidence integrity while matching user identifiers and common personal contact fields were removed.', 'k20-ai-press' );

        // Agent plans can contain free-form user-authored objectives/context. Preserve
        // run chronology while erasing authored content and associated step payloads.
        $agent_ids = array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare( "SELECT id FROM {$t['agent_runs']} WHERE actor_id=%d ORDER BY id ASC LIMIT %d", $user->ID, self::EXPORT_BATCH ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        if ( $agent_ids ) {
            $in = implode( ',', $agent_ids );
            $wpdb->query( "UPDATE {$t['agent_steps']} SET input_json='{}',output_json='{}',evidence_json='{}',last_error=NULL WHERE run_id IN ({$in})" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $changed = $wpdb->query( "UPDATE {$t['agent_runs']} SET actor_id=NULL,objective='[erased]',context='{}',last_error=NULL WHERE id IN ({$in})" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            if ( false !== $changed && $changed > 0 ) { $removed = true; $retained = true; $messages[] = __( 'Agent run chronology was retained while user-authored objectives, context, step payloads, and the WordPress user identifier were erased.', 'k20-ai-press' ); }
        }

        $visibility_ids = array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare( "SELECT id FROM {$t['visibility_queries']} WHERE created_by=%d ORDER BY id ASC LIMIT %d", $user->ID, self::EXPORT_BATCH ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        if ( $visibility_ids ) {
            $in = implode( ',', $visibility_ids );
            $changed = $wpdb->query( "UPDATE {$t['visibility_queries']} SET created_by=NULL,query_text='[erased]',tags='[]' WHERE id IN ({$in})" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            if ( false !== $changed && $changed > 0 ) { $removed = true; $retained = true; $messages[] = __( 'AI visibility measurement history was retained while user-authored query text and the WordPress user identifier were erased.', 'k20-ai-press' ); }
        }

        $reference_specs = array(
            array( $t['claims'], 'reviewer' ),
            array( $t['compat_rules'], 'reviewer' ),
            array( $t['seo_scans'], 'created_by' ),
            array( $t['bridge_snapshots'], 'actor_id' ),
            array( $t['migration_snapshots'], 'created_by' ),
            array( $t['seo_actions'], 'proposed_by' ),
            array( $t['seo_actions'], 'reviewed_by' ),
            array( $t['seo_actions'], 'applied_by' ),
        );
        $reference_changes = 0;
        foreach ( $reference_specs as $reference_spec ) {
            [ $table, $column ] = $reference_spec;
            $changed = $wpdb->query( $wpdb->prepare( "UPDATE {$table} SET {$column}=NULL WHERE {$column}=%d LIMIT %d", $user->ID, self::EXPORT_BATCH ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            if ( false !== $changed && $changed > 0 ) $reference_changes += (int) $changed;
        }
        if ( $reference_changes > 0 ) {
            $removed = true;
            $retained = true;
            $messages[] = __( 'Reviewer, scan, action, and rollback records were retained for operational integrity while the WordPress user identifier was anonymized.', 'k20-ai-press' );
        }

        if ( 1 === $page ) {
            delete_user_meta( $user->ID, 'k20ai_ui_language' );
            delete_user_meta( $user->ID, 'k20ai_ui_theme' );
            $removed = true;
        }

        return array(
            'items_removed'  => $removed,
            'items_retained' => $retained,
            'messages'       => array_values( array_unique( $messages ) ),
            'done'           => 0 === self::count_user_references( $user->ID, $t ),
        );
    }

    /** @return array<string,mixed> */
    private static function settings(): array {
        $defaults = array(
            'prompt_log_retention'          => 30,
            'ip_retention'                  => 7,
            'bot_log_retention'             => 90,
            'provider_log_retention'        => 90,
            'audit_log_retention'           => 365,
            'event_log_retention'           => 90,
            'webhook_log_retention'         => 30,
            'engine_run_retention'          => 180,
            'supplier_submission_retention' => 730,
            'agent_run_retention'            => 180,
            'visibility_retention'           => 730,
            'migration_snapshot_retention'   => 365,
        );
        $saved = get_option( 'k20ai_settings', array() );
        $settings = wp_parse_args( is_array( $saved ) ? $saved : array(), $defaults );
        foreach ( array_keys( $defaults ) as $key ) {
            $settings[ $key ] = max( 0, min( 3650, absint( $settings[ $key ] ?? $defaults[ $key ] ) ) );
        }
        return $settings;
    }

    private static function cutoff( int $days ): string {
        return gmdate( 'Y-m-d H:i:s', time() - max( 0, $days ) * DAY_IN_SECONDS );
    }

    /** @return array{steps:int,runs:int} */
    private static function delete_agent_history_older_than( string $steps_table, string $runs_table, int $days ): array {
        global $wpdb;
        $cutoff = self::cutoff( $days );
        $deleted_steps = 0;
        $deleted_runs = 0;
        for ( $i = 0; $i < self::CLEANUP_LOOPS; ++$i ) {
            $ids = array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare( "SELECT id FROM {$runs_table} WHERE created_at<%s ORDER BY id ASC LIMIT %d", $cutoff, self::CLEANUP_BATCH ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            if ( ! $ids ) break;
            $in = implode( ',', $ids );
            $step_count = $wpdb->query( "DELETE FROM {$steps_table} WHERE run_id IN ({$in})" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $run_count = $wpdb->query( "DELETE FROM {$runs_table} WHERE id IN ({$in})" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            if ( false !== $step_count ) $deleted_steps += (int) $step_count;
            if ( false === $run_count ) break;
            $deleted_runs += (int) $run_count;
            if ( count( $ids ) < self::CLEANUP_BATCH ) break;
        }
        return array( 'steps' => $deleted_steps, 'runs' => $deleted_runs );
    }

    private static function delete_older_than( string $table, string $column, int $days ): int {
        global $wpdb;
        $deleted = 0;
        $cutoff = self::cutoff( $days );
        for ( $i = 0; $i < self::CLEANUP_LOOPS; ++$i ) {
            $count = $wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE {$column}<%s LIMIT %d", $cutoff, self::CLEANUP_BATCH ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            if ( false === $count || $count <= 0 ) break;
            $deleted += (int) $count;
            if ( $count < self::CLEANUP_BATCH ) break;
        }
        return $deleted;
    }

    private static function anonymize_ip_hashes( string $table, int $days ): int {
        global $wpdb;
        $changed = 0;
        $cutoff = self::cutoff( $days );
        for ( $i = 0; $i < self::CLEANUP_LOOPS; ++$i ) {
            $count = $wpdb->query( $wpdb->prepare( "UPDATE {$table} SET ip_hash=NULL WHERE ip_hash IS NOT NULL AND created_at<%s LIMIT %d", $cutoff, self::CLEANUP_BATCH ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            if ( false === $count || $count <= 0 ) break;
            $changed += (int) $count;
            if ( $count < self::CLEANUP_BATCH ) break;
        }
        return $changed;
    }

    /** @param array<string,mixed> $values @return array<string,mixed> */
    private static function export_item( string $group_id, string $group_label, string $item_id, array $values ): array {
        $rows = array();
        foreach ( $values as $name => $value ) {
            if ( null === $value || '' === $value ) continue;
            $rows[] = array( 'name' => (string) $name, 'value' => (string) $value );
        }
        return array( 'group_id' => $group_id, 'group_label' => $group_label, 'item_id' => $item_id, 'data' => $rows );
    }

    /**
     * Export a bounded page of records where a single fixed user-reference column matches.
     * Table/column/select identifiers are supplied only by this class's fixed schema map.
     *
     * @param array<int,array<string,mixed>> $data
     * @param array<int,int> $batch_counts
     * @param array<int,string> $display_columns
     */
    private static function append_simple_reference_exports( array &$data, array &$batch_counts, string $table, string $user_column, int $user_id, int $offset, string $item_prefix, string $group_label, string $select_columns, array $display_columns ): void {
        global $wpdb;
        $rows = $wpdb->get_results( $wpdb->prepare( "SELECT {$select_columns} FROM {$table} WHERE {$user_column}=%d ORDER BY id ASC LIMIT %d OFFSET %d", $user_id, self::EXPORT_BATCH, $offset ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $batch_counts[] = count( (array) $rows );
        foreach ( (array) $rows as $row ) {
            $values = array();
            foreach ( $display_columns as $column ) {
                if ( ! array_key_exists( $column, $row ) ) continue;
                $values[ self::export_column_label( $column ) ] = $row[ $column ];
            }
            $data[] = self::export_item( 'k20-ai-press-' . $item_prefix, $group_label, $item_prefix . '-' . (int) $row['id'], $values );
        }
    }

    private static function export_column_label( string $column ): string {
        $labels = array(
            'claim_key'      => __( 'Claim key', 'k20-ai-press' ),
            'rule_key'       => __( 'Rule key', 'k20-ai-press' ),
            'title'          => __( 'Title', 'k20-ai-press' ),
            'status'         => __( 'Status', 'k20-ai-press' ),
            'verified_at'    => __( 'Verified at', 'k20-ai-press' ),
            'created_at'     => __( 'Created at', 'k20-ai-press' ),
            'updated_at'     => __( 'Updated at', 'k20-ai-press' ),
            'completed_at'   => __( 'Completed at', 'k20-ai-press' ),
            'scan_type'      => __( 'Scan type', 'k20-ai-press' ),
            'scope'          => __( 'Scope', 'k20-ai-press' ),
            'snapshot_key'   => __( 'Snapshot key', 'k20-ai-press' ),
            'action'         => __( 'Action', 'k20-ai-press' ),
            'object_type'    => __( 'Target type', 'k20-ai-press' ),
            'object_id'      => __( 'Target ID', 'k20-ai-press' ),
            'rolled_back_at' => __( 'Rolled back at', 'k20-ai-press' ),
        );
        return $labels[ $column ] ?? ucwords( str_replace( '_', ' ', $column ) );
    }

    /** @param array<string,string> $t */
    private static function count_user_references( int $user_id, array $t ): int {
        global $wpdb;
        $count = 0;
        $queries = array(
            $wpdb->prepare( "SELECT COUNT(*) FROM {$t['audit_log']} WHERE actor_id=%d", $user_id ),
            $wpdb->prepare( "SELECT COUNT(*) FROM {$t['supplier_submissions']} WHERE supplier_id=%s OR reviewer=%d", (string) $user_id, $user_id ),
            $wpdb->prepare( "SELECT COUNT(*) FROM {$t['claims']} WHERE reviewer=%d", $user_id ),
            $wpdb->prepare( "SELECT COUNT(*) FROM {$t['compat_rules']} WHERE reviewer=%d", $user_id ),
            $wpdb->prepare( "SELECT COUNT(*) FROM {$t['seo_scans']} WHERE created_by=%d", $user_id ),
            $wpdb->prepare( "SELECT COUNT(*) FROM {$t['seo_actions']} WHERE proposed_by=%d OR reviewed_by=%d OR applied_by=%d", $user_id, $user_id, $user_id ),
            $wpdb->prepare( "SELECT COUNT(*) FROM {$t['bridge_snapshots']} WHERE actor_id=%d", $user_id ),
            $wpdb->prepare( "SELECT COUNT(*) FROM {$t['agent_runs']} WHERE actor_id=%d", $user_id ),
            $wpdb->prepare( "SELECT COUNT(*) FROM {$t['visibility_queries']} WHERE created_by=%d", $user_id ),
            $wpdb->prepare( "SELECT COUNT(*) FROM {$t['migration_snapshots']} WHERE created_by=%d", $user_id ),
        );
        foreach ( $queries as $query ) $count += (int) $wpdb->get_var( $query ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        return $count;
    }

    private static function safe_export_payload( mixed $raw ): string {
        $decoded = is_array( $raw ) ? $raw : json_decode( (string) $raw, true );
        if ( ! is_array( $decoded ) ) return sanitize_textarea_field( (string) $raw );
        return (string) wp_json_encode( $decoded, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
    }

    private static function erase_personal_fields_from_payload( mixed $raw ): string {
        $decoded = is_array( $raw ) ? $raw : json_decode( (string) $raw, true );
        if ( ! is_array( $decoded ) ) return '';
        $clean = self::erase_personal_fields_recursive( $decoded );
        return (string) wp_json_encode( $clean, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
    }

    private static function erase_personal_fields_recursive( array $input ): array {
        $out = array();
        foreach ( $input as $key => $value ) {
            $raw_name = preg_replace( '/([a-z0-9])([A-Z])/', '$1_$2', (string) $key );
            $name = strtolower( (string) preg_replace( '/[^a-zA-Z0-9]+/', '_', (string) $raw_name ) );
            $name = trim( $name, '_' );
            if ( self::is_personal_payload_key( $name ) ) continue;
            $out[ $key ] = is_array( $value ) ? self::erase_personal_fields_recursive( $value ) : $value;
        }
        return $out;
    }

    private static function is_personal_payload_key( string $name ): bool {
        $exact = array(
            'name', 'full_name', 'first_name', 'last_name', 'contact_name',
            'email', 'email_address', 'e_mail', 'phone', 'phone_number', 'telephone', 'mobile', 'mobile_number',
            'address', 'address_1', 'address_2', 'street', 'postal_code', 'postcode',
            'ip', 'ip_address', 'user_agent', 'username', 'user_login', 'login',
        );
        if ( in_array( $name, $exact, true ) ) return true;
        return str_starts_with( $name, 'contact_' ) || str_starts_with( $name, 'billing_' ) || str_starts_with( $name, 'shipping_' );
    }
}
