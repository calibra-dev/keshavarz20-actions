<?php

defined( 'ABSPATH' ) || exit;

final class K20AI_Ability_Registry {
    /** @var array<string,array<string,mixed>> */
    private array $abilities = array();

    public function __construct() {
        $this->define_defaults();
    }

    private function schema_object( array $properties = array(), array $required = array() ): array {
        return array(
            'type'                 => 'object',
            'properties'           => (object) $properties,
            'required'             => $required,
            'additionalProperties' => false,
        );
    }

    private function add( string $name, string $description, string $risk, bool $side_effect, bool $confirmation, array $input = array(), array $output = array() ): void {
        $legacy_prefixes = array( 'quote.', 'support.', 'order.', 'warranty.', 'return.', 'supplier.' );
        $surface = 'core';
        foreach ( $legacy_prefixes as $prefix ) {
            if ( str_starts_with( $name, $prefix ) ) { $surface = 'internal_legacy'; break; }
        }
        if ( K20AI_Security::ability_public_readonly( $name ) ) $surface = 'public_tool';
        if ( 'manage_options' === K20AI_Security::ability_required_capability( $name, $side_effect ) ) $surface = 'system';
        $this->abilities[ $name ] = array(
            'name'                  => $name,
            'description'           => $description,
            'input_schema'          => $input ?: array( 'type' => 'object', 'additionalProperties' => true ),
            'output_schema'         => $output ?: array( 'type' => array( 'object', 'array', 'string', 'number', 'integer', 'boolean', 'null' ) ),
            'permission'            => K20AI_Security::ability_required_capability( $name, $side_effect ),
            'surface'               => $surface,
            'public_exposure'       => K20AI_Security::ability_public_readonly( $name ) ? 'readonly_allowlist' : 'internal',
            'risk_class'            => $risk,
            'side_effect'           => $side_effect,
            'idempotent'            => ! $side_effect,
            'rate_limit'            => match ( $risk ) {
                'READ' => '100/min',
                'LOW' => '60/min',
                'REVERSIBLE_WRITE' => '30/min',
                'SENSITIVE', 'COMMERCE' => '10/min',
                'DESTRUCTIVE' => '2/min',
                default => '30/min',
            },
            'requires_confirmation' => $confirmation,
        );
    }

    private function define_defaults(): void {
        $id = array( 'type' => 'integer', 'minimum' => 1 );
        $this->add( 'catalog.search', 'جست‌وجوی کاتالوگ محصول', 'READ', false, false, $this->schema_object( array( 'query' => array( 'type' => 'string', 'maxLength' => 200 ), 'limit' => array( 'type' => 'integer', 'minimum' => 1, 'maximum' => 50 ) ), array( 'query' ) ) );
        $this->add( 'product.get', 'دریافت Product Truth محصول', 'READ', false, false, $this->schema_object( array( 'product_id' => $id ), array( 'product_id' ) ) );
        $this->add( 'product.update', 'ویرایش کنترل‌شده فیلدهای محصول از داخل هسته هوش محصول', 'REVERSIBLE_WRITE', true, true, array( 'type' => 'object', 'properties' => (object) array( 'product_id' => $id, 'fields' => array( 'type' => 'object', 'additionalProperties' => true ) ), 'required' => array( 'product_id', 'fields' ), 'additionalProperties' => false ) );
        $this->add( 'product.autofix', 'اصلاح خودکار کم‌ریسک فیلدهای قابل‌استنتاج محصول', 'REVERSIBLE_WRITE', true, true, array( 'type' => 'object', 'properties' => (object) array( 'product_id' => $id, 'scope' => array( 'type' => 'string', 'enum' => array( 'safe', 'all' ) ) ), 'required' => array( 'product_id' ), 'additionalProperties' => false ) );
        $this->add( 'product.compare', 'مقایسه محصولات با داده قابل اثبات', 'READ', false, false, $this->schema_object( array( 'product_ids' => array( 'type' => 'array', 'minItems' => 2, 'maxItems' => 5, 'items' => $id ) ), array( 'product_ids' ) ) );
        $this->add( 'product.enrichment.backlog', 'نمایش صف واقعی محصولات نیازمند تکمیل', 'READ', false, false );
        $this->add( 'supplier.import.preview', 'پیش‌نمایش داده‌های ثبت‌شده تأمین‌کنندگان بدون تغییر محصول', 'READ', false, false );
        $this->add( 'product.get_verified_specs', 'دریافت مشخصات تأییدشده محصول', 'READ', false, false, $this->schema_object( array( 'product_id' => $id ), array( 'product_id' ) ) );
        $this->add( 'claim.verify', 'اعتبارسنجی ادعا', 'READ', false, false, $this->schema_object( array( 'claim_id' => $id ), array( 'claim_id' ) ) );
        $this->add( 'evidence.get', 'دریافت شواهد یک ادعا', 'READ', false, false, $this->schema_object( array( 'claim_id' => $id ), array( 'claim_id' ) ) );
        $this->add( 'compatibility.check', 'بررسی سازگاری براساس Rule Engine', 'READ', false, false, $this->schema_object( array( 'context' => array( 'type' => 'object' ) ), array( 'context' ) ) );
        $this->add( 'compatibility.explain', 'توضیح سازگاری و منبع قانون', 'READ', false, false, $this->schema_object( array( 'rule_id' => $id ), array( 'rule_id' ) ) );
        $this->add( 'engineering.convert_units', 'تبدیل deterministic واحدها', 'READ', false, false, $this->schema_object( array( 'value' => array( 'type' => 'number' ), 'from' => array( 'type' => 'string' ), 'to' => array( 'type' => 'string' ) ), array( 'value', 'from', 'to' ) ) );
        $this->add( 'engineering.calculate_drip_tape', 'محاسبه طول نوار تیپ', 'READ', false, false, $this->schema_object( array( 'area_m2' => array( 'type' => 'number', 'exclusiveMinimum' => 0 ), 'row_spacing_m' => array( 'type' => 'number', 'exclusiveMinimum' => 0 ) ), array( 'area_m2', 'row_spacing_m' ) ) );
        $this->add( 'engineering.calculate_pipe', 'محاسبه ساده سطح مقطع/سرعت لوله', 'READ', false, false, $this->schema_object( array( 'flow_m3h' => array( 'type' => 'number', 'minimum' => 0 ), 'diameter_mm' => array( 'type' => 'number', 'exclusiveMinimum' => 0 ) ), array( 'flow_m3h', 'diameter_mm' ) ) );
        $this->add( 'engineering.calculate_filter', 'محاسبه حداقل ظرفیت فیلتر', 'READ', false, false, $this->schema_object( array( 'flow_m3h' => array( 'type' => 'number', 'minimum' => 0 ), 'safety_factor' => array( 'type' => 'number', 'minimum' => 1, 'maximum' => 3 ) ), array( 'flow_m3h' ) ) );
        $this->add( 'cart.build', 'ساخت BOM آزمایشی بدون ایجاد سفارش', 'READ', false, false, $this->schema_object( array( 'items' => array( 'type' => 'array', 'items' => array( 'type' => 'object' ) ) ), array( 'items' ) ) );
        $this->add( 'cart.validate', 'اعتبارسنجی موجودی و اقلام سبد', 'READ', false, false, $this->schema_object( array( 'items' => array( 'type' => 'array', 'items' => array( 'type' => 'object' ) ) ), array( 'items' ) ) );
        $this->add( 'price.get', 'خواندن قیمت جاری WooCommerce', 'READ', false, false, $this->schema_object( array( 'product_id' => $id ), array( 'product_id' ) ) );
        $this->add( 'stock.get', 'خواندن موجودی جاری WooCommerce', 'READ', false, false, $this->schema_object( array( 'product_id' => $id ), array( 'product_id' ) ) );
        $this->add( 'shipping.estimate', 'برآورد حمل از نرخ‌های واقعی WooCommerce؛ بدون نرخ واقعی Fail-closed', 'READ', false, false, $this->schema_object( array( 'destination' => array( 'type' => 'object' ), 'items' => array( 'type' => 'array' ) ), array( 'destination', 'items' ) ) );
        $this->add( 'quote.create', 'ایجاد پیش‌فاکتور کنترل‌شده', 'COMMERCE', true, true, $this->schema_object( array( 'items' => array( 'type' => 'array', 'minItems' => 1 ), 'customer_note' => array( 'type' => 'string', 'maxLength' => 1000 ) ), array( 'items' ) ) );
        $this->add( 'quote.get', 'خواندن پیش‌فاکتور', 'READ', false, false, $this->schema_object( array( 'quote_id' => array( 'type' => 'string', 'maxLength' => 64 ) ), array( 'quote_id' ) ) );
        $this->add( 'support.create_case', 'ایجاد تیکت پشتیبانی', 'REVERSIBLE_WRITE', true, true, $this->schema_object( array( 'subject' => array( 'type' => 'string', 'minLength' => 3, 'maxLength' => 200 ), 'message' => array( 'type' => 'string', 'minLength' => 3, 'maxLength' => 5000 ) ), array( 'subject', 'message' ) ) );
        $this->add( 'order.track', 'پیگیری سفارش احراز هویت‌شده', 'SENSITIVE', false, true, $this->schema_object( array( 'order_id' => $id ), array( 'order_id' ) ) );
        $this->add( 'warranty.check', 'بررسی داده گارانتی ثبت‌شده', 'READ', false, false, $this->schema_object( array( 'product_id' => $id ), array( 'product_id' ) ) );
        $this->add( 'return.request', 'ثبت درخواست مرجوعی', 'COMMERCE', true, true, $this->schema_object( array( 'order_id' => $id, 'reason' => array( 'type' => 'string', 'minLength' => 3, 'maxLength' => 1000 ) ), array( 'order_id', 'reason' ) ) );
        $this->add( 'admin.review_claim', 'بازبینی ادعا توسط مدیر', 'REVERSIBLE_WRITE', true, true, $this->schema_object( array( 'claim_id' => $id, 'status' => array( 'type' => 'string', 'enum' => array( 'VERIFIED', 'PARTIAL', 'CONFLICTING', 'UNKNOWN', 'EXPIRED' ) ) ), array( 'claim_id', 'status' ) ) );
        $this->add( 'admin.publish_rule', 'انتشار قانون سازگاری بازبینی‌شده', 'REVERSIBLE_WRITE', true, true, $this->schema_object( array( 'rule_id' => $id ), array( 'rule_id' ) ) );
        $this->add( 'admin.trigger_reindex', 'درخواست Reindex', 'REVERSIBLE_WRITE', true, true, $this->schema_object( array( 'scope' => array( 'type' => 'string', 'enum' => array( 'all', 'products', 'content', 'selected' ) ) ), array( 'scope' ) ) );
        $this->add( 'admin.resolve_conflict', 'ثبت نتیجه بازبینی تعارض؛ رفع فنی باید جداگانه Readback شود', 'REVERSIBLE_WRITE', true, true, $this->schema_object( array( 'conflict_type' => array( 'type' => 'string', 'minLength' => 2, 'maxLength' => 64 ), 'resolution' => array( 'type' => 'string', 'minLength' => 3, 'maxLength' => 2000 ) ), array( 'conflict_type', 'resolution' ) ) );
        $this->add( 'supplier.submit_product_data', 'ثبت داده تأمین‌کننده برای بازبینی', 'REVERSIBLE_WRITE', true, true );
        $this->add( 'supplier.submit_catalog', 'ثبت کاتالوگ تأمین‌کننده برای بازبینی', 'REVERSIBLE_WRITE', true, true );
        $this->add( 'supplier.update_evidence', 'ثبت شواهد تأمین‌کننده برای بازبینی', 'REVERSIBLE_WRITE', true, true );
        $this->add( 'audit.run', 'اجرای آدیت فقط‌خواندنی محیط', 'READ', false, false );
        $this->add( 'mode.readiness', 'بررسی Readiness Gate برای مهاجرت Mode', 'READ', false, false );
        $this->add( 'mode.promote', 'مهاجرت کنترل‌شده Shadow/Hybrid/Primary پس از Gate', 'SENSITIVE', true, true, $this->schema_object( array( 'target' => array( 'type' => 'string', 'enum' => array( 'shadow','hybrid','primary' ) ) ), array( 'target' ) ) );
        $this->add( 'system.retest', 'بازآزمایی سلامت سیستم', 'READ', false, false );
        $this->add( 'bot.registry.list', 'دریافت Bot Registry نسخه‌دار', 'READ', false, false );
        $this->add( 'bot.registry.update', 'به‌روزرسانی Registry ربات‌ها با قواعد اعتبارسنجی', 'REVERSIBLE_WRITE', true, true, $this->schema_object( array( 'entries' => array( 'type' => 'array', 'maxItems' => 200, 'items' => array( 'type' => 'object', 'additionalProperties' => true ) ) ), array( 'entries' ) ) );
        $this->add( 'bot.policy.get', 'خواندن سیاست Botها', 'READ', false, false );
        $this->add( 'bot.policy.update', 'به‌روزرسانی سیاست Botها', 'REVERSIBLE_WRITE', true, true, $this->schema_object( array( 'preset' => array( 'type' => 'string' ), 'overrides' => array( 'type' => 'object', 'additionalProperties' => array( 'type' => 'boolean' ) ) ) ) );
        $this->add( 'bot.verify', 'اعتبارسنجی Bot با User-Agent و DNS در صورت وجود قاعده معتبر', 'READ', false, false, $this->schema_object( array( 'user_agent' => array( 'type' => 'string', 'maxLength' => 1000 ), 'ip' => array( 'type' => 'string', 'maxLength' => 64 ) ), array( 'user_agent','ip' ) ) );
        $this->add( 'brand.truth.get', 'خواندن Brand Truth مرکزی', 'READ', false, false );
        $this->add( 'brand.truth.update', 'به‌روزرسانی Brand Truth مرکزی', 'REVERSIBLE_WRITE', true, true );
        $this->add( 'schema.preview', 'پیش‌نمایش Schema مبتنی بر Product Truth', 'READ', false, false, $this->schema_object( array( 'product_id' => $id ), array( 'product_id' ) ) );
        $this->add( 'schema.validate', 'اعتبارسنجی parity اسکیمای محصول', 'READ', false, false, $this->schema_object( array( 'product_id' => $id ), array( 'product_id' ) ) );
        $this->add( 'citation.pack', 'ساخت Citation Pack از محتوای واقعی و Claimهای تأییدشده', 'READ', false, false, $this->schema_object( array( 'url' => array( 'type' => 'string', 'format' => 'uri' ) ), array( 'url' ) ) );
        $this->add( 'rag.index', 'ایندکس افزایشی دانش محلی', 'REVERSIBLE_WRITE', true, true, $this->schema_object( array( 'scope' => array( 'type' => 'string', 'enum' => array( 'all','products','content' ) ), 'limit' => array( 'type' => 'integer', 'minimum' => 1, 'maximum' => 500 ) ) ) );
        $this->add( 'rag.search', 'جست‌وجوی Hybrid/lexical در دانش ایندکس‌شده', 'READ', false, false, $this->schema_object( array( 'query' => array( 'type' => 'string', 'minLength' => 2, 'maxLength' => 500 ), 'limit' => array( 'type' => 'integer', 'minimum' => 1, 'maximum' => 20 ) ), array( 'query' ) ) );
        $this->add( 'feed.acp.snapshot', 'تولید snapshot سازگار با مسیر ACP بدون ارسال خارجی', 'READ', false, false, $this->schema_object( array( 'limit' => array( 'type' => 'integer', 'minimum' => 1, 'maximum' => 500 ) ) ) );
        $this->add( 'feed.acp.persist_snapshot', 'ذخیره snapshot فعلی ACP برای freshness و diff', 'REVERSIBLE_WRITE', true, true, $this->schema_object( array( 'limit' => array( 'type' => 'integer', 'minimum' => 1, 'maximum' => 500 ) ) ) );
        $this->add( 'feed.health', 'سلامت و تازگی snapshotهای تجاری', 'READ', false, false );
        $this->add( 'ucp.catalog.search', 'جست‌وجوی Catalog مطابق UCP 2026-08-25', 'READ', false, false, $this->schema_object( array( 'query' => array( 'type' => 'string', 'maxLength' => 500 ), 'filters' => array( 'type' => 'object', 'additionalProperties' => true ), 'pagination' => array( 'type' => 'object', 'additionalProperties' => true ) ) ) );
        $this->add( 'ucp.catalog.lookup', 'Lookup گروهی محصول مطابق UCP 2026-08-25', 'READ', false, false, $this->schema_object( array( 'ids' => array( 'type' => 'array', 'minItems' => 1, 'maxItems' => 50, 'items' => array( 'type' => 'string' ) ) ), array( 'ids' ) ) );
        $this->add( 'ucp.catalog.product', 'دریافت جزئیات یک محصول مطابق UCP 2026-08-25', 'READ', false, false, $this->schema_object( array( 'id' => array( 'type' => 'string', 'minLength' => 1, 'maxLength' => 191 ) ), array( 'id' ) ) );
        $this->add( 'feed.ucp.profile', 'تولید UCP profile عمومی سایت', 'READ', false, false );
        $this->add( 'visibility.summary', 'خلاصه Citation و Bot visibility از داده واقعی', 'READ', false, false, $this->schema_object( array( 'days' => array( 'type' => 'integer', 'minimum' => 1, 'maximum' => 365 ) ) ) );
        $this->add( 'visibility.ingest_citation', 'ثبت مشاهده Citation با منبع و نمونه واقعی', 'REVERSIBLE_WRITE', true, true );
        $this->add( 'provider.matrix', 'ماتریس Provider/Capability موجود', 'READ', false, false );
        $this->add( 'mcp.status', 'وضعیت WordPress Abilities و MCP Adapter رسمی', 'READ', false, false );
        $this->add( 'observability.status', 'وضعیت Queue، Provider، MCP و freshness', 'READ', false, false );
        $this->add( 'eval.run', 'اجرای Eval Gate داخلی', 'REVERSIBLE_WRITE', true, true );
        $this->add( 'provider.route', 'انتخاب Provider براساس قابلیت واقعی', 'READ', false, false, $this->schema_object( array( 'task' => array( 'type' => 'string', 'maxLength' => 64 ) ), array( 'task' ) ) );
        $this->add( 'ai.generate_text', 'تولید متن از WordPress AI Client با تأیید هزینه/فراخوانی', 'SENSITIVE', true, true, $this->schema_object( array( 'prompt' => array( 'type' => 'string', 'minLength' => 1, 'maxLength' => 12000 ) ), array( 'prompt' ) ) );
        $this->add( 'media.audit', 'ممیزی ALT و پوشش تصاویر محصولات', 'READ', false, false );
        $this->add( 'taxonomy.audit', 'ممیزی دسته‌بندی و برند محصولات', 'READ', false, false );
        $this->add( 'content.engines.status', 'کشف وضعیت Cron موتورهای محتوایی', 'READ', false, false );
        $this->add( 'support.workflows.status', 'وضعیت Workflowهای پشتیبانی و پس از خرید', 'READ', false, false );
        $this->add( 'parity.validate', 'مقایسه Product Truth/WooCommerce/Schema برای فیلدهای حیاتی', 'READ', false, false, $this->schema_object( array( 'product_id' => $id ), array( 'product_id' ) ) );
        $this->add( 'graph.rebuild', 'بازسازی Knowledge Graph از داده واقعی محصولات', 'REVERSIBLE_WRITE', true, true, $this->schema_object( array( 'limit' => array( 'type' => 'integer', 'minimum' => 1, 'maximum' => 500 ) ) ) );
        $this->add( 'graph.query', 'خواندن یک موجودیت و روابط آن', 'READ', false, false, $this->schema_object( array( 'entity_key' => array( 'type' => 'string', 'minLength' => 3, 'maxLength' => 191 ) ), array( 'entity_key' ) ) );
        $this->add( 'intent.parse', 'استخراج constraintهای مأموریت کاربر', 'READ', false, false, $this->schema_object( array( 'query' => array( 'type' => 'string', 'minLength' => 2, 'maxLength' => 1000 ) ), array( 'query' ) ) );
        $this->add( 'guided.sell', 'Shortlist مبتنی بر context و evidence بدون boost تجاری مخفی', 'READ', false, false, $this->schema_object( array( 'query' => array( 'type' => 'string', 'minLength' => 2, 'maxLength' => 1000 ) ), array( 'query' ) ) );
        $this->add( 'reviews.summary', 'خلاصه آماری Reviewهای واقعی محصول', 'READ', false, false, $this->schema_object( array( 'product_id' => $id ), array( 'product_id' ) ) );
        $this->add( 'media.truth', 'Media Asset Truth محصول', 'READ', false, false, $this->schema_object( array( 'product_id' => $id ), array( 'product_id' ) ) );
        $this->add( 'stats.noise', 'کنترل آماری Noise تغییرات سری زمانی', 'READ', false, false, $this->schema_object( array( 'values' => array( 'type' => 'array', 'minItems' => 3, 'items' => array( 'type' => 'number' ) ) ), array( 'values' ) ) );
        $this->add( 'prompt.bank', 'دریافت Prompt Bank baseline', 'READ', false, false, $this->schema_object( array( 'limit' => array( 'type' => 'integer', 'minimum' => 1, 'maximum' => 500 ) ) ) );
        $this->add( 'robots.preview', 'پیش‌نمایش robots policy بدون write', 'READ', false, false );
        $this->add( 'robots.apply_virtual', 'اعمال robots مجازی با backup؛ فایل فیزیکی دست‌نخورده می‌ماند', 'SENSITIVE', true, true );
        $this->add( 'robots.rollback', 'Rollback سیاست robots مجازی', 'REVERSIBLE_WRITE', true, true );
        $this->add( 'webhook.list', 'لیست Webhookها بدون Secret', 'READ', false, false );
        $this->add( 'webhook.register', 'ثبت Webhook HTTPS با HMAC', 'SENSITIVE', true, true, $this->schema_object( array( 'url' => array( 'type' => 'string', 'format' => 'uri' ), 'events' => array( 'type' => 'array', 'maxItems' => 50, 'items' => array( 'type' => 'string' ) ), 'secret' => array( 'type' => 'string', 'minLength' => 32, 'maxLength' => 191 ) ), array( 'url' ) ) );
        $this->add( 'webhook.test', 'ارسال تست Webhook با SSRF guard', 'SENSITIVE', true, true, $this->schema_object( array( 'id' => array( 'type' => 'string', 'maxLength' => 64 ) ), array( 'id' ) ) );
        $this->add( 'budget.get', 'خواندن بودجه Providerها', 'READ', false, false );
        $this->add( 'budget.update', 'به‌روزرسانی بودجه AI/Provider', 'REVERSIBLE_WRITE', true, true );
        $this->add( 'budget.status', 'وضعیت مصرف بودجه', 'READ', false, false );
        $this->add( 'slo.get', 'خواندن SLOها', 'READ', false, false );
        $this->add( 'slo.update', 'به‌روزرسانی SLOها', 'REVERSIBLE_WRITE', true, true );
        $this->add( 'gs1.mapping', 'GS1 Digital Link-ready mapping در صورت وجود GTIN واقعی', 'READ', false, false, $this->schema_object( array( 'product_id' => $id ), array( 'product_id' ) ) );
        $this->add( 'setup.status', 'وضعیت ده مرحله Setup Wizard', 'READ', false, false );
        $this->add( 'command.center', 'Command Center یکپارچه با صف اقدام، Agent، Commerce و AI Visibility', 'READ', false, false );
        $this->add( 'agent.plan', 'ساخت برنامه Agent بدون اجرای مستقیم عملیات خارج از Abilityها', 'REVERSIBLE_WRITE', true, false, $this->schema_object( array( 'objective' => array( 'type' => 'string', 'minLength' => 3, 'maxLength' => 2000 ), 'mode' => array( 'type' => 'string', 'enum' => array( 'read_only','assisted','autonomous_low_risk' ) ), 'context' => array( 'type' => 'object', 'additionalProperties' => true ), 'abilities' => array( 'type' => 'array', 'maxItems' => 12 ), 'idempotency_key' => array( 'type' => 'string', 'maxLength' => 191 ) ), array( 'objective' ) ) );
        $this->add( 'agent.status', 'خواندن وضعیت و Stepهای یک Agent Run', 'READ', false, false, $this->schema_object( array( 'run_key' => array( 'type' => 'string', 'maxLength' => 36 ) ), array( 'run_key' ) ) );
        $this->add( 'agent.list', 'فهرست Runهای اخیر Agent', 'READ', false, false, $this->schema_object( array( 'limit' => array( 'type' => 'integer', 'minimum' => 1, 'maximum' => 100 ) ) ) );
        $this->add( 'agent.approve', 'تأیید مرحله‌های نیازمند Approval در Agent Run', 'REVERSIBLE_WRITE', true, true, $this->schema_object( array( 'run_key' => array( 'type' => 'string', 'maxLength' => 36 ), 'step_ids' => array( 'type' => 'array', 'maxItems' => 12, 'items' => $id ) ), array( 'run_key' ) ) );
        $this->add( 'agent.execute', 'اجرای Agent Run فقط از مسیر Abilityهای مجاز و Verify پس از اجرا', 'SENSITIVE', true, true, $this->schema_object( array( 'run_key' => array( 'type' => 'string', 'maxLength' => 36 ) ), array( 'run_key' ) ) );
        $this->add( 'agent.cancel', 'لغو Agent Run باز', 'REVERSIBLE_WRITE', true, true, $this->schema_object( array( 'run_key' => array( 'type' => 'string', 'maxLength' => 36 ) ), array( 'run_key' ) ) );
        $this->add( 'agent.retry', 'بازنشانی یک Step شکست‌خورده برای Retry محدود', 'REVERSIBLE_WRITE', true, true, $this->schema_object( array( 'run_key' => array( 'type' => 'string', 'maxLength' => 36 ), 'step_id' => $id ), array( 'run_key','step_id' ) ) );
        $this->add( 'product.intelligence', 'امتیاز توضیح‌پذیر Product/Commerce/AI readiness با ابعاد اندازه‌گیری‌شده', 'READ', false, false, $this->schema_object( array( 'product_id' => $id ), array( 'product_id' ) ) );
        $this->add( 'product.intelligence.backlog', 'صف Product Intelligence بر پایه شکاف‌های اندازه‌گیری‌شده', 'READ', false, false, $this->schema_object( array( 'limit' => array( 'type' => 'integer', 'minimum' => 1, 'maximum' => 100 ) ) ) );
        $this->add( 'visibility.query.list', 'فهرست Queryهای AI Visibility Observatory', 'READ', false, false, $this->schema_object( array( 'enabled_only' => array( 'type' => 'boolean' ) ) ) );
        $this->add( 'visibility.query.upsert', 'ثبت یا به‌روزرسانی Query قابل پایش AI Visibility', 'REVERSIBLE_WRITE', true, true, $this->schema_object( array( 'query' => array( 'type' => 'string', 'minLength' => 2, 'maxLength' => 500 ), 'locale' => array( 'type' => 'string', 'maxLength' => 32 ), 'country' => array( 'type' => 'string', 'maxLength' => 2 ), 'tags' => array( 'type' => 'array', 'maxItems' => 30 ), 'enabled' => array( 'type' => 'boolean' ) ), array( 'query' ) ) );
        $this->add( 'visibility.observation.ingest', 'ثبت Observation اندازه‌گیری‌شده AI Search با Evidence اجباری', 'REVERSIBLE_WRITE', true, true, $this->schema_object( array( 'query_id' => $id, 'engine' => array( 'type' => 'string', 'enum' => K20AI_AI_Visibility::engines() ), 'mentioned' => array( 'type' => 'boolean' ), 'cited' => array( 'type' => 'boolean' ), 'cited_url' => array( 'type' => 'string', 'maxLength' => 2048 ), 'competitor' => array( 'type' => 'string', 'maxLength' => 255 ), 'position_label' => array( 'type' => 'string', 'maxLength' => 64 ), 'source_url' => array( 'type' => 'string', 'maxLength' => 2048 ), 'evidence' => array( 'type' => 'object', 'additionalProperties' => true ), 'collector' => array( 'type' => 'string', 'maxLength' => 64 ), 'collector_ref' => array( 'type' => 'string', 'maxLength' => 191 ), 'observed_at' => array( 'type' => 'string', 'maxLength' => 64 ) ), array( 'query_id', 'engine' ) ) );
        $this->add( 'visibility.observatory', 'AI Search Observatory با Citation/Mention Gain/Loss واقعی', 'READ', false, false, $this->schema_object( array( 'days' => array( 'type' => 'integer', 'minimum' => 1, 'maximum' => 365 ), 'limit' => array( 'type' => 'integer', 'minimum' => 1, 'maximum' => 500 ) ) ) );
        $this->add( 'visibility.collector.status', 'وضعیت Collectorهای AI Visibility و مرز حقیقت هر منبع', 'READ', false, false );
        $this->add( 'visibility.collect.now', 'اجرای محدود Collector خودکار OpenAI Web Search با Attribution صریح', 'SENSITIVE', true, true, $this->schema_object( array( 'limit' => array( 'type' => 'integer', 'minimum' => 1, 'maximum' => 20 ) ) ) );
        $this->add( 'onboarding.status', 'وضعیت Onboarding پنج‌مرحله‌ای', 'READ', false, false );
        $this->add( 'onboarding.update', 'ذخیره پیشرفت Onboarding بدون اجرای migration خودکار', 'REVERSIBLE_WRITE', true, true );
        $this->add( 'migration.preview', 'پیش‌نمایش Migration از Yoast/Rank Math/AIOSEO/SEOPress بدون write', 'READ', false, false, $this->schema_object( array( 'source' => array( 'type' => 'string', 'enum' => array( 'yoast','rank_math','aioseo','seopress' ) ), 'limit' => array( 'type' => 'integer', 'minimum' => 1, 'maximum' => 500 ), 'offset' => array( 'type' => 'integer', 'minimum' => 0 ) ), array( 'source' ) ) );
        $this->add( 'migration.import', 'Migration کنترل‌شده SEO metadata با backup و verify؛ منبع حذف نمی‌شود', 'REVERSIBLE_WRITE', true, true, $this->schema_object( array( 'source' => array( 'type' => 'string', 'enum' => array( 'yoast','rank_math','aioseo','seopress' ) ), 'post_ids' => array( 'type' => 'array', 'minItems' => 1, 'maxItems' => 500, 'items' => $id ) ), array( 'source','post_ids' ) ) );
        $this->add( 'migration.rollback', 'Rollback دقیق Migration از Snapshot داخلی', 'REVERSIBLE_WRITE', true, true, $this->schema_object( array( 'snapshot_key' => array( 'type' => 'string', 'maxLength' => 36 ) ), array( 'snapshot_key' ) ) );
        $this->add( 'license.status', 'وضعیت License بدون افشای License Key', 'READ', false, false );
        $this->add( 'license.activate', 'فعال‌سازی License فقط از endpoint HTTPS امضاشده', 'SENSITIVE', true, true, $this->schema_object( array( 'license_key' => array( 'type' => 'string', 'minLength' => 8, 'maxLength' => 255 ) ), array( 'license_key' ) ) );
        $this->add( 'license.deactivate', 'غیرفعال‌سازی License و پاک‌کردن Secret محلی', 'SENSITIVE', true, true );
        $this->add( 'license.sync', 'همگام‌سازی License و update manifest امضاشده', 'SENSITIVE', true, true );
        $this->add( 'diagnostics.bundle', 'بسته Diagnostics بدون Secret برای پشتیبانی', 'READ', false, false );
    }

    /** @return array<string,array<string,mixed>> */
    public function all(): array {
        return $this->abilities;
    }

    /** @return array<string,array<string,mixed>> */
    public function visible(): array {
        return array_filter(
            $this->abilities,
            static fn( array $ability ): bool => 'internal_legacy' !== (string) ( $ability['surface'] ?? 'core' )
        );
    }

    /** @return array<string,mixed>|null */
    public function get( string $name ): ?array {
        return $this->abilities[ $name ] ?? null;
    }
}
