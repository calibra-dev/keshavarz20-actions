<?php

defined( 'ABSPATH' ) || exit;

/** Localization helpers for the Persian/English commercial admin UI. */
final class K20AI_I18n {
    public static function user_ui_language( int $user_id = 0 ): string {
        $user_id = $user_id > 0 ? $user_id : get_current_user_id();
        $stored = $user_id > 0 ? (string) get_user_meta( $user_id, 'k20ai_ui_language', true ) : '';
        if ( in_array( $stored, array( 'fa', 'en' ), true ) ) return $stored;
        $locale = function_exists( 'get_user_locale' ) ? (string) get_user_locale( $user_id ?: null ) : (string) get_locale();
        return str_starts_with( strtolower( $locale ), 'fa' ) ? 'fa' : 'en';
    }

    public static function pair( string $fa, string $en, ?string $language = null ): string {
        $language = in_array( $language, array( 'fa', 'en' ), true ) ? $language : self::user_ui_language();
        $translated = translate( $en, 'k20-ai-press' );
        if ( 'fa' === $language ) {
            return $translated !== $en ? $translated : $fa;
        }
        return $translated;
    }
}
