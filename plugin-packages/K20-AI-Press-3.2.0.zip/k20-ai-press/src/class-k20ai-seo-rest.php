<?php

defined( 'ABSPATH' ) || exit;

final class K20AI_SEO_REST {
    private K20AI_SEO_OS $seo;
    private ?K20AI_Connection_Center $connections;
    private ?K20AI_AI_Orchestrator $ai;
    private ?K20AI_Content_Engines $content_engines;
    private ?K20AI_Bridge $bridge;

    public function __construct( K20AI_SEO_OS $seo, ?K20AI_Connection_Center $connections = null, ?K20AI_AI_Orchestrator $ai = null, ?K20AI_Content_Engines $content_engines = null, ?K20AI_Bridge $bridge = null ) {
        $this->seo = $seo;
        $this->connections = $connections;
        $this->ai = $ai;
        $this->content_engines = $content_engines;
        $this->bridge = $bridge;
    }

    public function register(): void {
        $ns = 'k20-ai/v3';
        register_rest_route( $ns, '/dashboard', array(
            'methods' => WP_REST_Server::READABLE,
            'permission_callback' => array( $this, 'can_view' ),
            'callback' => fn() => rest_ensure_response( $this->seo->dashboard() ),
        ) );
        register_rest_route( $ns, '/workspace/(?P<mode>[a-z0-9-]+)', array(
            'methods' => WP_REST_Server::READABLE,
            'permission_callback' => array( $this, 'can_view' ),
            'callback' => function( WP_REST_Request $request ) {
                $filters = array();
                foreach ( array( 'id','kind','limit','q','status','page','paged','per_page','category_id','query','entity_query','entity_paged','keyword_paged','content_paged' ) as $key ) {
                    if ( null !== $request->get_param( $key ) ) $filters[ $key ] = $request->get_param( $key );
                }
                return rest_ensure_response( $this->seo->workspace( sanitize_key( (string) $request['mode'] ), $filters ) );
            },
        ) );
        register_rest_route( $ns, '/scans', array(
            array(
                'methods' => WP_REST_Server::READABLE,
                'permission_callback' => array( $this, 'can_view' ),
                'callback' => fn() => rest_ensure_response( $this->seo->latest_active_scan() ),
            ),
            array(
                'methods' => WP_REST_Server::CREATABLE,
                'permission_callback' => array( $this, 'can_scan' ),
                'callback' => function( WP_REST_Request $request ) {
                    $body = (array) $request->get_json_params();
                    $result = $this->seo->create_scan( sanitize_key( (string) ( $body['type'] ?? 'full' ) ), sanitize_key( (string) ( $body['scope'] ?? 'all' ) ), get_current_user_id() );
                    return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
                },
            ),
        ) );
        register_rest_route( $ns, '/scans/(?P<id>\d+)', array(
            'methods' => WP_REST_Server::READABLE,
            'permission_callback' => array( $this, 'can_view' ),
            'callback' => fn( WP_REST_Request $request ) => rest_ensure_response( $this->seo->scan( absint( $request['id'] ) ) ),
        ) );
        register_rest_route( $ns, '/scans/(?P<id>\d+)/tick', array(
            'methods' => WP_REST_Server::CREATABLE,
            'permission_callback' => array( $this, 'can_scan' ),
            'callback' => fn( WP_REST_Request $request ) => rest_ensure_response( $this->seo->tick_scan( absint( $request['id'] ) ) ),
        ) );
        register_rest_route( $ns, '/crawl/url', array(
            'methods' => WP_REST_Server::CREATABLE,
            'permission_callback' => array( $this, 'can_edit' ),
            'callback' => function( WP_REST_Request $request ) {
                $body = (array) $request->get_json_params();
                $result = $this->seo->crawl_url( esc_url_raw( (string) ( $body['url'] ?? '' ) ) );
                return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
            },
        ) );
        register_rest_route( $ns, '/entity/(?P<kind>[a-z0-9_-]+)/(?P<id>\d+)', array(
            array(
                'methods' => WP_REST_Server::READABLE,
                'permission_callback' => array( $this, 'can_read_entity' ),
                'callback' => fn( WP_REST_Request $request ) => rest_ensure_response( $this->seo->entity_detail( sanitize_key( (string) $request['kind'] ), absint( $request['id'] ) ) ),
            ),
            array(
                'methods' => WP_REST_Server::EDITABLE,
                'permission_callback' => array( $this, 'can_edit_entity' ),
                'callback' => function( WP_REST_Request $request ) {
                    $body = (array) $request->get_json_params();
                    $fields = isset( $body['fields'] ) && is_array( $body['fields'] ) ? $body['fields'] : $body;
                    $protected = K20AI_Security::protected_fields_error( $fields );
                    if ( is_wp_error( $protected ) ) return $protected;
                    $result = $this->seo->update_entity( sanitize_key( (string) $request['kind'] ), absint( $request['id'] ), $this->sanitize_entity_fields( $fields ) );
                    return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
                },
            ),
        ) );
        register_rest_route( $ns, '/entity/(?P<kind>[a-z0-9_-]+)/(?P<id>\d+)/preview', array(
            'methods' => WP_REST_Server::CREATABLE,
            'permission_callback' => array( $this, 'can_edit_entity' ),
            'callback' => function( WP_REST_Request $request ) {
                $body = (array) $request->get_json_params();
                $fields = isset( $body['fields'] ) && is_array( $body['fields'] ) ? $body['fields'] : $body;
                $protected = K20AI_Security::protected_fields_error( $fields );
                if ( is_wp_error( $protected ) ) return $protected;
                $result = $this->seo->preview_entity_update( sanitize_key( (string) $request['kind'] ), absint( $request['id'] ), $this->sanitize_entity_fields( $fields ) );
                return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
            },
        ) );
        register_rest_route( $ns, '/entity/(?P<kind>[a-z0-9_-]+)/(?P<id>\d+)/safe-fix', array(
            'methods' => WP_REST_Server::CREATABLE,
            'permission_callback' => array( $this, 'can_edit_entity' ),
            'callback' => function( WP_REST_Request $request ) {
                $result = $this->seo->propose_safe_fix( sanitize_key( (string) $request['kind'] ), absint( $request['id'] ), get_current_user_id() );
                return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
            },
        ) );
        register_rest_route( $ns, '/actions/(?P<id>\d+)/review', array(
            'methods' => WP_REST_Server::CREATABLE,
            'permission_callback' => array( $this, 'can_edit' ),
            'callback' => function( WP_REST_Request $request ) {
                $body = (array) $request->get_json_params();
                $decision = 'approve' === (string) ( $body['decision'] ?? '' ) ? 'approve' : 'reject';
                $result = $this->seo->review_action( absint( $request['id'] ), $decision, sanitize_textarea_field( (string) ( $body['note'] ?? '' ) ), get_current_user_id() );
                return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
            },
        ) );
        register_rest_route( $ns, '/actions/(?P<id>\d+)/apply', array(
            'methods' => WP_REST_Server::CREATABLE,
            'permission_callback' => array( $this, 'can_edit' ),
            'callback' => function( WP_REST_Request $request ) {
                $result = $this->seo->apply_action( absint( $request['id'] ), get_current_user_id() );
                return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
            },
        ) );
        register_rest_route( $ns, '/actions/(?P<id>\d+)/rollback', array(
            'methods' => WP_REST_Server::CREATABLE,
            'permission_callback' => array( $this, 'can_edit' ),
            'callback' => function( WP_REST_Request $request ) {
                $result = $this->seo->rollback_action( absint( $request['id'] ), get_current_user_id() );
                return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
            },
        ) );
        register_rest_route( $ns, '/serp/research', array(
            'methods' => WP_REST_Server::CREATABLE,
            'permission_callback' => array( $this, 'can_edit' ),
            'callback' => function( WP_REST_Request $request ) {
                $body = (array) $request->get_json_params();
                $result = $this->seo->serp_research( sanitize_text_field( (string) ( $body['query'] ?? '' ) ) );
                return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
            },
        ) );
        register_rest_route( $ns, '/serp/live', array(
            'methods' => WP_REST_Server::CREATABLE,
            'permission_callback' => array( $this, 'can_edit' ),
            'callback' => function( WP_REST_Request $request ) {
                $body = (array) $request->get_json_params();
                $result = $this->seo->live_serp_report(
                    sanitize_text_field( (string) ( $body['query'] ?? '' ) ),
                    sanitize_key( (string) ( $body['kind'] ?? '' ) ),
                    absint( $body['id'] ?? 0 )
                );
                return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
            },
        ) );
        register_rest_route( $ns, '/calendar/schedule', array(
            'methods' => WP_REST_Server::CREATABLE,
            'permission_callback' => array( $this, 'can_edit' ),
            'callback' => function( WP_REST_Request $request ) {
                $body = (array) $request->get_json_params();
                $result = $this->seo->schedule_post( absint( $body['id'] ?? 0 ), sanitize_text_field( (string) ( $body['datetime'] ?? '' ) ) );
                return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
            },
        ) );
        register_rest_route( $ns, '/keywords/import', array(
            'methods' => WP_REST_Server::CREATABLE,
            'permission_callback' => array( $this, 'can_edit' ),
            'callback' => function( WP_REST_Request $request ) {
                $body = (array) $request->get_json_params();
                $rows = isset( $body['rows'] ) && is_array( $body['rows'] ) ? $body['rows'] : array();
                $source = sanitize_key( (string) ( $body['source'] ?? 'manual' ) );
                $result = $this->seo->import_keywords( $rows, $source );
                return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
            },
        ) );
        register_rest_route( $ns, '/competitors', array(
            'methods' => WP_REST_Server::CREATABLE,
            'permission_callback' => array( $this, 'can_edit' ),
            'callback' => function( WP_REST_Request $request ) {
                $body = (array) $request->get_json_params();
                $result = $this->seo->add_competitor(
                    sanitize_text_field( (string) ( $body['domain'] ?? '' ) ),
                    sanitize_text_field( (string) ( $body['label'] ?? '' ) ),
                    isset( $body['metrics'] ) && is_array( $body['metrics'] ) ? $body['metrics'] : array(),
                    sanitize_key( (string) ( $body['source'] ?? 'manual' ) )
                );
                return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
            },
        ) );
        register_rest_route( $ns, '/radar/refresh', array(
            'methods' => WP_REST_Server::CREATABLE,
            'permission_callback' => array( $this, 'can_edit' ),
            'callback' => fn() => rest_ensure_response( $this->seo->refresh_market_radar() ),
        ) );
        register_rest_route( $ns, '/settings', array(
            array(
                'methods' => WP_REST_Server::READABLE,
                'permission_callback' => array( $this, 'can_view' ),
                'callback' => fn() => rest_ensure_response( $this->seo->settings() ),
            ),
            array(
                'methods' => WP_REST_Server::EDITABLE,
                'permission_callback' => array( $this, 'can_system' ),
                'callback' => fn( WP_REST_Request $request ) => rest_ensure_response( $this->seo->save_settings( (array) $request->get_json_params() ) ),
            ),
        ) );
        register_rest_route( $ns, '/connections', array(
            'methods' => WP_REST_Server::READABLE,
            'permission_callback' => array( $this, 'can_system' ),
            'callback' => function() {
                if ( ! $this->connections ) return new WP_Error( 'connections_unavailable', __( 'مرکز اتصال در دسترس نیست.', 'k20-ai-press' ), array( 'status' => 503 ) );
                return rest_ensure_response( array( 'connections' => $this->connections->snapshot(), 'ai_providers' => $this->ai ? $this->ai->providers() : array() ) );
            },
        ) );
        register_rest_route( $ns, '/connections/(?P<provider>[a-z0-9_-]+)', array(
            array(
                'methods' => WP_REST_Server::EDITABLE,
                'permission_callback' => array( $this, 'can_system' ),
                'callback' => function( WP_REST_Request $request ) {
                    if ( ! $this->connections ) return new WP_Error( 'connections_unavailable', __( 'مرکز اتصال در دسترس نیست.', 'k20-ai-press' ), array( 'status' => 503 ) );
                    $result = $this->connections->save( sanitize_key( (string) $request['provider'] ), (array) $request->get_json_params() );
                    return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
                },
            ),
            array(
                'methods' => WP_REST_Server::DELETABLE,
                'permission_callback' => array( $this, 'can_system' ),
                'callback' => function( WP_REST_Request $request ) {
                    if ( ! $this->connections ) return new WP_Error( 'connections_unavailable', __( 'مرکز اتصال در دسترس نیست.', 'k20-ai-press' ), array( 'status' => 503 ) );
                    return rest_ensure_response( $this->connections->disconnect( sanitize_key( (string) $request['provider'] ) ) );
                },
            ),
        ) );
        register_rest_route( $ns, '/connections/(?P<provider>[a-z0-9_-]+)/test', array(
            'methods' => WP_REST_Server::CREATABLE,
            'permission_callback' => array( $this, 'can_system' ),
            'callback' => function( WP_REST_Request $request ) {
                if ( ! $this->connections ) return new WP_Error( 'connections_unavailable', __( 'مرکز اتصال در دسترس نیست.', 'k20-ai-press' ), array( 'status' => 503 ) );
                $result = $this->connections->test( sanitize_key( (string) $request['provider'] ) );
                return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
            },
        ) );
        register_rest_route( $ns, '/connections/(?P<provider>[a-z0-9_-]+)/sync', array(
            'methods' => WP_REST_Server::CREATABLE,
            'permission_callback' => array( $this, 'can_system' ),
            'callback' => function( WP_REST_Request $request ) {
                if ( ! $this->connections ) return new WP_Error( 'connections_unavailable', __( 'مرکز اتصال در دسترس نیست.', 'k20-ai-press' ), array( 'status' => 503 ) );
                $result = $this->connections->sync( sanitize_key( (string) $request['provider'] ) );
                return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
            },
        ) );
        register_rest_route( $ns, '/connections/github/dispatch', array(
            'methods' => WP_REST_Server::CREATABLE,
            'permission_callback' => array( $this, 'can_system' ),
            'callback' => function( WP_REST_Request $request ) {
                if ( ! $this->connections ) return new WP_Error( 'connections_unavailable', __( 'مرکز اتصال در دسترس نیست.', 'k20-ai-press' ), array( 'status' => 503 ) );
                $body = (array) $request->get_json_params();
                $result = $this->connections->github_dispatch( isset( $body['inputs'] ) && is_array( $body['inputs'] ) ? $body['inputs'] : array() );
                return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
            },
        ) );
        register_rest_route( $ns, '/entity/(?P<kind>[a-z0-9_-]+)/(?P<id>\d+)/ai-complete', array(
            'methods' => WP_REST_Server::CREATABLE,
            'permission_callback' => array( $this, 'can_edit' ),
            'callback' => function( WP_REST_Request $request ) {
                if ( ! $this->ai ) return new WP_Error( 'ai_unavailable', __( 'موتور تکمیل AI در دسترس نیست.', 'k20-ai-press' ), array( 'status' => 503 ) );
                $result = $this->ai->preview( sanitize_key( (string) $request['kind'] ), absint( $request['id'] ), (array) $request->get_json_params() );
                return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
            },
        ) );
        register_rest_route( $ns, '/ai/apply', array(
            'methods' => WP_REST_Server::CREATABLE,
            'permission_callback' => array( $this, 'can_edit' ),
            'callback' => function( WP_REST_Request $request ) {
                if ( ! $this->ai ) return new WP_Error( 'ai_unavailable', __( 'موتور تکمیل AI در دسترس نیست.', 'k20-ai-press' ), array( 'status' => 503 ) );
                $body = (array) $request->get_json_params();
                $selected = isset( $body['fields'] ) && is_array( $body['fields'] ) ? $body['fields'] : array();
                $result = $this->ai->apply_preview( sanitize_text_field( (string) ( $body['preview_id'] ?? '' ) ), $selected );
                return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
            },
        ) );
        register_rest_route( $ns, '/content-engines', array(
            'methods' => WP_REST_Server::READABLE,
            'permission_callback' => array( $this, 'can_view' ),
            'callback' => function() {
                if ( ! $this->content_engines ) return new WP_Error( 'content_engines_unavailable', __( 'Content engines are unavailable.', 'k20-ai-press' ), array( 'status' => 503 ) );
                return rest_ensure_response( $this->content_engines->status() );
            },
        ) );
        register_rest_route( $ns, '/content-engines/settings', array(
            'methods' => WP_REST_Server::EDITABLE,
            'permission_callback' => array( $this, 'can_system' ),
            'callback' => function( WP_REST_Request $request ) {
                if ( ! $this->content_engines ) return new WP_Error( 'content_engines_unavailable', __( 'Content engines are unavailable.', 'k20-ai-press' ), array( 'status' => 503 ) );
                return rest_ensure_response( $this->content_engines->save_settings( (array) $request->get_json_params() ) );
            },
        ) );
        register_rest_route( $ns, '/content-engines/(?P<engine>news|article)/run', array(
            'methods' => WP_REST_Server::CREATABLE,
            'permission_callback' => array( $this, 'can_system' ),
            'callback' => function( WP_REST_Request $request ) {
                if ( ! $this->content_engines ) return new WP_Error( 'content_engines_unavailable', __( 'Content engines are unavailable.', 'k20-ai-press' ), array( 'status' => 503 ) );
                $result = $this->content_engines->run( sanitize_key( (string) $request['engine'] ), 'manual' );
                return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
            },
        ) );
        register_rest_route( $ns, '/content-engines/receipt', array(
            'methods' => WP_REST_Server::CREATABLE,
            'permission_callback' => array( $this, 'can_system' ),
            'callback' => function( WP_REST_Request $request ) {
                if ( ! $this->content_engines ) return new WP_Error( 'content_engines_unavailable', __( 'Content engines are unavailable.', 'k20-ai-press' ), array( 'status' => 503 ) );
                $result = $this->content_engines->record_remote_receipt( (array) $request->get_json_params() );
                return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
            },
        ) );
        register_rest_route( $ns, '/bridge/contract', array(
            'methods' => WP_REST_Server::READABLE,
            'permission_callback' => array( $this, 'can_system' ),
            'callback' => function() {
                if ( ! $this->bridge ) return new WP_Error( 'bridge_unavailable', __( 'Bridge is unavailable.', 'k20-ai-press' ), array( 'status' => 503 ) );
                return rest_ensure_response( $this->bridge->contract() );
            },
        ) );
        register_rest_route( $ns, '/bridge/execute', array(
            'methods' => WP_REST_Server::CREATABLE,
            'permission_callback' => array( $this, 'can_system' ),
            'callback' => function( WP_REST_Request $request ) {
                if ( ! $this->bridge ) return new WP_Error( 'bridge_unavailable', __( 'Bridge is unavailable.', 'k20-ai-press' ), array( 'status' => 503 ) );
                $result = $this->bridge->execute( (array) $request->get_json_params() );
                return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
            },
        ) );
        register_rest_route( $ns, '/bridge/asset', array(
            'methods' => WP_REST_Server::CREATABLE,
            'permission_callback' => array( $this, 'can_system' ),
            'callback' => function( WP_REST_Request $request ) {
                if ( ! $this->bridge ) return new WP_Error( 'bridge_unavailable', __( 'Bridge is unavailable.', 'k20-ai-press' ), array( 'status' => 503 ) );
                $files = $request->get_file_params();
                $file = isset( $files['file'] ) && is_array( $files['file'] ) ? $files['file'] : array();
                $result = $this->bridge->upload_asset( $file, $request->get_params() );
                return is_wp_error( $result ) ? $result : rest_ensure_response( array( 'ok' => true, 'contract' => K20AI_Bridge::CONTRACT, 'result' => $result ) );
            },
        ) );
        register_rest_route( $ns, '/ui-preferences', array(
            'methods' => WP_REST_Server::EDITABLE,
            'permission_callback' => array( $this, 'can_edit' ),
            'callback' => function( WP_REST_Request $request ) {
                $body = (array) $request->get_json_params();
                $theme = isset( $body['theme'] ) && in_array( $body['theme'], array( 'light', 'dark' ), true ) ? $body['theme'] : null;
                $language = isset( $body['language'] ) && in_array( $body['language'], array( 'fa', 'en' ), true ) ? $body['language'] : null;
                if ( $theme ) update_user_meta( get_current_user_id(), 'k20ai_ui_theme', $theme );
                if ( $language ) update_user_meta( get_current_user_id(), 'k20ai_ui_language', $language );
                return rest_ensure_response( array( 'theme' => $theme ?: get_user_meta( get_current_user_id(), 'k20ai_ui_theme', true ), 'language' => $language ?: get_user_meta( get_current_user_id(), 'k20ai_ui_language', true ) ) );
            },
        ) );

        register_rest_route( $ns, '/bot-control', array(
            'methods' => WP_REST_Server::READABLE,
            'permission_callback' => array( $this, 'can_view' ),
            'callback' => fn() => rest_ensure_response( $this->seo->bot_control() ),
        ) );
        register_rest_route( $ns, '/bot-control/policy', array(
            'methods' => WP_REST_Server::EDITABLE,
            'permission_callback' => array( $this, 'can_system' ),
            'callback' => fn( WP_REST_Request $request ) => rest_ensure_response( $this->seo->save_bot_policy( (array) $request->get_json_params() ) ),
        ) );
        register_rest_route( $ns, '/bot-control/apply', array(
            'methods' => WP_REST_Server::CREATABLE,
            'permission_callback' => array( $this, 'can_system' ),
            'callback' => function() {
                $result = $this->seo->apply_bot_policy();
                return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
            },
        ) );
        register_rest_route( $ns, '/bot-control/rollback', array(
            'methods' => WP_REST_Server::CREATABLE,
            'permission_callback' => array( $this, 'can_system' ),
            'callback' => function() {
                $result = $this->seo->rollback_bot_policy();
                return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
            },
        ) );
        register_rest_route( $ns, '/report/export', array(
            'methods' => WP_REST_Server::READABLE,
            'permission_callback' => array( $this, 'can_view' ),
            'callback' => function( WP_REST_Request $request ) {
                $format = 'json' === sanitize_key( (string) $request->get_param( 'format' ) ) ? 'json' : 'csv';
                return rest_ensure_response( $this->seo->export_report( $format ) );
            },
        ) );
        register_rest_route( $ns, '/health', array(
            'methods' => WP_REST_Server::READABLE,
            'permission_callback' => '__return_true',
            'callback' => function() {
                $health = array( 'status' => 'ok' );
                if ( K20AI_Security::can_view() ) {
                    $health['version'] = K20AI_PRESS_VERSION;
                    $health['db_version'] = K20AI_Database::DB_VERSION;
                }
                return rest_ensure_response( $health );
            },
        ) );
    }

    public function can_view(): bool { return K20AI_Security::can_view(); }
    public function can_edit(): bool { return K20AI_Security::can_edit_content(); }
    public function can_read_entity( WP_REST_Request $request ): bool {
        return K20AI_Entity_Access::can_read( sanitize_key( (string) $request['kind'] ), absint( $request['id'] ) );
    }
    public function can_edit_entity( WP_REST_Request $request ): bool {
        return K20AI_Entity_Access::can_edit( sanitize_key( (string) $request['kind'] ), absint( $request['id'] ) );
    }
    public function can_scan(): bool { return K20AI_Security::can_manage_system(); }
    public function can_system(): bool { return K20AI_Security::can_manage_system(); }

    /** @return array<string,mixed> */
    private function sanitize_entity_fields( array $fields ): array {
        $out = array();
        foreach ( array( 'title','seo_title','meta_description','focus_keyword','sku','gtin','mpn','model','alt','excerpt','short_description' ) as $key ) {
            if ( ! array_key_exists( $key, $fields ) ) continue;
            $out[ $key ] = in_array( $key, array( 'meta_description','excerpt','short_description' ), true ) ? K20AI_Data_Integrity::clean_textarea( $fields[ $key ] ) : K20AI_Data_Integrity::clean_text( $fields[ $key ] );
        }
        foreach ( array( 'content','description' ) as $key ) if ( array_key_exists( $key, $fields ) ) $out[ $key ] = K20AI_Data_Integrity::clean_html( $fields[ $key ] );
        foreach ( array( 'price','stock_status','weight','length','width','height','brand_id' ) as $key ) if ( array_key_exists( $key, $fields ) ) $out[ $key ] = $fields[ $key ];
        if ( isset( $fields['categories'] ) && is_array( $fields['categories'] ) ) $out['categories'] = array_values( array_filter( array_map( 'absint', $fields['categories'] ) ) );
        if ( isset( $fields['attribute_terms'] ) && is_array( $fields['attribute_terms'] ) ) {
            $out['attribute_terms'] = array();
            foreach ( $fields['attribute_terms'] as $taxonomy => $ids ) {
                $taxonomy = sanitize_key( (string) $taxonomy );
                if ( ! str_starts_with( $taxonomy, 'pa_' ) ) continue;
                $out['attribute_terms'][ $taxonomy ] = array_values( array_filter( array_map( 'absint', (array) $ids ) ) );
            }
        }
        if ( isset( $fields['image_alts'] ) && is_array( $fields['image_alts'] ) ) {
            $out['image_alts'] = array();
            foreach ( $fields['image_alts'] as $image_id => $alt ) {
                $image_id = absint( $image_id );
                if ( $image_id ) $out['image_alts'][ $image_id ] = K20AI_Data_Integrity::clean_text( $alt );
            }
        }
        return $out;
    }
}
