<?php

defined( 'ABSPATH' ) || exit;

/** One actionable control plane over SEO, commerce, visibility and agents. */
final class K20AI_Command_Center {
    private K20AI_SEO_OS $seo;
    private K20AI_Agent_Engine $agents;
    private K20AI_AI_Visibility $visibility;
    private K20AI_Product_Intelligence $products;
    private K20AI_Commercial $commercial;
    private K20AI_Onboarding_Migration $onboarding;

    public function __construct( K20AI_SEO_OS $seo, K20AI_Agent_Engine $agents, K20AI_AI_Visibility $visibility, K20AI_Product_Intelligence $products, K20AI_Commercial $commercial, K20AI_Onboarding_Migration $onboarding ) {
        $this->seo = $seo; $this->agents = $agents; $this->visibility = $visibility; $this->products = $products; $this->commercial = $commercial; $this->onboarding = $onboarding;
    }

    /** @return array<string,mixed> */
    public function snapshot(): array {
        $seo = $this->seo->dashboard();
        $agent = $this->agents->summary();
        $visibility = $this->visibility->observatory( 30, 200 );
        $product_backlog = $this->products->backlog( 25 );
        $visibility_metric = $this->visibility_metric( $visibility );
        $commerce_opportunities = count( array_filter( (array) ( $product_backlog['items'] ?? array() ), static fn( array $row ): bool => null !== ( $row['opportunity'] ?? null ) && (int) $row['opportunity'] >= 15 ) );
        $priorities = $this->priority_queue( $seo, $agent, $product_backlog, $visibility );
        return array(
            'generated_at' => current_time( DATE_ATOM, true ),
            'metrics' => array(
                'site_health' => $seo['health']['score'] ?? null,
                'ai_visibility' => $visibility_metric,
                'commerce_opportunities' => $commerce_opportunities,
                'critical_issues' => (int) ( $seo['issues']['critical'] ?? 0 ),
                'awaiting_approval' => (int) ( $agent['waiting_approval'] ?? 0 ) + (int) ( $seo['actions']['proposed'] ?? 0 ),
                'active_agents' => (int) ( $agent['running'] ?? 0 ),
            ),
            'priority_queue' => array_slice( $priorities, 0, 30 ),
            'agents' => array( 'summary' => $agent, 'recent' => $this->agents->list_runs( 8 ) ),
            'ai_visibility' => $visibility,
            'product_intelligence' => $product_backlog,
            'integrations' => $seo['integrations'] ?? array(),
            'onboarding' => $this->onboarding->status(),
            'license' => $this->commercial->status(),
            'measurement_note' => __( 'Null values mean the metric has not been measured; they are never converted to a synthetic score.', 'k20-ai-press' ),
        );
    }

    private function visibility_metric( array $observatory ): ?float {
        $current = (array) ( $observatory['current'] ?? array() );
        if ( ! $current ) return null;
        $score = 0.0;
        foreach ( $current as $row ) {
            if ( ! empty( $row['cited'] ) ) $score += 1.0;
            elseif ( ! empty( $row['mentioned'] ) ) $score += 0.5;
        }
        return round( 100 * $score / count( $current ), 1 );
    }

    /** @return array<int,array<string,mixed>> */
    private function priority_queue( array $seo, array $agent, array $products, array $visibility ): array {
        $rows = array();
        foreach ( (array) ( $seo['priority_queue'] ?? array() ) as $item ) {
            if ( ! is_array( $item ) ) continue;
            $rows[] = array_merge( array( 'source' => 'seo', 'actionable' => true ), K20AI_Logger::sanitize_context( $item ) );
        }
        if ( (int) ( $agent['waiting_approval'] ?? 0 ) > 0 ) {
            $rows[] = array( 'source' => 'agent', 'priority' => 'critical', 'title' => sprintf( __( '%d agent runs are waiting for approval.', 'k20-ai-press' ), (int) $agent['waiting_approval'] ), 'action' => 'agent.review', 'actionable' => true );
        }
        if ( (int) ( $agent['failed'] ?? 0 ) > 0 ) {
            $rows[] = array( 'source' => 'agent', 'priority' => 'high', 'title' => sprintf( __( '%d agent runs need failure review.', 'k20-ai-press' ), (int) $agent['failed'] ), 'action' => 'agent.inspect', 'actionable' => true );
        }
        foreach ( array_slice( (array) ( $products['items'] ?? array() ), 0, 8 ) as $product ) {
            if ( null === ( $product['opportunity'] ?? null ) || (int) $product['opportunity'] < 15 ) continue;
            $rows[] = array( 'source' => 'product_intelligence', 'priority' => (int) $product['opportunity'] >= 35 ? 'high' : 'medium', 'title' => sprintf( __( '%1$s has a measured readiness opportunity of %2$d points.', 'k20-ai-press' ), (string) ( $product['product_name'] ?? '#' . (int) $product['product_id'] ), (int) $product['opportunity'] ), 'product_id' => (int) $product['product_id'], 'action' => 'product.intelligence', 'evidence' => $product['top_gaps'] ?? array(), 'actionable' => true );
        }
        $changes = array_count_values( array_map( static fn( $row ) => (string) ( $row['change'] ?? '' ), (array) ( $visibility['current'] ?? array() ) ) );
        if ( ! empty( $changes['citation_loss'] ) || ! empty( $changes['mention_loss'] ) ) {
            $rows[] = array( 'source' => 'ai_visibility', 'priority' => 'high', 'title' => sprintf( __( '%1$d citation losses and %2$d mention losses were measured.', 'k20-ai-press' ), (int) ( $changes['citation_loss'] ?? 0 ), (int) ( $changes['mention_loss'] ?? 0 ) ), 'action' => 'visibility.observatory', 'actionable' => true );
        }
        $rank = array( 'critical' => 4, 'high' => 3, 'medium' => 2, 'low' => 1 );
        usort( $rows, static fn( array $a, array $b ): int => ( $rank[ strtolower( (string) ( $b['priority'] ?? 'low' ) ) ] ?? 0 ) <=> ( $rank[ strtolower( (string) ( $a['priority'] ?? 'low' ) ) ] ?? 0 ) );
        return $rows;
    }
}
