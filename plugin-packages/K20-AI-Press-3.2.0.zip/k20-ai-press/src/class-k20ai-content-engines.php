<?php

defined( 'ABSPATH' ) || exit;

/**
 * Business-aware news and article engines.
 *
 * The engine never assumes an agriculture domain. It derives business context
 * from the current WordPress/WooCommerce site, then uses either a connected AI
 * provider (local runner) or a configured GitHub Actions workflow (remote runner).
 * Generated content is draft-only by default and every run is auditable.
 */
final class K20AI_Content_Engines {
    private const OPTION = 'k20ai_content_engines_v302';
    private const HOOK = 'k20ai_content_engine_tick';
    private const RUN_HOOK = 'k20ai_content_engine_run';

    private K20AI_SEO_OS $seo;
    private K20AI_Connection_Center $connections;
    private K20AI_AI_Orchestrator $ai;

    public function __construct( K20AI_SEO_OS $seo, K20AI_Connection_Center $connections, K20AI_AI_Orchestrator $ai ) {
        $this->seo = $seo;
        $this->connections = $connections;
        $this->ai = $ai;
    }

    public function register_hooks(): void {
        add_action( self::HOOK, array( $this, 'cron_tick' ), 10, 1 );
        add_action( self::RUN_HOOK, array( $this, 'queued_run' ), 10, 2 );
        add_action( 'k20ai_connection_connected', array( $this, 'connection_ready' ), 10, 2 );
        add_filter( 'cron_schedules', array( $this, 'cron_schedules' ) );
        add_action( 'init', array( $this, 'ensure_schedules' ), 20 );
    }

    /** @return array<string,array<string,int|string>> */
    public function cron_schedules( array $schedules ): array {
        if ( ! isset( $schedules['k20ai_15min'] ) ) {
            $schedules['k20ai_15min'] = array( 'interval' => 15 * MINUTE_IN_SECONDS, 'display' => 'K20 AI Press 15 minutes' );
        }
        return $schedules;
    }

    /** @return array<string,mixed> */
    public function settings(): array {
        $defaults = array(
            'auto_enable_on_ready' => true,
            'default_runner' => 'auto',
            'news' => array(
                'enabled' => false,
                'time' => '08:00',
                'runner' => 'auto',
                'provider' => 'auto',
                'workflow' => '',
                'post_type' => 'auto',
                'status' => 'draft',
                'lookback_hours' => 24,
                'web_research' => true,
                'max_sources' => 8,
            ),
            'article' => array(
                'enabled' => false,
                'time' => '09:00',
                'runner' => 'auto',
                'provider' => 'auto',
                'workflow' => '',
                'post_type' => 'post',
                'status' => 'draft',
                'lookback_hours' => 168,
                'web_research' => true,
                'max_sources' => 10,
            ),
        );
        $stored = get_option( self::OPTION, array() );
        $stored = is_array( $stored ) ? $stored : array();
        $out = wp_parse_args( $stored, $defaults );
        foreach ( array( 'news', 'article' ) as $engine ) {
            $out[ $engine ] = wp_parse_args( isset( $stored[ $engine ] ) && is_array( $stored[ $engine ] ) ? $stored[ $engine ] : array(), $defaults[ $engine ] );
        }
        return $out;
    }

    /** @return array<string,mixed> */
    public function save_settings( array $input ): array {
        $current = $this->settings();
        if ( array_key_exists( 'auto_enable_on_ready', $input ) ) {
            $current['auto_enable_on_ready'] = (bool) $input['auto_enable_on_ready'];
        }
        if ( isset( $input['default_runner'] ) && in_array( $input['default_runner'], array( 'auto', 'local', 'github' ), true ) ) {
            $current['default_runner'] = $input['default_runner'];
        }
        foreach ( array( 'news', 'article' ) as $engine ) {
            if ( empty( $input[ $engine ] ) || ! is_array( $input[ $engine ] ) ) continue;
            $row = $current[ $engine ];
            $source = $input[ $engine ];
            if ( array_key_exists( 'enabled', $source ) ) $row['enabled'] = (bool) $source['enabled'];
            if ( isset( $source['time'] ) && preg_match( '/^(?:[01][0-9]|2[0-3]):[0-5][0-9]$/', (string) $source['time'] ) ) $row['time'] = (string) $source['time'];
            if ( isset( $source['runner'] ) && in_array( $source['runner'], array( 'auto', 'local', 'github' ), true ) ) $row['runner'] = $source['runner'];
            if ( isset( $source['provider'] ) ) $row['provider'] = sanitize_key( (string) $source['provider'] ) ?: 'auto';
            if ( isset( $source['workflow'] ) ) $row['workflow'] = sanitize_text_field( (string) $source['workflow'] );
            if ( isset( $source['post_type'] ) ) $row['post_type'] = sanitize_key( (string) $source['post_type'] ) ?: ( 'news' === $engine ? 'auto' : 'post' );
            if ( isset( $source['status'] ) && in_array( $source['status'], array( 'draft', 'pending' ), true ) ) $row['status'] = $source['status'];
            if ( isset( $source['lookback_hours'] ) ) $row['lookback_hours'] = max( 1, min( 720, absint( $source['lookback_hours'] ) ) );
            if ( array_key_exists( 'web_research', $source ) ) $row['web_research'] = (bool) $source['web_research'];
            if ( isset( $source['max_sources'] ) ) $row['max_sources'] = max( 2, min( 20, absint( $source['max_sources'] ) ) );
            $current[ $engine ] = $row;
        }
        update_option( self::OPTION, $current, false );
        $this->ensure_schedules( true );
        return $this->status();
    }

    public function ensure_schedules( bool $force = false ): void {
        foreach ( array( 'news', 'article' ) as $engine ) {
            $args = array( $engine );
            if ( $force ) wp_clear_scheduled_hook( self::HOOK, $args );
            $settings = $this->settings();
            if ( empty( $settings[ $engine ]['enabled'] ) ) {
                wp_clear_scheduled_hook( self::HOOK, $args );
                continue;
            }
            if ( wp_next_scheduled( self::HOOK, $args ) ) continue;
            wp_schedule_event( $this->next_timestamp( (string) $settings[ $engine ]['time'] ), 'daily', self::HOOK, $args );
        }
    }

    private function next_timestamp( string $time ): int {
        try {
            $tz = function_exists( 'wp_timezone' ) ? wp_timezone() : new DateTimeZone( 'UTC' );
            $now = new DateTimeImmutable( 'now', $tz );
            $target = new DateTimeImmutable( $now->format( 'Y-m-d' ) . ' ' . $time . ':00', $tz );
            if ( $target <= $now ) $target = $target->modify( '+1 day' );
            return $target->getTimestamp();
        } catch ( Throwable $e ) {
            return time() + HOUR_IN_SECONDS;
        }
    }

    /** @return array<string,mixed> */
    public function status(): array {
        $settings = $this->settings();
        $profile = $this->business_profile();
        $ai_providers = array();
        foreach ( $this->ai->providers() as $provider ) {
            if ( 'connected' === (string) ( $provider['status'] ?? '' ) ) $ai_providers[] = $provider;
        }
        $github = $this->connections->get( 'github', false );
        $rows = array();
        foreach ( array( 'news', 'article' ) as $engine ) {
            $cfg = $settings[ $engine ];
            $runner = $this->resolve_runner( $engine, $cfg );
            $rows[ $engine ] = array(
                'key' => $engine,
                'enabled' => (bool) $cfg['enabled'],
                'time' => (string) $cfg['time'],
                'runner' => $runner,
                'provider' => $this->resolve_provider( $cfg ),
                'workflow' => $this->resolve_workflow( $engine, $cfg ),
                'next_run' => wp_next_scheduled( self::HOOK, array( $engine ) ) ?: null,
                'ready' => 'github' === $runner ? $this->github_ready( $engine, $cfg ) : ! empty( $ai_providers ),
                'queue_backend' => K20AI_Security::action_scheduler_available() ? 'action-scheduler' : 'wp-cron',
                'post_type' => 'news' === $engine ? $this->resolve_news_post_type( (string) $cfg['post_type'] ) : (string) $cfg['post_type'],
                'status' => (string) $cfg['status'],
            );
        }
        return array(
            'settings' => $settings,
            'profile' => $profile,
            'engines' => $rows,
            'ai_providers' => $ai_providers,
            'github' => array( 'status' => $github['status'] ?? 'disconnected', 'repository' => $github['config']['repository'] ?? '', 'discovery' => $github['meta']['discovery'] ?? array() ),
            'runs' => $this->recent_runs( 30 ),
        );
    }

    /** @return array<string,mixed> */
    public function business_profile(): array {
        $categories = array();
        $products = array();
        if ( taxonomy_exists( 'product_cat' ) ) {
            $terms = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => true, 'number' => 20, 'orderby' => 'count', 'order' => 'DESC' ) );
            if ( ! is_wp_error( $terms ) ) foreach ( $terms as $term ) $categories[] = array( 'id' => (int) $term->term_id, 'name' => (string) $term->name, 'count' => (int) $term->count );
        }
        if ( function_exists( 'wc_get_products' ) ) {
            $items = wc_get_products( array( 'status' => array( 'publish' ), 'limit' => 20, 'orderby' => 'date', 'order' => 'DESC' ) );
            foreach ( $items as $product ) {
                if ( is_object( $product ) && method_exists( $product, 'get_name' ) ) $products[] = sanitize_text_field( (string) $product->get_name() );
            }
        }
        $post_categories = array();
        $terms = get_terms( array( 'taxonomy' => 'category', 'hide_empty' => true, 'number' => 20, 'orderby' => 'count', 'order' => 'DESC' ) );
        if ( ! is_wp_error( $terms ) ) foreach ( $terms as $term ) $post_categories[] = array( 'id' => (int) $term->term_id, 'name' => (string) $term->name, 'count' => (int) $term->count );
        $recent_titles = array();
        foreach ( get_posts( array( 'post_type' => get_post_types( array( 'public' => true ), 'names' ), 'post_status' => 'publish', 'posts_per_page' => 20, 'orderby' => 'date', 'order' => 'DESC', 'no_found_rows' => true ) ) as $post ) {
            if ( 'attachment' === $post->post_type ) continue;
            $recent_titles[] = sanitize_text_field( (string) $post->post_title );
        }
        $text = strtolower( wp_strip_all_tags( implode( ' ', array_merge( array( get_bloginfo( 'name' ), get_bloginfo( 'description' ) ), array_column( $categories, 'name' ), array_column( $post_categories, 'name' ), $products ) ) ) );
        $sensitive = (bool) preg_match( '/pharmacy|medical|health|medicine|drug|clinic|\x{062F}\x{0627}\x{0631}\x{0648}|\x{067E}\x{0632}\x{0634}\x{06A9}|\x{0633}\x{0644}\x{0627}\x{0645}\x{062A}|\x{062F}\x{0627}\x{0631}\x{0648}\x{062E}\x{0627}\x{0646}\x{0647}/iu', $text );
        return array(
            'site_name' => get_bloginfo( 'name' ),
            'tagline' => get_bloginfo( 'description' ),
            'url' => home_url(),
            'locale' => determine_locale(),
            'product_categories' => $categories,
            'post_categories' => $post_categories,
            'sample_products' => array_slice( array_values( array_unique( $products ) ), 0, 15 ),
            'recent_content' => array_slice( array_values( array_unique( $recent_titles ) ), 0, 15 ),
            'sensitive_domain' => $sensitive,
            'human_review_required' => $sensitive,
        );
    }

    public function connection_ready( string $provider, array $result = array() ): void {
        $settings = $this->settings();
        if ( empty( $settings['auto_enable_on_ready'] ) ) return;
        if ( 'github' === $provider ) {
            foreach ( array( 'news', 'article' ) as $engine ) {
                if ( $this->github_ready( $engine, $settings[ $engine ] ) ) $settings[ $engine ]['enabled'] = true;
            }
        } elseif ( in_array( $provider, array( 'openai', 'gemini', 'anthropic', 'deepseek', 'custom_ai' ), true ) ) {
            foreach ( array( 'news', 'article' ) as $engine ) if ( 'github' !== $settings[ $engine ]['runner'] ) $settings[ $engine ]['enabled'] = true;
        }
        update_option( self::OPTION, $settings, false );
        $this->ensure_schedules( true );
    }

    public function cron_tick( string $engine ): void {
        $engine = sanitize_key( $engine );
        if ( ! in_array( $engine, array( 'news', 'article' ), true ) ) return;
        $settings = $this->settings();
        if ( empty( $settings[ $engine ]['enabled'] ) ) return;
        if ( K20AI_Security::action_scheduler_available() ) {
            K20AI_Security::enqueue_unique_action( self::RUN_HOOK, array( $engine, 'schedule' ) );
            return;
        }
        $this->run( $engine, 'schedule' );
    }

    public function queued_run( string $engine, string $trigger = 'schedule' ): void {
        $this->run( sanitize_key( $engine ), sanitize_key( $trigger ) ?: 'schedule' );
    }

    public function reconcile_upgrade( string $previous_version ): void {
        if ( version_compare( $previous_version, '3.0.4', '>=' ) ) return;
        // Preserve explicit operator choice. Reconcile only when an older build never
        // created the engine option at all.
        if ( false !== get_option( self::OPTION, false ) ) {
            $this->ensure_schedules( true );
            return;
        }
        $settings = $this->settings();
        $connected_ai = false;
        foreach ( $this->ai->providers() as $provider ) {
            if ( 'connected' === (string) ( $provider['status'] ?? '' ) ) { $connected_ai = true; break; }
        }
        $github_ready = false;
        foreach ( array( 'news', 'article' ) as $engine ) {
            if ( $this->github_ready( $engine, $settings[ $engine ] ) ) { $github_ready = true; break; }
        }
        if ( ! empty( $settings['auto_enable_on_ready'] ) && ( $connected_ai || $github_ready ) ) {
            foreach ( array( 'news', 'article' ) as $engine ) $settings[ $engine ]['enabled'] = true;
        }
        update_option( self::OPTION, $settings, false );
        update_option( 'k20ai_content_engine_upgrade_receipt_v304', array(
            'from' => $previous_version,
            'enabled' => array( 'news' => (bool) $settings['news']['enabled'], 'article' => (bool) $settings['article']['enabled'] ),
            'reason' => ( $connected_ai || $github_ready ) ? 'existing_ready_connection' : 'no_ready_provider_preserved_disabled',
            'at' => gmdate( DATE_ATOM ),
        ), false );
        $this->ensure_schedules( true );
    }

    /** @return array<string,mixed>|WP_Error */
    public function run( string $engine, string $trigger = 'manual' ): array|WP_Error {
        $engine = sanitize_key( $engine );
        if ( ! in_array( $engine, array( 'news', 'article' ), true ) ) return new WP_Error( 'invalid_engine', __( 'Unknown content engine.', 'k20-ai-press' ), array( 'status' => 400 ) );
        if ( ! $this->acquire_engine_lock( $engine ) ) return new WP_Error( 'engine_run_in_progress', __( 'اجرای همین موتور هنوز فعال است؛ اجرای موازی تکراری متوقف شد.', 'k20-ai-press' ), array( 'status' => 409 ) );
        $settings = $this->settings();
        $cfg = $settings[ $engine ];
        $runner = $this->resolve_runner( $engine, $cfg );
        $run_id = $this->start_run( $engine, $runner, $trigger );
        try {
            if ( 'github' === $runner ) {
                $result = $this->run_github( $engine, $cfg, $run_id );
            } else {
                $result = $this->run_local( $engine, $cfg );
            }
            if ( is_wp_error( $result ) ) {
                $this->finish_run( $run_id, 'failed', array(), $result->get_error_message() );
                return $result;
            }
            $this->finish_run( $run_id, (string) ( $result['status'] ?? 'completed' ), $result, null );
            $result['run_id'] = $run_id;
            return $result;
        } catch ( Throwable $e ) {
            $this->finish_run( $run_id, 'failed', array(), $e->getMessage() );
            return new WP_Error( 'engine_exception', $e->getMessage(), array( 'status' => 500 ) );
        } finally {
            $this->release_engine_lock( $engine );
        }
    }

    private function acquire_engine_lock( string $engine ): bool {
        $key = 'k20ai_engine_run_lock_' . sanitize_key( $engine );
        $now = time();
        if ( add_option( $key, $now, '', false ) ) return true;
        $existing = (int) get_option( $key, 0 );
        if ( $existing > 0 && ( $now - $existing ) > 1800 ) {
            delete_option( $key );
            return (bool) add_option( $key, $now, '', false );
        }
        return false;
    }

    private function release_engine_lock( string $engine ): void {
        delete_option( 'k20ai_engine_run_lock_' . sanitize_key( $engine ) );
    }

    /** @return array<string,mixed>|WP_Error */
    private function run_github( string $engine, array $cfg, int $run_id ): array|WP_Error {
        if ( ! $this->github_ready( $engine, $cfg ) ) return new WP_Error( 'github_engine_not_ready', __( 'GitHub is connected but the selected engine workflow is not configured.', 'k20-ai-press' ), array( 'status' => 409 ) );
        $workflow = $this->resolve_workflow( $engine, $cfg );
        $profile = $this->business_profile();
        $inputs = array(
            'engine' => $engine,
            'site_url' => home_url(),
            'site_name' => get_bloginfo( 'name' ),
            'site_locale' => determine_locale(),
            'business_context' => substr( wp_json_encode( array( 'product_categories' => array_column( $profile['product_categories'], 'name' ), 'post_categories' => array_column( $profile['post_categories'], 'name' ), 'sample_products' => $profile['sample_products'] ), JSON_UNESCAPED_UNICODE ), 0, 900 ),
            'lookback_hours' => (string) absint( $cfg['lookback_hours'] ),
            'draft_only' => 'true',
            'k20_run_id' => (string) $run_id,
            'k20_receipt_url' => rest_url( 'k20-ai/v3/content-engines/receipt' ),
            'k20_contract' => '3.0.4',
        );
        $result = $this->connections->github_dispatch_workflow( $workflow, $inputs );
        if ( is_wp_error( $result ) ) return $result;
        return array_merge( array( 'status' => 'dispatched', 'engine' => $engine, 'runner' => 'github' ), $result );
    }

    /** @return array<string,mixed>|WP_Error */
    private function run_local( string $engine, array $cfg ): array|WP_Error {
        $provider = $this->resolve_provider( $cfg );
        if ( '' === $provider ) return new WP_Error( 'ai_provider_required', __( 'A tested AI provider is required for the local content engine.', 'k20-ai-press' ), array( 'status' => 409 ) );
        $profile = $this->business_profile();
        $radar = $this->seo->refresh_market_radar();
        $context = $this->research_context( $engine, $cfg );
        if ( 'news' === $engine && empty( $context['signals'] ) && ( 'openai' !== $provider || empty( $cfg['web_research'] ) ) ) {
            return new WP_Error( 'news_sources_required', __( 'No live news source is available. Add trusted RSS feeds or use an OpenAI connection with Web Search enabled.', 'k20-ai-press' ), array( 'status' => 409 ) );
        }

        $schema = $this->output_schema();
        $system = $this->system_prompt( $engine, $profile );
        $prompt = $this->engine_prompt( $engine, $profile, $context, $cfg );
        $generated = $this->connections->ai_generate( $provider, array(
            'system' => $system,
            'prompt' => $prompt,
            'web_search' => ! empty( $cfg['web_research'] ),
            'schema' => $schema,
        ) );
        if ( is_wp_error( $generated ) ) return $generated;
        $data = isset( $generated['data'] ) && is_array( $generated['data'] ) ? $generated['data'] : array();
        $sources = isset( $generated['sources'] ) && is_array( $generated['sources'] ) ? $generated['sources'] : array();
        if ( empty( $sources ) ) $sources = (array) $context['sources'];
        $normalized = $this->normalize_generated( $engine, $data, $sources, $profile );
        if ( is_wp_error( $normalized ) ) return $normalized;
        $post = $this->create_draft( $engine, $normalized, $cfg, $provider );
        if ( is_wp_error( $post ) ) return $post;
        return array(
            'status' => 'completed',
            'engine' => $engine,
            'runner' => 'local',
            'provider' => $provider,
            'post_id' => (int) $post['post_id'],
            'post_type' => (string) $post['post_type'],
            'edit_url' => (string) $post['edit_url'],
            'title' => (string) $normalized['title'],
            'sources' => $sources,
            'source_count' => count( $sources ),
            'radar_refresh' => $radar,
            'human_review_required' => true,
        );
    }

    /** @return array<string,mixed> */
    private function research_context( string $engine, array $cfg ): array {
        global $wpdb;
        $t = K20AI_Database::tables();
        $hours = max( 1, absint( $cfg['lookback_hours'] ) );
        $since = gmdate( 'Y-m-d H:i:s', time() - $hours * HOUR_IN_SECONDS );
        $signals = $wpdb->get_results( $wpdb->prepare( "SELECT source,signal_type,subject,source_url,score,observed_at FROM {$t['seo_signals']} WHERE observed_at >= %s ORDER BY score DESC,observed_at DESC LIMIT %d", $since, max( 5, absint( $cfg['max_sources'] ) * 3 ) ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $keywords = $wpdb->get_results( "SELECT phrase,target_url,current_position,impressions,clicks,ctr,source,checked_at FROM {$t['seo_keywords']} ORDER BY COALESCE(impressions,0) DESC,checked_at DESC LIMIT 30", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $sources = array();
        foreach ( (array) $signals as $signal ) {
            if ( empty( $signal['source_url'] ) ) continue;
            $sources[] = array( 'url' => esc_url_raw( (string) $signal['source_url'] ), 'title' => sanitize_text_field( (string) $signal['subject'] ), 'source' => sanitize_key( (string) $signal['source'] ) );
        }
        return array( 'signals' => array_slice( (array) $signals, 0, 30 ), 'keywords' => (array) $keywords, 'sources' => array_slice( $sources, 0, absint( $cfg['max_sources'] ) ) );
    }

    /** @return array<string,mixed> */
    private function output_schema(): array {
        $nullable = array( 'type' => array( 'string', 'null' ) );
        return array(
            'type' => 'object',
            'properties' => array(
                'title' => array( 'type' => 'string' ),
                'slug' => $nullable,
                'excerpt' => array( 'type' => 'string' ),
                'content_html' => array( 'type' => 'string' ),
                'seo_title' => $nullable,
                'meta_description' => $nullable,
                'focus_keyphrase' => $nullable,
                'category_id' => array( 'type' => array( 'integer', 'null' ) ),
                'tags' => array( 'type' => 'array', 'items' => array( 'type' => 'string' ) ),
                'source_urls' => array( 'type' => 'array', 'items' => array( 'type' => 'string' ) ),
                'source_names' => array( 'type' => 'array', 'items' => array( 'type' => 'string' ) ),
                'selection_reason' => array( 'type' => 'string' ),
                'fact_check_notes' => array( 'type' => 'string' ),
                'image_search_query' => $nullable,
            ),
            'required' => array( 'title', 'excerpt', 'content_html', 'tags', 'source_urls', 'source_names', 'selection_reason', 'fact_check_notes' ),
            'additionalProperties' => false,
        );
    }

    private function system_prompt( string $engine, array $profile ): string {
        $type = 'news' === $engine ? 'news research and draft engine' : 'evergreen article research and draft engine';
        return implode( "\n", array(
            'You are a business-aware ' . $type . ' embedded in a commercial WordPress SEO/content operating system.',
            'Return one valid JSON object only, matching the supplied schema. Do not return Markdown fences.',
            'Infer the business domain only from the supplied site profile. Never assume agriculture, cosmetics, pharmacy, or another vertical unless the site data supports it.',
            'Use fresh, trustworthy sources when web research is available. Prefer primary/official sources and cross-check important claims.',
            'Do not invent prices, stock, medical claims, legal claims, statistics, certifications, product specifications, or quotations.',
            'Generated content must be useful, specific, people-first, non-spammy, and naturally connected to the business audience.',
            'The output is always a draft requiring human review. Sensitive health/medical/legal/financial topics require explicit human review and conservative wording.',
            'Only choose category_id from the supplied allowed category IDs. Otherwise return null.',
            'Include source URLs used for factual claims. If a claim cannot be sourced, omit it.',
            'Site locale: ' . determine_locale(),
        ) );
    }

    private function engine_prompt( string $engine, array $profile, array $context, array $cfg ): string {
        $allowed_categories = 'news' === $engine ? $profile['post_categories'] : $profile['post_categories'];
        $task = 'news' === $engine
            ? 'Find the most relevant genuinely recent development for this business and prepare one concise but complete news draft. Avoid duplicating recent site content.'
            : 'Choose one high-value evergreen topic that solves a real customer problem, fills a search/content gap, and naturally supports the site business. Avoid duplicating recent site content.';
        return $task . "\n" .
            'Business profile JSON: ' . wp_json_encode( $profile, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . "\n" .
            'Allowed categories JSON: ' . wp_json_encode( $allowed_categories, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . "\n" .
            'Recent sourced signals JSON: ' . wp_json_encode( array_slice( (array) $context['signals'], 0, 20 ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . "\n" .
            'Search/query evidence JSON: ' . wp_json_encode( array_slice( (array) $context['keywords'], 0, 20 ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . "\n" .
            'Research lookback hours: ' . absint( $cfg['lookback_hours'] ) . ".\n" .
            'Draft only. Use clean semantic HTML for content_html. Do not include script/style tags.';
    }

    /** @return array<string,mixed>|WP_Error */
    private function normalize_generated( string $engine, array $data, array $sources, array $profile ): array|WP_Error {
        $title = $this->clean_text( (string) ( $data['title'] ?? '' ) );
        $content = $this->clean_html( (string) ( $data['content_html'] ?? '' ) );
        $excerpt = $this->clean_textarea( (string) ( $data['excerpt'] ?? '' ) );
        if ( '' === $title || '' === trim( wp_strip_all_tags( $content ) ) || '' === $excerpt ) return new WP_Error( 'engine_output_incomplete', __( 'AI output is missing title, excerpt, or content.', 'k20-ai-press' ), array( 'status' => 422 ) );
        $source_urls = array();
        foreach ( (array) ( $data['source_urls'] ?? array() ) as $url ) {
            $url = esc_url_raw( (string) $url );
            if ( $url && wp_http_validate_url( $url ) ) $source_urls[] = $url;
        }
        foreach ( $sources as $source ) {
            $url = esc_url_raw( (string) ( is_array( $source ) ? ( $source['url'] ?? '' ) : '' ) );
            if ( $url && wp_http_validate_url( $url ) ) $source_urls[] = $url;
        }
        $source_urls = array_values( array_unique( $source_urls ) );
        if ( 'news' === $engine && empty( $source_urls ) ) return new WP_Error( 'news_output_unsourced', __( 'News draft has no verifiable source URL.', 'k20-ai-press' ), array( 'status' => 422 ) );
        $allowed_categories = array_map( 'intval', array_column( (array) $profile['post_categories'], 'id' ) );
        $category_id = absint( $data['category_id'] ?? 0 );
        if ( $category_id && ! in_array( $category_id, $allowed_categories, true ) ) $category_id = 0;
        $tags = array_values( array_filter( array_unique( array_map( array( $this, 'clean_text' ), array_slice( (array) ( $data['tags'] ?? array() ), 0, 12 ) ) ) ) );
        return array(
            'title' => $title,
            'slug' => sanitize_title( (string) ( $data['slug'] ?? $title ) ),
            'excerpt' => $excerpt,
            'content_html' => $content,
            'seo_title' => $this->clean_text( (string) ( $data['seo_title'] ?? '' ) ),
            'meta_description' => $this->clean_textarea( (string) ( $data['meta_description'] ?? '' ) ),
            'focus_keyphrase' => $this->clean_text( (string) ( $data['focus_keyphrase'] ?? '' ) ),
            'category_id' => $category_id,
            'tags' => $tags,
            'source_urls' => $source_urls,
            'source_names' => array_values( array_filter( array_map( array( $this, 'clean_text' ), array_slice( (array) ( $data['source_names'] ?? array() ), 0, 20 ) ) ) ),
            'selection_reason' => $this->clean_textarea( (string) ( $data['selection_reason'] ?? '' ) ),
            'fact_check_notes' => $this->clean_textarea( (string) ( $data['fact_check_notes'] ?? '' ) ),
            'image_search_query' => $this->clean_text( (string) ( $data['image_search_query'] ?? '' ) ),
        );
    }

    /** @return array<string,mixed>|WP_Error */
    private function create_draft( string $engine, array $data, array $cfg, string $provider ): array|WP_Error {
        $post_type = 'news' === $engine ? $this->resolve_news_post_type( (string) $cfg['post_type'] ) : ( post_type_exists( (string) $cfg['post_type'] ) ? (string) $cfg['post_type'] : 'post' );
        if ( ! post_type_exists( $post_type ) ) $post_type = 'post';
        $slug = sanitize_title( (string) $data['slug'] );
        if ( $slug && get_page_by_path( $slug, OBJECT, $post_type ) ) return new WP_Error( 'duplicate_engine_slug', __( 'A post with the generated slug already exists.', 'k20-ai-press' ), array( 'status' => 409 ) );
        $postarr = array(
            'post_type' => $post_type,
            'post_status' => in_array( $cfg['status'], array( 'draft', 'pending' ), true ) ? $cfg['status'] : 'draft',
            'post_title' => (string) $data['title'],
            'post_name' => $slug,
            'post_excerpt' => (string) $data['excerpt'],
            'post_content' => (string) $data['content_html'],
            'post_author' => get_current_user_id() ?: 1,
        );
        if ( 'post' === $post_type && ! empty( $data['category_id'] ) ) $postarr['post_category'] = array( absint( $data['category_id'] ) );
        $post_id = wp_insert_post( wp_slash( $postarr ), true );
        if ( is_wp_error( $post_id ) ) return $post_id;
        if ( taxonomy_exists( 'post_tag' ) && $data['tags'] ) wp_set_post_terms( $post_id, $data['tags'], 'post_tag', false );
        update_post_meta( $post_id, '_k20ai_engine', $engine );
        update_post_meta( $post_id, '_k20ai_engine_provider', $provider );
        update_post_meta( $post_id, '_k20ai_engine_sources', wp_json_encode( $data['source_urls'], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) );
        update_post_meta( $post_id, '_k20ai_engine_selection_reason', $data['selection_reason'] );
        update_post_meta( $post_id, '_k20ai_engine_fact_check_notes', $data['fact_check_notes'] );
        update_post_meta( $post_id, '_k20ai_review_status', 'human_review_required_before_publish' );
        if ( $data['seo_title'] ) update_post_meta( $post_id, '_yoast_wpseo_title', $data['seo_title'] );
        if ( $data['meta_description'] ) update_post_meta( $post_id, '_yoast_wpseo_metadesc', $data['meta_description'] );
        if ( $data['focus_keyphrase'] ) update_post_meta( $post_id, '_yoast_wpseo_focuskw', $data['focus_keyphrase'] );
        return array( 'post_id' => (int) $post_id, 'post_type' => $post_type, 'edit_url' => get_edit_post_link( $post_id, 'raw' ) ?: '' );
    }

    private function resolve_news_post_type( string $configured ): string {
        if ( 'auto' !== $configured && post_type_exists( $configured ) ) return $configured;
        foreach ( array( 'news', 'press', 'article_news' ) as $candidate ) if ( post_type_exists( $candidate ) ) return $candidate;
        $objects = get_post_types( array( 'public' => true ), 'objects' );
        foreach ( $objects as $object ) {
            $label = strtolower( wp_strip_all_tags( (string) ( $object->labels->name ?? '' ) ) );
            if ( str_contains( $label, 'news' ) ) return (string) $object->name;
        }
        return 'post';
    }

    private function resolve_runner( string $engine, array $cfg ): string {
        $runner = (string) ( $cfg['runner'] ?? 'auto' );
        if ( 'auto' === $runner ) return $this->github_ready( $engine, $cfg ) ? 'github' : 'local';
        return in_array( $runner, array( 'local', 'github' ), true ) ? $runner : 'local';
    }

    private function resolve_provider( array $cfg ): string {
        $configured = sanitize_key( (string) ( $cfg['provider'] ?? 'auto' ) );
        $providers = $this->ai->providers();
        if ( 'auto' !== $configured && '' !== $configured ) {
            foreach ( $providers as $row ) if ( $configured === (string) $row['key'] && 'connected' === (string) $row['status'] ) return $configured;
            return '';
        }
        foreach ( array( 'openai', 'gemini', 'anthropic', 'deepseek', 'custom_ai' ) as $preferred ) {
            foreach ( $providers as $row ) if ( $preferred === (string) $row['key'] && 'connected' === (string) $row['status'] ) return $preferred;
        }
        return '';
    }

    private function github_ready( string $engine, array $cfg ): bool {
        $github = $this->connections->get( 'github', false );
        return 'connected' === (string) ( $github['status'] ?? '' ) && '' !== $this->resolve_workflow( $engine, $cfg );
    }

    private function resolve_workflow( string $engine, array $cfg ): string {
        if ( ! empty( $cfg['workflow'] ) ) return sanitize_text_field( (string) $cfg['workflow'] );
        $github = $this->connections->get( 'github', false );
        $key = 'news' === $engine ? 'news_workflow' : 'article_workflow';
        $configured = sanitize_text_field( (string) ( $github['config'][ $key ] ?? '' ) );
        if ( '' !== $configured ) return $configured;

        // A successful GitHub connection test stores workflow discovery. Use it
        // to make the two content engines work without forcing buyers to copy a
        // workflow filename by hand. Explicit engine/provider settings always
        // win; discovery is only a safe fallback.
        $discovery = isset( $github['meta']['discovery'] ) && is_array( $github['meta']['discovery'] ) ? $github['meta']['discovery'] : array();
        $workflows = isset( $discovery['workflows'] ) && is_array( $discovery['workflows'] ) ? $discovery['workflows'] : array();
        $best = '';
        $best_score = 0;
        foreach ( $workflows as $workflow ) {
            if ( ! is_array( $workflow ) ) continue;
            $path = sanitize_text_field( (string) ( $workflow['path'] ?? '' ) );
            $name = sanitize_text_field( (string) ( $workflow['name'] ?? '' ) );
            $state = sanitize_key( (string) ( $workflow['state'] ?? '' ) );
            if ( '' === $path ) continue;
            $haystack = strtolower( $path . ' ' . $name );
            if ( ! str_contains( $haystack, $engine ) ) continue;
            $score = 0;
            if ( str_contains( $haystack, 'content-' . $engine ) || str_contains( $haystack, $engine . '-content' ) || str_contains( $haystack, 'k20ai-' . $engine ) || str_contains( $haystack, 'universal-' . $engine ) ) $score += 100;
            if ( str_contains( $haystack, 'queue-publisher' ) || str_contains( $haystack, 'publisher' ) ) $score += 40;
            if ( str_contains( $haystack, 'daily' ) ) $score += 15;
            if ( 'active' === $state ) $score += 10;
            foreach ( array( 'preview', 'selftest', 'test', 'smoke', 'diagnostic', 'audit' ) as $negative ) {
                if ( str_contains( $haystack, $negative ) ) $score -= 100;
            }
            if ( $score > $best_score ) {
                $best_score = $score;
                $best = $path;
            }
        }
        return $best_score >= 80 ? $best : '';
    }

    private function start_run( string $engine, string $runner, string $trigger ): int {
        global $wpdb;
        $t = K20AI_Database::tables();
        $wpdb->insert( $t['engine_runs'], array( 'engine' => $engine, 'runner' => $runner, 'status' => 'running', 'trigger_type' => sanitize_key( $trigger ), 'started_at' => current_time( 'mysql', true ), 'created_at' => current_time( 'mysql', true ) ) );
        return (int) $wpdb->insert_id;
    }

    private function finish_run( int $run_id, string $status, array $result, ?string $error ): void {
        global $wpdb;
        $t = K20AI_Database::tables();
        $sources = isset( $result['sources'] ) && is_array( $result['sources'] ) ? $result['sources'] : array();
        $wpdb->update( $t['engine_runs'], array(
            'status' => sanitize_key( $status ),
            'provider' => sanitize_key( (string) ( $result['provider'] ?? '' ) ),
            'topic' => sanitize_text_field( (string) ( $result['title'] ?? '' ) ),
            'post_id' => ! empty( $result['post_id'] ) ? absint( $result['post_id'] ) : null,
            'source_count' => count( $sources ),
            'sources' => wp_json_encode( $sources, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ),
            'result' => wp_json_encode( $result, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ),
            'error' => $error ? sanitize_textarea_field( $error ) : null,
            'finished_at' => current_time( 'mysql', true ),
        ), array( 'id' => $run_id ) );
    }

    /** @return array<int,array<string,mixed>> */
    public function recent_runs( int $limit = 30 ): array {
        global $wpdb;
        $t = K20AI_Database::tables();
        $limit = max( 1, min( 100, $limit ) );
        $rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t['engine_runs']} ORDER BY id DESC LIMIT %d", $limit ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        foreach ( $rows as &$row ) {
            $row['sources'] = $this->decode_json( $row['sources'] ?? null );
            $row['result'] = $this->decode_json( $row['result'] ?? null );
        }
        unset( $row );
        return $rows;
    }


    /** @return array<string,mixed>|WP_Error */
    public function record_remote_receipt( array $input ): array|WP_Error {
        global $wpdb;
        $t = K20AI_Database::tables();
        $run_id = absint( $input['run_id'] ?? $input['k20_run_id'] ?? 0 );
        if ( ! $run_id ) return new WP_Error( 'engine_receipt_run_id', __( 'A valid run_id is required.', 'k20-ai-press' ), array( 'status' => 400 ) );
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT id,engine,runner,status FROM {$t['engine_runs']} WHERE id=%d", $run_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        if ( ! $row || 'github' !== (string) ( $row['runner'] ?? '' ) ) return new WP_Error( 'engine_receipt_run_missing', __( 'GitHub engine run was not found.', 'k20-ai-press' ), array( 'status' => 404 ) );

        $engine = sanitize_key( (string) ( $input['engine'] ?? $row['engine'] ?? '' ) );
        if ( $engine !== (string) $row['engine'] || ! in_array( $engine, array( 'news', 'article' ), true ) ) return new WP_Error( 'engine_receipt_engine', __( 'Receipt engine does not match the dispatched run.', 'k20-ai-press' ), array( 'status' => 409 ) );
        $status = sanitize_key( (string) ( $input['status'] ?? 'completed' ) );
        if ( ! in_array( $status, array( 'completed', 'failed' ), true ) ) return new WP_Error( 'engine_receipt_status', __( 'Receipt status must be completed or failed.', 'k20-ai-press' ), array( 'status' => 400 ) );

        $sources = array();
        foreach ( array_slice( (array) ( $input['sources'] ?? array() ), 0, 20 ) as $source ) {
            if ( is_string( $source ) ) $source = array( 'url' => $source );
            if ( ! is_array( $source ) ) continue;
            $url = esc_url_raw( (string) ( $source['url'] ?? '' ) );
            if ( ! $url || ! wp_http_validate_url( $url ) ) continue;
            $sources[] = array(
                'url' => $url,
                'title' => sanitize_text_field( (string) ( $source['title'] ?? '' ) ),
                'source' => sanitize_text_field( (string) ( $source['source'] ?? '' ) ),
            );
        }
        $post_id = absint( $input['post_id'] ?? 0 );
        if ( $post_id && ! get_post( $post_id ) ) return new WP_Error( 'engine_receipt_post_missing', __( 'Receipt post_id does not exist on this site.', 'k20-ai-press' ), array( 'status' => 409 ) );
        $result = array(
            'status' => $status,
            'engine' => $engine,
            'runner' => 'github',
            'provider' => sanitize_key( (string) ( $input['provider'] ?? 'github' ) ),
            'title' => sanitize_text_field( (string) ( $input['title'] ?? '' ) ),
            'post_id' => $post_id ?: null,
            'edit_url' => $post_id ? ( get_edit_post_link( $post_id, 'raw' ) ?: '' ) : '',
            'sources' => $sources,
            'source_count' => count( $sources ),
            'workflow_run_id' => absint( $input['workflow_run_id'] ?? 0 ) ?: null,
            'repository' => sanitize_text_field( (string) ( $input['repository'] ?? '' ) ),
            'workflow' => sanitize_text_field( (string) ( $input['workflow'] ?? '' ) ),
            'selection_reason' => $this->clean_textarea( (string) ( $input['selection_reason'] ?? '' ) ),
            'fact_check_notes' => $this->clean_textarea( (string) ( $input['fact_check_notes'] ?? '' ) ),
            'human_review_required' => true,
        );
        $error = 'failed' === $status ? $this->clean_textarea( (string) ( $input['error'] ?? 'Remote workflow failed.' ) ) : null;
        $this->finish_run( $run_id, $status, $result, $error );
        return array( 'run_id' => $run_id, 'status' => $status, 'recorded' => true, 'post_id' => $post_id ?: null, 'source_count' => count( $sources ) );
    }

    /** @return array<string,mixed> */
    private function decode_json( $value ): array {
        $decoded = is_string( $value ) ? json_decode( $value, true ) : null;
        return is_array( $decoded ) ? $decoded : array();
    }

    private function clean_text( string $value ): string {
        return sanitize_text_field( $this->strip_hidden( $value ) );
    }

    private function clean_textarea( string $value ): string {
        return sanitize_textarea_field( $this->strip_hidden( $value ) );
    }

    private function clean_html( string $value ): string {
        $value = $this->strip_hidden( $value );
        $value = preg_replace( '#<(script|style|iframe|object|embed)[^>]*>.*?</\\1>#is', '', $value );
        return wp_kses_post( (string) $value );
    }

    private function strip_hidden( string $value ): string {
        $value = preg_replace( '/[\x{200B}\x{200D}-\x{200F}\x{202A}-\x{202E}\x{2060}-\x{206F}\x{FEFF}\x{E0000}-\x{E007F}]/u', '', $value );
        return is_string( $value ) ? $value : '';
    }
}
