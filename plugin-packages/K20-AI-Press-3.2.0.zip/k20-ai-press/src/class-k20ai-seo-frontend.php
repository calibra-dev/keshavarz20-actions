<?php

defined( 'ABSPATH' ) || exit;

/**
 * Conservative storefront output for SEO fields managed by K20 AI Press.
 * It stays out of the way when a mature SEO plugin already owns the output.
 */
final class K20AI_SEO_Frontend {
    private K20AI_SEO_OS $seo;

    public function __construct( K20AI_SEO_OS $seo ) {
        $this->seo = $seo;
    }

    public function register(): void {
        add_filter( 'pre_get_document_title', array( $this, 'document_title' ), 50 );
        add_action( 'wp_head', array( $this, 'head_meta' ), 6 );
        add_filter( 'wp_robots', array( $this, 'robots' ), 50 );
    }

    public function document_title( string $title ): string {
        if ( is_admin() || ! is_singular() || $this->external_seo_owner() ) return $title;
        $id = get_queried_object_id();
        if ( ! $id ) return $title;
        $custom = trim( (string) get_post_meta( $id, '_k20ai_title', true ) );
        return '' !== $custom ? $custom : $title;
    }

    public function head_meta(): void {
        if ( is_admin() || ! is_singular() || $this->external_seo_owner() ) return;
        $id = get_queried_object_id();
        if ( ! $id ) return;
        $description = trim( (string) get_post_meta( $id, '_k20ai_description', true ) );
        $canonical   = trim( (string) get_post_meta( $id, '_k20ai_canonical', true ) );
        if ( $description ) echo "\n<meta name=\"description\" content=\"" . esc_attr( $description ) . "\">\n";
        if ( $canonical ) echo '<link rel="canonical" href="' . esc_url( $canonical ) . '">' . "\n";

        $settings = $this->seo->settings();
        if ( empty( $settings['schema_output_enabled'] ) ) return;
        $post = get_post( $id );
        if ( ! $post ) return;
        // WooCommerce core already owns Product structured data. Never emit a second Product graph.
        if ( 'product' === $post->post_type && class_exists( 'WC_Structured_Data' ) ) return;
        $kind = 'product' === $post->post_type ? 'product' : ( 'page' === $post->post_type ? 'page' : ( str_contains( $post->post_type, 'news' ) ? 'news' : 'content_post' ) );
        $detail = $this->seo->entity_detail( $kind, $id );
        if ( empty( $detail['schema'] ) ) return;
        echo '<script type="application/ld+json" class="k20ai-schema">' . wp_json_encode( $detail['schema'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . '</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
    }

    /** @param array<string,bool> $robots @return array<string,bool> */
    public function robots( array $robots ): array {
        if ( is_admin() || ! is_singular() ) return $robots;
        $id = get_queried_object_id();
        if ( ! $id ) return $robots;
        $noindex = get_post_meta( $id, '_k20ai_noindex', true );
        if ( '1' === (string) $noindex ) {
            $robots['noindex'] = true;
            unset( $robots['index'] );
        }
        return $robots;
    }

    private function external_seo_owner(): bool {
        return defined( 'WPSEO_VERSION' )
            || defined( 'RANK_MATH_VERSION' )
            || defined( 'AIOSEO_VERSION' )
            || defined( 'SEOPRESS_VERSION' )
            || defined( 'SLIM_SEO_VERSION' )
            || class_exists( 'The_SEO_Framework\\Load' );
    }
}
