<?php

defined( 'ABSPATH' ) || exit;

trait K20AI_Advanced_Intelligence_Trait {
    public function bot_registry(): array {
        $builtins = array(
            array( 'id' => 'openai-search', 'provider' => 'OpenAI', 'category' => 'SEARCH', 'patterns' => array( 'OAI-SearchBot' ), 'robots_tokens' => array( 'OAI-SearchBot' ), 'dns_suffixes' => array(), 'ip_ranges_url' => 'https://openai.com/searchbot.json' ),
            array( 'id' => 'openai-user', 'provider' => 'OpenAI', 'category' => 'USER_TRIGGERED', 'patterns' => array( 'ChatGPT-User' ), 'robots_tokens' => array(), 'dns_suffixes' => array(), 'ip_ranges_url' => 'https://openai.com/chatgpt-user.json' ),
            array( 'id' => 'openai-ads', 'provider' => 'OpenAI', 'category' => 'ANALYTICS', 'patterns' => array( 'OAI-AdsBot' ), 'robots_tokens' => array(), 'dns_suffixes' => array(), 'ip_ranges_url' => 'https://openai.com/adsbot.json' ),
            array( 'id' => 'openai-training', 'provider' => 'OpenAI', 'category' => 'TRAINING', 'patterns' => array( 'GPTBot' ), 'robots_tokens' => array( 'GPTBot' ), 'dns_suffixes' => array(), 'ip_ranges_url' => 'https://openai.com/gptbot.json' ),
            array( 'id' => 'google-search', 'provider' => 'Google', 'category' => 'SEARCH', 'patterns' => array( 'Googlebot', 'Googlebot-Image', 'Googlebot-Video', 'Googlebot-News', 'Storebot-Google', 'Google-InspectionTool' ), 'robots_tokens' => array( 'Googlebot', 'Googlebot-Image', 'Googlebot-Video', 'Googlebot-News', 'Storebot-Google', 'Google-InspectionTool' ), 'dns_suffixes' => array( '.googlebot.com', '.google.com' ) ),
            array( 'id' => 'google-other', 'provider' => 'Google', 'category' => 'UNKNOWN', 'patterns' => array( 'GoogleOther', 'GoogleOther-Image', 'GoogleOther-Video' ), 'robots_tokens' => array( 'GoogleOther', 'GoogleOther-Image', 'GoogleOther-Video' ), 'dns_suffixes' => array( '.googlebot.com', '.google.com' ) ),
            array( 'id' => 'google-cloud-vertex', 'provider' => 'Google', 'category' => 'USER_TRIGGERED', 'patterns' => array( 'Google-CloudVertexBot' ), 'robots_tokens' => array( 'Google-CloudVertexBot' ), 'dns_suffixes' => array( '.googlebot.com', '.google.com' ) ),
            array( 'id' => 'google-extended', 'provider' => 'Google', 'category' => 'TRAINING', 'patterns' => array(), 'robots_tokens' => array( 'Google-Extended' ), 'dns_suffixes' => array() ),
            array( 'id' => 'anthropic', 'provider' => 'Anthropic', 'category' => 'ASSISTANT', 'patterns' => array( 'ClaudeBot', 'Claude-User', 'Claude-SearchBot' ), 'dns_suffixes' => array() ),
            array( 'id' => 'perplexity', 'provider' => 'Perplexity', 'category' => 'ASSISTANT', 'patterns' => array( 'PerplexityBot', 'Perplexity-User' ), 'dns_suffixes' => array() ),
            array( 'id' => 'bing', 'provider' => 'Microsoft', 'category' => 'SEARCH', 'patterns' => array( 'bingbot', 'BingPreview' ), 'dns_suffixes' => array( '.search.msn.com' ) ),
            array( 'id' => 'apple', 'provider' => 'Apple', 'category' => 'SEARCH', 'patterns' => array( 'Applebot', 'Applebot-Extended' ), 'dns_suffixes' => array( '.applebot.apple.com' ) ),
            array( 'id' => 'meta', 'provider' => 'Meta', 'category' => 'TRAINING', 'patterns' => array( 'Meta-ExternalAgent', 'FacebookBot' ), 'dns_suffixes' => array() ),
            array( 'id' => 'meta-fetcher', 'provider' => 'Meta', 'category' => 'USER_TRIGGERED', 'patterns' => array( 'Meta-ExternalFetcher' ), 'robots_tokens' => array(), 'dns_suffixes' => array() ),
            array( 'id' => 'facebook-externalhit', 'provider' => 'Meta', 'category' => 'USER_TRIGGERED', 'patterns' => array( 'facebookexternalhit' ), 'robots_tokens' => array(), 'dns_suffixes' => array() ),
            array( 'id' => 'xai', 'provider' => 'xAI', 'category' => 'ASSISTANT', 'patterns' => array( 'Grok', 'xAI' ), 'dns_suffixes' => array() ),
            array( 'id' => 'commoncrawl', 'provider' => 'Common Crawl', 'category' => 'TRAINING', 'patterns' => array( 'CCBot' ), 'robots_tokens' => array( 'CCBot' ), 'dns_suffixes' => array() ),
            array( 'id' => 'duckduckgo', 'provider' => 'DuckDuckGo', 'category' => 'SEARCH', 'patterns' => array( 'DuckDuckBot' ), 'dns_suffixes' => array( '.duckduckgo.com' ) ),
            array( 'id' => 'duckassist', 'provider' => 'DuckDuckGo', 'category' => 'ASSISTANT', 'patterns' => array( 'DuckAssistBot' ), 'robots_tokens' => array(), 'dns_suffixes' => array() ),
            array( 'id' => 'youbot', 'provider' => 'You.com', 'category' => 'ASSISTANT', 'patterns' => array( 'YouBot' ), 'dns_suffixes' => array() ),
            array( 'id' => 'bytespider', 'provider' => 'ByteDance', 'category' => 'TRAINING', 'patterns' => array( 'Bytespider' ), 'dns_suffixes' => array() ),
            array( 'id' => 'tiktok-spider', 'provider' => 'ByteDance', 'category' => 'UNKNOWN', 'patterns' => array( 'TikTokSpider' ), 'robots_tokens' => array(), 'dns_suffixes' => array() ),
            array( 'id' => 'diffbot', 'provider' => 'Diffbot', 'category' => 'ANALYTICS', 'patterns' => array( 'Diffbot' ), 'dns_suffixes' => array() ),
            array( 'id' => 'dataforseo', 'provider' => 'DataForSEO', 'category' => 'ANALYTICS', 'patterns' => array( 'DataForSeoBot' ), 'robots_tokens' => array(), 'dns_suffixes' => array() ),
            array( 'id' => 'amazon', 'provider' => 'Amazon', 'category' => 'SEARCH', 'patterns' => array( 'Amazonbot' ), 'dns_suffixes' => array() ),
            array( 'id' => 'deepseek', 'provider' => 'DeepSeek', 'category' => 'ASSISTANT', 'patterns' => array( 'DeepSeekBot' ), 'dns_suffixes' => array() ),
            array( 'id' => 'alibaba-qwen', 'provider' => 'Alibaba/Qwen', 'category' => 'ASSISTANT', 'patterns' => array(), 'dns_suffixes' => array() ),
            array( 'id' => 'mistral', 'provider' => 'Mistral', 'category' => 'ASSISTANT', 'patterns' => array(), 'dns_suffixes' => array() ),
            array( 'id' => 'cohere', 'provider' => 'Cohere', 'category' => 'ASSISTANT', 'patterns' => array(), 'dns_suffixes' => array() ),
            array( 'id' => 'cohere-training', 'provider' => 'Cohere', 'category' => 'TRAINING', 'patterns' => array( 'cohere-training-data-crawler' ), 'robots_tokens' => array(), 'dns_suffixes' => array() ),
            array( 'id' => 'huggingface', 'provider' => 'HuggingFace', 'category' => 'TRAINING', 'patterns' => array(), 'dns_suffixes' => array() ),
            array( 'id' => 'petalbot', 'provider' => 'Petal Search', 'category' => 'SEARCH', 'patterns' => array( 'PetalBot' ), 'robots_tokens' => array(), 'dns_suffixes' => array() ),
            array( 'id' => 'ai2bot', 'provider' => 'AllenAI', 'category' => 'TRAINING', 'patterns' => array( 'AI2Bot' ), 'robots_tokens' => array(), 'dns_suffixes' => array() ),
        );
        $custom = get_option( 'k20ai_bot_registry_custom', array() );
        if ( is_array( $custom ) ) {
            $by_id = array();
            foreach ( $builtins as $entry ) { $by_id[ $entry['id'] ] = $entry; }
            foreach ( $custom as $entry ) {
                if ( is_array( $entry ) && ! empty( $entry['id'] ) ) { $by_id[ $entry['id'] ] = $entry; }
            }
            $builtins = array_values( $by_id );
        }
        foreach ( $builtins as &$entry ) { $entry['registry_version'] = '2026-10-03'; $entry['robots_tokens'] = array_values( (array) ( $entry['robots_tokens'] ?? $entry['patterns'] ?? array() ) ); $entry['ip_ranges_url'] = $entry['ip_ranges_url'] ?? null; }
        unset( $entry );
        return apply_filters( 'k20ai_bot_registry', $builtins );
    }

    public function bot_registry_info(): array {
        $entries = $this->bot_registry();
        $pattern_count = 0;
        foreach ( $entries as $entry ) { $pattern_count += count( (array) ( $entry['patterns'] ?? array() ) ); }
        return array( 'version' => '2026-10-03', 'entries' => $entries, 'families' => count( $entries ), 'user_agent_patterns' => $pattern_count, 'robots_tokens' => array_sum( array_map( static fn( $entry ) => count( (array) ( $entry['robots_tokens'] ?? array() ) ), $entries ) ), 'rule' => 'User-Agent alone is never verification.' );
    }

    public function save_bot_registry( array $entries ): array|WP_Error {
        $allowed_categories = array( 'SEARCH','TRAINING','USER_TRIGGERED','ASSISTANT','ANALYTICS','UNKNOWN' );
        $clean = array();
        foreach ( array_slice( $entries, 0, 200 ) as $entry ) {
            if ( ! is_array( $entry ) ) { continue; }
            $id = sanitize_key( (string) ( $entry['id'] ?? '' ) );
            $provider = sanitize_text_field( (string) ( $entry['provider'] ?? '' ) );
            $category = strtoupper( sanitize_key( (string) ( $entry['category'] ?? 'UNKNOWN' ) ) );
            if ( ! $id || ! $provider || ! in_array( $category, $allowed_categories, true ) ) { continue; }
            $patterns = array_values( array_filter( array_map( 'sanitize_text_field', (array) ( $entry['patterns'] ?? array() ) ) ) );
            $suffixes = array();
            foreach ( (array) ( $entry['dns_suffixes'] ?? array() ) as $suffix ) {
                $suffix = strtolower( trim( sanitize_text_field( (string) $suffix ) ) );
                if ( '' !== $suffix && preg_match( '/^\.[a-z0-9.-]+$/', $suffix ) ) { $suffixes[] = $suffix; }
            }
            $robots_tokens = array_values( array_filter( array_map( 'sanitize_text_field', (array) ( $entry['robots_tokens'] ?? $patterns ) ) ) );
            $range_url = esc_url_raw( (string) ( $entry['ip_ranges_url'] ?? '' ), array( 'https' ) );
            $range_host = $range_url ? strtolower( (string) wp_parse_url( $range_url, PHP_URL_HOST ) ) : '';
            if ( $range_url && ! in_array( $range_host, array( 'openai.com', 'www.openai.com', 'developers.google.com' ), true ) ) { $range_url = ''; }
            $clean[] = array( 'id'=>$id, 'provider'=>$provider, 'category'=>$category, 'patterns'=>array_slice( $patterns, 0, 20 ), 'robots_tokens'=>array_slice( $robots_tokens, 0, 20 ), 'dns_suffixes'=>array_values( array_unique( $suffixes ) ), 'ip_ranges_url'=>$range_url ?: null );
        }
        update_option( 'k20ai_bot_registry_custom', $clean, false );
        return $this->bot_registry_info();
    }

    public function bot_policy(): array {
        $defaults = array(
            'preset'           => 'BALANCED',
            'SEARCH_ALLOWED'   => true,
            'TRAINING_ALLOWED' => false,
            'USER_FETCH_ALLOWED' => true,
            'API_ALLOWED'      => false,
            'overrides'        => array(),
        );
        $saved = get_option( 'k20ai_bot_policy', array() );
        $policy = wp_parse_args( is_array( $saved ) ? $saved : array(), $defaults );
        $policy['overrides'] = is_array( $policy['overrides'] ?? null ) ? $policy['overrides'] : array();
        return $policy;
    }

    public function save_bot_policy( array $input ): array {
        $policy = $this->bot_policy();
        $allowed_presets = array( 'MAXIMUM_VISIBILITY', 'BALANCED', 'SEARCH_ALLOWED_TRAINING_BLOCKED', 'PRIVATE', 'CUSTOM' );
        if ( isset( $input['preset'] ) && in_array( $input['preset'], $allowed_presets, true ) ) {
            $policy['preset'] = $input['preset'];
        }
        foreach ( array( 'SEARCH_ALLOWED', 'TRAINING_ALLOWED', 'USER_FETCH_ALLOWED', 'API_ALLOWED' ) as $key ) {
            if ( array_key_exists( $key, $input ) ) {
                $policy[ $key ] = (bool) $input[ $key ];
            }
        }
        if ( isset( $input['overrides'] ) && is_array( $input['overrides'] ) ) {
            $valid_ids = array_fill_keys( array_map( static fn( array $entry ): string => (string) $entry['id'], $this->bot_registry() ), true );
            $clean_overrides = ! empty( $input['reset_overrides'] ) ? array() : (array) ( $policy['overrides'] ?? array() );
            foreach ( $input['overrides'] as $id => $allowed ) {
                $id = sanitize_key( (string) $id );
                if ( isset( $valid_ids[ $id ] ) ) {
                    $clean_overrides[ $id ] = (bool) $allowed;
                }
            }
            $policy['overrides'] = $clean_overrides;
            $policy['preset'] = 'CUSTOM';
        }
        update_option( 'k20ai_bot_policy', $policy, false );
        return $policy;
    }

    public function bot_entry_allowed( array $entry, ?array $policy = null ): bool {
        $policy = is_array( $policy ) ? $policy : $this->bot_policy();
        $id = (string) ( $entry['id'] ?? '' );
        if ( $id && array_key_exists( $id, (array) ( $policy['overrides'] ?? array() ) ) ) {
            return (bool) $policy['overrides'][ $id ];
        }
        return match ( strtoupper( (string) ( $entry['category'] ?? 'UNKNOWN' ) ) ) {
            'SEARCH'         => ! empty( $policy['SEARCH_ALLOWED'] ),
            'TRAINING'       => ! empty( $policy['TRAINING_ALLOWED'] ),
            'USER_TRIGGERED', 'ASSISTANT' => ! empty( $policy['USER_FETCH_ALLOWED'] ),
            'ANALYTICS'      => ! empty( $policy['API_ALLOWED'] ),
            default          => false,
        };
    }

    public function bot_control_center(): array {
        $policy = $this->bot_policy();
        $entries = array();
        foreach ( $this->bot_registry() as $entry ) {
            $tokens = array_values( array_filter( array_map( 'trim', (array) ( $entry['robots_tokens'] ?? array() ) ) ) );
            $patterns = array_values( array_filter( array_map( 'trim', (array) ( $entry['patterns'] ?? array() ) ) ) );
            $entries[] = array_merge(
                $entry,
                array(
                    'allowed'      => $this->bot_entry_allowed( $entry, $policy ),
                    'controllable' => ! empty( $tokens ),
                    'monitorable'  => ! empty( $patterns ),
                    'display_name' => $tokens[0] ?? ( $patterns[0] ?? (string) ( $entry['provider'] ?? $entry['id'] ?? 'Bot' ) ),
                    'token_count'  => count( $tokens ),
                )
            );
        }
        return array(
            'policy' => $policy,
            'entries' => $entries,
            'families' => count( $entries ),
            'controllable' => count( array_filter( $entries, static fn( array $entry ): bool => ! empty( $entry['controllable'] ) ) ),
            'monitorable' => count( array_filter( $entries, static fn( array $entry ): bool => ! empty( $entry['monitorable'] ) ) ),
        );
    }

    public function classify_bot( string $user_agent ): array {
        foreach ( $this->bot_registry() as $bot ) {
            foreach ( (array) $bot['patterns'] as $pattern ) {
                if ( '' !== $pattern && false !== stripos( $user_agent, $pattern ) ) {
                    return array(
                        'claimed_bot' => $bot['id'],
                        'provider'    => $bot['provider'],
                        'category'    => $bot['category'],
                        'verified'    => false,
                        'verification_method' => 'user-agent-only',
                    );
                }
            }
        }
        return array( 'claimed_bot' => null, 'provider' => null, 'category' => 'UNKNOWN', 'verified' => false, 'verification_method' => 'none' );
    }

    public function verify_bot_ip( string $user_agent, string $ip ): array|WP_Error {
        $classification = $this->classify_bot( $user_agent );
        if ( empty( $classification['claimed_bot'] ) ) {
            return new WP_Error( 'bot_unknown', __( 'User-Agent با Bot Registry تطبیق ندارد.', 'k20-ai-press' ), array( 'status' => 422 ) );
        }
        $bot = null;
        foreach ( $this->bot_registry() as $candidate ) {
            if ( $candidate['id'] === $classification['claimed_bot'] ) {
                $bot = $candidate;
                break;
            }
        }
        if ( ! $bot ) {
            return new WP_Error( 'bot_registry_error', __( 'Bot Registry entry پیدا نشد.', 'k20-ai-press' ), array( 'status' => 500 ) );
        }
        if ( ! filter_var( $ip, FILTER_VALIDATE_IP ) ) {
            return new WP_Error( 'invalid_ip', __( 'IP معتبر نیست.', 'k20-ai-press' ), array( 'status' => 422 ) );
        }
        if ( ! empty( $bot['ip_ranges_url'] ) ) {
            $range_check = $this->verify_ip_from_published_ranges( $ip, (string) $bot['ip_ranges_url'] );
            if ( true === $range_check ) {
                $classification['verified'] = true;
                $classification['verified_bot'] = $classification['claimed_bot'];
                $classification['verification_method'] = 'published-ip-range';
                return $classification;
            }
            if ( false === $range_check ) {
                $classification['verification_method'] = 'published-ip-range-mismatch';
                return $classification;
            }
        }
        if ( empty( $bot['dns_suffixes'] ) ) {
            $classification['verification_method'] = 'no-authoritative-verification-rule';
            return $classification;
        }
        $host = @gethostbyaddr( $ip ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
        if ( ! is_string( $host ) || $host === $ip ) {
            $classification['verification_method'] = 'reverse-dns-failed';
            return $classification;
        }
        $suffix_ok = false;
        foreach ( $bot['dns_suffixes'] as $suffix ) {
            if ( str_ends_with( strtolower( rtrim( $host, '.' ) ), strtolower( $suffix ) ) ) {
                $suffix_ok = true;
                break;
            }
        }
        if ( ! $suffix_ok ) {
            $classification['verification_method'] = 'reverse-dns-mismatch';
            return $classification;
        }
        $forward = @gethostbynamel( $host ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
        $classification['verified'] = is_array( $forward ) && in_array( $ip, $forward, true );
        $classification['verified_bot'] = $classification['verified'] ? $classification['claimed_bot'] : null;
        $classification['verification_method'] = 'forward-confirmed-reverse-dns';
        $classification['hostname'] = $host;
        return $classification;
    }

    private function verify_ip_from_published_ranges( string $ip, string $url ): ?bool {
        if ( ! function_exists( 'wp_safe_remote_get' ) ) { return null; }
        $host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
        if ( ! in_array( $host, array( 'openai.com', 'www.openai.com', 'developers.google.com' ), true ) ) { return null; }
        $cache_key = 'k20ai_ipranges_' . md5( $url );
        $data = get_transient( $cache_key );
        if ( ! is_array( $data ) ) {
            $response = wp_safe_remote_get( $url, array( 'timeout' => 5, 'redirection' => 0, 'headers' => array( 'Accept' => 'application/json' ) ) );
            if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) { return null; }
            $decoded = json_decode( (string) wp_remote_retrieve_body( $response ), true );
            if ( ! is_array( $decoded ) ) { return null; }
            $data = $decoded;
            set_transient( $cache_key, $data, 6 * HOUR_IN_SECONDS );
        }
        $prefixes = array();
        foreach ( (array) ( $data['prefixes'] ?? array() ) as $row ) {
            if ( ! is_array( $row ) ) { continue; }
            foreach ( array( 'ipv4Prefix', 'ipv6Prefix' ) as $key ) {
                if ( ! empty( $row[ $key ] ) ) { $prefixes[] = (string) $row[ $key ]; }
            }
        }
        if ( empty( $prefixes ) ) { return null; }
        foreach ( $prefixes as $cidr ) { if ( $this->ip_in_cidr( $ip, $cidr ) ) { return true; } }
        return false;
    }

    private function ip_in_cidr( string $ip, string $cidr ): bool {
        if ( ! str_contains( $cidr, '/' ) ) { return $ip === $cidr; }
        [ $network, $bits_raw ] = explode( '/', $cidr, 2 );
        $ip_bin = @inet_pton( $ip ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
        $net_bin = @inet_pton( $network ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
        if ( false === $ip_bin || false === $net_bin || strlen( $ip_bin ) !== strlen( $net_bin ) ) { return false; }
        $bits = (int) $bits_raw;
        $max = 8 * strlen( $ip_bin );
        if ( $bits < 0 || $bits > $max ) { return false; }
        $bytes = intdiv( $bits, 8 );
        $remainder = $bits % 8;
        if ( $bytes && substr( $ip_bin, 0, $bytes ) !== substr( $net_bin, 0, $bytes ) ) { return false; }
        if ( 0 === $remainder ) { return true; }
        $mask = ( 0xFF << ( 8 - $remainder ) ) & 0xFF;
        return ( ord( $ip_bin[ $bytes ] ) & $mask ) === ( ord( $net_bin[ $bytes ] ) & $mask );
    }

    public function log_bot_visit( array $request = array() ): void {
        global $wpdb;
        $ua = substr( sanitize_text_field( (string) ( $request['user_agent'] ?? ( $_SERVER['HTTP_USER_AGENT'] ?? '' ) ) ), 0, 500 );
        $classification = $this->classify_bot( $ua );
        if ( 'UNKNOWN' === $classification['category'] ) {
            return;
        }
        $t = K20AI_Database::tables();
        $ip = sanitize_text_field( (string) ( $request['ip'] ?? ( $_SERVER['REMOTE_ADDR'] ?? '' ) ) );
        $policy = $this->bot_policy();
        $policy_map = array( 'SEARCH'=>'SEARCH_ALLOWED', 'TRAINING'=>'TRAINING_ALLOWED', 'USER_TRIGGERED'=>'USER_FETCH_ALLOWED', 'ASSISTANT'=>'USER_FETCH_ALLOWED', 'ANALYTICS'=>'API_ALLOWED' );
        $allowed_key = $policy_map[ $classification['category'] ] ?? 'API_ALLOWED';
        $allowed = isset( $policy[ $allowed_key ] ) ? (bool) $policy[ $allowed_key ] : false;
        $verified = $classification;
        if ( $ip && filter_var( $ip, FILTER_VALIDATE_IP ) ) {
            $attempt = $this->verify_bot_ip( $ua, $ip );
            if ( ! is_wp_error( $attempt ) ) { $verified = $attempt; }
        }
        $wpdb->insert(
            $t['bot_visits'],
            array(
                'claimed_bot'        => $classification['claimed_bot'],
                'verified_bot'       => $verified['verified_bot'] ?? null,
                'provider'           => $classification['provider'],
                'user_agent'         => $ua,
                'ip_hash'            => $ip ? hash_hmac( 'sha256', $ip, wp_salt( 'auth' ) ) : null,
                'verification_method'=> $verified['verification_method'] ?? 'user-agent-only',
                'url'                => esc_url_raw( (string) ( $request['url'] ?? home_url( wp_unslash( $_SERVER['REQUEST_URI'] ?? '/' ) ) ) ),
                'http_status'        => null,
                'response_time_ms'   => null,
                'allowed'            => $allowed ? 1 : 0,
                'blocked_reason'     => $allowed ? null : 'policy',
                'created_at'         => current_time( 'mysql', true ),
            )
        );
    }

    public function brand_truth(): array {
        $site_name = sanitize_text_field( (string) get_bloginfo( 'name' ) );
        if ( '' === $site_name ) { $site_name = (string) ( wp_parse_url( home_url(), PHP_URL_HOST ) ?: 'WordPress' ); }
        $defaults = array(
            'name_fa' => $site_name,
            'name_en' => $site_name,
            'legal_name' => '',
            'domain' => wp_parse_url( home_url(), PHP_URL_HOST ),
            'logo' => '',
            'phone' => '',
            'email' => '',
            'address' => '',
            'social_profiles' => array(),
            'expertise' => array(),
            'seller_identity' => '',
            'return_policy' => '',
            'shipping_policy' => '',
            'authenticity_policy' => '',
            'warranty_policy' => '',
            'support_hours' => '',
            'official_descriptions' => array(),
            'historical_aliases' => array(),
        );
        $saved = get_option( 'k20ai_brand_truth', array() );
        return wp_parse_args( is_array( $saved ) ? $saved : array(), $defaults );
    }

    public function save_brand_truth( array $input ): array {
        $truth = $this->brand_truth();
        $scalar = array( 'name_fa','name_en','legal_name','domain','logo','phone','email','address','seller_identity','return_policy','shipping_policy','authenticity_policy','warranty_policy','support_hours' );
        foreach ( $scalar as $key ) {
            if ( array_key_exists( $key, $input ) ) {
                $truth[ $key ] = 'email' === $key ? sanitize_email( (string) $input[ $key ] ) : sanitize_textarea_field( (string) $input[ $key ] );
            }
        }
        foreach ( array( 'social_profiles','expertise','official_descriptions','historical_aliases' ) as $key ) {
            if ( isset( $input[ $key ] ) && is_array( $input[ $key ] ) ) {
                $truth[ $key ] = array_values( array_filter( array_map( 'sanitize_text_field', $input[ $key ] ) ) );
            }
        }
        update_option( 'k20ai_brand_truth', $truth, false );
        return $truth;
    }

    public function schema_preview( int $product_id ): array|WP_Error {
        if ( ! function_exists( 'wc_get_product' ) ) {
            return new WP_Error( 'woocommerce_missing', __( 'WooCommerce در دسترس نیست.', 'k20-ai-press' ), array( 'status' => 503 ) );
        }
        $p = wc_get_product( $product_id );
        if ( ! $p ) {
            return new WP_Error( 'product_not_found', __( 'محصول پیدا نشد.', 'k20-ai-press' ), array( 'status' => 404 ) );
        }
        $schema = array(
            '@context' => 'https://schema.org',
            '@type' => 'Product',
            '@id' => get_permalink( $product_id ) . '#product',
            'name' => $p->get_name(),
            'url' => get_permalink( $product_id ),
            'sku' => $p->get_sku() ?: null,
            'image' => array_values( array_filter( array_map( 'wp_get_attachment_url', array_merge( array( $p->get_image_id() ), $p->get_gallery_image_ids() ) ) ) ),
        );
        if ( '' !== (string) $p->get_price() ) {
            $schema['offers'] = array(
                '@type' => 'Offer',
                'price' => $p->get_price(),
                'priceCurrency' => function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : null,
                'availability' => 'instock' === $p->get_stock_status() ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock',
                'url' => get_permalink( $product_id ),
            );
        }
        return array_filter( $schema, static fn( $v ) => null !== $v && array() !== $v );
    }

    public function schema_validate( int $product_id ): array|WP_Error {
        $schema = $this->schema_preview( $product_id );
        if ( is_wp_error( $schema ) ) {
            return $schema;
        }
        $errors = array();
        foreach ( array( '@type','name','url' ) as $required ) {
            if ( empty( $schema[ $required ] ) ) {
                $errors[] = 'missing:' . $required;
            }
        }
        if ( isset( $schema['offers'] ) ) {
            foreach ( array( 'price','priceCurrency','availability' ) as $field ) {
                if ( empty( $schema['offers'][ $field ] ) && 'price' !== $field ) {
                    $errors[] = 'offers_missing:' . $field;
                }
            }
        }
        return array( 'valid' => empty( $errors ), 'errors' => $errors, 'schema' => $schema, 'note' => 'این Validator Product Truth/WooCommerce parity را می‌سنجد؛ Rich Results گوگل باید جداگانه بررسی شود.' );
    }

    public function citation_pack( string $url ): array|WP_Error {
        $post_id = url_to_postid( $url );
        if ( ! $post_id || 'publish' !== get_post_status( $post_id ) ) {
            return new WP_Error( 'url_not_found', __( 'URL به محتوای عمومی و منتشرشده قابل شناسایی نگاشت نشد.', 'k20-ai-press' ), array( 'status' => 404 ) );
        }
        global $wpdb;
        $t = K20AI_Database::tables();
        $claims = $wpdb->get_results( $wpdb->prepare( "SELECT id,subject,predicate,value,unit,confidence,status,verified_at FROM {$t['claims']} WHERE subject=%s AND status='VERIFIED' ORDER BY confidence DESC,id DESC LIMIT 30", 'post:' . $post_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $claims = is_array( $claims ) ? $claims : array();
        $evidence = array();
        if ( $claims ) {
            $ids = array_values( array_filter( array_map( 'absint', wp_list_pluck( $claims, 'id' ) ) ) );
            if ( $ids ) {
                $placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
                // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                $sql = $wpdb->prepare( "SELECT id,claim_id,title,source_url,source_type,confidence,status,verified_at,valid_until FROM {$t['evidence']} WHERE claim_id IN ($placeholders) AND status IN ('VERIFIED','MANUFACTURER_VERIFIED','SITE_VERIFIED','SUPPLIER_VERIFIED','USER_CONFIRMED') ORDER BY confidence DESC,id DESC LIMIT 100", ...$ids );
                // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
                $evidence = $wpdb->get_results( $sql, ARRAY_A );
                $evidence = is_array( $evidence ) ? $evidence : array();
            }
        }
        $faq = array();
        $raw_faq = get_post_meta( $post_id, '_k20ai_faq', true );
        $faq = is_array( $raw_faq ) ? $raw_faq : array();
        $sources = array();
        foreach ( $evidence as $ev ) {
            if ( ! empty( $ev['source_url'] ) ) {
                $sources[] = array(
                    'title' => (string) ( $ev['title'] ?? '' ),
                    'url' => esc_url_raw( (string) $ev['source_url'] ),
                    'type' => (string) ( $ev['source_type'] ?? '' ),
                    'verified_at' => $ev['verified_at'] ?? null,
                    'valid_until' => $ev['valid_until'] ?? null,
                );
            }
        }
        return array(
            'canonical_url' => get_permalink( $post_id ),
            'entity' => get_the_title( $post_id ),
            'direct_answer' => null,
            'verified_facts' => $claims,
            'technical_specs' => 'product' === get_post_type( $post_id ) ? $this->schema_preview( $post_id ) : array(),
            'suitable_for' => array(),
            'not_suitable_for' => array(),
            'compatibility' => array(),
            'evidence' => $evidence,
            'FAQ' => $faq,
            'author' => (int) get_post_field( 'post_author', $post_id ),
            'reviewer' => get_post_meta( $post_id, '_k20ai_reviewer', true ) ?: null,
            'dateModified' => get_post_modified_time( DATE_ATOM, true, $post_id ),
            'sources' => $sources,
            'related_products' => array(),
            'related_guides' => array(),
        );
    }

    public function rag_index( string $scope = 'all', int $limit = 100 ): array {
        global $wpdb;
        $t = K20AI_Database::tables();
        $post_types = 'products' === $scope ? array( 'product' ) : array( 'post', 'page', 'product' );
        $posts = get_posts( array( 'post_type' => $post_types, 'post_status' => 'publish', 'posts_per_page' => max( 1, min( 500, $limit ) ), 'orderby' => 'modified', 'order' => 'DESC' ) );
        $indexed = 0;
        foreach ( $posts as $post ) {
            $plain = $this->normalize_persian( wp_strip_all_tags( $post->post_title . "\n" . $post->post_content ) );
            if ( '' === $plain ) {
                continue;
            }
            $chunks = $this->chunk_text( $plain, 1200, 120 );
            foreach ( $chunks as $i => $chunk ) {
                $source_id = 'post:' . $post->ID . ':chunk:' . $i;
                $hash = hash( 'sha256', $chunk );
                $exists = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t['vectors_meta']} WHERE source_id=%s LIMIT 1", $source_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                $row = array(
                    'source_id' => $source_id,
                    'content_type' => $post->post_type,
                    'entity_id' => null,
                    'product_id' => 'product' === $post->post_type ? $post->ID : null,
                    'claim_ids' => null,
                    'freshness' => get_post_modified_time( 'Y-m-d H:i:s', true, $post ),
                    'content_hash' => $hash,
                    'content' => $chunk,
                    'chunk_index' => $i,
                    'token_estimate' => max( 1, (int) ceil( mb_strlen( $chunk ) / 4 ) ),
                    'language' => 'fa',
                    'visibility' => 'public',
                    'evidence_level' => 'unknown',
                    'provider' => 'local-lexical',
                    'embedding_model' => null,
                    'status' => 'INDEXED',
                    'updated_at' => current_time( 'mysql', true ),
                );
                if ( $exists ) {
                    $wpdb->update( $t['vectors_meta'], $row, array( 'id' => $exists ) );
                } else {
                    $wpdb->insert( $t['vectors_meta'], $row );
                }
                ++$indexed;
            }
        }
        return array( 'indexed_chunks' => $indexed, 'scope' => $scope, 'provider' => 'local-lexical', 'semantic_provider' => apply_filters( 'k20ai_semantic_provider_available', false ) ? 'external-filter' : null );
    }

    private function chunk_text( string $text, int $size, int $overlap ): array {
        $len = mb_strlen( $text );
        if ( $len <= $size ) {
            return array( $text );
        }
        $chunks = array();
        $start = 0;
        $step = max( 100, $size - $overlap );
        while ( $start < $len ) {
            $chunk = trim( mb_substr( $text, $start, $size ) );
            if ( '' !== $chunk ) {
                $chunks[] = $chunk;
            }
            $start += $step;
        }
        return $chunks;
    }

    public function rag_search( string $query, int $limit = 8 ): array {
        global $wpdb;
        $t = K20AI_Database::tables();
        $query = $this->normalize_persian( $query );
        $terms = array_values( array_unique( array_filter( preg_split( '/\s+/u', $query ) ?: array(), static fn( $x ) => mb_strlen( $x ) > 1 ) ) );
        if ( ! $terms ) {
            return array();
        }
        $rows = $wpdb->get_results( "SELECT id,source_id,content_type,product_id,content,freshness,evidence_level,updated_at FROM {$t['vectors_meta']} WHERE status='INDEXED' ORDER BY updated_at DESC LIMIT 1000", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $scored = array();
        foreach ( $rows ?: array() as $row ) {
            $content = $this->normalize_persian( (string) $row['content'] );
            $score = 0.0;
            foreach ( $terms as $term ) {
                $count = substr_count( mb_strtolower( $content ), mb_strtolower( $term ) );
                if ( $count ) {
                    $score += 1 + log( 1 + $count );
                }
            }
            if ( $row['product_id'] && preg_match( '/\b' . preg_quote( (string) $row['product_id'], '/' ) . '\b/u', $query ) ) {
                $score += 2.0;
            }
            $score = (float) apply_filters( 'k20ai_rag_score', $score, $query, $row );
            if ( $score > 0 ) {
                $row['score'] = round( $score, 4 );
                $row['excerpt'] = mb_substr( $content, 0, 420 );
                unset( $row['content'] );
                $scored[] = $row;
            }
        }
        usort( $scored, static fn( $a, $b ) => $b['score'] <=> $a['score'] );
        return array_slice( $scored, 0, max( 1, min( 20, $limit ) ) );
    }
}
