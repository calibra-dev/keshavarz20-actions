<?php

defined( 'ABSPATH' ) || exit;

final class K20AI_Services {
    use K20AI_Services_Product_Trait;
    private K20AI_Ability_Registry $registry;
    private K20AI_Advanced $advanced;
    private K20AI_Operations $operations;
    private ?K20AI_Agent_Engine $agent_engine = null;
    private ?K20AI_Product_Intelligence $product_intelligence = null;
    private ?K20AI_AI_Visibility $ai_visibility = null;
    private ?K20AI_Onboarding_Migration $onboarding_migration = null;
    private ?K20AI_Commercial $commercial = null;
    private ?K20AI_Command_Center $command_center = null;

    public function __construct( K20AI_Ability_Registry $registry, K20AI_Advanced $advanced, K20AI_Operations $operations ) {
        $this->registry = $registry;
        $this->advanced = $advanced;
        $this->operations = $operations;
    }

    public function set_platform_modules( K20AI_Agent_Engine $agent_engine, K20AI_Product_Intelligence $product_intelligence, K20AI_AI_Visibility $ai_visibility, K20AI_Onboarding_Migration $onboarding_migration, K20AI_Commercial $commercial, K20AI_Command_Center $command_center ): void {
        $this->agent_engine = $agent_engine;
        $this->product_intelligence = $product_intelligence;
        $this->ai_visibility = $ai_visibility;
        $this->onboarding_migration = $onboarding_migration;
        $this->commercial = $commercial;
        $this->command_center = $command_center;
    }

    private function platform_not_ready(): WP_Error {
        return new WP_Error( 'platform_not_ready', __( 'K20 AI Press platform modules are not ready yet.', 'k20-ai-press' ), array( 'status' => 503 ) );
    }

    public function settings(): array {
        $defaults = array(
            'mode'                 => 'shadow',
            'prompt_log_retention' => 30,
            'ip_retention'         => 7,
            'bot_log_retention'    => 90,
            'provider_log_retention'=> 90,
            'audit_log_retention'  => 365,
            'event_log_retention'  => 90,
            'webhook_log_retention'=> 30,
            'engine_run_retention' => 180,
            'supplier_submission_retention' => 730,
            'agent_run_retention'   => 180,
            'visibility_retention'  => 730,
            'migration_snapshot_retention' => 365,
            'diagnostic_logging_enabled' => false,
            'feature_flags'        => array(),
            'bridge_enabled'       => true,
            'indexnow_reuse'       => true,
            'fail_closed'          => true,
            'mcp_public_readonly'   => true,
            'mcp_authenticated_tools_enabled' => true,
            'bot_logging_enabled'   => true,
            'rag_local_index_enabled'=> true,
            'commerce_feeds_enabled'=> true,
            'visibility_auto_collect' => false,
        );
        $saved = get_option( 'k20ai_settings', array() );
        return wp_parse_args( is_array( $saved ) ? $saved : array(), $defaults );
    }

    public function save_settings( array $input ): array {
        $settings = $this->settings();
        if ( isset( $input['mode'] ) && in_array( $input['mode'], array( 'shadow', 'hybrid', 'primary' ), true ) ) {
            // All mode transitions are approval/readiness gated through mode.promote.
            // The settings endpoint may persist the currently active mode only; it cannot transition modes.
            if ( $input['mode'] !== $settings['mode'] ) {
                unset( $input['mode'] );
            }
        }
        foreach ( array( 'prompt_log_retention', 'ip_retention', 'bot_log_retention', 'provider_log_retention', 'audit_log_retention', 'event_log_retention', 'webhook_log_retention', 'engine_run_retention', 'supplier_submission_retention', 'agent_run_retention', 'visibility_retention', 'migration_snapshot_retention' ) as $key ) {
            if ( isset( $input[ $key ] ) ) {
                $settings[ $key ] = max( 0, min( 3650, absint( $input[ $key ] ) ) );
            }
        }
        foreach ( array( 'bridge_enabled', 'indexnow_reuse', 'fail_closed', 'mcp_public_readonly', 'mcp_authenticated_tools_enabled', 'bot_logging_enabled', 'rag_local_index_enabled', 'commerce_feeds_enabled', 'diagnostic_logging_enabled', 'visibility_auto_collect' ) as $key ) {
            if ( array_key_exists( $key, $input ) ) {
                $settings[ $key ] = (bool) $input[ $key ];
            }
        }
        update_option( 'k20ai_settings', $settings, false );
        $this->audit( 'settings.update', 'settings', 'global', 'OK', array( 'fields' => array_keys( $input ) ) );
        return $settings;
    }

    public function audit_snapshot(): array {
        global $wpdb, $wp_version;
        $settings = $this->settings();
        $checks   = array();
        $checks[] = $this->check( 'WordPress', $wp_version ?? get_bloginfo( 'version' ), version_compare( get_bloginfo( 'version' ), '7.1', '>=' ), 'نسخه وردپرس' );
        $checks[] = $this->check( 'PHP', PHP_VERSION, version_compare( PHP_VERSION, '8.3', '>=' ), 'نسخه PHP' );
        $woo_version = defined( 'WC_VERSION' ) ? (string) WC_VERSION : '';
        $checks[] = $this->check( 'WooCommerce', '' !== $woo_version ? $woo_version : '—', '' !== $woo_version && version_compare( $woo_version, '11.1', '>=' ), 'ووکامرس' );
        $checks[] = $this->check( 'Database', $wpdb->db_version(), true, 'پایگاه‌داده' );
        $using_ext_object_cache = (bool) wp_using_ext_object_cache();
        $checks[] = $this->check( 'Object Cache', $using_ext_object_cache ? 'External' : 'Default', $using_ext_object_cache, 'کش شیء', false );
        $checks[] = $this->check( 'Cron', defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ? 'Disabled' : 'Active', ! ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ), 'کرون' );
        $checks[] = $this->check( 'Action Scheduler', class_exists( 'ActionScheduler' ) ? 'Active' : 'Unavailable', class_exists( 'ActionScheduler' ), 'صف اجرای ووکامرس', false );
        $yoast_core = defined( 'WPSEO_VERSION' ) ? (string) WPSEO_VERSION : '';
        $yoast_premium = defined( 'WPSEO_PREMIUM_VERSION' ) ? (string) WPSEO_PREMIUM_VERSION : '';
        $checks[] = $this->check( 'Yoast SEO', $yoast_core ?: '—', '' !== $yoast_core, 'سئو', false );
        if ( '' !== $yoast_premium ) {
            $aligned = '' === $yoast_core || explode( '.', $yoast_core, 3 )[0] . '.' . ( explode( '.', $yoast_core, 3 )[1] ?? '' ) === explode( '.', $yoast_premium, 3 )[0] . '.' . ( explode( '.', $yoast_premium, 3 )[1] ?? '' );
            $checks[] = $this->check( 'Yoast Premium alignment', $yoast_premium, $aligned, 'هم‌نسخه بودن Yoast Core/Premium', false );
        }
        $checks[] = $this->check( 'Official MCP Adapter', class_exists( '\\WP\\MCP\\Core\\McpAdapter' ) ? 'Active' : 'Unavailable', class_exists( '\\WP\\MCP\\Core\\McpAdapter' ), 'WordPress MCP Adapter', false );
        $checks[] = $this->check( 'Bridge', $settings['bridge_enabled'] ? 'Enabled' : 'Disabled', (bool) $settings['bridge_enabled'], 'Bridge integration', false );
        $checks[] = $this->check( 'IndexNow reuse', $settings['indexnow_reuse'] ? 'Reuse' : 'Off', (bool) $settings['indexnow_reuse'], 'IndexNow', false );
        $checks[] = $this->check( 'REST API', rest_get_url_prefix(), true, 'REST' );
        $checks[] = $this->check( 'SSL', is_ssl() ? 'HTTPS' : 'HTTP', is_ssl(), 'HTTPS', false );
        $checks[] = $this->check( 'Permalinks', (string) get_option( 'permalink_structure', '' ), '' !== get_option( 'permalink_structure', '' ), 'پیوند یکتا', false );

        $conflicts = $this->detect_conflicts();
        return array(
            'mode'      => $settings['mode'],
            'checks'    => $checks,
            'conflicts' => $conflicts,
            'time'      => current_time( 'mysql' ),
            'time_gmt'  => current_time( 'mysql', true ),
        );
    }

    private function check( string $name, mixed $value, mixed $pass, string $label, bool $required = true ): array {
        // WordPress and third-party filters can occasionally return null-ish values.
        // Normalize at this boundary so an environmental quirk cannot fatal the admin UI.
        $passed = (bool) $pass;
        $display_value = is_scalar( $value ) || null === $value ? (string) $value : wp_json_encode( $value );
        return array(
            'name'     => $name,
            'label'    => $label,
            'value'    => false === $display_value ? '' : $display_value,
            'status'   => $passed ? 'PASS' : ( $required ? 'FAIL' : 'WARN' ),
            'required' => $required,
        );
    }

    public function detect_conflicts(): array {
        global $wp_filter;
        $out = array();
        if ( defined( 'WPSEO_VERSION' ) && class_exists( 'RankMath' ) ) {
            $out[] = array( 'severity' => 'high', 'type' => 'schema_overlap', 'message' => 'چند افزونه SEO فعال است؛ مالکیت Schema باید مشخص شود.' );
        }
        if ( class_exists( 'NeuralPress' ) || defined( 'NEURALPRESS_VERSION' ) ) {
            $reviews = get_option( 'k20ai_conflict_reviews', array() );
            $review  = is_array( $reviews ) && isset( $reviews['ai_overlap'] ) && is_array( $reviews['ai_overlap'] ) ? $reviews['ai_overlap'] : array();
            $resolution = (string) ( $review['resolution'] ?? '' );
            $managed = str_starts_with( $resolution, 'managed_primary_coexistence:' );
            $out[] = array(
                'severity'   => $managed ? 'medium' : 'high',
                'type'       => 'ai_overlap',
                'managed'    => $managed,
                'resolution' => $managed ? 'REUSE / ISOLATE' : '',
                'message'    => $managed
                    ? 'هم‌پوشانی افزونه AI با سیاست همزیستی مدیریت شده است؛ افزونه خارجی حفظ می‌شود و قابلیت‌های تکراری این افزونه پشت Gate و تأیید صریح باقی می‌مانند.'
                    : 'افزونه AI دیگری فعال است؛ Hybrid برای همزیستی مجاز است و هنگام ورود به Primary باید مالکیت قابلیت‌های تکراری مدیریت شود.',
            );
        }
        $active_plugins = (array) get_option( 'active_plugins', array() );
        $mcp_overlap = array_values( array_filter( $active_plugins, static function( string $plugin ): bool {
            return in_array( $plugin, array( 'vibe-ai/vibe-ai.php', 'miniorange-secure-mcp-server/miniorange-secure-mcp-server.php', 'keshavarz20-mcp-bridge/keshavarz20-mcp-bridge.php', 'mcp-adapter/mcp-adapter.php' ), true );
        } ) );
        if ( count( $mcp_overlap ) > 1 ) {
            $out[] = array( 'severity' => 'medium', 'type' => 'mcp_overlap', 'plugins' => $mcp_overlap, 'message' => 'چند لایه MCP/AI connector همزمان فعال است؛ یک Adapter canonical انتخاب و سطح دسترسی هر اتصال مستند شود.' );
        }
        if ( defined( 'WPSEO_VERSION' ) && defined( 'WPSEO_PREMIUM_VERSION' ) ) {
            $core_parts = explode( '.', (string) WPSEO_VERSION );
            $premium_parts = explode( '.', (string) WPSEO_PREMIUM_VERSION );
            if ( ( $core_parts[0] ?? '' ) . '.' . ( $core_parts[1] ?? '' ) !== ( $premium_parts[0] ?? '' ) . '.' . ( $premium_parts[1] ?? '' ) ) {
                $out[] = array( 'severity' => 'medium', 'type' => 'yoast_version_mismatch', 'message' => 'نسخه Yoast SEO و Yoast SEO Premium در یک release family نیستند؛ برای کاهش ریسک integration بهتر است هم‌نسخه شوند.' );
            }
        }
        if ( isset( $wp_filter['rest_api_init'] ) && count( $wp_filter['rest_api_init']->callbacks ?? array() ) > 30 ) {
            $out[] = array( 'severity' => 'low', 'type' => 'rest_density', 'message' => 'تعداد زیادی REST registration وجود دارد؛ collision scan توصیه می‌شود.' );
        }
        return $out;
    }

    /** @return array<string,mixed> */
    public function dashboard(): array {
        $audit = $this->audit_snapshot();
        $t     = K20AI_Database::tables();
        global $wpdb;

        $evidence_counts = $this->status_counts( $t['claims'], 'status' );
        $jobs            = $this->status_counts( $t['jobs'], 'status' );
        $products        = $this->product_summary();
        $citations       = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t['citations']} WHERE cited = 1" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $recent_audit    = $wpdb->get_results( "SELECT action_name,result,created_at FROM {$t['audit_log']} ORDER BY id DESC LIMIT 6", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $feed_health     = $this->advanced->feed_health();
        $visibility      = $this->advanced->visibility_summary( 30 );
        $visibility_series = $this->advanced->visibility_series( 30 );
        $evidence_workspace = $this->evidence_workspace_snapshot();
        $bot_control = $this->advanced->bot_control_center();

        $metrics = array(
            array( 'key' => 'technical', 'label' => 'Technical Readiness', 'value' => $this->pass_percent( $audit['checks'] ), 'icon' => 'pulse' ),
            array( 'key' => 'truth', 'label' => 'Product Truth', 'value' => $products['score'], 'icon' => 'cube' ),
            array( 'key' => 'evidence', 'label' => 'Evidence Quality', 'value' => $this->ratio_or_null( (int) ( $evidence_counts['VERIFIED'] ?? 0 ), array_sum( $evidence_counts ) ), 'icon' => 'shield' ),
            array( 'key' => 'compat', 'label' => 'Compatibility', 'value' => $this->compatibility_score(), 'icon' => 'link' ),
            array( 'key' => 'rag', 'label' => 'RAG Health', 'value' => $this->rag_score(), 'icon' => 'database' ),
            array( 'key' => 'commerce', 'label' => 'Commerce Readiness', 'value' => $this->commerce_score( $feed_health ), 'icon' => 'cart' ),
            array( 'key' => 'reliability', 'label' => 'Reliability', 'value' => $this->reliability_score( $jobs ), 'icon' => 'heart' ),
            array( 'key' => 'security', 'label' => 'Security', 'value' => $this->security_score(), 'icon' => 'lock' ),
        );

        return array(
            'site'            => home_url(),
            'mode'            => $this->settings()['mode'],
            'metrics'         => $metrics,
            'audit'           => $audit,
            'products'        => $products,
            'evidence_counts' => $evidence_counts,
            'jobs'            => $jobs,
            'actual_citation' => $citations,
            'visibility'      => $visibility,
            'visibility_series'=> $visibility_series,
            'feed_health'     => $feed_health,
            'recent_audit'    => $recent_audit,
            'evidence_workspace' => $evidence_workspace,
            'bot_control'     => $bot_control,
            'robots_preview'  => $this->operations->robots_preview(),
            'abilities'       => array_values( $this->registry->visible() ),
        );
    }

    private function status_counts( string $table, string $field ): array {
        global $wpdb;
        if ( ! preg_match( '/^[A-Za-z0-9_]+$/', $field ) ) {
            return array();
        }
        $rows = $wpdb->get_results( "SELECT {$field} AS s, COUNT(*) AS c FROM {$table} GROUP BY {$field}", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $out  = array();
        foreach ( $rows ?: array() as $row ) {
            $out[ (string) $row['s'] ] = (int) $row['c'];
        }
        return $out;
    }

    private function pass_percent( array $checks ): ?int {
        $required = array_values( array_filter( $checks, static fn( $c ) => ! empty( $c['required'] ) ) );
        if ( ! $required ) {
            return null;
        }
        $pass = count( array_filter( $required, static fn( $c ) => 'PASS' === $c['status'] ) );
        return (int) round( 100 * $pass / count( $required ) );
    }

    private function ratio_or_null( int $part, int $total ): ?int {
        return $total > 0 ? (int) round( 100 * $part / $total ) : null;
    }

    private function ability_object_access_error( string $ability, array $input ): ?WP_Error {
        $product_read = array(
            'product.get', 'product.get_verified_specs', 'price.get', 'stock.get', 'warranty.check',
            'schema.preview', 'schema.validate', 'reviews.summary', 'media.truth', 'parity.validate', 'gs1.mapping', 'product.intelligence',
        );
        $product_write = array( 'product.update', 'product.autofix' );

        if ( in_array( $ability, $product_read, true ) ) {
            return K20AI_Entity_Access::read_error( 'product', absint( $input['product_id'] ?? 0 ) );
        }
        if ( in_array( $ability, $product_write, true ) ) {
            return K20AI_Entity_Access::edit_error( 'product', absint( $input['product_id'] ?? 0 ) );
        }
        if ( 'product.compare' === $ability ) {
            foreach ( array_values( array_unique( array_filter( array_map( 'absint', (array) ( $input['product_ids'] ?? array() ) ) ) ) ) as $product_id ) {
                $error = K20AI_Entity_Access::read_error( 'product', $product_id );
                if ( is_wp_error( $error ) ) return $error;
            }
        }
        return null;
    }

    public function execute( string $ability, array $input = array(), bool $confirmed = false ): array|WP_Error {
        $spec = $this->registry->get( $ability );
        if ( ! $spec ) {
            return new WP_Error( 'unknown_ability', __( 'Ability ناشناخته است.', 'k20-ai-press' ), array( 'status' => 404 ) );
        }
        if ( ! K20AI_Security::ability_permission( $spec ) ) {
            return new WP_Error( 'forbidden', __( 'دسترسی کافی نیست.', 'k20-ai-press' ), array( 'status' => 403 ) );
        }
        if ( $spec['requires_confirmation'] && ! $confirmed ) {
            return new WP_Error( 'confirmation_required', __( 'این عملیات نیازمند تأیید صریح است.', 'k20-ai-press' ), array( 'status' => 409 ) );
        }
        $validation = $this->validate_input( $input, (array) $spec['input_schema'] );
        if ( is_wp_error( $validation ) ) {
            return $validation;
        }
        $object_access = $this->ability_object_access_error( $ability, $input );
        if ( is_wp_error( $object_access ) ) {
            return $object_access;
        }
        if ( ! $this->rate_limit( $ability, (string) $spec['rate_limit'] ) ) {
            return new WP_Error( 'rate_limited', __( 'محدودیت نرخ این Ability پر شده است.', 'k20-ai-press' ), array( 'status' => 429 ) );
        }

        $result = match ( $ability ) {
            'audit.run', 'system.retest' => $this->audit_snapshot(),
            'mode.readiness' => $this->mode_readiness(),
            'mode.promote' => $this->promote_mode( (string) ( $input['target'] ?? '' ) ),
            'catalog.search' => $this->catalog_search( (string) ( $input['query'] ?? '' ), (int) ( $input['limit'] ?? 10 ) ),
            'product.get', 'product.get_verified_specs' => $this->product_truth( absint( $input['product_id'] ?? 0 ) ),
            'product.update' => $this->update_product_fields( absint( $input['product_id'] ?? 0 ), is_array( $input['fields'] ?? null ) ? (array) $input['fields'] : array() ),
            'product.autofix' => $this->autofix_product( absint( $input['product_id'] ?? 0 ), (string) ( $input['scope'] ?? 'safe' ) ),
            'product.compare' => $this->compare_products( array_map( 'absint', (array) ( $input['product_ids'] ?? array() ) ) ),
            'product.enrichment.backlog' => $this->product_enrichment_backlog(),
            'supplier.import.preview' => $this->supplier_import_preview(),
            'claim.verify' => $this->claim_verify( absint( $input['claim_id'] ?? 0 ) ),
            'evidence.get' => $this->evidence_get( absint( $input['claim_id'] ?? 0 ) ),
            'compatibility.check' => $this->compatibility_check( (array) ( $input['context'] ?? array() ) ),
            'compatibility.explain' => $this->compatibility_explain( absint( $input['rule_id'] ?? 0 ) ),
            'engineering.convert_units' => $this->convert_units( (float) ( $input['value'] ?? 0 ), (string) ( $input['from'] ?? '' ), (string) ( $input['to'] ?? '' ) ),
            'engineering.calculate_drip_tape' => $this->calculate_drip_tape( (float) ( $input['area_m2'] ?? 0 ), (float) ( $input['row_spacing_m'] ?? 0 ) ),
            'engineering.calculate_pipe' => $this->calculate_pipe( (float) ( $input['flow_m3h'] ?? 0 ), (float) ( $input['diameter_mm'] ?? 0 ) ),
            'engineering.calculate_filter' => $this->calculate_filter( (float) ( $input['flow_m3h'] ?? 0 ), (float) ( $input['safety_factor'] ?? 1.2 ) ),
            'cart.build', 'cart.validate' => $this->validate_cart( (array) ( $input['items'] ?? array() ) ),
            'price.get' => $this->read_product_field( absint( $input['product_id'] ?? 0 ), 'price' ),
            'stock.get' => $this->read_product_field( absint( $input['product_id'] ?? 0 ), 'stock' ),
            'shipping.estimate' => $this->shipping_estimate( (array) ( $input['destination'] ?? array() ), (array) ( $input['items'] ?? array() ) ),
            'quote.create' => $this->create_quote( (array) ( $input['items'] ?? array() ), (string) ( $input['customer_note'] ?? '' ) ),
            'quote.get' => $this->get_quote( (string) ( $input['quote_id'] ?? '' ) ),
            'support.create_case' => $this->create_support_case( (string) ( $input['subject'] ?? '' ), (string) ( $input['message'] ?? '' ) ),
            'order.track' => $this->track_order( absint( $input['order_id'] ?? 0 ) ),
            'warranty.check' => $this->warranty_check( absint( $input['product_id'] ?? 0 ) ),
            'return.request' => $this->return_request( absint( $input['order_id'] ?? 0 ), (string) ( $input['reason'] ?? '' ) ),
            'admin.review_claim' => $this->review_claim( absint( $input['claim_id'] ?? 0 ), (string) ( $input['status'] ?? '' ) ),
            'admin.publish_rule' => $this->publish_rule( absint( $input['rule_id'] ?? 0 ) ),
            'admin.trigger_reindex' => $this->queue_job( 'rag_reindex', array( 'scope' => (string) ( $input['scope'] ?? 'all' ) ) ),
            'admin.resolve_conflict' => $this->record_conflict_resolution( (string) ( $input['conflict_type'] ?? '' ), (string) ( $input['resolution'] ?? '' ) ),
            'supplier.submit_product_data', 'supplier.submit_catalog', 'supplier.update_evidence' => $this->supplier_submission( $ability, $input ),
            'bot.registry.list' => $this->advanced->bot_registry_info(),
            'bot.registry.update' => $this->advanced->save_bot_registry( (array) ( $input['entries'] ?? array() ) ),
            'bot.policy.get' => $this->advanced->bot_policy(),
            'bot.policy.update' => $this->advanced->save_bot_policy( $input ),
            'bot.verify' => $this->advanced->verify_bot_ip( (string) ( $input['user_agent'] ?? '' ), (string) ( $input['ip'] ?? '' ) ),
            'brand.truth.get' => $this->advanced->brand_truth(),
            'brand.truth.update' => $this->advanced->save_brand_truth( $input ),
            'schema.preview' => $this->advanced->schema_preview( absint( $input['product_id'] ?? 0 ) ),
            'schema.validate' => $this->advanced->schema_validate( absint( $input['product_id'] ?? 0 ) ),
            'citation.pack' => $this->advanced->citation_pack( esc_url_raw( (string) ( $input['url'] ?? '' ) ) ),
            'rag.index' => $this->advanced->rag_index( (string) ( $input['scope'] ?? 'all' ), absint( $input['limit'] ?? 100 ) ),
            'rag.search' => $this->advanced->rag_search( (string) ( $input['query'] ?? '' ), absint( $input['limit'] ?? 8 ) ),
            'feed.acp.snapshot' => $this->advanced->feed_acp( absint( $input['limit'] ?? 100 ) ),
            'feed.acp.persist_snapshot' => $this->persist_acp_snapshot( absint( $input['limit'] ?? 100 ) ),
            'feed.health' => $this->advanced->feed_health(),
            'ucp.catalog.search' => $this->advanced->ucp_catalog_search( $input ),
            'ucp.catalog.lookup' => $this->advanced->ucp_catalog_lookup( $input ),
            'ucp.catalog.product' => $this->advanced->ucp_catalog_product( $input ),
            'feed.ucp.profile' => $this->advanced->ucp_profile(),
            'visibility.summary' => $this->advanced->visibility_summary( absint( $input['days'] ?? 30 ) ),
            'visibility.ingest_citation' => $this->advanced->ingest_citation( $input ),
            'provider.matrix' => $this->advanced->provider_matrix(),
            'mcp.status' => $this->advanced->mcp_status(),
            'observability.status' => $this->advanced->observability(),
            'eval.run' => $this->advanced->eval_run(),
            'provider.route' => $this->advanced->provider_route( (string) ( $input['task'] ?? '' ) ),
            'ai.generate_text' => $this->advanced->ai_generate_text( (string) ( $input['prompt'] ?? '' ) ),
            'media.audit' => $this->advanced->media_audit(),
            'taxonomy.audit' => $this->advanced->taxonomy_audit(),
            'content.engines.status' => $this->advanced->content_engines_status(),
            'support.workflows.status' => $this->advanced->support_workflows_status(),
            'parity.validate' => $this->advanced->channel_parity( absint( $input['product_id'] ?? 0 ) ),
            'graph.rebuild' => $this->operations->graph_rebuild( absint( $input['limit'] ?? 300 ) ),
            'graph.query' => $this->operations->graph_query( (string) ( $input['entity_key'] ?? '' ) ),
            'intent.parse' => $this->operations->intent_parse( (string) ( $input['query'] ?? '' ) ),
            'guided.sell' => $this->operations->guided_sell( (string) ( $input['query'] ?? '' ) ),
            'reviews.summary' => $this->operations->review_summary( absint( $input['product_id'] ?? 0 ) ),
            'media.truth' => $this->operations->media_truth( absint( $input['product_id'] ?? 0 ) ),
            'stats.noise' => $this->operations->statistical_noise( (array) ( $input['values'] ?? array() ) ),
            'prompt.bank' => $this->operations->prompt_bank( absint( $input['limit'] ?? 200 ) ),
            'robots.preview' => $this->operations->robots_preview(),
            'robots.apply_virtual' => $this->operations->robots_apply_virtual(),
            'robots.rollback' => $this->operations->robots_rollback(),
            'webhook.list' => $this->operations->webhooks(),
            'webhook.register' => $this->operations->webhook_register( (string) ( $input['url'] ?? '' ), (array) ( $input['events'] ?? array() ), (string) ( $input['secret'] ?? '' ) ),
            'webhook.test' => $this->operations->webhook_test( (string) ( $input['id'] ?? '' ) ),
            'budget.get' => $this->operations->budgets(),
            'budget.update' => $this->operations->save_budgets( $input ),
            'budget.status' => $this->operations->budget_status(),
            'slo.get' => $this->operations->slo(),
            'slo.update' => $this->operations->save_slo( $input ),
            'gs1.mapping' => $this->operations->gs1_mapping( absint( $input['product_id'] ?? 0 ) ),
            'command.center' => $this->command_center ? $this->command_center->snapshot() : $this->platform_not_ready(),
            'agent.plan' => $this->agent_engine ? $this->agent_engine->create_run( $input ) : $this->platform_not_ready(),
            'agent.status' => $this->agent_engine ? $this->agent_engine->get_run( (string) ( $input['run_key'] ?? '' ) ) : $this->platform_not_ready(),
            'agent.list' => $this->agent_engine ? $this->agent_engine->list_runs( absint( $input['limit'] ?? 20 ) ) : $this->platform_not_ready(),
            'agent.approve' => $this->agent_engine ? $this->agent_engine->approve_run( (string) ( $input['run_key'] ?? '' ), (array) ( $input['step_ids'] ?? array() ) ) : $this->platform_not_ready(),
            'agent.execute' => $this->agent_engine ? $this->agent_engine->execute_run( (string) ( $input['run_key'] ?? '' ) ) : $this->platform_not_ready(),
            'agent.cancel' => $this->agent_engine ? $this->agent_engine->cancel_run( (string) ( $input['run_key'] ?? '' ) ) : $this->platform_not_ready(),
            'agent.retry' => $this->agent_engine ? $this->agent_engine->retry_step( (string) ( $input['run_key'] ?? '' ), absint( $input['step_id'] ?? 0 ) ) : $this->platform_not_ready(),
            'product.intelligence' => $this->product_intelligence ? $this->product_intelligence->score_product( absint( $input['product_id'] ?? 0 ) ) : $this->platform_not_ready(),
            'product.intelligence.backlog' => $this->product_intelligence ? $this->product_intelligence->backlog( absint( $input['limit'] ?? 30 ) ) : $this->platform_not_ready(),
            'visibility.query.list' => $this->ai_visibility ? $this->ai_visibility->queries( ! empty( $input['enabled_only'] ) ) : $this->platform_not_ready(),
            'visibility.query.upsert' => $this->ai_visibility ? $this->ai_visibility->upsert_query( $input ) : $this->platform_not_ready(),
            'visibility.observation.ingest' => $this->ai_visibility ? $this->ai_visibility->ingest_observation( $input ) : $this->platform_not_ready(),
            'visibility.observatory' => $this->ai_visibility ? $this->ai_visibility->observatory( absint( $input['days'] ?? 30 ), absint( $input['limit'] ?? 100 ) ) : $this->platform_not_ready(),
            'visibility.collector.status' => $this->ai_visibility ? $this->ai_visibility->collector_status() : $this->platform_not_ready(),
            'visibility.collect.now' => $this->ai_visibility ? $this->ai_visibility->collect_now( absint( $input['limit'] ?? 5 ) ) : $this->platform_not_ready(),
            'onboarding.status' => $this->onboarding_migration ? $this->onboarding_migration->status() : $this->platform_not_ready(),
            'onboarding.update' => $this->onboarding_migration ? $this->onboarding_migration->update_status( $input ) : $this->platform_not_ready(),
            'migration.preview' => $this->onboarding_migration ? $this->onboarding_migration->preview( (string) ( $input['source'] ?? '' ), absint( $input['limit'] ?? 100 ), absint( $input['offset'] ?? 0 ) ) : $this->platform_not_ready(),
            'migration.import' => $this->onboarding_migration ? $this->onboarding_migration->import( (string) ( $input['source'] ?? '' ), (array) ( $input['post_ids'] ?? array() ) ) : $this->platform_not_ready(),
            'migration.rollback' => $this->onboarding_migration ? $this->onboarding_migration->rollback( (string) ( $input['snapshot_key'] ?? '' ) ) : $this->platform_not_ready(),
            'license.status' => $this->commercial ? $this->commercial->status() : $this->platform_not_ready(),
            'license.activate' => $this->commercial ? $this->commercial->activate( (string) ( $input['license_key'] ?? '' ) ) : $this->platform_not_ready(),
            'license.deactivate' => $this->commercial ? $this->commercial->deactivate() : $this->platform_not_ready(),
            'license.sync' => $this->commercial ? $this->commercial->sync() : $this->platform_not_ready(),
            'diagnostics.bundle' => $this->commercial ? $this->commercial->diagnostics( $this->registry, $this ) : $this->platform_not_ready(),
            'setup.status' => $this->operations->setup_status(),
            default => new WP_Error( 'not_implemented', __( 'این Ability ثبت شده ولی Adapter اجرایی آن پیکربندی نشده است.', 'k20-ai-press' ), array( 'status' => 501 ) ),
        };

        $this->audit( $ability, 'ability', $ability, is_wp_error( $result ) ? 'ERROR' : 'OK', is_wp_error( $result ) ? array( 'code' => $result->get_error_code() ) : array() );
        return $result;
    }

    public function mode_readiness(): array {
        $audit = $this->audit_snapshot();
        $required_failures = array_values( array_filter( $audit['checks'], static fn( $c ) => ! empty( $c['required'] ) && 'FAIL' === $c['status'] ) );
        $high_conflicts = array_values( array_filter( $audit['conflicts'], static fn( $c ) => 'high' === strtolower( (string) ( $c['severity'] ?? '' ) ) ) );
        $managed_conflicts = array_values( array_filter( $audit['conflicts'], static fn( $c ) => ! empty( $c['managed'] ) ) );
        $hybrid_warnings = array_values( array_filter( $audit['conflicts'], static fn( $c ) => in_array( strtolower( (string) ( $c['severity'] ?? '' ) ), array( 'high', 'medium' ), true ) ) );
        $setup = $this->operations->setup_status();
        global $wpdb;
        $t = K20AI_Database::tables();
        $dead = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t['jobs']} WHERE status='DEAD_LETTER'" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $eval = $this->advanced->eval_run( false );
        $eval_pass = ! empty( $eval['pass'] );
        // Hybrid is the controlled coexistence/migration mode. High conflicts are warnings
        // to be resolved *inside* Hybrid, not a reason to prevent entering Hybrid.
        // Primary remains strict and requires every high-severity conflict to be gone.
        $hybrid_ready = empty( $required_failures );
        $primary_ready = $hybrid_ready && empty( $high_conflicts ) && 0 === $dead && $eval_pass && (int) ( $setup['completed'] ?? 0 ) === (int) ( $setup['total'] ?? -1 );
        return array(
            'current_mode' => $this->settings()['mode'],
            'hybrid_ready' => $hybrid_ready,
            'primary_ready' => $primary_ready,
            'required_failures' => $required_failures,
            'high_conflicts' => $high_conflicts,
            'managed_conflicts' => $managed_conflicts,
            'hybrid_warnings' => $hybrid_warnings,
            'dead_letter' => $dead,
            'eval_pass' => $eval_pass,
            'setup' => $setup,
        );
    }

    private function promote_mode( string $target ): array|WP_Error {
        if ( ! in_array( $target, array( 'shadow','hybrid','primary' ), true ) ) {
            return new WP_Error( 'invalid_mode', __( 'Mode نامعتبر است.', 'k20-ai-press' ), array( 'status' => 422 ) );
        }
        $settings = $this->settings();
        $current = $settings['mode'];
        if ( $target === $current ) { return array( 'mode' => $current, 'changed' => false, 'readiness' => $this->mode_readiness() ); }
        if ( 'shadow' === $target ) {
            $settings['mode'] = 'shadow'; update_option( 'k20ai_settings', $settings, false );
            return array( 'mode' => 'shadow', 'changed' => true, 'readiness' => $this->mode_readiness() );
        }
        $readiness = $this->mode_readiness();
        if ( 'hybrid' === $target ) {
            if ( empty( $readiness['hybrid_ready'] ) ) { return new WP_Error( 'hybrid_not_ready', __( 'Hybrid Readiness Gate پاس نشده است.', 'k20-ai-press' ), array( 'status' => 409, 'readiness' => $readiness ) ); }
            $settings['mode'] = 'hybrid'; update_option( 'k20ai_settings', $settings, false );
            return array( 'mode' => 'hybrid', 'changed' => true, 'readiness' => $readiness );
        }
        if ( 'hybrid' !== $current ) { return new WP_Error( 'primary_requires_hybrid', __( 'برای Primary ابتدا باید Hybrid فعال و پایدار باشد.', 'k20-ai-press' ), array( 'status' => 409 ) ); }

        $managed_now = array();
        if ( empty( $readiness['primary_ready'] ) && ! empty( $readiness['high_conflicts'] ) ) {
            $only_ai_overlap = true;
            foreach ( $readiness['high_conflicts'] as $conflict ) {
                if ( 'ai_overlap' !== (string) ( $conflict['type'] ?? '' ) ) {
                    $only_ai_overlap = false;
                    break;
                }
            }
            $setup_complete = (int) ( $readiness['setup']['completed'] ?? 0 ) === (int) ( $readiness['setup']['total'] ?? -1 );
            if ( $only_ai_overlap && empty( $readiness['required_failures'] ) && 0 === (int) ( $readiness['dead_letter'] ?? 0 ) && ! empty( $readiness['eval_pass'] ) && $setup_complete ) {
                $managed_now = $this->manage_ai_overlap_for_primary();
                $readiness = $this->mode_readiness();
            }
        }

        if ( empty( $readiness['primary_ready'] ) ) { return new WP_Error( 'primary_not_ready', __( 'Primary Readiness Gate پاس نشده است.', 'k20-ai-press' ), array( 'status' => 409, 'readiness' => $readiness ) ); }
        $settings['mode'] = 'primary'; update_option( 'k20ai_settings', $settings, false );
        return array( 'mode' => 'primary', 'changed' => true, 'readiness' => $this->mode_readiness(), 'managed_conflicts' => $managed_now );
    }

    /**
     * Record a safe coexistence policy for the known AI-overlap case.
     * This does not disable or modify another plugin. It only records ownership
     * inside this plugin so Primary can operate without pretending the external
     * plugin disappeared.
     *
     * @return array<int,array<string,mixed>>
     */
    private function manage_ai_overlap_for_primary(): array {
        $conflicts = $this->detect_conflicts();
        $active = array_values( array_filter( $conflicts, static fn( $c ) => 'ai_overlap' === (string) ( $c['type'] ?? '' ) && empty( $c['managed'] ) ) );
        if ( empty( $active ) ) {
            return array();
        }

        $records = get_option( 'k20ai_conflict_reviews', array() );
        $records = is_array( $records ) ? $records : array();
        $records['ai_overlap'] = array(
            'resolution'     => 'managed_primary_coexistence: external AI remains active; K20 write-capabilities remain gated and duplicate ownership is isolated internally',
            'reviewer'       => get_current_user_id(),
            'reviewed_at'    => current_time( 'mysql', true ),
            'severity'       => 'high',
            'still_detected' => true,
            'policy'         => 'reuse_external_and_isolate_duplicate_writes',
        );
        update_option( 'k20ai_conflict_reviews', $records, false );
        $this->audit( 'conflict.manage', 'conflict', 'ai_overlap', 'OK', array( 'policy' => 'reuse_external_and_isolate_duplicate_writes' ) );
        return array(
            array(
                'type'       => 'ai_overlap',
                'resolution' => 'REUSE / ISOLATE',
                'message'    => 'افزونه AI خارجی حفظ شد و هم‌پوشانی قابلیت‌های نوشتنی داخل این افزونه تحت Gate و تأیید صریح مدیریت شد.',
            ),
        );
    }

    private function persist_acp_snapshot( int $limit ): array|WP_Error {
        $payload = $this->advanced->feed_acp( max( 1, min( 500, $limit ) ) );
        if ( isset( $payload['errors'] ) && ! empty( $payload['errors'] ) ) {
            return new WP_Error( 'feed_generation_failed', __( 'ACP feed generation failed.', 'k20-ai-press' ), array( 'status' => 503, 'errors' => $payload['errors'] ) );
        }
        if ( ! isset( $payload['products'], $payload['invalid_products'] ) ) {
            return new WP_Error( 'feed_generation_invalid', __( 'ACP feed shape نامعتبر است.', 'k20-ai-press' ), array( 'status' => 500 ) );
        }
        return $this->advanced->save_feed_snapshot( 'acp', $payload );
    }

    private function catalog_search( string $query, int $limit ): array {
        if ( ! function_exists( 'wc_get_products' ) ) {
            return array();
        }
        $query = sanitize_text_field( $query );
        $limit = max( 1, min( 50, $limit ) );
        $posts = get_posts( array( 'post_type' => 'product', 'post_status' => array( 'publish', 'draft', 'private' ), 's' => $query, 'posts_per_page' => $limit, 'fields' => 'ids' ) );
        $out = array();
        foreach ( $posts as $id ) {
            $p = wc_get_product( $id );
            if ( $p ) {
                $out[] = array( 'id' => $id, 'name' => $p->get_name(), 'sku' => $p->get_sku(), 'stock_status' => $p->get_stock_status() );
            }
        }
        return $out;
    }

    private function compare_products( array $ids ): array {
        $out = array();
        foreach ( array_slice( array_unique( array_filter( $ids ) ), 0, 5 ) as $id ) {
            $truth = $this->product_truth( $id );
            if ( ! is_wp_error( $truth ) ) {
                $out[] = $truth;
            }
        }
        return $out;
    }

    private function claim_verify( int $id ): array|WP_Error {
        global $wpdb;
        $t = K20AI_Database::tables();
        $claim = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t['claims']} WHERE id=%d", $id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        if ( ! $claim ) {
            return new WP_Error( 'claim_not_found', __( 'ادعا پیدا نشد.', 'k20-ai-press' ), array( 'status' => 404 ) );
        }
        $claim['evidence'] = $this->evidence_get( $id );
        return $claim;
    }

    private function evidence_get( int $claim_id ): array {
        global $wpdb;
        $t = K20AI_Database::tables();
        return $wpdb->get_results( $wpdb->prepare( "SELECT id,title,source_url,source_type,confidence,status,verified_at,valid_until FROM {$t['evidence']} WHERE claim_id=%d ORDER BY id DESC LIMIT 500", $claim_id ), ARRAY_A ) ?: array(); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
    }

    private function compatibility_check( array $context ): array {
        global $wpdb;
        $t = K20AI_Database::tables();
        $rules = $wpdb->get_results( "SELECT id,rule_key,title,conditions,result,source,confidence,exceptions,status FROM {$t['compat_rules']} WHERE status='VERIFIED' ORDER BY id DESC LIMIT 1000", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $matches = array();
        foreach ( $rules ?: array() as $rule ) {
            $conditions = json_decode( (string) $rule['conditions'], true );
            if ( ! is_array( $conditions ) ) {
                continue;
            }
            $ok = true;
            foreach ( $conditions as $key => $expected ) {
                if ( ! array_key_exists( $key, $context ) || (string) $context[ $key ] !== (string) $expected ) {
                    $ok = false;
                    break;
                }
            }
            if ( $ok ) {
                $matches[] = $rule;
            }
        }
        return array( 'result' => $matches ? (string) $matches[0]['result'] : 'UNKNOWN', 'matches' => $matches );
    }

    private function compatibility_explain( int $id ): array|WP_Error {
        global $wpdb;
        $t = K20AI_Database::tables();
        $rule = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t['compat_rules']} WHERE id=%d", $id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        return $rule ?: new WP_Error( 'rule_not_found', __( 'قانون پیدا نشد.', 'k20-ai-press' ), array( 'status' => 404 ) );
    }

    private function convert_units( float $value, string $from, string $to ): array|WP_Error {
        $from = strtolower( trim( $from ) );
        $to   = strtolower( trim( $to ) );
        $pairs = array(
            'mm:inch' => fn( $v ) => $v / 25.4,
            'inch:mm' => fn( $v ) => $v * 25.4,
            'l/s:m3/h' => fn( $v ) => $v * 3.6,
            'm3/h:l/s' => fn( $v ) => $v / 3.6,
            'bar:mh2o' => fn( $v ) => $v * 10.19716213,
            'mh2o:bar' => fn( $v ) => $v / 10.19716213,
        );
        $key = $from . ':' . $to;
        if ( ! isset( $pairs[ $key ] ) ) {
            return new WP_Error( 'unsupported_unit_pair', __( 'تبدیل این دو واحد پشتیبانی نمی‌شود.', 'k20-ai-press' ), array( 'status' => 422 ) );
        }
        return array( 'value' => $value, 'from' => $from, 'to' => $to, 'result' => round( $pairs[ $key ]( $value ), 6 ) );
    }

    private function calculate_drip_tape( float $area_m2, float $row_spacing_m ): array|WP_Error {
        if ( $area_m2 <= 0 || $row_spacing_m <= 0 ) {
            return new WP_Error( 'invalid_input', __( 'مساحت و فاصله ردیف باید بزرگ‌تر از صفر باشد.', 'k20-ai-press' ), array( 'status' => 422 ) );
        }
        return array( 'length_m' => round( $area_m2 / $row_spacing_m, 2 ), 'assumption' => 'محاسبه هندسی پایه؛ ضریب پرت و مسیر مانيفولد جداگانه است.' );
    }

    private function calculate_pipe( float $flow_m3h, float $diameter_mm ): array|WP_Error {
        if ( $flow_m3h < 0 || $diameter_mm <= 0 ) {
            return new WP_Error( 'invalid_input', __( 'دبی نامنفی و قطر مثبت لازم است.', 'k20-ai-press' ), array( 'status' => 422 ) );
        }
        $q = $flow_m3h / 3600;
        $d = $diameter_mm / 1000;
        $area = M_PI * $d * $d / 4;
        return array( 'area_m2' => round( $area, 8 ), 'velocity_m_s' => $area > 0 ? round( $q / $area, 4 ) : null, 'note' => 'افت فشار نیازمند طول، زبری و اتصالات است و اینجا حدس زده نمی‌شود.' );
    }

    private function calculate_filter( float $flow_m3h, float $factor ): array|WP_Error {
        if ( $flow_m3h < 0 || $factor < 1 || $factor > 3 ) {
            return new WP_Error( 'invalid_input', __( 'ورودی محاسبه فیلتر معتبر نیست.', 'k20-ai-press' ), array( 'status' => 422 ) );
        }
        return array( 'minimum_capacity_m3h' => round( $flow_m3h * $factor, 2 ), 'safety_factor' => $factor, 'note' => 'نوع/مش فیلتر بدون کیفیت آب و تجهیز مصرف‌کننده تعیین نمی‌شود.' );
    }

    private function validate_cart( array $items ): array {
        $rows = array();
        $ok = true;
        foreach ( $items as $item ) {
            $id  = absint( $item['product_id'] ?? 0 );
            $qty = max( 1, absint( $item['quantity'] ?? 1 ) );
            $p   = function_exists( 'wc_get_product' ) ? wc_get_product( $id ) : null;
            if ( ! $p ) {
                $rows[] = array( 'product_id' => $id, 'valid' => false, 'reason' => 'not_found' );
                $ok = false;
                continue;
            }
            $stock_ok = ! $p->managing_stock() || null === $p->get_stock_quantity() || $p->get_stock_quantity() >= $qty;
            $rows[] = array( 'product_id' => $id, 'name' => $p->get_name(), 'quantity' => $qty, 'stock_ok' => $stock_ok, 'price' => $p->get_price(), 'valid' => $stock_ok );
            $ok = $ok && $stock_ok;
        }
        return array( 'valid' => $ok, 'items' => $rows );
    }

    private function read_product_field( int $id, string $field ): array|WP_Error {
        $p = function_exists( 'wc_get_product' ) ? wc_get_product( $id ) : null;
        if ( ! $p ) {
            return new WP_Error( 'product_not_found', __( 'محصول پیدا نشد.', 'k20-ai-press' ), array( 'status' => 404 ) );
        }
        if ( 'price' === $field ) {
            return array( 'product_id' => $id, 'price' => $p->get_price(), 'currency' => function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : null, 'timestamp' => current_time( DATE_ATOM, true ) );
        }
        return array( 'product_id' => $id, 'stock_quantity' => $p->get_stock_quantity(), 'stock_status' => $p->get_stock_status(), 'timestamp' => current_time( DATE_ATOM, true ) );
    }

    private function create_quote( array $items, string $note ): array|WP_Error {
        $validated = $this->validate_cart( $items );
        if ( empty( $validated['valid'] ) ) {
            return new WP_Error( 'cart_invalid', __( 'سبد برای پیش‌فاکتور معتبر نیست.', 'k20-ai-press' ), array( 'status' => 422, 'details' => $validated ) );
        }
        $id = 'K20Q-' . gmdate( 'YmdHis' ) . '-' . wp_rand( 1000, 9999 );
        $quote = array( 'id' => $id, 'items' => $validated['items'], 'note' => sanitize_textarea_field( $note ), 'created_at' => current_time( DATE_ATOM, true ), 'valid_until' => gmdate( DATE_ATOM, time() + DAY_IN_SECONDS ) );
        set_transient( 'k20ai_quote_' . md5( $id ), $quote, DAY_IN_SECONDS );
        return $quote;
    }

    private function get_quote( string $id ): array|WP_Error {
        $quote = get_transient( 'k20ai_quote_' . md5( sanitize_text_field( $id ) ) );
        return is_array( $quote ) ? $quote : new WP_Error( 'quote_not_found', __( 'پیش‌فاکتور پیدا نشد یا منقضی است.', 'k20-ai-press' ), array( 'status' => 404 ) );
    }

    private function create_support_case( string $subject, string $message ): array|WP_Error {
        $post_id = wp_insert_post( array( 'post_type' => 'k20ai_case', 'post_status' => 'private', 'post_title' => sanitize_text_field( $subject ), 'post_content' => wp_kses_post( $message ) ), true );
        if ( is_wp_error( $post_id ) ) {
            return $post_id;
        }
        return array( 'case_id' => $post_id, 'status' => 'OPEN' );
    }

    private function track_order( int $order_id ): array|WP_Error {
        if ( ! function_exists( 'wc_get_order' ) ) {
            return new WP_Error( 'woocommerce_missing', __( 'WooCommerce در دسترس نیست.', 'k20-ai-press' ), array( 'status' => 503 ) );
        }
        $o = wc_get_order( $order_id );
        if ( ! $o ) {
            return new WP_Error( 'order_not_found', __( 'سفارش پیدا نشد.', 'k20-ai-press' ), array( 'status' => 404 ) );
        }
        return array( 'order_id' => $order_id, 'status' => $o->get_status(), 'date_modified' => $o->get_date_modified() ? $o->get_date_modified()->date( DATE_ATOM ) : null );
    }

    private function warranty_check( int $product_id ): array|WP_Error {
        $p = function_exists( 'wc_get_product' ) ? wc_get_product( $product_id ) : null;
        if ( ! $p ) {
            return new WP_Error( 'product_not_found', __( 'محصول پیدا نشد.', 'k20-ai-press' ), array( 'status' => 404 ) );
        }
        $warranty = get_post_meta( $product_id, '_warranty', true );
        return array( 'product_id' => $product_id, 'warranty' => $warranty ?: null, 'status' => $warranty ? 'KNOWN' : 'UNKNOWN' );
    }

    private function return_request( int $order_id, string $reason ): array|WP_Error {
        if ( ! function_exists( 'wc_get_order' ) ) {
            return new WP_Error( 'woocommerce_missing', __( 'WooCommerce در دسترس نیست.', 'k20-ai-press' ), array( 'status' => 503 ) );
        }
        $order = wc_get_order( $order_id );
        if ( ! $order ) {
            return new WP_Error( 'order_not_found', __( 'سفارش پیدا نشد.', 'k20-ai-press' ), array( 'status' => 404 ) );
        }
        $reason = sanitize_textarea_field( $reason );
        if ( mb_strlen( $reason ) < 3 ) {
            return new WP_Error( 'reason_required', __( 'دلیل مرجوعی لازم است.', 'k20-ai-press' ), array( 'status' => 422 ) );
        }
        $post_id = wp_insert_post( array(
            'post_type' => 'k20ai_case',
            'post_status' => 'private',
            'post_title' => sprintf( 'Return request #%d', $order_id ),
            'post_content' => $reason,
        ), true );
        if ( is_wp_error( $post_id ) ) { return $post_id; }
        update_post_meta( $post_id, '_k20ai_case_type', 'return_request' );
        update_post_meta( $post_id, '_k20ai_order_id', $order_id );
        update_post_meta( $post_id, '_k20ai_case_status', 'OPEN' );
        return array( 'case_id' => (int) $post_id, 'order_id' => $order_id, 'status' => 'OPEN', 'note' => 'این درخواست فقط Case ایجاد می‌کند و Refund/Payment را تغییر نمی‌دهد.' );
    }

    private function shipping_estimate( array $destination, array $items ): array|WP_Error {
        if ( ! function_exists( 'wc_get_product' ) || ! class_exists( 'WC_Shipping_Zones' ) ) {
            return new WP_Error( 'shipping_unavailable', __( 'موتور حمل WooCommerce در دسترس نیست.', 'k20-ai-press' ), array( 'status' => 503 ) );
        }
        $country = strtoupper( sanitize_text_field( (string) ( $destination['country'] ?? '' ) ) );
        if ( '' === $country ) {
            return new WP_Error( 'destination_required', __( 'کشور مقصد برای محاسبه نرخ حمل الزامی است.', 'k20-ai-press' ), array( 'status' => 422 ) );
        }
        $contents = array();
        $contents_cost = 0.0;
        foreach ( array_slice( $items, 0, 100 ) as $index => $item ) {
            if ( ! is_array( $item ) ) { continue; }
            $product_id = absint( $item['product_id'] ?? 0 );
            $quantity = max( 1, min( 9999, absint( $item['quantity'] ?? 1 ) ) );
            $product = wc_get_product( $product_id );
            if ( ! $product || 'publish' !== get_post_status( $product_id ) ) {
                return new WP_Error( 'product_not_found', __( 'یکی از اقلام حمل معتبر یا منتشرشده نیست.', 'k20-ai-press' ), array( 'status' => 404, 'product_id' => $product_id ) );
            }
            $unit_price = '' !== (string) $product->get_price() ? (float) $product->get_price() : 0.0;
            $line_total = $unit_price * $quantity;
            $contents_cost += $line_total;
            $contents[ 'k20ai_' . $index ] = array(
                'key' => 'k20ai_' . $index,
                'product_id' => $product->is_type( 'variation' ) ? $product->get_parent_id() : $product_id,
                'variation_id' => $product->is_type( 'variation' ) ? $product_id : 0,
                'variation' => method_exists( $product, 'get_attributes' ) ? $product->get_attributes() : array(),
                'quantity' => $quantity,
                'data' => $product,
                'line_total' => $line_total,
                'line_tax' => 0,
                'line_subtotal' => $line_total,
                'line_subtotal_tax' => 0,
            );
        }
        if ( empty( $contents ) ) {
            return new WP_Error( 'items_required', __( 'حداقل یک قلم معتبر برای محاسبه حمل لازم است.', 'k20-ai-press' ), array( 'status' => 422 ) );
        }
        $package = array(
            'contents' => $contents,
            'contents_cost' => $contents_cost,
            'applied_coupons' => array(),
            'user' => array( 'ID' => get_current_user_id() ),
            'destination' => array(
                'country' => $country,
                'state' => sanitize_text_field( (string) ( $destination['state'] ?? '' ) ),
                'postcode' => sanitize_text_field( (string) ( $destination['postcode'] ?? '' ) ),
                'city' => sanitize_text_field( (string) ( $destination['city'] ?? '' ) ),
                'address' => sanitize_text_field( (string) ( $destination['address'] ?? '' ) ),
                'address_1' => sanitize_text_field( (string) ( $destination['address'] ?? '' ) ),
                'address_2' => sanitize_text_field( (string) ( $destination['address_2'] ?? '' ) ),
            ),
            'cart_subtotal' => $contents_cost,
        );
        try {
            $zone = WC_Shipping_Zones::get_zone_matching_package( $package );
            $rates = array();
            foreach ( $zone->get_shipping_methods( true ) as $method ) {
                if ( ! is_object( $method ) || ! method_exists( $method, 'calculate_shipping' ) ) { continue; }
                $method->rates = array();
                $method->calculate_shipping( $package );
                foreach ( (array) ( $method->rates ?? array() ) as $rate ) {
                    if ( ! is_object( $rate ) ) { continue; }
                    $rates[] = array(
                        'id' => method_exists( $rate, 'get_id' ) ? $rate->get_id() : '',
                        'label' => method_exists( $rate, 'get_label' ) ? $rate->get_label() : '',
                        'cost' => method_exists( $rate, 'get_cost' ) ? (float) $rate->get_cost() : null,
                        'taxes' => method_exists( $rate, 'get_taxes' ) ? $rate->get_taxes() : array(),
                        'currency' => function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : null,
                    );
                }
            }
        } catch ( Throwable $e ) {
            return new WP_Error( 'shipping_calculation_failed', __( 'محاسبه نرخ حمل WooCommerce ناموفق بود.', 'k20-ai-press' ), array( 'status' => 502, 'detail' => sanitize_text_field( $e->getMessage() ) ) );
        }
        if ( empty( $rates ) ) {
            return new WP_Error( 'shipping_rate_unavailable', __( 'برای مقصد و اقلام فعلی هیچ نرخ واقعی WooCommerce پیدا نشد؛ تخمین ساختگی تولید نشد.', 'k20-ai-press' ), array( 'status' => 404 ) );
        }
        return array(
            'source' => 'woocommerce_shipping_zones',
            'zone_id' => method_exists( $zone, 'get_id' ) ? (int) $zone->get_id() : null,
            'zone_name' => method_exists( $zone, 'get_zone_name' ) ? $zone->get_zone_name() : null,
            'rates' => $rates,
            'assumptions' => array(),
            'estimated' => false,
        );
    }

    private function record_conflict_resolution( string $conflict_type, string $resolution ): array|WP_Error {
        $conflict_type = sanitize_key( $conflict_type );
        $resolution = sanitize_textarea_field( $resolution );
        if ( '' === $conflict_type || mb_strlen( $resolution ) < 3 ) {
            return new WP_Error( 'invalid_resolution', __( 'نوع تعارض و توضیح بازبینی معتبر لازم است.', 'k20-ai-press' ), array( 'status' => 422 ) );
        }
        $current = $this->detect_conflicts();
        $match = null;
        foreach ( $current as $conflict ) {
            if ( ( $conflict['type'] ?? '' ) === $conflict_type ) { $match = $conflict; break; }
        }
        if ( ! $match ) {
            return new WP_Error( 'conflict_not_active', __( 'این نوع تعارض در اسکن فعلی فعال نیست.', 'k20-ai-press' ), array( 'status' => 404 ) );
        }
        $records = get_option( 'k20ai_conflict_reviews', array() );
        $records = is_array( $records ) ? $records : array();
        $records[ $conflict_type ] = array(
            'resolution' => $resolution,
            'reviewer' => get_current_user_id(),
            'reviewed_at' => current_time( 'mysql', true ),
            'severity' => $match['severity'] ?? 'unknown',
            'still_detected' => true,
        );
        update_option( 'k20ai_conflict_reviews', $records, false );
        return array(
            'conflict_type' => $conflict_type,
            'review_recorded' => true,
            'still_detected' => true,
            'next_action' => 'تغییر فنی لازم را خارج از این Ability انجام دهید، سپس audit.run را برای readback اجرا کنید.',
        );
    }

    private function review_claim( int $id, string $status ): array|WP_Error {
        global $wpdb;
        if ( ! in_array( $status, array( 'VERIFIED', 'PARTIAL', 'CONFLICTING', 'UNKNOWN', 'EXPIRED' ), true ) ) {
            return new WP_Error( 'invalid_status', __( 'وضعیت معتبر نیست.', 'k20-ai-press' ), array( 'status' => 422 ) );
        }
        $t = K20AI_Database::tables();
        $updated = $wpdb->update( $t['claims'], array( 'status' => $status, 'reviewer' => get_current_user_id(), 'verified_at' => current_time( 'mysql', true ), 'updated_at' => current_time( 'mysql', true ) ), array( 'id' => $id ), array( '%s', '%d', '%s', '%s' ), array( '%d' ) );
        return false === $updated ? new WP_Error( 'db_error', __( 'به‌روزرسانی ادعا ناموفق بود.', 'k20-ai-press' ), array( 'status' => 500 ) ) : array( 'claim_id' => $id, 'status' => $status );
    }

    private function publish_rule( int $id ): array|WP_Error {
        global $wpdb;
        $t = K20AI_Database::tables();
        $rule = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t['compat_rules']} WHERE id=%d", $id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        if ( ! $rule || empty( $rule['source'] ) ) {
            return new WP_Error( 'evidence_required', __( 'قانون بدون منبع معتبر منتشر نمی‌شود.', 'k20-ai-press' ), array( 'status' => 422 ) );
        }
        $wpdb->update( $t['compat_rules'], array( 'status' => 'VERIFIED', 'reviewer' => get_current_user_id(), 'updated_at' => current_time( 'mysql', true ) ), array( 'id' => $id ), array( '%s', '%d', '%s' ), array( '%d' ) );
        return array( 'rule_id' => $id, 'status' => 'VERIFIED' );
    }

    public function queue_job( string $type, array $payload ): array|WP_Error {
        global $wpdb;
        $t = K20AI_Database::tables();
        $job_key = sanitize_key( $type ) . '-' . wp_generate_uuid4();
        $ok = $wpdb->insert( $t['jobs'], array( 'job_key' => $job_key, 'job_type' => sanitize_key( $type ), 'status' => 'QUEUED', 'payload' => wp_json_encode( $payload ), 'created_at' => current_time( 'mysql', true ), 'updated_at' => current_time( 'mysql', true ) ), array( '%s', '%s', '%s', '%s', '%s', '%s' ) );
        if ( ! $ok ) {
            return new WP_Error( 'db_error', __( 'ایجاد Job ناموفق بود.', 'k20-ai-press' ), array( 'status' => 500 ) );
        }
        $id = (int) $wpdb->insert_id;
        K20AI_Security::enqueue_unique_action( 'k20ai_process_job', array( $id ), time() + 2 );
        return array( 'job_id' => $id, 'job_key' => $job_key, 'status' => 'QUEUED' );
    }

    public function process_job( int $job_id ): void {
        global $wpdb;
        $t = K20AI_Database::tables();
        $job = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t['jobs']} WHERE id=%d", $job_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        if ( ! $job || in_array( $job['status'], array( 'COMPLETED', 'DEAD_LETTER' ), true ) ) {
            return;
        }
        $attempt = (int) $job['attempt'] + 1;
        $wpdb->update( $t['jobs'], array( 'status' => 'RUNNING', 'attempt' => $attempt, 'heartbeat' => current_time( 'mysql', true ), 'lease_until' => gmdate( 'Y-m-d H:i:s', time() + 300 ), 'updated_at' => current_time( 'mysql', true ) ), array( 'id' => $job_id ) );
        try {
            if ( 'rag_reindex' === $job['job_type'] ) {
                $payload = json_decode( (string) $job['payload'], true );
                $scope = is_array( $payload ) ? (string) ( $payload['scope'] ?? 'all' ) : 'all';
                $this->advanced->rag_index( $scope, 500 );
            }
            $wpdb->update( $t['jobs'], array( 'status' => 'COMPLETED', 'progress' => 100, 'updated_at' => current_time( 'mysql', true ) ), array( 'id' => $job_id ) );
        } catch ( Throwable $e ) {
            if ( $attempt >= 3 ) {
                $wpdb->update( $t['jobs'], array( 'status' => 'DEAD_LETTER', 'last_error' => sanitize_text_field( $e->getMessage() ), 'updated_at' => current_time( 'mysql', true ) ), array( 'id' => $job_id ) );
                return;
            }
            $delay = min( HOUR_IN_SECONDS, (int) pow( 2, $attempt ) * 30 + wp_rand( 1, 15 ) );
            $next = time() + $delay;
            $wpdb->update( $t['jobs'], array( 'status' => 'RETRYING', 'last_error' => sanitize_text_field( $e->getMessage() ), 'next_retry' => gmdate( 'Y-m-d H:i:s', $next ), 'updated_at' => current_time( 'mysql', true ) ), array( 'id' => $job_id ) );
            K20AI_Security::enqueue_unique_action( 'k20ai_process_job', array( $job_id ), $next );
        }
    }

    public function recover_stalled_jobs(): void {
        global $wpdb;
        $t = K20AI_Database::tables();
        $ids = $wpdb->get_col( $wpdb->prepare( "SELECT id FROM {$t['jobs']} WHERE status='RUNNING' AND lease_until IS NOT NULL AND lease_until < %s LIMIT 50", current_time( 'mysql', true ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        foreach ( $ids ?: array() as $id ) {
            $wpdb->update( $t['jobs'], array( 'status' => 'CHECKPOINTED', 'updated_at' => current_time( 'mysql', true ) ), array( 'id' => (int) $id ) );
            K20AI_Security::enqueue_unique_action( 'k20ai_process_job', array( (int) $id ), time() + 5 );
        }
    }

    private function supplier_submission( string $ability, array $input ): array|WP_Error {
        global $wpdb;
        $t = K20AI_Database::tables();
        $type = str_replace( 'supplier.', '', $ability );
        $ok = $wpdb->insert( $t['supplier_submissions'], array( 'supplier_id' => (string) get_current_user_id(), 'submission_type' => sanitize_key( $type ), 'product_ref' => sanitize_text_field( (string) ( $input['product_ref'] ?? '' ) ), 'payload' => wp_json_encode( $input ), 'status' => 'PENDING', 'created_at' => current_time( 'mysql', true ), 'updated_at' => current_time( 'mysql', true ) ) );
        return $ok ? array( 'submission_id' => (int) $wpdb->insert_id, 'status' => 'PENDING' ) : new WP_Error( 'db_error', __( 'ثبت ارسال ناموفق بود.', 'k20-ai-press' ), array( 'status' => 500 ) );
    }

    private function rate_limit( string $ability, string $limit_spec = '60/min' ): bool {
        $limit = 60;
        if ( preg_match( '/^(\d+)\/min$/', $limit_spec, $m ) ) {
            $limit = max( 1, (int) $m[1] );
        }
        $key = 'k20ai_rl_' . md5( get_current_user_id() . '|' . $ability . '|' . gmdate( 'YmdHi' ) );
        $count = (int) get_transient( $key );
        if ( $count >= $limit ) {
            return false;
        }
        set_transient( $key, $count + 1, MINUTE_IN_SECONDS + 5 );
        return true;
    }

    private function validate_input( $value, array $schema, string $path = '$' ): bool|WP_Error {
        $type = $schema['type'] ?? null;
        if ( 'object' === $type ) {
            if ( ! is_array( $value ) ) {
                return new WP_Error( 'invalid_input_schema', $path . ' باید object باشد.', array( 'status' => 422 ) );
            }
            foreach ( (array) ( $schema['required'] ?? array() ) as $required ) {
                if ( ! array_key_exists( $required, $value ) ) {
                    return new WP_Error( 'invalid_input_schema', $path . '.' . $required . ' الزامی است.', array( 'status' => 422 ) );
                }
            }
            $props = (array) ( $schema['properties'] ?? array() );
            if ( false === ( $schema['additionalProperties'] ?? true ) ) {
                foreach ( array_keys( $value ) as $key ) {
                    if ( ! array_key_exists( $key, $props ) ) {
                        return new WP_Error( 'invalid_input_schema', $path . '.' . $key . ' مجاز نیست.', array( 'status' => 422 ) );
                    }
                }
            }
            foreach ( $props as $key => $child_schema ) {
                if ( array_key_exists( $key, $value ) && is_array( $child_schema ) ) {
                    $valid = $this->validate_input( $value[ $key ], $child_schema, $path . '.' . $key );
                    if ( is_wp_error( $valid ) ) { return $valid; }
                }
            }
        } elseif ( 'array' === $type ) {
            if ( ! is_array( $value ) ) { return new WP_Error( 'invalid_input_schema', $path . ' باید array باشد.', array( 'status' => 422 ) ); }
            $count = count( $value );
            if ( isset( $schema['minItems'] ) && $count < (int) $schema['minItems'] ) { return new WP_Error( 'invalid_input_schema', $path . ' تعداد کافی ندارد.', array( 'status' => 422 ) ); }
            if ( isset( $schema['maxItems'] ) && $count > (int) $schema['maxItems'] ) { return new WP_Error( 'invalid_input_schema', $path . ' بیش از حد مجاز است.', array( 'status' => 422 ) ); }
            if ( isset( $schema['items'] ) && is_array( $schema['items'] ) ) {
                foreach ( $value as $i => $item ) {
                    $valid = $this->validate_input( $item, $schema['items'], $path . '[' . $i . ']' );
                    if ( is_wp_error( $valid ) ) { return $valid; }
                }
            }
        } elseif ( 'string' === $type ) {
            if ( ! is_string( $value ) ) { return new WP_Error( 'invalid_input_schema', $path . ' باید string باشد.', array( 'status' => 422 ) ); }
            $len = mb_strlen( $value );
            if ( isset( $schema['minLength'] ) && $len < (int) $schema['minLength'] ) { return new WP_Error( 'invalid_input_schema', $path . ' کوتاه‌تر از حد مجاز است.', array( 'status' => 422 ) ); }
            if ( isset( $schema['maxLength'] ) && $len > (int) $schema['maxLength'] ) { return new WP_Error( 'invalid_input_schema', $path . ' بلندتر از حد مجاز است.', array( 'status' => 422 ) ); }
            if ( isset( $schema['enum'] ) && ! in_array( $value, (array) $schema['enum'], true ) ) { return new WP_Error( 'invalid_input_schema', $path . ' خارج از enum مجاز است.', array( 'status' => 422 ) ); }
        } elseif ( 'integer' === $type ) {
            if ( ! is_int( $value ) && ! ( is_numeric( $value ) && (int) $value == $value ) ) { return new WP_Error( 'invalid_input_schema', $path . ' باید integer باشد.', array( 'status' => 422 ) ); }
            $n = (int) $value;
            if ( isset( $schema['minimum'] ) && $n < (int) $schema['minimum'] ) { return new WP_Error( 'invalid_input_schema', $path . ' کمتر از minimum است.', array( 'status' => 422 ) ); }
            if ( isset( $schema['maximum'] ) && $n > (int) $schema['maximum'] ) { return new WP_Error( 'invalid_input_schema', $path . ' بیشتر از maximum است.', array( 'status' => 422 ) ); }
        } elseif ( 'number' === $type ) {
            if ( ! is_numeric( $value ) ) { return new WP_Error( 'invalid_input_schema', $path . ' باید number باشد.', array( 'status' => 422 ) ); }
            $n = (float) $value;
            if ( isset( $schema['minimum'] ) && $n < (float) $schema['minimum'] ) { return new WP_Error( 'invalid_input_schema', $path . ' کمتر از minimum است.', array( 'status' => 422 ) ); }
            if ( isset( $schema['exclusiveMinimum'] ) && $n <= (float) $schema['exclusiveMinimum'] ) { return new WP_Error( 'invalid_input_schema', $path . ' باید بزرگ‌تر از حداقل باشد.', array( 'status' => 422 ) ); }
            if ( isset( $schema['maximum'] ) && $n > (float) $schema['maximum'] ) { return new WP_Error( 'invalid_input_schema', $path . ' بیشتر از maximum است.', array( 'status' => 422 ) ); }
        } elseif ( 'boolean' === $type && ! is_bool( $value ) ) {
            return new WP_Error( 'invalid_input_schema', $path . ' باید boolean باشد.', array( 'status' => 422 ) );
        }
        return true;
    }

    public function audit( string $action, string $target_type, string $target_id, string $result, array $meta = array() ): void {
        global $wpdb;
        $t = K20AI_Database::tables();
        $wpdb->insert( $t['audit_log'], array( 'actor_id' => get_current_user_id(), 'actor_type' => 'human', 'action_name' => $action, 'target_type' => $target_type, 'target_id' => $target_id, 'result' => $result, 'trace_id' => wp_generate_uuid4(), 'meta' => wp_json_encode( $meta ), 'created_at' => current_time( 'mysql', true ) ) );
    }
}
