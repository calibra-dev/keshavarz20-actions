<?php

defined( 'ABSPATH' ) || exit;

trait K20AI_SEO_Scan_Trait {
/**
     * Create a persistent full/entity/crawl scan.
     *
     * @return array<string,mixed>|WP_Error
     */
    public function create_scan( string $type = 'full', string $scope = 'all', ?int $created_by = null ): array|WP_Error {
        global $wpdb;
        $t = K20AI_Database::tables();
        if ( ! in_array( $type, array( 'full', 'product', 'content', 'media', 'media-duplicates', 'taxonomy', 'links', 'crawl' ), true ) ) {
            return new WP_Error( 'invalid_scan_type', __( 'نوع اسکن معتبر نیست.', 'k20-ai-press' ), array( 'status' => 422 ) );
        }
        $scope = sanitize_key( $scope ) ?: 'all';
        if ( ! $this->acquire_scan_create_lock( $type ) ) {
            $existing_id = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t['seo_scans']} WHERE scan_type=%s AND status IN ('queued','running') ORDER BY id DESC LIMIT 1", $type ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            if ( $existing_id > 0 ) return $this->scan( $existing_id );
            return new WP_Error( 'scan_create_busy', __( 'ایجاد اسکن هم‌نوع هم‌اکنون در حال ثبت است؛ درخواست تکراری متوقف شد.', 'k20-ai-press' ), array( 'status' => 409 ) );
        }
        try {
            // Re-check after the lock: two concurrent requests must never create duplicate scans.
            $existing_id = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t['seo_scans']} WHERE scan_type=%s AND status IN ('queued','running') ORDER BY id DESC LIMIT 1", $type ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            if ( $existing_id > 0 ) return $this->scan( $existing_id );
            $now = current_time( 'mysql', true );
            $total = $this->scan_total( $type );
            $wpdb->insert(
                $t['seo_scans'],
                array(
                    'scan_type'    => $type,
                    'scope'        => $scope,
                    'status'       => 'queued',
                    'total'        => $total,
                    'processed'    => 0,
                    'issues_found' => 0,
                    'cursor_value' => 0,
                    'payload'      => wp_json_encode( array( 'phase' => 'entities' ) ),
                    'created_by'   => $created_by,
                    'created_at'   => $now,
                    'updated_at'   => $now,
                ),
                array( '%s','%s','%s','%d','%d','%d','%d','%s','%d','%s','%s' )
            );
            $id = (int) $wpdb->insert_id;
            if ( $id <= 0 ) return new WP_Error( 'scan_create_failed', __( 'ایجاد صف اسکن ناموفق بود.', 'k20-ai-press' ), array( 'status' => 500 ) );
        } finally {
            $this->release_scan_create_lock( $type );
        }
        // Return immediately so the UI can show live progress without waiting for a batch.
        // The first worker is queued immediately; subsequent workers self-chain with a short delay.
        $this->schedule_scan( $id, true );
        return $this->scan( $id );
    }

    /** @return array<string,mixed> */
    public function scan( int $scan_id ): array {
        global $wpdb;
        $t = K20AI_Database::tables();
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t['seo_scans']} WHERE id=%d", $scan_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        if ( ! $row ) {
            return array();
        }
        $row['id'] = (int) $row['id'];
        $row['total'] = (int) $row['total'];
        $row['processed'] = (int) $row['processed'];
        $row['issues_found'] = (int) $row['issues_found'];
        $row['health_score'] = isset( $row['health_score'] ) && null !== $row['health_score'] ? (int) $row['health_score'] : null;
        $row['progress'] = $row['total'] > 0 ? min( 100, (int) round( 100 * $row['processed'] / $row['total'] ) ) : ( 'completed' === $row['status'] ? 100 : 0 );
        $row['payload'] = $this->json( $row['payload'] ?? null );
        return $row;
    }

    /** @return array<string,mixed>|null */
    public function latest_scan(): ?array {
        global $wpdb;
        $t = K20AI_Database::tables();
        if ( ! $this->table_exists( $t['seo_scans'] ) ) {
            return null;
        }
        $id = (int) $wpdb->get_var( "SELECT id FROM {$t['seo_scans']} ORDER BY id DESC LIMIT 1" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        return $id ? $this->scan( $id ) : null;
    }

    /** @return array<string,mixed>|null */
    public function latest_active_scan(): ?array {
        global $wpdb;
        $t = K20AI_Database::tables();
        if ( ! $this->table_exists( $t['seo_scans'] ) ) return null;
        $id = (int) $wpdb->get_var( "SELECT id FROM {$t['seo_scans']} WHERE status IN ('queued','running') ORDER BY id DESC LIMIT 1" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        if ( ! $id ) return null;
        return $this->scan( $id );
    }

    /** @return array<string,mixed> */
    public function resume_scan_if_stalled( int $scan_id ): array {
        $scan = $this->scan( $scan_id );
        if ( ! $scan || ! in_array( (string) ( $scan['status'] ?? '' ), array( 'queued','running' ), true ) ) return $scan;
        $updated = ! empty( $scan['updated_at'] ) ? strtotime( (string) $scan['updated_at'] . ' UTC' ) : false;
        $lock_key = 'k20ai_scan_lock_' . $scan_id;
        $lock_started = (int) get_option( $lock_key, 0 );
        $lock_age = $lock_started > 0 ? max( 0, time() - $lock_started ) : null;

        // Do not enqueue parallel workers while a legitimate worker still owns the lock.
        // Media workers are deliberately bounded to a few seconds, so a much shorter stale-lock
        // window is safe and avoids waiting five minutes after a killed PHP request.
        $is_media_scan = in_array( (string) ( $scan['scan_type'] ?? '' ), array( 'media', 'media-duplicates' ), true );
        $lock_timeout  = $is_media_scan ? 25 : 60;
        $stale_after   = $is_media_scan ? 3 : 10;
        if ( null !== $lock_age && $lock_age < $lock_timeout ) return $scan;
        if ( null !== $lock_age && $lock_age >= $lock_timeout ) delete_option( $lock_key );

        if ( false === $updated || ( time() - $updated ) >= $stale_after ) {
            $this->schedule_scan( $scan_id, true );
        }
        return $scan;
    }


    /**
     * Browser-assisted scan acceleration.
     *
     * The background queue remains authoritative, but an open K20 admin page may
     * execute one bounded batch when the scheduler has not made progress. The
     * existing scan lock guarantees that this never overlaps a real worker.
     *
     * @return array<string,mixed>
     */
    public function tick_scan( int $scan_id ): array {
        $scan = $this->scan( $scan_id );
        if ( ! $scan || ! in_array( (string) ( $scan['status'] ?? '' ), array( 'queued', 'running' ), true ) ) {
            return $scan;
        }
        $lock_key = 'k20ai_scan_lock_' . $scan_id;
        $lock_started = (int) get_option( $lock_key, 0 );
        $is_media = in_array( (string) ( $scan['scan_type'] ?? '' ), array( 'media', 'media-duplicates' ), true );
        $lock_timeout = $is_media ? 25 : 60;
        if ( $lock_started > 0 && ( time() - $lock_started ) >= $lock_timeout ) {
            delete_option( $lock_key );
            $lock_started = 0;
        }
        if ( 0 === $lock_started ) {
            // Keep REST polling responsive. On WooCommerce sites Action Scheduler is the
            // authoritative worker; browser polling only wakes the queue. Fall back to one
            // bounded synchronous batch only when no scheduler is available.
            if ( K20AI_Security::action_scheduler_available() ) {
                $this->schedule_scan( $scan_id, true );
            } else {
                $this->process_scan( $scan_id );
            }
        }
        return $this->scan( $scan_id );
    }


    public function process_scan( int $scan_id ): void {
        global $wpdb;
        $t = K20AI_Database::tables();
        $scan = $this->scan( $scan_id );
        if ( ! $scan || in_array( $scan['status'], array( 'completed', 'failed', 'cancelled' ), true ) ) {
            return;
        }
        $type = (string) $scan['scan_type'];
        $lock_timeout = in_array( $type, array( 'media', 'media-duplicates' ), true ) ? 25 : 60;
        if ( ! $this->acquire_scan_lock( $scan_id, $lock_timeout ) ) return;
        delete_transient( 'k20ai_scan_wakeup_' . $scan_id );
        $settings = $this->settings();
        $batch = max( 5, min( 100, (int) $settings['scan_batch_size'] ) );
        // Normal media analysis is metadata-only, so it can use a larger batch.
        // Deep duplicate hashing stays deliberately tiny and isolated.
        if ( 'media' === $type ) $batch = max( 80, min( 120, $batch * 4 ) );
        if ( 'media-duplicates' === $type ) $batch = 2;
        $cursor = (int) ( $scan['cursor_value'] ?? 0 );
        $now = current_time( 'mysql', true );
        $wpdb->update( $t['seo_scans'], array( 'status' => 'running', 'started_at' => $scan['started_at'] ?: $now, 'updated_at' => $now ), array( 'id' => $scan_id ) );

        try {
            $phase = is_array( $scan['payload'] ?? null ) ? (string) ( $scan['payload']['phase'] ?? 'entities' ) : 'entities';
            $phase_done = false;
            $next_phase = $phase;
            if ( 'full' === $type ) {
                if ( 'taxonomy' === $phase ) {
                    $result = $this->process_taxonomy_batch( $cursor, $batch );
                    $next_phase = 'links';
                } elseif ( 'links' === $phase ) {
                    $result = $this->process_links_batch( $cursor, $batch );
                    $next_phase = 'crawl';
                } elseif ( 'crawl' === $phase ) {
                    $result = $this->process_crawl_batch( $scan_id, $cursor, max( 1, min( 3, (int) $settings['crawl_batch_size'] ) ), $this->scan_progress_heartbeat( $scan_id, $scan ) );
                    $next_phase = 'done';
                } else {
                    $result = $this->process_entity_batch( 'full', $cursor, $batch, false, $this->scan_progress_heartbeat( $scan_id, $scan ) );
                    $next_phase = 'taxonomy';
                }
                $phase_done = ! empty( $result['done'] );
                $done = $phase_done && 'done' === $next_phase;
            } elseif ( 'crawl' === $type ) {
                $result = $this->process_crawl_batch( $scan_id, $cursor, max( 1, min( 3, (int) $settings['crawl_batch_size'] ) ), $this->scan_progress_heartbeat( $scan_id, $scan ) );
                $done = ! empty( $result['done'] );
            } elseif ( 'links' === $type ) {
                $result = $this->process_links_batch( $cursor, $batch );
                $done = ! empty( $result['done'] );
            } elseif ( 'taxonomy' === $type ) {
                $result = $this->process_taxonomy_batch( $cursor, $batch );
                $done = ! empty( $result['done'] );
            } else {
                $heartbeat = $this->scan_progress_heartbeat( $scan_id, $scan );
                $result = $this->process_entity_batch( $type, $cursor, $batch, 'media-duplicates' === $type, $heartbeat );
                $done = ! empty( $result['done'] );
            }
            $processed_total = (int) $scan['processed'] + (int) $result['processed'];
            $issues_total = (int) $scan['issues_found'] + (int) $result['issues'];
            // Keep the displayed accounting truthful if eligible rows are added or removed
            // while a long-running scan is in flight. Completed scans reconcile to the exact
            // number of units actually consumed, and running scans can only expand their total.
            $accounting_total = $done ? $processed_total : max( (int) $scan['total'], $processed_total );
            $phase_transition = 'full' === $type && $phase_done && ! $done;
            $finished_at = current_time( 'mysql', true );
            $update = array(
                'status'       => $done ? 'completed' : 'running',
                'total'        => $accounting_total,
                'processed'    => $processed_total,
                'issues_found' => $issues_total,
                'cursor_value' => $phase_transition ? 0 : (int) $result['cursor'],
                'updated_at'   => $finished_at,
            );
            if ( 'full' === $type ) {
                $update['payload'] = wp_json_encode( array( 'phase' => $phase_transition ? $next_phase : $phase ) );
            }
            if ( $done ) {
                $update['completed_at'] = $finished_at;
                $measured = $wpdb->get_var( "SELECT ROUND(AVG(score_total)) FROM {$t['seo_profiles']}" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                $update['health_score'] = null !== $measured ? max( 0, min( 100, (int) $measured ) ) : null;
                if ( 'full' === $type ) {
                    $next = $settings;
                    $next['last_full_scan_at'] = $finished_at;
                    $next['last_crawl_at'] = $finished_at;
                    update_option( 'k20ai_v3_settings', $next, false );
                } elseif ( 'crawl' === $type ) {
                    $next = $settings;
                    $next['last_crawl_at'] = $finished_at;
                    update_option( 'k20ai_v3_settings', $next, false );
                }
            }
            $wpdb->update( $t['seo_scans'], $update, array( 'id' => $scan_id ) );
            if ( ! $done ) {
                $this->schedule_scan( $scan_id );
            }
        } catch ( Throwable $error ) {
            $wpdb->update(
                $t['seo_scans'],
                array( 'status' => 'failed', 'last_error' => mb_substr( $error->getMessage(), 0, 2000 ), 'updated_at' => $now ),
                array( 'id' => $scan_id )
            );
        } finally {
            $this->release_scan_lock( $scan_id );
        }
    }

    private function acquire_scan_create_lock( string $type ): bool {
        $key = 'k20ai_scan_create_lock_' . sanitize_key( $type );
        $now = time();
        if ( add_option( $key, $now, '', false ) ) return true;
        $existing = (int) get_option( $key, 0 );
        if ( $existing > 0 && ( $now - $existing ) > 30 ) {
            delete_option( $key );
            return (bool) add_option( $key, $now, '', false );
        }
        return false;
    }

    private function release_scan_create_lock( string $type ): void {
        delete_option( 'k20ai_scan_create_lock_' . sanitize_key( $type ) );
    }

    private function acquire_scan_lock( int $scan_id, int $stale_after = 300 ): bool {
        $key = 'k20ai_scan_lock_' . $scan_id;
        $now = time();
        if ( add_option( $key, $now, '', false ) ) return true;
        $existing = (int) get_option( $key, 0 );
        $stale_after = max( 10, $stale_after );
        if ( $existing > 0 && ( $now - $existing ) >= $stale_after ) {
            delete_option( $key );
            return (bool) add_option( $key, $now, '', false );
        }
        return false;
    }

    private function release_scan_lock( int $scan_id ): void {
        delete_option( 'k20ai_scan_lock_' . $scan_id );
    }

    private function acquire_scan_schedule_lock( int $scan_id ): bool {
        $key = 'k20ai_scan_schedule_lock_' . $scan_id;
        $now = time();
        if ( add_option( $key, $now, '', false ) ) return true;
        $existing = (int) get_option( $key, 0 );
        if ( $existing > 0 && ( $now - $existing ) >= 10 ) {
            delete_option( $key );
            return (bool) add_option( $key, $now, '', false );
        }
        return false;
    }

    private function release_scan_schedule_lock( int $scan_id ): void {
        delete_option( 'k20ai_scan_schedule_lock_' . $scan_id );
    }

    private function has_pending_scan_action( int $scan_id ): bool {
        $hook  = 'k20ai_v3_process_scan';
        $args  = array( $scan_id );
        $group = 'k20-ai-press-scan';
        if ( function_exists( 'as_get_scheduled_actions' ) ) {
            $ids = as_get_scheduled_actions(
                array(
                    'hook'     => $hook,
                    'args'     => $args,
                    'group'    => $group,
                    'status'   => 'pending',
                    'per_page' => 1,
                ),
                'ids'
            );
            if ( ! empty( $ids ) ) return true;
        }
        return (bool) wp_next_scheduled( $hook, $args );
    }

    private function schedule_scan( int $scan_id, bool $force = false ): void {
        // add_option() is the atomic critical section. A pending-action lookup by itself is not
        // sufficient because browser assist, watchdog and background workers can race between
        // "check" and "enqueue". Do not use Action Scheduler's unique=true here: the currently
        // running action also counts as a duplicate and would block its own successor.
        if ( ! $this->acquire_scan_schedule_lock( $scan_id ) ) return;
        try {
            if ( $this->has_pending_scan_action( $scan_id ) ) return;
            $guard = 'k20ai_scan_wakeup_' . $scan_id;
            if ( ! $force && get_transient( $guard ) ) return;
            set_transient( $guard, 1, 3 );
            $scheduled = K20AI_Security::enqueue_unique_action(
                'k20ai_v3_process_scan',
                array( $scan_id ),
                0,
                'k20-ai-press-scan',
                false
            );
            if ( ! $scheduled && ! $this->has_pending_scan_action( $scan_id ) ) {
                delete_transient( $guard );
                wp_schedule_single_event( time() + 2, 'k20ai_v3_process_scan', array( $scan_id ) );
            }
        } finally {
            $this->release_scan_schedule_lock( $scan_id );
        }
    }

    private function scan_total( string $type ): int {
        $counts = $this->entity_counts();
        if ( 'product' === $type ) return $counts['products'];
        if ( in_array( $type, array( 'media', 'media-duplicates' ), true ) ) return $counts['media'];
        if ( 'taxonomy' === $type ) return $counts['taxonomies'];
        if ( 'content' === $type ) return $counts['content_items'];
        if ( 'links' === $type || 'crawl' === $type ) return $counts['total_content'];
        $entity_total = $counts['products'] + $counts['content_items'] + $counts['media'];
        // A full scan covers entity analysis + taxonomies + internal-link graph + same-host crawl.
        return $entity_total + $counts['taxonomies'] + ( 2 * $counts['total_content'] );
    }

    /** @return array<string,int|bool> */
    private function process_entity_batch( string $type, int $cursor, int $limit, bool $deep_media_hash = false, ?callable $progress_callback = null ): array {
        global $wpdb;
        $post_types = $this->post_types_for_scan( $type );
        if ( empty( $post_types ) ) {
            return array( 'processed' => 0, 'issues' => 0, 'cursor' => $cursor, 'done' => true );
        }
        $placeholders = implode( ',', array_fill( 0, count( $post_types ), '%s' ) );
        $params = array_merge( $post_types, array( $cursor, $limit ) );
        $sql = $wpdb->prepare(
            "SELECT ID,post_type FROM {$wpdb->posts} WHERE post_type IN ($placeholders) AND ((post_type='attachment' AND post_status='inherit') OR (post_type='product' AND post_status NOT IN ('trash','auto-draft')) OR (post_type NOT IN ('attachment','product') AND post_status='publish')) AND ID>%d ORDER BY ID ASC LIMIT %d",
            ...$params
        ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $rows = $wpdb->get_results( $sql, ARRAY_A );
        $issues = 0;
        $processed = 0;
        $last = $cursor;
        $started = microtime( true );
        $time_budget = 'media' === $type ? 2.8 : ( 'media-duplicates' === $type ? 5.0 : 6.0 );
        $last_heartbeat = $started;

        foreach ( (array) $rows as $row ) {
            $id = (int) $row['ID'];
            try {
                $evidence = $this->collect_post_evidence( $id, $deep_media_hash );
                if ( ! empty( $evidence ) ) {
                    $analysis = $this->analyzer->analyze( $evidence );
                    $issues += count( (array) $analysis['issues'] );
                    $this->persist_analysis( $evidence, $analysis );
                }
            } catch ( Throwable $item_error ) {
                // A single broken attachment must never poison the scan cursor forever.
                // Record the item as consumed and continue with the next batch.
                ++$issues;
            }
            ++$processed;
            $last = $id;
            $now_tick = microtime( true );
            if ( $progress_callback && ( 0 === ( $processed % 20 ) || ( $now_tick - $last_heartbeat ) >= 0.35 ) ) {
                $progress_callback( $processed, $issues, $last );
                $last_heartbeat = $now_tick;
            }
            if ( ( $now_tick - $started ) >= $time_budget ) break;
        }

        if ( $progress_callback && $processed > 0 ) {
            $progress_callback( $processed, $issues, $last );
        }
        // If we stopped early because the time budget was reached, there are still rows to do.
        $done = $processed === count( $rows ) && count( $rows ) < $limit;
        return array( 'processed' => $processed, 'issues' => $issues, 'cursor' => $last, 'done' => $done );
    }

    /** @return array<int,string> */
    private function post_types_for_scan( string $type ): array {
        if ( 'product' === $type ) return post_type_exists( 'product' ) ? array( 'product' ) : array();
        if ( in_array( $type, array( 'media', 'media-duplicates' ), true ) ) return array( 'attachment' );
        $content = $this->public_content_post_types();
        if ( 'content' === $type ) return $content;
        return array_values( array_unique( array_merge( post_type_exists( 'product' ) ? array( 'product' ) : array(), $content, array( 'attachment' ) ) ) );
    }

    /**
     * Return every front-end queryable content post type so scans cover posts, pages,
     * news and plugin/theme custom content without pulling editor/system-only records.
     *
     * @return array<int,string>
     */
    private function public_content_post_types(): array {
        $content = array();
        $objects = get_post_types( array( 'public' => true ), 'objects' );
        foreach ( (array) $objects as $slug => $object ) {
            if ( in_array( $slug, array( 'product', 'attachment' ), true ) ) continue;
            if ( ! in_array( $slug, array( 'post', 'page' ), true ) && empty( $object->publicly_queryable ) ) continue;
            $content[] = (string) $slug;
        }
        foreach ( array( 'post', 'page' ) as $builtin ) {
            if ( post_type_exists( $builtin ) ) $content[] = $builtin;
        }
        return array_values( array_unique( $content ) );
    }

    private function is_news_post_type( string $post_type ): bool {
        $object = get_post_type_object( $post_type );
        $label = strtolower( (string) ( $object->label ?? '' ) );
        return str_contains( strtolower( $post_type ), 'news' )
            || str_contains( strtolower( $post_type ), 'press' )
            || str_contains( $label, 'news' )
            || str_contains( $label, 'خبر' );
    }

    private function content_kind_for_post_type( string $post_type ): string {
        if ( 'page' === $post_type ) return 'page';
        if ( $this->is_news_post_type( $post_type ) ) return 'news';
        return 'content_post';
    }

    /** @return array<string,mixed> */
    public function collect_post_evidence( int $id, bool $deep_media_hash = true ): array {
        $post = get_post( $id );
        if ( ! $post ) return array();
        if ( 'attachment' === $post->post_type ) return $this->collect_media_evidence( $id, $deep_media_hash );
        if ( 'product' === $post->post_type && function_exists( 'wc_get_product' ) ) return $this->collect_product_evidence( $id );

        $kind = $this->content_kind_for_post_type( (string) $post->post_type );
        $post_type_object = get_post_type_object( (string) $post->post_type );
        $public_indexable = 'publish' === $post->post_status && ( in_array( $post->post_type, array( 'post', 'page' ), true ) || ( $post_type_object && ! empty( $post_type_object->publicly_queryable ) ) );
        $url = $public_indexable ? get_permalink( $id ) : '';
        $content = (string) $post->post_content;
        $links = $this->extract_internal_links( $content, $url );
        $modified = get_post_modified_time( 'U', true, $post );
        $seo_title = $this->seo_meta( $id, 'title', $post->post_title );
        $description = $this->seo_meta( $id, 'description', $post->post_excerpt ?: wp_trim_words( wp_strip_all_tags( $content ), 30, '' ) );
        $focus_keyword = (string) get_post_meta( $id, '_k20ai_focus_keyword', true );
        if ( '' === trim( $focus_keyword ) && defined( 'WPSEO_VERSION' ) ) $focus_keyword = (string) get_post_meta( $id, '_yoast_wpseo_focuskw', true );
        $canonical = $this->seo_meta( $id, 'canonical', $url );
        $noindex = (bool) get_post_meta( $id, '_yoast_wpseo_meta-robots-noindex', true );
        $featured = (int) get_post_thumbnail_id( $id );
        $payload = array(
            'kind'                    => $kind,
            'entity_id'               => $id,
            'entity_key'              => 'post:' . $id,
            'post_type'               => $post->post_type,
            'status'                  => $post->post_status,
            'public_indexable'        => $public_indexable,
            'title'                   => $post->post_title,
            'seo_title'               => $seo_title,
            'meta_description'        => $description,
            'focus_keyword'           => $focus_keyword,
            'excerpt'                 => $post->post_excerpt,
            'content'                 => $content,
            'url'                     => $url,
            'canonical'               => $canonical,
            'noindex'                 => $noindex,
            'author_id'               => (int) $post->post_author,
            'featured_image_id'       => $featured,
            'image_ids'               => $featured ? array( $featured ) : array(),
            'word_count'              => $this->word_count( $content ),
            'internal_outbound_count' => count( $links ),
            'internal_inbound_count'  => $this->count_inbound_links( $id ),
            'modified_at'             => K20AI_Security::normalize_mysql_datetime_to_iso( $post->post_modified_gmt, $post->post_modified ),
            'stale_days'              => $modified ? max( 0, (int) floor( ( time() - $modified ) / DAY_IN_SECONDS ) ) : null,
            'schema_types'            => $this->detected_schema_types( $id, $kind ),
        );
        return $payload;
    }

    /** @return array<string,mixed> */
    private function collect_product_evidence( int $id ): array {
        $product = wc_get_product( $id );
        if ( ! $product ) return array();
        $post = get_post( $id );
        $image_ids = array_values( array_unique( array_filter( array_merge( array( $product->get_image_id() ), $product->get_gallery_image_ids() ) ) ) );
        $alt_count = 0;
        foreach ( $image_ids as $image_id ) {
            if ( trim( (string) get_post_meta( $image_id, '_wp_attachment_image_alt', true ) ) !== '' ) ++$alt_count;
        }
        $category_terms = wp_get_post_terms( $id, 'product_cat' );
        if ( is_wp_error( $category_terms ) ) $category_terms = array();
        $categories = array_map( static fn( $term ) => (string) $term->name, $category_terms );
        $category_ids = array_map( static fn( $term ) => (int) $term->term_id, $category_terms );
        $brand = $this->product_brand( $id );
        $brand_taxonomy = $this->brand_taxonomy();
        $brand_terms = $brand_taxonomy ? wp_get_post_terms( $id, $brand_taxonomy ) : array();
        if ( is_wp_error( $brand_terms ) ) $brand_terms = array();
        $brand_term_ids = array_map( static fn( $term ) => (int) $term->term_id, $brand_terms );
        $attrs = array();
        $attribute_detail = array();
        foreach ( (array) $product->get_attributes() as $attribute ) {
            if ( ! is_object( $attribute ) || ! method_exists( $attribute, 'get_name' ) ) continue;
            $name = (string) $attribute->get_name();
            $attrs[] = $name;
            $is_taxonomy = method_exists( $attribute, 'is_taxonomy' ) && $attribute->is_taxonomy();
            $options = method_exists( $attribute, 'get_options' ) ? (array) $attribute->get_options() : array();
            $values = array();
            if ( $is_taxonomy && taxonomy_exists( $name ) ) {
                $terms = wp_get_post_terms( $id, $name );
                if ( ! is_wp_error( $terms ) ) {
                    foreach ( $terms as $term ) $values[] = array( 'id' => (int) $term->term_id, 'label' => (string) $term->name );
                }
            } else {
                foreach ( $options as $option ) $values[] = array( 'id' => null, 'label' => (string) $option );
            }
            $attribute_detail[] = array(
                'taxonomy' => $name,
                'label' => function_exists( 'wc_attribute_label' ) ? wc_attribute_label( $name ) : $name,
                'taxonomy_based' => $is_taxonomy,
                'variation' => method_exists( $attribute, 'get_variation' ) ? (bool) $attribute->get_variation() : false,
                'visible' => method_exists( $attribute, 'get_visible' ) ? (bool) $attribute->get_visible() : true,
                'values' => $values,
            );
        }
        $image_items = array();
        foreach ( $image_ids as $image_id ) {
            $image_items[] = array(
                'id' => (int) $image_id,
                'thumbnail' => (string) wp_get_attachment_image_url( $image_id, 'thumbnail' ),
                'url' => (string) wp_get_attachment_image_url( $image_id, 'large' ),
                'alt' => (string) get_post_meta( $image_id, '_wp_attachment_image_alt', true ),
                'title' => (string) get_the_title( $image_id ),
            );
        }
        $short_description = (string) $product->get_short_description();
        $description = (string) $product->get_description();
        $content = trim( $short_description . "\n" . $description );
        $public_indexable = 'publish' === $product->get_status();
        $url = $public_indexable ? get_permalink( $id ) : '';
        $gtin_raw = method_exists( $product, 'get_global_unique_id' ) ? (string) $product->get_global_unique_id() : '';
        if ( '' === trim( $gtin_raw ) ) $gtin_raw = (string) $this->first_meta( $id, array( '_global_unique_id', '_wc_gtin', '_gtin', 'gtin' ) );
        $gtin = K20AI_Data_Integrity::normalize_gtin( $gtin_raw );
        $mpn = $this->first_meta( $id, array( '_mpn', 'mpn', '_manufacturer_part_number' ) );
        $model = $this->first_meta( $id, array( '_model', 'model', '_product_model' ) );
        $modified = $post ? get_post_modified_time( 'U', true, $post ) : null;
        $links = $this->extract_internal_links( $content, $url );
        return array(
            'kind'                    => 'product',
            'entity_id'               => $id,
            'entity_key'              => 'product:' . $id,
            'post_type'               => 'product',
            'status'                  => $product->get_status(),
            'public_indexable'        => $public_indexable,
            'title'                   => $product->get_name(),
            'seo_title'               => $this->seo_meta( $id, 'title', $product->get_name() ),
            'meta_description'        => $this->seo_meta( $id, 'description', wp_trim_words( wp_strip_all_tags( $product->get_short_description() ), 30, '' ) ),
            'focus_keyword'           => (string) ( get_post_meta( $id, '_k20ai_focus_keyword', true ) ?: ( defined( 'WPSEO_VERSION' ) ? get_post_meta( $id, '_yoast_wpseo_focuskw', true ) : '' ) ),
            'short_description'       => $short_description,
            'description'             => $description,
            'content'                 => $content,
            'url'                     => $url,
            'canonical'               => $this->seo_meta( $id, 'canonical', $url ),
            'noindex'                 => (bool) get_post_meta( $id, '_yoast_wpseo_meta-robots-noindex', true ),
            'sku'                     => $product->get_sku(),
            'gtin'                    => $gtin,
            'gtin_raw'                => '' !== trim( $gtin_raw ) ? $gtin_raw : null,
            'gtin_valid'              => null !== $gtin,
            'mpn'                     => $mpn,
            'model'                   => $model,
            'brand'                   => $brand,
            'weight'                  => $product->get_weight(),
            'length'                  => $product->get_length(),
            'width'                   => $product->get_width(),
            'height'                  => $product->get_height(),
            'categories'              => array_values( (array) $categories ),
            'category_ids'            => array_values( $category_ids ),
            'brand_term_ids'          => array_values( $brand_term_ids ),
            'attributes'              => array_filter( $attrs ),
            'attribute_detail'        => $attribute_detail,
            'image_ids'               => $image_ids,
            'image_items'             => $image_items,
            'image_alt_count'         => $alt_count,
            'word_count'              => $this->word_count( $content ),
            'price'                   => $product->get_price(),
            'regular_price'           => $product->get_regular_price(),
            'sale_price'              => $product->get_sale_price(),
            'stock_status'            => $product->get_stock_status(),
            'stock_quantity'          => $product->get_stock_quantity(),
            'is_variable'             => $product->is_type( 'variable' ),
            'variation_count'         => $product->is_type( 'variable' ) ? count( $product->get_children() ) : 0,
            'internal_outbound_count' => count( $links ),
            'internal_inbound_count'  => $this->count_inbound_links( $id ),
            'modified_at'             => $post ? K20AI_Security::normalize_mysql_datetime_to_iso( $post->post_modified_gmt, $post->post_modified ) : null,
            'stale_days'              => $modified ? max( 0, (int) floor( ( time() - $modified ) / DAY_IN_SECONDS ) ) : null,
            'schema_types'            => $this->detected_schema_types( $id, 'product' ),
        );
    }

    /** @return array<string,mixed> */
    private function collect_media_evidence( int $id, bool $deep_hash = true ): array {
        global $wpdb;
        $post = get_post( $id );
        if ( ! $post ) return array();
        $meta = wp_get_attachment_metadata( $id );
        $path = get_attached_file( $id );

        // WordPress stores filesize in attachment metadata on modern installs. Prefer it so
        // the normal media audit does not stat thousands of files on network/shared storage.
        $filesize = is_array( $meta ) && ! empty( $meta['filesize'] ) ? (int) $meta['filesize'] : null;
        if ( ! $filesize && $path && is_file( $path ) ) {
            $measured_size = @filesize( $path );
            $filesize = false !== $measured_size ? (int) $measured_size : null;
        }

        $modified_at = K20AI_Security::normalize_mysql_datetime_to_iso( $post->post_modified_gmt, $post->post_modified );
        $file_hash = null;
        $file_mtime = null;

        // Hash work belongs exclusively to the dedicated duplicate scan. The normal Images/ALT
        // scan must never query the hash cache, previous profile, file mtime or read file bytes.
        if ( $deep_hash && $path && is_readable( $path ) && $filesize ) {
            $mtime = @filemtime( $path );
            $file_mtime = false !== $mtime ? (int) $mtime : 0;
            $sig = hash( 'sha256', (string) $path . '|' . (string) $filesize . '|' . (string) $file_mtime );
            $cached_sig = (string) get_post_meta( $id, '_k20ai_media_hash_sig', true );
            $cached_hash = (string) get_post_meta( $id, '_k20ai_media_hash_sha256', true );
            if ( $cached_sig === $sig && preg_match( '/^[a-f0-9]{64}$/D', $cached_hash ) ) {
                $file_hash = $cached_hash;
            }

            if ( ! $file_hash ) {
                $t = K20AI_Database::tables();
                $previous_raw = $wpdb->get_var( $wpdb->prepare( "SELECT payload FROM {$t['seo_profiles']} WHERE entity_kind='media' AND entity_id=%d ORDER BY id DESC LIMIT 1", $id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                $previous = $this->json( $previous_raw );
                $previous_hash = (string) ( $previous['file_hash'] ?? '' );
                $same_size = isset( $previous['filesize'] ) && (int) $previous['filesize'] === (int) $filesize;
                $same_modified = ! empty( $previous['modified_at'] ) && (string) $previous['modified_at'] === (string) $modified_at;
                if ( $same_size && $same_modified && preg_match( '/^[a-f0-9]{64}$/D', $previous_hash ) ) {
                    $file_hash = $previous_hash;
                }
            }

            if ( ! $file_hash && $filesize <= 12 * MB_IN_BYTES ) {
                $file_hash = hash_file( 'sha256', $path ) ?: null;
            }
            if ( $file_hash ) {
                update_post_meta( $id, '_k20ai_media_hash_sig', $sig );
                update_post_meta( $id, '_k20ai_media_hash_sha256', $file_hash );
            }
        }

        $url = wp_get_attachment_url( $id );
        $alt = (string) get_post_meta( $id, '_wp_attachment_image_alt', true );
        return array(
            'kind'         => 'media',
            'entity_id'    => $id,
            'entity_key'   => 'media:' . $id,
            'status'       => $post->post_status,
            'public_indexable' => false,
            'title'        => $post->post_title,
            'url'          => $url,
            'alt'          => $alt,
            'mime_type'    => $post->post_mime_type,
            'width'        => is_array( $meta ) ? (int) ( $meta['width'] ?? 0 ) : 0,
            'height'       => is_array( $meta ) ? (int) ( $meta['height'] ?? 0 ) : 0,
            'filesize'     => $filesize,
            'file_mtime'   => $file_mtime ?: null,
            'file_hash'    => $file_hash,
            'parent_id'    => (int) $post->post_parent,
            'modified_at'  => $modified_at,
            'stale_days'   => null,
            'canonical'    => $url,
        );
    }

    /** @return array<string,int|bool> */
    private function process_taxonomy_batch( int $cursor, int $limit ): array {
        global $wpdb;
        $taxonomies = $this->public_taxonomy_names();
        if ( empty( $taxonomies ) ) return array( 'processed' => 0, 'issues' => 0, 'cursor' => $cursor, 'done' => true );
        $placeholders = implode( ',', array_fill( 0, count( $taxonomies ), '%s' ) );
        $params = array_merge( $taxonomies, array( $cursor, $limit ) );
        // Use term_taxonomy_id as stable global cursor across taxonomies.
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT tt.term_taxonomy_id,tt.term_id,tt.taxonomy,tt.count,t.name,t.slug,t.term_group
                 FROM {$wpdb->term_taxonomy} tt INNER JOIN {$wpdb->terms} t ON t.term_id=tt.term_id
                 WHERE tt.taxonomy IN ($placeholders) AND tt.term_taxonomy_id>%d ORDER BY tt.term_taxonomy_id ASC LIMIT %d",
                ...$params
            ),
            ARRAY_A
        );
        $issues = 0;
        $last = $cursor;
        foreach ( (array) $rows as $row ) {
            $taxonomy = get_taxonomy( $row['taxonomy'] );
            $last = (int) $row['term_taxonomy_id'];
            if ( ! $taxonomy || empty( $taxonomy->public ) ) continue;
            $term = get_term( (int) $row['term_id'], $row['taxonomy'] );
            if ( ! $term || is_wp_error( $term ) ) continue;
            $kind = $this->taxonomy_kind( $row['taxonomy'] );
            $url = get_term_link( $term );
            if ( is_wp_error( $url ) ) $url = '';
            $description = (string) $term->description;
            $evidence = array(
                'kind'             => $kind,
                'entity_id'        => (int) $row['term_taxonomy_id'],
                'entity_key'       => 'term:' . $row['taxonomy'] . ':' . $row['term_id'],
                'taxonomy'         => $row['taxonomy'],
                'term_id'          => (int) $row['term_id'],
                'status'           => 'publish',
                'public_indexable' => true,
                'title'            => $term->name,
                'seo_title'        => $term->name,
                'meta_description' => wp_trim_words( wp_strip_all_tags( $description ), 30, '' ),
                'content'          => $description,
                'word_count'       => $this->word_count( $description ),
                'url'              => $url,
                'canonical'        => $url,
                'product_count'    => (int) $term->count,
                'internal_inbound_count' => 0,
            );
            $analysis = $this->analyzer->analyze( $evidence );
            // Add taxonomy-specific evidence-aware issue without fabricating data.
            if ( in_array( $kind, array( 'category', 'brand' ), true ) && $evidence['word_count'] < 25 ) {
                $analysis['issues'][] = array(
                    'rule_code' => 'taxonomy.description.short', 'severity' => 'warning', 'component' => 'content', 'penalty' => 12,
                    'title' => 'توضیح Taxonomy کافی نیست', 'description' => 'برای صفحه دسته یا برند، توضیح منحصربه‌فرد و کاربردی ثبت شود.',
                    'suggested_fix' => array( 'minimum_words' => 25 ),
                );
                $analysis['content'] = max( 0, $analysis['content'] - 12 );
                $analysis['total'] = max( 0, $analysis['total'] - 4 );
            }
            $issues += count( (array) $analysis['issues'] );
            $this->persist_analysis( $evidence, $analysis );
        }
        return array( 'processed' => count( $rows ), 'issues' => $issues, 'cursor' => $last, 'done' => count( $rows ) < $limit );
    }

    private function taxonomy_kind( string $taxonomy ): string {
        if ( in_array( $taxonomy, array( 'product_cat', 'category' ), true ) || str_contains( $taxonomy, 'cat' ) ) return 'category';
        if ( str_contains( $taxonomy, 'brand' ) ) return 'brand';
        if ( str_starts_with( $taxonomy, 'pa_' ) || str_contains( $taxonomy, 'attribute' ) ) return 'attribute';
        return 'taxonomy';
    }

    /** @return array<string,int|bool> */
    private function process_links_batch( int $cursor, int $limit ): array {
        global $wpdb;
        $t = K20AI_Database::tables();
        $types = array_values( array_diff( $this->post_types_for_scan( 'full' ), array( 'attachment' ) ) );
        if ( empty( $types ) ) return array( 'processed' => 0, 'issues' => 0, 'cursor' => $cursor, 'done' => true );
        $placeholders = implode( ',', array_fill( 0, count( $types ), '%s' ) );
        $params = array_merge( $types, array( $cursor, $limit ) );
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT ID,post_type,post_content FROM {$wpdb->posts} WHERE post_type IN ($placeholders) AND post_status='publish' AND ID>%d ORDER BY ID ASC LIMIT %d",
            ...$params
        ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $last = $cursor;
        foreach ( (array) $rows as $row ) {
            $id = (int) $row['ID'];
            $last = $id;
            $wpdb->delete( $t['seo_links'], array( 'source_id' => $id, 'source_kind' => $row['post_type'] ) );
            $source_url = get_permalink( $id );
            foreach ( $this->extract_internal_links( (string) $row['post_content'], $source_url ) as $link ) {
                $target_id = url_to_postid( $link['url'] );
                $wpdb->insert( $t['seo_links'], array(
                    'source_kind'    => $row['post_type'],
                    'source_id'      => $id,
                    'target_url'     => $link['url'],
                    'target_post_id' => $target_id ?: null,
                    'anchor_text'    => mb_substr( $link['anchor'], 0, 255 ),
                    'relation'       => 'existing',
                    'status'         => 'active',
                    'discovered_at'  => current_time( 'mysql', true ),
                    'updated_at'     => current_time( 'mysql', true ),
                ) );
            }
        }
        return array( 'processed' => count( $rows ), 'issues' => 0, 'cursor' => $last, 'done' => count( $rows ) < $limit );
    }

    /**
     * Persist partial progress so a hosting timeout cannot make the same crawl batch repeat forever.
     *
     * @param array<string,mixed> $scan
     */
    private function scan_progress_heartbeat( int $scan_id, array $scan ): callable {
        global $wpdb;
        $t = K20AI_Database::tables();
        $base_processed = (int) ( $scan['processed'] ?? 0 );
        $base_issues    = (int) ( $scan['issues_found'] ?? 0 );
        $base_total     = (int) ( $scan['total'] ?? 0 );
        return static function( int $partial_processed, int $partial_issues, int $partial_cursor ) use ( $wpdb, $t, $scan_id, $base_processed, $base_issues, $base_total ): void {
            $processed = $base_processed + $partial_processed;
            $wpdb->update(
                $t['seo_scans'],
                array(
                    'status'       => 'running',
                    'total'        => max( $base_total, $processed ),
                    'processed'    => $processed,
                    'issues_found' => $base_issues + $partial_issues,
                    'cursor_value' => $partial_cursor,
                    'updated_at'   => current_time( 'mysql', true ),
                ),
                array( 'id' => $scan_id )
            );
        };
    }

    /** @return array<string,int|bool> */
    private function process_crawl_batch( int $scan_id, int $cursor, int $limit, ?callable $progress_callback = null ): array {
        global $wpdb;
        $types = array_values( array_diff( $this->post_types_for_scan( 'full' ), array( 'attachment' ) ) );
        if ( empty( $types ) ) return array( 'processed' => 0, 'issues' => 0, 'cursor' => $cursor, 'done' => true );
        $placeholders = implode( ',', array_fill( 0, count( $types ), '%s' ) );
        $params = array_merge( $types, array( $cursor, $limit ) );
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT ID,post_type FROM {$wpdb->posts} WHERE post_type IN ($placeholders) AND post_status='publish' AND ID>%d ORDER BY ID ASC LIMIT %d",
            ...$params
        ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $issues = 0;
        $processed = 0;
        $last = $cursor;
        $started = microtime( true );
        $time_budget = 7.0;
        foreach ( (array) $rows as $row ) {
            $last = (int) $row['ID'];
            $url = get_permalink( $last );
            if ( $url ) {
                $observation = $this->crawl_url( $url, $scan_id );
                if ( is_wp_error( $observation ) ) {
                    ++$issues;
                } elseif ( empty( $observation['indexable'] ) || (int) ( $observation['http_status'] ?? 0 ) >= 400 ) {
                    ++$issues;
                }
            }
            ++$processed;
            if ( $progress_callback ) $progress_callback( $processed, $issues, $last );
            if ( ( microtime( true ) - $started ) >= $time_budget ) break;
        }
        $done = $processed === count( $rows ) && count( $rows ) < $limit;
        return array( 'processed' => $processed, 'issues' => $issues, 'cursor' => $last, 'done' => $done );
    }

    /** @return array<string,mixed>|WP_Error */
    public function crawl_url( string $url, ?int $scan_id = null ): array|WP_Error {
        global $wpdb;
        $t = K20AI_Database::tables();
        $url = esc_url_raw( $url );
        if ( ! $this->is_same_host_url( $url ) ) {
            return new WP_Error( 'crawl_scope', __( 'برای امنیت، خزش فقط روی دامنه همین سایت مجاز است.', 'k20-ai-press' ), array( 'status' => 422 ) );
        }
        $start = microtime( true );
        $response = wp_safe_remote_get( $url, array(
            'timeout' => 5,
            'redirection' => 3,
            'headers' => array( 'User-Agent' => 'K20AI-Press-Audit/' . K20AI_PRESS_VERSION . '; ' . home_url() ),
        ) );
        $elapsed = (int) round( ( microtime( true ) - $start ) * 1000 );
        if ( is_wp_error( $response ) ) return $response;
        $status = (int) wp_remote_retrieve_response_code( $response );
        $content_type = (string) wp_remote_retrieve_header( $response, 'content-type' );
        $body = (string) wp_remote_retrieve_body( $response );
        // Protect admin requests from huge responses.
        if ( strlen( $body ) > 3 * MB_IN_BYTES ) $body = substr( $body, 0, 3 * MB_IN_BYTES );
        $parsed = $this->parse_html_signals( $body, $url );
        $indexable = $status >= 200 && $status < 400 && ! str_contains( strtolower( $parsed['robots'] ), 'noindex' );
        $row = array(
            'scan_id'          => $scan_id,
            'url_hash'         => hash( 'sha256', $url ),
            'url'              => $url,
            'http_status'      => $status ?: null,
            'response_time_ms' => $elapsed,
            'content_type'     => mb_substr( $content_type, 0, 128 ),
            'title'            => $parsed['title'],
            'canonical'        => $parsed['canonical'],
            'robots'           => $parsed['robots'],
            'schema_types'     => implode( ',', $parsed['schema_types'] ),
            'indexable'        => $indexable ? 1 : 0,
            'payload'          => wp_json_encode( array( 'h1_count' => $parsed['h1_count'], 'meta_description' => $parsed['meta_description'], 'bytes' => strlen( $body ) ) ),
            'fetched_at'       => current_time( 'mysql', true ),
        );
        $existing = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t['seo_crawl']} WHERE url_hash=%s", $row['url_hash'] ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        if ( $existing ) $wpdb->update( $t['seo_crawl'], $row, array( 'id' => (int) $existing ) );
        else $wpdb->insert( $t['seo_crawl'], $row );
        return $row;
    }

    /** @return array<string,mixed> */
    private function parse_html_signals( string $html, string $url ): array {
        $result = array( 'title' => '', 'canonical' => '', 'robots' => '', 'schema_types' => array(), 'h1_count' => 0, 'meta_description' => '' );
        if ( '' === $html ) return $result;
        if ( class_exists( 'DOMDocument' ) ) {
            $dom = new DOMDocument();
            libxml_use_internal_errors( true );
            $loaded = $dom->loadHTML( '<?xml encoding="utf-8" ?>' . $html );
            libxml_clear_errors();
            if ( $loaded ) {
                $titles = $dom->getElementsByTagName( 'title' );
                if ( $titles->length ) $result['title'] = trim( $titles->item( 0 )->textContent );
                $result['h1_count'] = $dom->getElementsByTagName( 'h1' )->length;
                foreach ( $dom->getElementsByTagName( 'link' ) as $link ) {
                    if ( 'canonical' === strtolower( trim( (string) $link->getAttribute( 'rel' ) ) ) ) {
                        $result['canonical'] = esc_url_raw( $link->getAttribute( 'href' ) );
                        break;
                    }
                }
                foreach ( $dom->getElementsByTagName( 'meta' ) as $meta ) {
                    $name = strtolower( trim( (string) $meta->getAttribute( 'name' ) ) );
                    if ( 'robots' === $name ) $result['robots'] = trim( (string) $meta->getAttribute( 'content' ) );
                    if ( 'description' === $name ) $result['meta_description'] = trim( (string) $meta->getAttribute( 'content' ) );
                }
                foreach ( $dom->getElementsByTagName( 'script' ) as $script ) {
                    if ( 'application/ld+json' !== strtolower( trim( (string) $script->getAttribute( 'type' ) ) ) ) continue;
                    $json = json_decode( trim( $script->textContent ), true );
                    foreach ( $this->schema_types_from_json( $json ) as $type ) $result['schema_types'][] = $type;
                }
            }
        } else {
            if ( preg_match( '/<title[^>]*>(.*?)<\/title>/is', $html, $m ) ) $result['title'] = trim( wp_strip_all_tags( $m[1] ) );
            if ( preg_match( '/<link[^>]+rel=["\']canonical["\'][^>]+href=["\']([^"\']+)/i', $html, $m ) ) $result['canonical'] = esc_url_raw( $m[1] );
            $result['h1_count'] = preg_match_all( '/<h1\b/i', $html );
        }
        $result['schema_types'] = array_values( array_unique( array_filter( $result['schema_types'] ) ) );
        if ( '' === $result['canonical'] ) $result['canonical'] = $url;
        return $result;
    }

    /** @return array<int,string> */
    private function schema_types_from_json( mixed $json ): array {
        if ( ! is_array( $json ) ) return array();
        $types = array();
        if ( isset( $json['@type'] ) ) {
            foreach ( (array) $json['@type'] as $type ) $types[] = sanitize_text_field( (string) $type );
        }
        foreach ( $json as $value ) {
            if ( is_array( $value ) ) $types = array_merge( $types, $this->schema_types_from_json( $value ) );
        }
        return array_values( array_unique( $types ) );
    }

    /** @return array<int,array<string,string>> */
    private function extract_internal_links( string $html, string $source_url = '' ): array {
        $links = array();
        $home_host = strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
        if ( preg_match_all( '/<a\s[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)<\/a>/is', $html, $matches, PREG_SET_ORDER ) ) {
            foreach ( $matches as $match ) {
                $href = html_entity_decode( trim( $match[1] ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
                if ( str_starts_with( $href, '#' ) || str_starts_with( $href, 'mailto:' ) || str_starts_with( $href, 'tel:' ) || str_starts_with( $href, 'javascript:' ) ) continue;
                if ( str_starts_with( $href, '/' ) ) $href = home_url( $href );
                $host = strtolower( (string) wp_parse_url( $href, PHP_URL_HOST ) );
                if ( $host && $home_host && preg_replace( '/^www\./', '', $host ) !== preg_replace( '/^www\./', '', $home_host ) ) continue;
                $safe = esc_url_raw( $href );
                if ( ! $safe || ( $source_url && untrailingslashit( $safe ) === untrailingslashit( $source_url ) ) ) continue;
                $links[] = array( 'url' => $safe, 'anchor' => trim( wp_strip_all_tags( $match[2] ) ) );
            }
        }
        return $links;
    }

    private function count_inbound_links( int $post_id ): int {
        global $wpdb;
        $t = K20AI_Database::tables();
        if ( ! $this->table_exists( $t['seo_links'] ) ) return 0;
        return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t['seo_links']} WHERE target_post_id=%d AND status='active'", $post_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
    }

    /** @param array<string,mixed> $evidence @param array<string,mixed> $analysis */
    private function persist_analysis( array $evidence, array $analysis ): void {
        global $wpdb;
        $t = K20AI_Database::tables();
        $now = current_time( 'mysql', true );
        $entity_kind = sanitize_key( (string) $evidence['kind'] );
        $entity_id = (int) $evidence['entity_id'];
        $entity_key = sanitize_text_field( (string) $evidence['entity_key'] );
        $payload = wp_json_encode( $evidence, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
        $profile = array(
            'entity_kind'     => $entity_kind,
            'entity_id'       => $entity_id,
            'entity_key'      => $entity_key,
            'url'             => esc_url_raw( (string) ( $evidence['url'] ?? '' ) ),
            'title'           => sanitize_text_field( (string) ( $evidence['title'] ?? '' ) ),
            'score_total'     => (int) $analysis['total'],
            'score_technical' => (int) $analysis['technical'],
            'score_content'   => (int) $analysis['content'],
            'score_schema'    => (int) $analysis['schema'],
            'score_media'     => (int) $analysis['media'],
            'score_commerce'  => (int) $analysis['commerce'],
            'payload'         => $payload,
            'content_hash'    => hash( 'sha256', (string) $payload ),
            'analyzed_at'     => $now,
            'updated_at'      => $now,
        );
        $existing_id = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t['seo_profiles']} WHERE entity_key=%s LIMIT 1", $entity_key ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        if ( $existing_id ) $wpdb->update( $t['seo_profiles'], $profile, array( 'id' => $existing_id ) );
        else $wpdb->insert( $t['seo_profiles'], $profile );

        $active_keys = array();
        $active_recommendation_keys = array();
        foreach ( (array) $analysis['issues'] as $issue ) {
            $code = sanitize_key( str_replace( '.', '_', (string) $issue['rule_code'] ) );
            // Keep original code in row but deterministic hash in key.
            $issue_key = hash( 'sha256', $entity_key . '|' . (string) $issue['rule_code'] );
            $active_keys[] = $issue_key;
            $issue_row = array(
                'issue_key'      => $issue_key,
                'entity_kind'    => $entity_kind,
                'entity_id'      => $entity_id,
                'rule_code'      => (string) $issue['rule_code'],
                'severity'       => in_array( $issue['severity'], array( 'critical', 'warning', 'info' ), true ) ? $issue['severity'] : 'info',
                'component'      => sanitize_key( (string) $issue['component'] ),
                'title'          => sanitize_text_field( (string) $issue['title'] ),
                'description'    => sanitize_textarea_field( (string) $issue['description'] ),
                'evidence'       => wp_json_encode( $this->issue_evidence( $evidence, $issue ) ),
                'suggested_fix'  => wp_json_encode( $issue['suggested_fix'] ?? array() ),
                'status'         => 'open',
                'last_seen_at'   => $now,
                'resolved_at'    => null,
            );
            $existing_issue = $wpdb->get_row( $wpdb->prepare( "SELECT id,first_seen_at FROM {$t['seo_issues']} WHERE issue_key=%s", $issue_key ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            if ( $existing_issue ) {
                $wpdb->update( $t['seo_issues'], $issue_row, array( 'id' => (int) $existing_issue['id'] ) );
            } else {
                $issue_row['first_seen_at'] = $now;
                $wpdb->insert( $t['seo_issues'], $issue_row );
            }
            $active_recommendation_keys[] = hash( 'sha256', $entity_key . '|' . (string) $issue['rule_code'] . '|recommendation' );
            $this->upsert_recommendation( $evidence, $analysis, $issue );
        }
        // Any previously open issue/recommendation not observed in the current analysis is resolved.
        if ( empty( $active_keys ) ) {
            $wpdb->query( $wpdb->prepare( "UPDATE {$t['seo_issues']} SET status='resolved',resolved_at=%s,last_seen_at=%s WHERE entity_kind=%s AND entity_id=%d AND status='open'", $now, $now, $entity_kind, $entity_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        } else {
            $quoted = implode( ',', array_fill( 0, count( $active_keys ), '%s' ) );
            $params = array_merge( array( $now, $now, $entity_kind, $entity_id ), $active_keys );
            $wpdb->query( $wpdb->prepare( "UPDATE {$t['seo_issues']} SET status='resolved',resolved_at=%s,last_seen_at=%s WHERE entity_kind=%s AND entity_id=%d AND status='open' AND issue_key NOT IN ($quoted)", ...$params ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        }
        if ( empty( $active_recommendation_keys ) ) {
            $wpdb->query( $wpdb->prepare( "UPDATE {$t['seo_recommendations']} SET status='resolved',updated_at=%s WHERE entity_kind=%s AND entity_id=%d AND status='open'", $now, $entity_kind, $entity_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        } else {
            $quoted = implode( ',', array_fill( 0, count( $active_recommendation_keys ), '%s' ) );
            $params = array_merge( array( $now, $entity_kind, $entity_id ), $active_recommendation_keys );
            $wpdb->query( $wpdb->prepare( "UPDATE {$t['seo_recommendations']} SET status='resolved',updated_at=%s WHERE entity_kind=%s AND entity_id=%d AND status='open' AND recommendation_key NOT IN ($quoted)", ...$params ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        }
    }

    /** @return array<string,mixed> */
    private function issue_evidence( array $evidence, array $issue ): array {
        $keys = array( 'entity_key','url','title','sku','brand','categories','word_count','price','stock_status','image_ids','image_alt_count','modified_at' );
        $snapshot = array();
        foreach ( $keys as $key ) if ( array_key_exists( $key, $evidence ) ) $snapshot[ $key ] = $evidence[ $key ];
        if ( isset( $issue['evidence'] ) ) $snapshot['rule_evidence'] = $issue['evidence'];
        return $snapshot;
    }

    private function upsert_recommendation( array $evidence, array $analysis, array $issue ): void {
        global $wpdb;
        $t = K20AI_Database::tables();
        $key = hash( 'sha256', $evidence['entity_key'] . '|' . $issue['rule_code'] . '|recommendation' );
        $priority = 'critical' === $issue['severity'] ? 'critical' : ( 'warning' === $issue['severity'] ? 'high' : 'medium' );
        $business = 'product' === $evidence['kind'] ? 85 : ( in_array( $evidence['kind'], array( 'content_post','news' ), true ) ? 72 : 60 );
        $commerce = 'product' === $evidence['kind'] ? ( empty( $evidence['price'] ) ? 50 : 80 ) : ( ! empty( $evidence['internal_outbound_count'] ) ? 65 : 45 );
        $risk = in_array( $issue['rule_code'], array( 'media.alt.missing','meta.description.missing','meta.title.length','meta.description.length' ), true ) ? 'low' : ( 'critical' === $issue['severity'] ? 'high' : 'medium' );
        $row = array(
            'engine'             => $this->engine_for_rule( (string) $issue['rule_code'] ),
            'entity_kind'        => sanitize_key( (string) $evidence['kind'] ),
            'entity_id'          => (int) $evidence['entity_id'],
            'recommendation_key' => $key,
            'title'              => sanitize_text_field( (string) $issue['title'] ),
            'reason'             => sanitize_textarea_field( (string) $issue['description'] ),
            'priority'           => $priority,
            'business_score'     => $business,
            'commerce_score'     => $commerce,
            'seo_score'          => max( 0, 100 - (int) ( $issue['penalty'] ?? 0 ) ),
            'source_trust'       => $this->source_trust_score( $evidence ),
            'risk'               => $risk,
            'payload'            => wp_json_encode( array( 'rule_code' => $issue['rule_code'], 'suggested_fix' => $issue['suggested_fix'] ?? array(), 'source_trust_basis' => 'local_evidence_completeness' ) ),
            'status'             => 'open',
            'updated_at'         => current_time( 'mysql', true ),
        );
        $existing = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t['seo_recommendations']} WHERE recommendation_key=%s", $key ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        if ( $existing ) $wpdb->update( $t['seo_recommendations'], $row, array( 'id' => (int) $existing ) );
        else {
            $row['created_at'] = current_time( 'mysql', true );
            $wpdb->insert( $t['seo_recommendations'], $row );
        }
    }

    /**
     * This is data-confidence, not an external authority metric. It is derived only
     * from the completeness of the local evidence snapshot so the UI never invents
     * a domain/source authority score.
     */
    private function source_trust_score( array $evidence ): int {
        $score = 100;
        $kind = (string) ( $evidence['kind'] ?? '' );
        if ( empty( $evidence['entity_id'] ) ) $score -= 25;
        if ( '' === trim( (string) ( $evidence['title'] ?? '' ) ) && 'media' !== $kind ) $score -= 15;
        if ( 'media' !== $kind && '' === trim( (string) ( $evidence['url'] ?? '' ) ) ) $score -= 10;

        if ( 'product' === $kind ) {
            if ( '' === trim( (string) ( $evidence['sku'] ?? '' ) ) ) $score -= 8;
            if ( '' === trim( (string) ( $evidence['brand'] ?? '' ) ) ) $score -= 10;
            if ( empty( $evidence['categories'] ) ) $score -= 10;
            if ( empty( $evidence['image_ids'] ) ) $score -= 12;
            if ( null === ( $evidence['price'] ?? null ) || '' === (string) ( $evidence['price'] ?? '' ) ) $score -= 8;
        } elseif ( in_array( $kind, array( 'content_post', 'news', 'page' ), true ) ) {
            if ( empty( $evidence['author_id'] ) ) $score -= 10;
            if ( (int) ( $evidence['word_count'] ?? 0 ) < 120 ) $score -= 10;
            if ( empty( $evidence['modified_at'] ) ) $score -= 5;
        } elseif ( 'media' === $kind ) {
            if ( empty( $evidence['alt'] ) ) $score -= 18;
            if ( empty( $evidence['width'] ) || empty( $evidence['height'] ) ) $score -= 12;
            if ( empty( $evidence['mime_type'] ) ) $score -= 8;
        } elseif ( in_array( $kind, array( 'category', 'brand', 'attribute', 'taxonomy' ), true ) ) {
            if ( '' === trim( (string) ( $evidence['description'] ?? '' ) ) ) $score -= 12;
        }
        return max( 35, min( 100, $score ) );
    }

    private function engine_for_rule( string $rule ): string {
        if ( str_starts_with( $rule, 'media.' ) ) return 'image-seo';
        if ( str_starts_with( $rule, 'product.' ) ) return 'product-truth';
        if ( str_starts_with( $rule, 'schema.' ) ) return 'schema';
        if ( str_starts_with( $rule, 'links.' ) ) return 'internal-linking';
        if ( str_starts_with( $rule, 'content.' ) || str_starts_with( $rule, 'freshness.' ) ) return 'content';
        return 'technical-auditor';
    }

    /** @return array<int,array<string,mixed>> */
}
