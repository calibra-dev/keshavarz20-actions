<?php

defined( 'ABSPATH' ) || exit;

/**
 * K20 AI Press 3.0 SEO/GEO operating system.
 *
 * The class deliberately keeps two rules:
 * 1) local WordPress/WooCommerce evidence is always authoritative for local state;
 * 2) external metrics are never fabricated. A provider is either connected,
 *    imported with provenance, or shown as unavailable.
 */
final class K20AI_SEO_OS {
    use K20AI_SEO_Scan_Trait;
    use K20AI_SEO_Workspaces_Trait;
    use K20AI_SEO_Entity_Trait;
    private K20AI_SEO_Analyzer $analyzer;
    private K20AI_Services $legacy;
    private K20AI_Advanced $advanced;
    private ?K20AI_Connection_Center $connection_center = null;
    private ?K20AI_Content_Engines $content_engines = null;
    private ?K20AI_Bridge $bridge = null;

    /** @var array<string,array<string,mixed>> */
    private array $workspace_config;

    public function __construct( K20AI_SEO_Analyzer $analyzer, K20AI_Services $legacy, K20AI_Advanced $advanced ) {
        $this->analyzer = $analyzer;
        $this->legacy   = $legacy;
        $this->advanced = $advanced;
        add_action( 'add_meta_boxes', array( $this, 'register_editor_metabox' ) );
        add_action( 'save_post', array( $this, 'save_editor_metabox' ), 20, 2 );
        $this->workspace_config = array(
            'overview'          => array( 'label' => 'نمای کلی', 'label_en' => 'Overview', 'group' => 'control', 'icon' => 'dashboard' ),
            'products'          => array( 'label' => 'برج کنترل محصولات', 'label_en' => 'Product Control Tower', 'group' => 'catalog', 'icon' => 'products' ),
            'product-intelligence'=> array( 'label' => 'هوش محصول و تجارت', 'label_en' => 'Product & Commerce Intelligence', 'group' => 'catalog', 'icon' => 'analytics' ),
            'competitors-serp'  => array( 'label' => 'تحلیل رقبا و SERP', 'label_en' => 'Competitors & SERP', 'group' => 'research', 'icon' => 'chart-bar' ),
            'live-editor'       => array( 'label' => 'ویرایشگر و دستیار زنده', 'label_en' => 'Live Editor & Assistant', 'group' => 'content', 'icon' => 'edit' ),
            'keywords-content'  => array( 'label' => 'کلمات کلیدی و محتوا', 'label_en' => 'Keywords & Content', 'group' => 'content', 'icon' => 'editor-spellcheck' ),
            'images-alt'        => array( 'label' => 'تصاویر و ALT', 'label_en' => 'Images & ALT', 'group' => 'catalog', 'icon' => 'format-image' ),
            'schema-preview'    => array( 'label' => 'اسکیما و پیش‌نمایش', 'label_en' => 'Schema & Preview', 'group' => 'catalog', 'icon' => 'editor-code' ),
            'categories-links'  => array( 'label' => 'دسته‌بندی و لینک‌سازی', 'label_en' => 'Categories & Internal Links', 'group' => 'catalog', 'icon' => 'networking' ),
            'technical-health'  => array( 'label' => 'سلامت فنی و کرال', 'label_en' => 'Technical Health & Crawl', 'group' => 'monitoring', 'icon' => 'shield' ),
            'rank-tracking'     => array( 'label' => 'ردیابی رتبه', 'label_en' => 'Rank Tracking', 'group' => 'monitoring', 'icon' => 'chart-line' ),
            'ai-visibility'     => array( 'label' => 'پایش دیده‌شدن در AI', 'label_en' => 'AI Visibility Observatory', 'group' => 'monitoring', 'icon' => 'visibility' ),
            'control-tower'     => array( 'label' => 'مرکز فرمان Agentها', 'label_en' => 'Agent Control Center', 'group' => 'control', 'icon' => 'superhero' ),
            'reports'           => array( 'label' => 'گزارش‌ها', 'label_en' => 'Reports', 'group' => 'system', 'icon' => 'media-document' ),
            'content-refresh'   => array( 'label' => 'محتوا و به‌روزرسانی', 'label_en' => 'Content Refresh', 'group' => 'content', 'icon' => 'update' ),
            'crawl-monitoring'  => array( 'label' => 'خزش و مانیتورینگ', 'label_en' => 'Crawl & Monitoring', 'group' => 'monitoring', 'icon' => 'visibility' ),
            'market-radar'      => array( 'label' => 'رادار خبر و بازار', 'label_en' => 'News & Market Radar', 'group' => 'research', 'icon' => 'megaphone' ),
            'content-engines'   => array( 'label' => 'موتور خبر و نوشته‌ها', 'label_en' => 'News & Article Engines', 'group' => 'research', 'icon' => 'controls-repeat' ),
            'connections'       => array( 'label' => 'مرکز اتصال', 'label_en' => 'Connection Center', 'group' => 'system', 'icon' => 'admin-links' ),
            'settings'          => array( 'label' => 'تنظیمات و قوانین', 'label_en' => 'Settings & Governance', 'group' => 'system', 'icon' => 'admin-generic' ),
            'setup-commercial'  => array( 'label' => 'راه‌اندازی، مهاجرت و لایسنس', 'label_en' => 'Setup, Migration & License', 'group' => 'system', 'icon' => 'admin-network' ),
        );
    }

    public function set_connection_center( K20AI_Connection_Center $center ): void {
        $this->connection_center = $center;
    }

    public function set_content_engines( K20AI_Content_Engines $engines ): void {
        $this->content_engines = $engines;
    }

    public function set_bridge( K20AI_Bridge $bridge ): void {
        $this->bridge = $bridge;
    }

    /** @return array<string,array<string,mixed>> */
    public function workspaces(): array {
        return $this->workspace_config;
    }

    public function register_editor_metabox(): void {
        $screens = get_post_types( array( 'public' => true ), 'names' );
        foreach ( (array) $screens as $screen ) {
            if ( in_array( $screen, array( 'attachment' ), true ) ) continue;
            add_meta_box(
                'k20-ai-press-inspector',
                'K20 AI Press · بازبینی و ویرایش سئو',
                array( $this, 'render_editor_metabox' ),
                $screen,
                'normal',
                'high'
            );
        }
    }

    public function render_editor_metabox( \WP_Post $post ): void {
        if ( ! current_user_can( 'edit_post', $post->ID ) ) return;
        global $wpdb;
        $t = K20AI_Database::tables();
        $kind = 'product' === $post->post_type ? 'product' : $this->content_kind_for_post_type( (string) $post->post_type );
        $detail = $this->entity_detail( $kind, (int) $post->ID );
        $profile = (array) ( $detail['profile'] ?? array() );
        $evidence = (array) ( $detail['evidence'] ?? array() );
        $issues = (array) ( $detail['issues'] ?? array() );
        $saved_seo_title = $this->editor_saved_meta( (int) $post->ID, 'title' );
        $saved_meta_description = $this->editor_saved_meta( (int) $post->ID, 'description' );
        $fallback_seo_title = trim( (string) ( $evidence['seo_title'] ?? $post->post_title ) );
        $fallback_meta_description = trim( (string) ( $evidence['meta_description'] ?? '' ) );
        wp_nonce_field( 'k20ai_editor_metabox_' . $post->ID, 'k20ai_editor_metabox_nonce' );
        echo '<div class="k20ai-editor-metabox" style="display:grid;gap:14px;font-family:Vazirmatn,Tahoma,sans-serif">';
        echo '<div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">';
        echo '<span style="background:#111827;color:#fff;border-radius:999px;padding:6px 10px">امتیاز: ' . esc_html( isset( $profile['score_total'] ) ? (string) (int) $profile['score_total'] . '/100' : '—' ) . '</span>';
        echo '<span style="background:#ecfdf5;color:#047857;border-radius:999px;padding:6px 10px">' . esc_html( $kind ) . '</span>';
        echo '<span style="background:#f5f3ff;color:#6d28d9;border-radius:999px;padding:6px 10px">' . esc_html( count( $issues ) . ' ایراد باز' ) . '</span>';
        echo '</div>';
        echo '<div style="display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:12px">';
        echo '<label style="display:grid;gap:6px"><strong>عنوان سئو</strong><input type="text" name="k20ai_seo_title" value="' . esc_attr( $saved_seo_title ) . '" placeholder="' . esc_attr( $fallback_seo_title ) . '" style="width:100%"/><input type="hidden" name="k20ai_seo_title_original" value="' . esc_attr( $saved_seo_title ) . '"/><small>مقدار پیشنهادی فقط Placeholder است؛ تا وقتی عمداً تغییرش ندهید ذخیره نمی‌شود.</small></label>';
        echo '<label style="display:grid;gap:6px"><strong>توضیحات متا</strong><textarea name="k20ai_meta_description" rows="3" placeholder="' . esc_attr( $fallback_meta_description ) . '" style="width:100%">' . esc_textarea( $saved_meta_description ) . '</textarea><input type="hidden" name="k20ai_meta_description_original" value="' . esc_attr( $saved_meta_description ) . '"/><small>در صورت تغییر عمدی، مقدار افزونه و Yoast همگام می‌شوند؛ پاک‌کردن عمدی نیز متا را حذف می‌کند.</small></label>';
        echo '</div>';
        echo '<div style="border:1px solid #e5e7eb;border-radius:12px;padding:12px;background:#f8fafc"><strong style="display:block;margin-bottom:8px">ایرادهای باز این صفحه</strong>';
        if ( $issues ) {
            echo '<ul style="margin:0;padding-right:18px">';
            foreach ( array_slice( $issues, 0, 8 ) as $issue ) {
                echo '<li style="margin:0 0 7px"><b>' . esc_html( (string) ( $issue['title'] ?? '' ) ) . '</b><br><small>' . esc_html( (string) ( $issue['description'] ?? '' ) ) . '</small></li>';
            }
            echo '</ul>';
        } else {
            echo '<p style="margin:0">در آخرین تحلیل ایراد بازی برای این صفحه ثبت نشده است.</p>';
        }
        echo '</div>';
        $workspace = 'product' === $kind ? 'products' : 'schema-preview';
        $url = admin_url( 'admin.php?page=k20-ai-press&workspace=' . $workspace . '&kind=' . rawurlencode( $kind ) . '&id=' . (int) $post->ID );
        echo '<p style="margin:0"><a class="button button-primary" href="' . esc_url( $url ) . '">باز کردن همین مورد در K20 AI Press</a></p>';
        echo '</div>';
    }

    public function save_editor_metabox( int $post_id, \WP_Post $post ): void {
        if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) return;
        if ( ! isset( $_POST['k20ai_editor_metabox_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['k20ai_editor_metabox_nonce'] ) ), 'k20ai_editor_metabox_' . $post_id ) ) return;
        if ( ! current_user_can( 'edit_post', $post_id ) ) return;
        if ( array_key_exists( 'k20ai_seo_title', $_POST ) && array_key_exists( 'k20ai_seo_title_original', $_POST ) ) {
            $seo_title = K20AI_Data_Integrity::clean_text( wp_unslash( $_POST['k20ai_seo_title'] ) );
            $original = K20AI_Data_Integrity::clean_text( wp_unslash( $_POST['k20ai_seo_title_original'] ) );
            $current = $this->editor_saved_meta( $post_id, 'title' );
            // Three-way comparison: untouched forms never persist fallbacks, and a stale editor
            // cannot overwrite a value changed by another request after this metabox was rendered.
            if ( $seo_title !== $original && $current === $original ) $this->save_editor_meta_value( $post_id, 'title', $seo_title );
        }
        if ( array_key_exists( 'k20ai_meta_description', $_POST ) && array_key_exists( 'k20ai_meta_description_original', $_POST ) ) {
            $meta_description = K20AI_Data_Integrity::clean_textarea( wp_unslash( $_POST['k20ai_meta_description'] ) );
            $original = K20AI_Data_Integrity::clean_textarea( wp_unslash( $_POST['k20ai_meta_description_original'] ) );
            $current = $this->editor_saved_meta( $post_id, 'description' );
            if ( $meta_description !== $original && $current === $original ) $this->save_editor_meta_value( $post_id, 'description', $meta_description );
        }
        $evidence = $this->collect_post_evidence( $post_id );
        if ( $evidence ) {
            $analysis = $this->analyzer->analyze( $evidence );
            $this->persist_analysis( $evidence, $analysis );
        }
    }

    /** @return array<string,mixed> */
    public function settings(): array {
        $defaults = array(
            'engine_profile'            => 'k30',
            'scan_batch_size'           => 25,
            'crawl_batch_size'          => 8,
            'auto_scan'                 => true,
            'auto_safe_fixes'           => false,
            'require_approval'           => true,
            'content_stale_days'        => 180,
            'min_product_words'         => 80,
            'min_content_words'         => 250,
            'schema_output_enabled'     => false,
            'radar_sources'             => array(),
            'allowed_crawl_host'        => wp_parse_url( home_url(), PHP_URL_HOST ),
            'gsc_imported_at'           => null,
            'rank_imported_at'          => null,
            'merchant_imported_at'      => null,
            'last_full_scan_at'         => null,
            'last_crawl_at'             => null,
            'ui_density'                => 'comfortable',
            'approval_risk_threshold'   => 'medium',
        );
        $stored = get_option( 'k20ai_v3_settings', array() );
        return wp_parse_args( is_array( $stored ) ? $stored : array(), $defaults );
    }

    /** @return array<string,mixed> */
    public function save_settings( array $input ): array {
        $current = $this->settings();
        $next = $current;
        $bools = array( 'auto_scan', 'auto_safe_fixes', 'require_approval', 'schema_output_enabled' );
        foreach ( $bools as $key ) {
            if ( array_key_exists( $key, $input ) ) {
                $next[ $key ] = (bool) $input[ $key ];
            }
        }
        foreach ( array( 'scan_batch_size', 'crawl_batch_size', 'content_stale_days', 'min_product_words', 'min_content_words' ) as $key ) {
            if ( array_key_exists( $key, $input ) ) {
                $next[ $key ] = max( 1, min( 1000, absint( $input[ $key ] ) ) );
            }
        }
        if ( isset( $input['ui_density'] ) && in_array( $input['ui_density'], array( 'comfortable', 'compact' ), true ) ) {
            $next['ui_density'] = $input['ui_density'];
        }
        if ( isset( $input['approval_risk_threshold'] ) && in_array( $input['approval_risk_threshold'], array( 'low', 'medium', 'high' ), true ) ) {
            $next['approval_risk_threshold'] = $input['approval_risk_threshold'];
        }
        if ( isset( $input['radar_sources'] ) ) {
            $urls = is_array( $input['radar_sources'] ) ? $input['radar_sources'] : preg_split( '/\r?\n/', (string) $input['radar_sources'] );
            $safe = array();
            foreach ( (array) $urls as $url ) {
                $url = esc_url_raw( trim( (string) $url ) );
                if ( $url && wp_http_validate_url( $url ) ) {
                    $safe[] = $url;
                }
            }
            $next['radar_sources'] = array_values( array_unique( $safe ) );
        }
        $legacy_keys = array(
            'prompt_log_retention', 'ip_retention', 'bot_log_retention', 'provider_log_retention',
            'audit_log_retention', 'event_log_retention', 'webhook_log_retention', 'engine_run_retention',
            'supplier_submission_retention', 'diagnostic_logging_enabled',
        );
        $legacy_input = array_intersect_key( $input, array_flip( $legacy_keys ) );
        if ( $legacy_input ) $this->legacy->save_settings( $legacy_input );
        update_option( 'k20ai_v3_settings', $next, false );
        return array_merge( $next, array( 'privacy' => $this->legacy->settings() ) );
    }

    /** @return array<string,mixed> */
    public function integration_status(): array {
        $plugins = function_exists( 'get_option' ) ? (array) get_option( 'active_plugins', array() ) : array();
        $has_yoast = defined( 'WPSEO_VERSION' ) || (bool) array_filter( $plugins, static fn( $plugin ) => str_contains( (string) $plugin, 'wordpress-seo' ) );
        $has_wc = class_exists( 'WooCommerce' ) || function_exists( 'WC' );
        $settings = $this->settings();
        $constants = array(
            'search_console'  => defined( 'K20AI_GSC_ACCESS_TOKEN' ) || defined( 'K20AI_GSC_SERVICE_ACCOUNT_JSON' ),
            'analytics'       => defined( 'K20AI_GA4_PROPERTY_ID' ) && ( defined( 'K20AI_GA4_ACCESS_TOKEN' ) || defined( 'K20AI_GA4_SERVICE_ACCOUNT_JSON' ) ),
            'merchant_center' => defined( 'K20AI_MERCHANT_ID' ) && ( defined( 'K20AI_GOOGLE_ACCESS_TOKEN' ) || defined( 'K20AI_GOOGLE_SERVICE_ACCOUNT_JSON' ) ),
            'pagespeed'       => defined( 'K20AI_PAGESPEED_API_KEY' ),
            'openai'          => defined( 'K20AI_OPENAI_API_KEY' ),
        );
        $rows = array(
            array( 'key' => 'wordpress', 'label' => 'WordPress', 'status' => 'connected', 'detail' => get_bloginfo( 'version' ) ),
            array( 'key' => 'woocommerce', 'label' => 'WooCommerce', 'status' => $has_wc ? 'connected' : 'unavailable', 'detail' => defined( 'WC_VERSION' ) ? WC_VERSION : null ),
            array( 'key' => 'yoast', 'label' => 'Yoast SEO', 'status' => $has_yoast ? 'connected' : 'optional', 'detail' => defined( 'WPSEO_VERSION' ) ? WPSEO_VERSION : null ),
            array( 'key' => 'search_console', 'label' => 'Search Console', 'status' => $constants['search_console'] || ! empty( $settings['gsc_imported_at'] ) ? 'connected' : 'disconnected', 'detail' => $settings['gsc_imported_at'] ? 'داده واردشده: ' . $settings['gsc_imported_at'] : null ),
            array( 'key' => 'analytics', 'label' => 'Google Analytics 4', 'status' => $constants['analytics'] ? 'configured' : 'disconnected', 'detail' => null ),
            array( 'key' => 'merchant_center', 'label' => 'Merchant Center', 'status' => $constants['merchant_center'] || ! empty( $settings['merchant_imported_at'] ) ? 'connected' : 'disconnected', 'detail' => null ),
            array( 'key' => 'pagespeed', 'label' => 'PageSpeed Insights', 'status' => $constants['pagespeed'] ? 'configured' : 'disconnected', 'detail' => null ),
            array( 'key' => 'openai', 'label' => 'AI Provider', 'status' => $constants['openai'] ? 'configured' : 'local-only', 'detail' => $constants['openai'] ? 'کلید محیطی فعال' : 'Rule Engine و تحلیل محلی فعال' ),
            array( 'key' => 'bridge', 'label' => 'Bridge 3.3', 'status' => $this->bridge ? 'ready' : 'disabled', 'detail' => $this->bridge ? 'Embedded Universal Bridge 3.3؛ runtime connection is verified only by an explicit self-test.' : null ),
            array( 'key' => 'indexnow', 'label' => 'IndexNow', 'status' => ! empty( $this->legacy->settings()['indexnow_reuse'] ) ? 'connected' : 'disabled', 'detail' => null ),
        );
        if ( $this->connection_center ) {
            $live = array();
            foreach ( $this->connection_center->snapshot() as $connector ) $live[ (string) $connector['key'] ] = $connector;
            $mapping = array(
                'search_console' => 'google',
                'analytics' => 'google',
                'merchant_center' => 'google',
                'pagespeed' => 'pagespeed',
                'openai' => 'openai',
            );
            foreach ( $rows as &$row ) {
                $provider = $mapping[ (string) $row['key'] ] ?? null;
                if ( ! $provider || ! isset( $live[ $provider ] ) ) continue;
                $connector = $live[ $provider ];
                if ( 'connected' === (string) ( $connector['status'] ?? '' ) ) {
                    $row['status'] = 'connected';
                    $row['detail'] = $connector['last_sync_at'] ? 'آخرین همگام‌سازی: ' . $connector['last_sync_at'] : 'تست اتصال موفق';
                }
            }
            unset( $row );
        }
        return $rows;
    }

    /** @return array<string,mixed> */
    public function dashboard(): array {
        global $wpdb;
        $t = K20AI_Database::tables();
        $profiles = $this->table_exists( $t['seo_profiles'] ) ? (array) $wpdb->get_row(
            "SELECT COUNT(*) total, COALESCE(ROUND(AVG(score_total)),0) avg_score, SUM(score_total>=85) healthy, SUM(score_total<60) low_score FROM {$t['seo_profiles']}", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            ARRAY_A
        ) : array();
        $issues = $this->table_exists( $t['seo_issues'] ) ? (array) $wpdb->get_row(
            "SELECT COUNT(*) total, SUM(status='open') open_count, COUNT(DISTINCT CASE WHEN status='open' THEN CONCAT(entity_kind,':',entity_id) END) affected_entities, SUM(status='open' AND severity='critical') critical, SUM(status='open' AND severity='warning') warnings, SUM(status='resolved') resolved FROM {$t['seo_issues']}", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            ARRAY_A
        ) : array();
        $recommendations = $this->table_exists( $t['seo_recommendations'] ) ? (array) $wpdb->get_row(
            "SELECT COUNT(*) total, SUM(status='open') open_count, SUM(status='open' AND priority='critical') critical, SUM(status='open' AND priority='high') high_count FROM {$t['seo_recommendations']}", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            ARRAY_A
        ) : array();
        $actions = $this->table_exists( $t['seo_actions'] ) ? (array) $wpdb->get_row(
            "SELECT COUNT(*) total, SUM(status='proposed') proposed, SUM(status='approved') approved, SUM(status='failed') failed FROM {$t['seo_actions']}", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            ARRAY_A
        ) : array();
        $entity_counts = $this->entity_counts();
        $priority = $this->priority_queue( 8 );
        $trend = $this->health_trend( 30 );
        $legacy = $this->legacy->dashboard();
        $settings = $this->settings();

        return array(
            'version'         => K20AI_PRESS_VERSION,
            'site'            => array( 'name' => get_bloginfo( 'name' ), 'url' => home_url(), 'locale' => determine_locale() ),
            'health'          => array(
                'score'     => isset( $profiles['avg_score'] ) ? (int) $profiles['avg_score'] : null,
                'healthy'   => (int) ( $profiles['healthy'] ?? 0 ),
                'low_score' => (int) ( $profiles['low_score'] ?? 0 ),
                'analyzed'  => (int) ( $profiles['total'] ?? 0 ),
            ),
            'issues'          => array_map( 'intval', array(
                'total'    => $issues['total'] ?? 0,
                'open'     => $issues['open_count'] ?? 0,
                'affected_entities' => $issues['affected_entities'] ?? 0,
                'critical' => $issues['critical'] ?? 0,
                'warnings' => $issues['warnings'] ?? 0,
                'resolved' => $issues['resolved'] ?? 0,
            ) ),
            'recommendations' => array_map( 'intval', array(
                'total'    => $recommendations['total'] ?? 0,
                'open'     => $recommendations['open_count'] ?? 0,
                'critical' => $recommendations['critical'] ?? 0,
                'high'     => $recommendations['high_count'] ?? 0,
            ) ),
            'actions'         => array_map( 'intval', array(
                'total'    => $actions['total'] ?? 0,
                'proposed' => $actions['proposed'] ?? 0,
                'approved' => $actions['approved'] ?? 0,
                'failed'   => $actions['failed'] ?? 0,
            ) ),
            'entities'        => $entity_counts,
            'priority_queue'  => $priority,
            'trend'           => $trend,
            'integrations'    => $this->integration_status(),
            'engines'         => $this->engines(),
            'layers'          => $this->layers(),
            'legacy'          => array(
                'product_score' => $legacy['products']['score'] ?? null,
                'security'      => $legacy['metrics'][5]['value'] ?? null,
                'bridge'        => ! empty( $this->legacy->settings()['bridge_enabled'] ),
            ),
            'settings'        => $settings,
            'last_scan'       => $this->latest_scan(),
        );
    }

    /** @return array<string,int> */
    public function entity_counts(): array {
        $product_total = 0;
        if ( post_type_exists( 'product' ) ) {
            $product_counts = wp_count_posts( 'product' );
            foreach ( array( 'publish','draft','pending','future','private' ) as $status ) $product_total += (int) ( $product_counts->{$status} ?? 0 );
        }
        $counts = array(
            'products'       => $product_total,
            'posts'          => (int) ( wp_count_posts( 'post' )->publish ?? 0 ),
            'pages'          => (int) ( wp_count_posts( 'page' )->publish ?? 0 ),
            'media'          => (int) ( wp_count_posts( 'attachment' )->inherit ?? 0 ),
            'news'           => 0,
            'custom_content' => 0,
            'taxonomies'     => 0,
        );
        foreach ( $this->public_content_post_types() as $post_type ) {
            if ( in_array( $post_type, array( 'post', 'page' ), true ) ) continue;
            $count = wp_count_posts( $post_type );
            $published = (int) ( $count->publish ?? 0 );
            if ( $this->is_news_post_type( $post_type ) ) $counts['news'] += $published;
            else $counts['custom_content'] += $published;
        }
        foreach ( $this->public_taxonomy_names() as $taxonomy ) {
            $term_count = wp_count_terms( array( 'taxonomy' => $taxonomy, 'hide_empty' => false ) );
            if ( ! is_wp_error( $term_count ) ) {
                $counts['taxonomies'] += (int) $term_count;
            }
        }
        $counts['content_items'] = $counts['posts'] + $counts['pages'] + $counts['news'] + $counts['custom_content'];
        $counts['total_content'] = $counts['products'] + $counts['content_items'];
        return $counts;
    }

    /** @return array<int,string> */
    private function public_taxonomy_names(): array {
        return array_values( array_filter( array_map( 'sanitize_key', (array) get_taxonomies( array( 'public' => true ), 'names' ) ) ) );
    }

    /** @return array<int,array<string,mixed>> */
    public function engines(): array {
        $integrations = $this->integration_status();
        $by_key = array();
        foreach ( $integrations as $integration ) {
            $by_key[ $integration['key'] ] = $integration;
        }
        return array(
            array( 'key' => 'crawl', 'label' => 'Crawl Engine', 'description' => 'خزش امن URLهای داخلی، وضعیت HTTP، Canonical، Robots و Schema', 'status' => 'ready', 'source' => 'local' ),
            array( 'key' => 'audit', 'label' => 'Technical Auditor', 'description' => 'Rule-based audit روی محصولات، محتوا، رسانه و Taxonomy', 'status' => 'ready', 'source' => 'local' ),
            array( 'key' => 'content', 'label' => 'Content Intelligence', 'description' => 'تازگی، کیفیت، متا، ساختار و اتصال محتوا به فروش', 'status' => 'ready', 'source' => 'local' ),
            array( 'key' => 'product', 'label' => 'Product Truth Engine', 'description' => 'هویت، برند، دسته، تصاویر، قیمت، موجودی و Merchant readiness', 'status' => class_exists( 'WooCommerce' ) ? 'ready' : 'unavailable', 'source' => 'woocommerce' ),
            array( 'key' => 'media', 'label' => 'Image SEO Agent', 'description' => 'ALT، ابعاد، فرمت، حجم و محل استفاده تصویر', 'status' => 'ready', 'source' => 'media' ),
            array( 'key' => 'links', 'label' => 'Internal Linking Engine', 'description' => 'کشف لینک‌های واقعی، صفحات یتیم و فرصت‌های لینک داخلی', 'status' => 'ready', 'source' => 'local' ),
            array( 'key' => 'schema', 'label' => 'Schema Engine', 'description' => 'Eligibility و پیش‌نمایش Product/Article/Breadcrumb/Organization', 'status' => 'ready', 'source' => 'local' ),
            array( 'key' => 'rank', 'label' => 'Rank Tracking Engine', 'description' => 'رتبه فقط از Search Console یا Import قابل‌ردیابی', 'status' => ( $by_key['search_console']['status'] ?? '' ) === 'connected' ? 'connected' : 'waiting-data', 'source' => 'external' ),
            array( 'key' => 'competitor', 'label' => 'Competitor Intelligence', 'description' => 'رقبا، شکاف محتوا و داده‌های واردشده با منبع', 'status' => 'ready', 'source' => 'manual+local' ),
            array( 'key' => 'market', 'label' => 'Market Radar', 'description' => 'سیگنال‌های داخلی و RSSهای معتبرِ تنظیم‌شده', 'status' => 'ready', 'source' => 'local+rss' ),
            array( 'key' => 'evidence', 'label' => 'Evidence / GEO Engine', 'description' => 'Claim، Evidence، Citation readiness و مسیر شواهد', 'status' => 'ready', 'source' => 'legacy' ),
            array( 'key' => 'rule', 'label' => 'Rule Engine', 'description' => 'قوانین پایدار، امتیاز و تشخیص بدون عدد ساختگی', 'status' => 'ready', 'source' => 'local' ),
            array( 'key' => 'orchestration', 'label' => 'AI Agent Orchestration', 'description' => 'پیشنهاد → تأیید → اجرا → Rollback با ریسک کنترل‌شده', 'status' => 'ready', 'source' => 'local' ),
            array( 'key' => 'bulk', 'label' => 'Bulk Optimization Engine', 'description' => 'Batch processing با صف و محدودیت برای جلوگیری از فشار روی سایت', 'status' => 'ready', 'source' => 'local' ),
            array( 'key' => 'reporting', 'label' => 'Reporting Engine', 'description' => 'گزارش مدیریتی، CSV/JSON و پرینت PDF', 'status' => 'ready', 'source' => 'local' ),
            array( 'key' => 'bot', 'label' => 'AI Crawler Control', 'description' => 'Registry و سیاست Robots برای خزنده‌های AI و موتورهای جست‌وجو', 'status' => 'ready', 'source' => 'legacy' ),
        );
    }

    /** @return array<int,array<string,mixed>> */
    public function layers(): array {
        return array(
            array( 'id' => 1, 'key' => 'observe', 'label' => 'مشاهده و جمع‌آوری داده', 'description' => 'WordPress، WooCommerce، خزش محلی، رسانه، لینک‌ها و داده‌های Provider متصل', 'tone' => 'blue' ),
            array( 'id' => 2, 'key' => 'diagnose', 'label' => 'تشخیص', 'description' => 'Rule Engine، امتیاز چندبعدی، Issue و اولویت‌بندی بر پایه Evidence', 'tone' => 'green' ),
            array( 'id' => 3, 'key' => 'recommend', 'label' => 'پیشنهاد', 'description' => 'Recommendationهای توضیح‌پذیر با اثر سئو/تجارت/ریسک', 'tone' => 'purple' ),
            array( 'id' => 4, 'key' => 'govern', 'label' => 'اجرا و کنترل', 'description' => 'پیش‌نمایش، تأیید انسانی، Apply، Audit log و Rollback', 'tone' => 'orange' ),
        );
    }

    public function hourly_tick(): void {
        $settings = $this->settings();
        if ( ! empty( $settings['auto_scan'] ) ) {
            $latest = $this->latest_scan();
            if ( ! $latest || ( 'completed' === $latest['status'] && strtotime( (string) $latest['completed_at'] ) < time() - 6 * HOUR_IN_SECONDS ) ) {
                $this->create_scan( 'full', 'scheduled', null );
            }
        }
        // Finish any scan left running/queued if a scheduled batch was missed.
        global $wpdb;
        $t = K20AI_Database::tables();
        $ids = $wpdb->get_col( "SELECT id FROM {$t['seo_scans']} WHERE status IN ('queued','running') ORDER BY id ASC LIMIT 3" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        foreach ( $ids as $id ) $this->process_scan( (int) $id );
    }

    public function daily_tick(): void {
        $this->refresh_market_radar();
        $settings = $this->settings();
        if ( empty( $settings['last_crawl_at'] ) || strtotime( (string) $settings['last_crawl_at'] ) < time() - DAY_IN_SECONDS ) {
            $this->create_scan( 'crawl', 'scheduled', null );
        }
    }

    public function invalidate_entity( int $post_id ): void {
        if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) return;
        $post = get_post( $post_id );
        if ( ! $post || 'trash' === $post->post_status ) return;
        $evidence = $this->collect_post_evidence( $post_id );
        if ( ! $evidence ) return;
        $analysis = $this->analyzer->analyze( $evidence );
        $this->persist_analysis( $evidence, $analysis );
    }
}
