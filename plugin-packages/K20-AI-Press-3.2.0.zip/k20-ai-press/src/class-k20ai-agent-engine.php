<?php

defined( 'ABSPATH' ) || exit;

/**
 * Governed agent runtime. Abilities remain the only execution surface.
 */
final class K20AI_Agent_Engine {
    private const MODES = array( 'read_only', 'assisted', 'autonomous_low_risk' );
    private const MAX_STEPS = 12;
    private const MAX_RETRIES = 3;

    private K20AI_Ability_Registry $registry;
    private K20AI_Services $services;
    private ?K20AI_Connection_Center $connections;
    private array $last_plan_meta = array( 'planner' => 'local-deterministic', 'provider' => 'local-deterministic', 'model' => null, 'estimated_cost' => null );

    public function __construct( K20AI_Ability_Registry $registry, K20AI_Services $services, ?K20AI_Connection_Center $connections = null ) {
        $this->registry = $registry;
        $this->services = $services;
        $this->connections = $connections;
    }

    /** @return array<string,mixed>|WP_Error */
    public function create_run( array $input ): array|WP_Error {
        global $wpdb;
        $objective = trim( wp_strip_all_tags( (string) ( $input['objective'] ?? '' ) ) );
        if ( mb_strlen( $objective ) < 3 || mb_strlen( $objective ) > 2000 ) {
            return new WP_Error( 'invalid_agent_objective', __( 'Agent objective must contain 3 to 2000 characters.', 'k20-ai-press' ), array( 'status' => 422 ) );
        }
        $mode = sanitize_key( (string) ( $input['mode'] ?? 'assisted' ) );
        if ( ! in_array( $mode, self::MODES, true ) ) $mode = 'assisted';
        $context = $this->sanitize_context( (array) ( $input['context'] ?? array() ) );
        $idempotency = trim( (string) ( $input['idempotency_key'] ?? '' ) );
        $actor = get_current_user_id();
        $t = K20AI_Database::tables();

        $idem_hash = null;
        if ( '' !== $idempotency ) {
            $idem_hash = hash( 'sha256', $actor . '|' . substr( $idempotency, 0, 191 ) );
            $existing = $wpdb->get_var( $wpdb->prepare( "SELECT run_key FROM {$t['agent_runs']} WHERE idempotency_key=%s LIMIT 1", $idem_hash ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            if ( is_string( $existing ) && '' !== $existing ) return $this->get_run( $existing );
        }

        $steps = $this->plan_steps( $objective, $mode, $context, (array) ( $input['abilities'] ?? array() ) );
        if ( is_wp_error( $steps ) ) return $steps;
        if ( ! $steps ) return new WP_Error( 'agent_plan_empty', __( 'No safe executable abilities matched this objective.', 'k20-ai-press' ), array( 'status' => 422 ) );

        $run_key = wp_generate_uuid4();
        $now = current_time( 'mysql', true );
        $requires_approval = count( array_filter( $steps, static fn( array $step ): bool => ! empty( $step['requires_approval'] ) ) );
        $inserted = $wpdb->insert( $t['agent_runs'], array(
            'run_key'          => $run_key,
            'objective'        => $objective,
            'mode'             => $mode,
            'status'           => $requires_approval ? 'waiting_approval' : 'plan_ready',
            'actor_id'         => $actor ?: null,
            'context'          => wp_json_encode( $context, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ),
            'provider'         => (string) ( $this->last_plan_meta['provider'] ?? 'local-deterministic' ),
            'estimated_cost'   => null === ( $this->last_plan_meta['estimated_cost'] ?? null ) ? null : (string) $this->last_plan_meta['estimated_cost'],
            'idempotency_key'  => $idem_hash,
            'created_at'       => $now,
            'updated_at'       => $now,
        ) );
        $run_id = (int) $wpdb->insert_id;
        if ( false === $inserted || $run_id < 1 ) {
            // A concurrent request may have won the idempotency race after the preflight lookup.
            if ( null !== $idem_hash ) {
                $existing = $wpdb->get_var( $wpdb->prepare( "SELECT run_key FROM {$t['agent_runs']} WHERE idempotency_key=%s LIMIT 1", $idem_hash ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                if ( is_string( $existing ) && '' !== $existing ) return $this->get_run( $existing );
            }
            K20AI_Logger::error( 'Agent plan persistence failed before step creation.', array( 'run_key' => $run_key ) );
            return new WP_Error( 'agent_run_persist_failed', __( 'The agent plan could not be saved. No actions were executed.', 'k20-ai-press' ), array( 'status' => 500 ) );
        }

        foreach ( $steps as $position => $step ) {
            $step_inserted = $wpdb->insert( $t['agent_steps'], array(
                'run_id'             => $run_id,
                'position'           => $position + 1,
                'ability'            => $step['ability'],
                'risk_class'         => $step['risk_class'],
                'status'             => $step['requires_approval'] ? 'waiting_approval' : 'planned',
                'input_json'         => wp_json_encode( $step['input'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ),
                'evidence_json'      => wp_json_encode( $step['evidence'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ),
                'requires_approval'  => $step['requires_approval'] ? 1 : 0,
                'attempt_count'      => 0,
                'created_at'         => $now,
                'updated_at'         => $now,
            ) );
            if ( false === $step_inserted || (int) $wpdb->insert_id < 1 ) {
                $clean = $this->cleanup_incomplete_plan( $run_id );
                K20AI_Logger::error( 'Agent plan persistence failed during step creation.', array(
                    'run_key'  => $run_key,
                    'position' => $position + 1,
                    'cleanup'  => $clean ? 'completed' : 'incomplete',
                ) );
                return new WP_Error( 'agent_step_persist_failed', __( 'The agent plan could not be saved completely. No actions were executed.', 'k20-ai-press' ), array( 'status' => 500 ) );
            }
        }
        K20AI_Logger::info( 'Agent plan created.', array( 'run_key' => $run_key, 'mode' => $mode, 'steps' => count( $steps ), 'planner' => $this->last_plan_meta['planner'] ?? 'local-deterministic', 'provider' => $this->last_plan_meta['provider'] ?? 'local-deterministic' ) );
        return $this->get_run( $run_key );
    }

    /** @return array<string,mixed>|WP_Error */
    public function execute_run( string $run_key ): array|WP_Error {
        global $wpdb;
        $run = $this->row_for_key( $run_key );
        if ( is_wp_error( $run ) ) return $run;
        if ( in_array( $run['status'], array( 'completed', 'cancelled' ), true ) ) return $this->get_run( $run_key );
        $t = K20AI_Database::tables();
        $steps = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t['agent_steps']} WHERE run_id=%d ORDER BY position ASC,id ASC", (int) $run['id'] ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $wpdb->update( $t['agent_runs'], array( 'status' => 'running', 'started_at' => $run['started_at'] ?: current_time( 'mysql', true ), 'updated_at' => current_time( 'mysql', true ) ), array( 'id' => (int) $run['id'] ) );

        foreach ( (array) $steps as $step ) {
            $status = (string) $step['status'];
            if ( in_array( $status, array( 'completed', 'skipped', 'cancelled' ), true ) ) continue;
            if ( ! empty( $step['requires_approval'] ) && 'approved' !== $status ) {
                $wpdb->update( $t['agent_runs'], array( 'status' => 'waiting_approval', 'updated_at' => current_time( 'mysql', true ) ), array( 'id' => (int) $run['id'] ) );
                return $this->get_run( $run_key );
            }
            if ( (int) $step['attempt_count'] >= self::MAX_RETRIES ) {
                $wpdb->update( $t['agent_runs'], array( 'status' => 'failed', 'last_error' => __( 'Agent step retry limit reached.', 'k20-ai-press' ), 'finished_at' => current_time( 'mysql', true ), 'updated_at' => current_time( 'mysql', true ) ), array( 'id' => (int) $run['id'] ) );
                return $this->get_run( $run_key );
            }
            $input = json_decode( (string) $step['input_json'], true );
            $input = is_array( $input ) ? $input : array();
            $wpdb->update( $t['agent_steps'], array( 'status' => 'running', 'attempt_count' => (int) $step['attempt_count'] + 1, 'updated_at' => current_time( 'mysql', true ) ), array( 'id' => (int) $step['id'] ) );
            $result = $this->services->execute( (string) $step['ability'], $input, ! empty( $step['requires_approval'] ) );
            if ( is_wp_error( $result ) ) {
                $message = $result->get_error_message();
                $wpdb->update( $t['agent_steps'], array( 'status' => 'failed', 'last_error' => $message, 'updated_at' => current_time( 'mysql', true ) ), array( 'id' => (int) $step['id'] ) );
                $wpdb->update( $t['agent_runs'], array( 'status' => 'failed', 'last_error' => $message, 'finished_at' => current_time( 'mysql', true ), 'updated_at' => current_time( 'mysql', true ) ), array( 'id' => (int) $run['id'] ) );
                K20AI_Logger::warning( 'Agent step failed.', array( 'run_key' => $run_key, 'ability' => $step['ability'], 'error' => $message ) );
                return $this->get_run( $run_key );
            }
            $verification = $this->verify_step( (string) $step['ability'], $input );
            if ( is_wp_error( $verification ) ) {
                $message = sprintf( /* translators: %s: verification error. */ __( 'Execution succeeded but verification failed: %s', 'k20-ai-press' ), $verification->get_error_message() );
                $wpdb->update( $t['agent_steps'], array( 'status' => 'failed', 'output_json' => wp_json_encode( $this->sanitize_context( $result ) ), 'last_error' => $message, 'updated_at' => current_time( 'mysql', true ) ), array( 'id' => (int) $step['id'] ) );
                $wpdb->update( $t['agent_runs'], array( 'status' => 'failed', 'last_error' => $message, 'finished_at' => current_time( 'mysql', true ), 'updated_at' => current_time( 'mysql', true ) ), array( 'id' => (int) $run['id'] ) );
                return $this->get_run( $run_key );
            }
            $output = array( 'result' => $this->sanitize_context( $result ), 'verification' => $this->sanitize_context( $verification ) );
            $wpdb->update( $t['agent_steps'], array( 'status' => 'completed', 'output_json' => wp_json_encode( $output, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ), 'last_error' => null, 'updated_at' => current_time( 'mysql', true ) ), array( 'id' => (int) $step['id'] ) );
        }

        $wpdb->update( $t['agent_runs'], array( 'status' => 'completed', 'finished_at' => current_time( 'mysql', true ), 'last_error' => null, 'updated_at' => current_time( 'mysql', true ) ), array( 'id' => (int) $run['id'] ) );
        K20AI_Logger::info( 'Agent run completed.', array( 'run_key' => $run_key ) );
        return $this->get_run( $run_key );
    }

    /** @return array<string,mixed>|WP_Error */
    public function approve_run( string $run_key, array $step_ids = array() ): array|WP_Error {
        global $wpdb;
        $run = $this->row_for_key( $run_key );
        if ( is_wp_error( $run ) ) return $run;
        if ( in_array( $run['status'], array( 'completed', 'cancelled' ), true ) ) return new WP_Error( 'agent_run_closed', __( 'This agent run is already closed.', 'k20-ai-press' ), array( 'status' => 409 ) );
        $t = K20AI_Database::tables();
        $ids = array_values( array_unique( array_filter( array_map( 'absint', $step_ids ) ) ) );
        if ( $ids ) {
            $in = implode( ',', $ids );
            $wpdb->query( $wpdb->prepare( "UPDATE {$t['agent_steps']} SET status='approved',approved_by=%d,approved_at=%s,updated_at=%s WHERE run_id=%d AND requires_approval=1 AND status='waiting_approval' AND id IN ({$in})", get_current_user_id(), current_time( 'mysql', true ), current_time( 'mysql', true ), (int) $run['id'] ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        } else {
            $wpdb->query( $wpdb->prepare( "UPDATE {$t['agent_steps']} SET status='approved',approved_by=%d,approved_at=%s,updated_at=%s WHERE run_id=%d AND requires_approval=1 AND status='waiting_approval'", get_current_user_id(), current_time( 'mysql', true ), current_time( 'mysql', true ), (int) $run['id'] ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        }
        $wpdb->update( $t['agent_runs'], array( 'status' => 'plan_ready', 'updated_at' => current_time( 'mysql', true ) ), array( 'id' => (int) $run['id'] ) );
        return $this->get_run( $run_key );
    }

    /** @return array<string,mixed>|WP_Error */
    public function cancel_run( string $run_key ): array|WP_Error {
        global $wpdb;
        $run = $this->row_for_key( $run_key );
        if ( is_wp_error( $run ) ) return $run;
        if ( 'completed' === $run['status'] ) return new WP_Error( 'agent_run_completed', __( 'A completed agent run cannot be cancelled.', 'k20-ai-press' ), array( 'status' => 409 ) );
        $t = K20AI_Database::tables();
        $now = current_time( 'mysql', true );
        $wpdb->update( $t['agent_runs'], array( 'status' => 'cancelled', 'finished_at' => $now, 'updated_at' => $now ), array( 'id' => (int) $run['id'] ) );
        $wpdb->query( $wpdb->prepare( "UPDATE {$t['agent_steps']} SET status='cancelled',updated_at=%s WHERE run_id=%d AND status NOT IN ('completed','failed')", $now, (int) $run['id'] ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        return $this->get_run( $run_key );
    }

    /** @return array<string,mixed>|WP_Error */
    public function retry_step( string $run_key, int $step_id ): array|WP_Error {
        global $wpdb;
        $run = $this->row_for_key( $run_key );
        if ( is_wp_error( $run ) ) return $run;
        $t = K20AI_Database::tables();
        $step = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t['agent_steps']} WHERE id=%d AND run_id=%d LIMIT 1", $step_id, (int) $run['id'] ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        if ( ! $step || 'failed' !== $step['status'] ) return new WP_Error( 'agent_step_not_retryable', __( 'Only failed steps can be retried.', 'k20-ai-press' ), array( 'status' => 409 ) );
        if ( (int) $step['attempt_count'] >= self::MAX_RETRIES ) return new WP_Error( 'agent_step_retry_limit', __( 'Agent step retry limit reached.', 'k20-ai-press' ), array( 'status' => 409 ) );
        $next_status = ! empty( $step['requires_approval'] ) && empty( $step['approved_at'] ) ? 'waiting_approval' : ( ! empty( $step['requires_approval'] ) ? 'approved' : 'planned' );
        $wpdb->update( $t['agent_steps'], array( 'status' => $next_status, 'last_error' => null, 'updated_at' => current_time( 'mysql', true ) ), array( 'id' => $step_id ) );
        $wpdb->update( $t['agent_runs'], array( 'status' => 'waiting_approval' === $next_status ? 'waiting_approval' : 'plan_ready', 'last_error' => null, 'finished_at' => null, 'updated_at' => current_time( 'mysql', true ) ), array( 'id' => (int) $run['id'] ) );
        return $this->get_run( $run_key );
    }

    /** @return array<string,mixed>|WP_Error */
    public function get_run( string $run_key ): array|WP_Error {
        global $wpdb;
        $run = $this->row_for_key( $run_key );
        if ( is_wp_error( $run ) ) return $run;
        $t = K20AI_Database::tables();
        $steps = $wpdb->get_results( $wpdb->prepare( "SELECT id,position,ability,risk_class,status,input_json,output_json,evidence_json,requires_approval,approved_by,approved_at,attempt_count,last_error,created_at,updated_at FROM {$t['agent_steps']} WHERE run_id=%d ORDER BY position ASC,id ASC", (int) $run['id'] ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        foreach ( (array) $steps as &$step ) {
            $step['id'] = (int) $step['id'];
            $step['position'] = (int) $step['position'];
            $step['requires_approval'] = (bool) $step['requires_approval'];
            $step['attempt_count'] = (int) $step['attempt_count'];
            $step['input'] = $this->decode_json( $step['input_json'] );
            $step['output'] = $this->decode_json( $step['output_json'] );
            $step['evidence'] = $this->decode_json( $step['evidence_json'] );
            unset( $step['input_json'], $step['output_json'], $step['evidence_json'], $step['approved_by'] );
        }
        unset( $step );
        $run['id'] = (int) $run['id'];
        $run['estimated_cost'] = null === $run['estimated_cost'] ? null : (float) $run['estimated_cost'];
        $run['context'] = $this->decode_json( $run['context'] );
        $run['steps'] = is_array( $steps ) ? $steps : array();
        $run['progress'] = $run['steps'] ? (int) round( 100 * count( array_filter( $run['steps'], static fn( array $s ): bool => 'completed' === $s['status'] ) ) / count( $run['steps'] ) ) : 0;
        unset( $run['idempotency_key'], $run['actor_id'] );
        return $run;
    }

    /** @return array<int,array<string,mixed>> */
    public function list_runs( int $limit = 20 ): array {
        global $wpdb;
        $t = K20AI_Database::tables();
        $limit = max( 1, min( 100, $limit ) );
        $rows = $wpdb->get_results( $wpdb->prepare( "SELECT run_key,objective,mode,status,created_at,started_at,finished_at,updated_at,last_error FROM {$t['agent_runs']} ORDER BY id DESC LIMIT %d", $limit ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        return is_array( $rows ) ? $rows : array();
    }

    /** @return array<string,int> */
    public function summary(): array {
        global $wpdb;
        $t = K20AI_Database::tables();
        $row = $wpdb->get_row( "SELECT COUNT(*) total,SUM(status='running') running,SUM(status='waiting_approval') waiting_approval,SUM(status='failed') failed,SUM(status='completed') completed FROM {$t['agent_runs']}", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        return array_map( 'intval', array(
            'total'            => $row['total'] ?? 0,
            'running'          => $row['running'] ?? 0,
            'waiting_approval' => $row['waiting_approval'] ?? 0,
            'failed'           => $row['failed'] ?? 0,
            'completed'        => $row['completed'] ?? 0,
        ) );
    }


    private function cleanup_incomplete_plan( int $run_id ): bool {
        global $wpdb;
        if ( $run_id < 1 ) return true;
        $t = K20AI_Database::tables();
        $steps_deleted = $wpdb->delete( $t['agent_steps'], array( 'run_id' => $run_id ), array( '%d' ) );
        $run_deleted = $wpdb->delete( $t['agent_runs'], array( 'id' => $run_id ), array( '%d' ) );
        return false !== $steps_deleted && false !== $run_deleted;
    }

    /** @return array<int,array<string,mixed>>|WP_Error */
    private function plan_steps( string $objective, string $mode, array $context, array $requested ): array|WP_Error {
        $abilities = array();
        foreach ( $requested as $raw ) {
            if ( is_string( $raw ) ) $abilities[] = array( 'ability' => sanitize_text_field( $raw ), 'input' => array() );
            elseif ( is_array( $raw ) && ! empty( $raw['ability'] ) ) $abilities[] = array( 'ability' => sanitize_text_field( (string) $raw['ability'] ), 'input' => (array) ( $raw['input'] ?? array() ) );
        }
        if ( $abilities ) {
            $this->last_plan_meta = array( 'planner' => 'explicit-abilities', 'provider' => 'user-specified', 'model' => null, 'estimated_cost' => null );
        } else {
            $planned = $this->structured_plan( $objective, $mode, $context );
            if ( is_wp_error( $planned ) ) {
                K20AI_Logger::warning( 'Structured agent planner unavailable; deterministic fallback used.', array( 'code' => $planned->get_error_code() ) );
                $abilities = $this->heuristic_plan( $objective, $context );
                $this->last_plan_meta = array( 'planner' => 'local-deterministic-fallback', 'provider' => 'local-deterministic', 'model' => null, 'estimated_cost' => null );
            } else {
                $abilities = $planned;
            }
        }
        $abilities = array_slice( $abilities, 0, self::MAX_STEPS );
        $steps = array();
        foreach ( $abilities as $item ) {
            $ability = (string) $item['ability'];
            $spec = $this->registry->get( $ability );
            if ( ! $spec || 'internal_legacy' === (string) ( $spec['surface'] ?? '' ) ) continue;
            if ( ! $this->agent_ability_allowed( $ability, $spec ) ) continue;
            if ( 'read_only' === $mode && ! empty( $spec['side_effect'] ) ) continue;
            $raw_input = array_merge( $this->default_input_for_ability( $ability, $context ), (array) $item['input'] );
            if ( $this->contains_sensitive_input( $raw_input ) ) {
                return new WP_Error( 'agent_sensitive_input_rejected', __( 'Agent plans cannot persist credentials, license keys, passwords, tokens, or other secrets. Use the dedicated secure configuration workflow instead.', 'k20-ai-press' ), array( 'status' => 422, 'ability' => $ability ) );
            }
            $input = $this->sanitize_context( $raw_input );
            $protected = K20AI_Security::protected_fields_error( $input['fields'] ?? array() );
            if ( is_wp_error( $protected ) ) return $protected;
            $requires = ! empty( $spec['side_effect'] ) || ! empty( $spec['requires_confirmation'] );
            $steps[] = array(
                'ability'           => $ability,
                'risk_class'        => (string) ( $spec['risk_class'] ?? 'READ' ),
                'input'             => $input,
                'requires_approval' => $requires,
                'evidence'          => array( 'objective' => $objective, 'source' => (string) ( $this->last_plan_meta['planner'] ?? 'agent_plan' ), 'provider' => (string) ( $this->last_plan_meta['provider'] ?? 'local-deterministic' ), 'model' => $this->last_plan_meta['model'] ?? null, 'planner_reason' => sanitize_text_field( (string) ( $item['_planner_reason'] ?? '' ) ), 'planner_confidence' => isset( $item['_planner_confidence'] ) ? (float) $item['_planner_confidence'] : null, 'measured_context' => array_keys( $context ) ),
            );
        }
        return $steps;
    }


    /** @return array<int,array<string,mixed>>|WP_Error */
    private function structured_plan( string $objective, string $mode, array $context ): array|WP_Error {
        if ( ! $this->connections ) {
            return new WP_Error( 'agent_planner_unavailable', __( 'No AI connection center is available for structured planning.', 'k20-ai-press' ) );
        }
        $provider = $this->planner_provider();
        if ( '' === $provider ) {
            return new WP_Error( 'agent_planner_disconnected', __( 'No verified AI provider is connected for structured planning.', 'k20-ai-press' ) );
        }

        $allowed = array();
        foreach ( $this->registry->visible() as $name => $spec ) {
            if ( ! $this->agent_ability_allowed( (string) $name, $spec ) ) continue;
            if ( 'read_only' === $mode && ! empty( $spec['side_effect'] ) ) continue;
            $allowed[] = array(
                'ability' => (string) $name,
                'risk' => (string) ( $spec['risk_class'] ?? 'READ' ),
                'side_effect' => ! empty( $spec['side_effect'] ),
                'description' => substr( wp_strip_all_tags( (string) ( $spec['description'] ?? '' ) ), 0, 240 ),
                'input_schema' => (array) ( $spec['input_schema'] ?? array() ),
            );
        }
        if ( ! $allowed ) return new WP_Error( 'agent_planner_no_abilities', __( 'No abilities are available to the structured planner.', 'k20-ai-press' ) );

        $schema = array(
            'type' => 'object',
            'additionalProperties' => false,
            'properties' => array(
                'steps' => array(
                    'type' => 'array',
                    'maxItems' => self::MAX_STEPS,
                    'items' => array(
                        'type' => 'object',
                        'additionalProperties' => false,
                        'properties' => array(
                            'ability' => array( 'type' => 'string' ),
                            'input' => array( 'type' => 'object', 'additionalProperties' => true ),
                            'reason' => array( 'type' => 'string', 'maxLength' => 500 ),
                            'confidence' => array( 'type' => 'number', 'minimum' => 0, 'maximum' => 1 ),
                        ),
                        'required' => array( 'ability', 'input', 'reason', 'confidence' ),
                    ),
                ),
                'warnings' => array( 'type' => 'array', 'items' => array( 'type' => 'string' ), 'maxItems' => 10 ),
            ),
            'required' => array( 'steps', 'warnings' ),
        );
        $system = implode( "\n", array(
            'You are a constrained WordPress operations planner.',
            'Return JSON only and use only abilities present in the supplied allowlist.',
            'Do not invent identifiers, facts, credentials, URLs, prices, stock values, payment data, or customer data.',
            'Prefer read abilities before writes. Any write will still require policy validation and human approval.',
            'Choose the minimum sufficient steps, maximum 12.',
        ) );
        $prompt = "Objective:\n" . $objective . "\n\nMode: " . $mode . "\n\nSanitized context:\n" . wp_json_encode( $context, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . "\n\nAllowed abilities:\n" . wp_json_encode( $allowed, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
        $generated = $this->connections->ai_generate( $provider, array( 'system' => $system, 'prompt' => $prompt, 'schema' => $schema, 'web_search' => false ) );
        if ( is_wp_error( $generated ) ) return $generated;
        $data = (array) ( $generated['data'] ?? array() );
        $raw_steps = (array) ( $data['steps'] ?? array() );
        if ( ! $raw_steps ) return new WP_Error( 'agent_planner_empty', __( 'The structured planner returned no executable steps.', 'k20-ai-press' ) );
        $steps = array();
        foreach ( array_slice( $raw_steps, 0, self::MAX_STEPS ) as $raw ) {
            if ( ! is_array( $raw ) || empty( $raw['ability'] ) ) continue;
            $ability = sanitize_text_field( (string) $raw['ability'] );
            $spec = $this->registry->get( $ability );
            if ( ! $spec || ! $this->agent_ability_allowed( $ability, $spec ) ) continue;
            if ( 'read_only' === $mode && ! empty( $spec['side_effect'] ) ) continue;
            $input = is_array( $raw['input'] ?? null ) ? (array) $raw['input'] : array();
            if ( $this->contains_sensitive_input( $input ) ) continue;
            $steps[] = array(
                'ability' => $ability,
                'input' => $input,
                '_planner_reason' => substr( sanitize_text_field( (string) ( $raw['reason'] ?? '' ) ), 0, 500 ),
                '_planner_confidence' => max( 0.0, min( 1.0, (float) ( $raw['confidence'] ?? 0 ) ) ),
            );
        }
        if ( ! $steps ) return new WP_Error( 'agent_planner_rejected', __( 'The structured planner did not return any policy-compliant abilities.', 'k20-ai-press' ) );
        $this->last_plan_meta = array(
            'planner' => 'llm-structured',
            'provider' => $provider,
            'model' => sanitize_text_field( (string) ( $generated['model'] ?? '' ) ),
            'estimated_cost' => null,
        );
        return $steps;
    }

    private function planner_provider(): string {
        if ( ! $this->connections ) return '';
        foreach ( array( 'openai', 'gemini', 'anthropic', 'deepseek', 'custom_ai' ) as $provider ) {
            $row = $this->connections->get( $provider, false );
            if ( 'connected' === (string) ( $row['status'] ?? '' ) ) return $provider;
        }
        return '';
    }

    /**
     * Keep the autonomous surface intentionally smaller than the whole admin API.
     * Read abilities are allowed unless they belong to security, identity, licensing,
     * migration, support/order, or agent-control namespaces. Side effects require an
     * explicit allowlist and still pass through confirmation + Services permissions.
     *
     * @param array<string,mixed> $spec
     */
    private function agent_ability_allowed( string $ability, array $spec ): bool {
        foreach ( array( 'agent.', 'license.', 'migration.', 'onboarding.', 'webhook.', 'budget.', 'mode.', 'support.', 'order.', 'return.', 'quote.' ) as $prefix ) {
            if ( str_starts_with( $ability, $prefix ) ) return false;
        }
        if ( in_array( $ability, array( 'admin.review_claim', 'admin.publish_rule', 'bot.policy.update', 'brand.truth.update' ), true ) ) return false;
        if ( empty( $spec['side_effect'] ) ) return true;
        return in_array( $ability, array(
            'product.autofix',
            'product.update',
            'admin.trigger_reindex',
            'graph.rebuild',
            'robots.apply_virtual',
            'robots.rollback',
            'visibility.query.upsert',
        ), true );
    }

    /** @param array<string,mixed> $input */
    private function contains_sensitive_input( array $input ): bool {
        foreach ( $input as $key => $value ) {
            $name = strtolower( (string) $key );
            if ( preg_match( '/(?:secret|password|passwd|authorization|api[_-]?key|license[_-]?key|client[_-]?secret|access[_-]?token|refresh[_-]?token|private[_-]?key|cookie)/i', $name ) ) return true;
            if ( is_array( $value ) && $this->contains_sensitive_input( $value ) ) return true;
        }
        return false;
    }

    /** @return array<int,array<string,mixed>> */
    private function heuristic_plan( string $objective, array $context ): array {
        $text = mb_strtolower( $objective );
        $plan = array( array( 'ability' => 'audit.run', 'input' => array() ) );
        $product_id = absint( $context['product_id'] ?? 0 );
        if ( $product_id ) {
            $plan[] = array( 'ability' => 'product.get', 'input' => array( 'product_id' => $product_id ) );
            $plan[] = array( 'ability' => 'product.intelligence', 'input' => array( 'product_id' => $product_id ) );
            $plan[] = array( 'ability' => 'schema.validate', 'input' => array( 'product_id' => $product_id ) );
            $plan[] = array( 'ability' => 'parity.validate', 'input' => array( 'product_id' => $product_id ) );
        }
        if ( preg_match( '/product|commerce|merchant|محصول|فروش|کاتالوگ/u', $text ) ) {
            $plan[] = array( 'ability' => 'product.intelligence.backlog', 'input' => array( 'limit' => 20 ) );
            $plan[] = array( 'ability' => 'feed.health', 'input' => array() );
            $plan[] = array( 'ability' => 'media.audit', 'input' => array() );
            $plan[] = array( 'ability' => 'taxonomy.audit', 'input' => array() );
        }
        if ( preg_match( '/visibility|citation|geo|aeo|chatgpt|gemini|perplexity|ai search|دیده|استناد|هوش مصنوعی/u', $text ) ) {
            $plan[] = array( 'ability' => 'visibility.observatory', 'input' => array( 'days' => 30 ) );
        }
        if ( preg_match( '/technical|crawl|index|schema|سئو|خزش|ایندکس|فنی/u', $text ) ) {
            $plan[] = array( 'ability' => 'observability.status', 'input' => array() );
            $plan[] = array( 'ability' => 'system.retest', 'input' => array() );
        }
        if ( preg_match( '/fix|autofix|اصلاح|درست/u', $text ) && $product_id ) {
            $plan[] = array( 'ability' => 'product.autofix', 'input' => array( 'product_id' => $product_id, 'scope' => 'safe' ) );
        }
        $seen = array();
        return array_values( array_filter( $plan, static function( array $item ) use ( &$seen ): bool {
            $key = $item['ability'] . '|' . md5( wp_json_encode( $item['input'] ) );
            if ( isset( $seen[ $key ] ) ) return false;
            $seen[ $key ] = true;
            return true;
        } ) );
    }

    /** @return array<string,mixed> */
    private function default_input_for_ability( string $ability, array $context ): array {
        $input = array();
        if ( str_starts_with( $ability, 'product.' ) || in_array( $ability, array( 'schema.validate', 'schema.preview', 'parity.validate', 'media.truth', 'reviews.summary', 'gs1.mapping' ), true ) ) {
            if ( ! empty( $context['product_id'] ) ) $input['product_id'] = absint( $context['product_id'] );
        }
        return $input;
    }

    /** @return array<string,mixed>|WP_Error */
    private function verify_step( string $ability, array $input ): array|WP_Error {
        if ( in_array( $ability, array( 'product.update', 'product.autofix' ), true ) && ! empty( $input['product_id'] ) ) {
            $result = $this->services->execute( 'product.get', array( 'product_id' => absint( $input['product_id'] ) ), false );
            return is_wp_error( $result ) ? $result : array( 'ability' => 'product.get', 'result' => $result );
        }
        if ( 'robots.apply_virtual' === $ability || 'robots.rollback' === $ability ) {
            $result = $this->services->execute( 'robots.preview', array(), false );
            return is_wp_error( $result ) ? $result : array( 'ability' => 'robots.preview', 'result' => $result );
        }
        return array( 'ability' => null, 'status' => 'not_required' );
    }

    /** @return array<string,mixed>|WP_Error */
    private function row_for_key( string $run_key ): array|WP_Error {
        global $wpdb;
        $run_key = sanitize_text_field( $run_key );
        if ( ! preg_match( '/^[a-f0-9-]{20,40}$/i', $run_key ) ) return new WP_Error( 'invalid_agent_run_key', __( 'Invalid agent run key.', 'k20-ai-press' ), array( 'status' => 422 ) );
        $t = K20AI_Database::tables();
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t['agent_runs']} WHERE run_key=%s LIMIT 1", $run_key ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        return $row ?: new WP_Error( 'agent_run_not_found', __( 'Agent run was not found.', 'k20-ai-press' ), array( 'status' => 404 ) );
    }

    /** @return array<string,mixed> */
    private function sanitize_context( array $context ): array {
        return K20AI_Logger::sanitize_context( $context );
    }

    /** @return array<string,mixed> */
    private function decode_json( mixed $value ): array {
        if ( ! is_string( $value ) || '' === $value ) return array();
        $decoded = json_decode( $value, true );
        return is_array( $decoded ) ? $decoded : array();
    }
}
