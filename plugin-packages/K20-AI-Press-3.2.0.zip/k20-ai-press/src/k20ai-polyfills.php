<?php
/**
 * Tiny UTF-8 fallbacks for hosts without ext-mbstring.
 * WordPress commonly runs with mbstring, but the plugin must not fatal when it is absent.
 */
defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'mb_strlen' ) ) {
    function mb_strlen( $string, $encoding = null ) { // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedFunctionFound
        $string = (string) $string;
        if ( '' === $string ) { return 0; }
        $ok = preg_match_all( '/./us', $string, $matches );
        return false === $ok ? strlen( $string ) : $ok;
    }
}
if ( ! function_exists( 'mb_substr' ) ) {
    function mb_substr( $string, $start, $length = null, $encoding = null ) { // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedFunctionFound
        $chars = preg_split( '//u', (string) $string, -1, PREG_SPLIT_NO_EMPTY );
        if ( false === $chars ) { return null === $length ? substr( (string) $string, (int) $start ) : substr( (string) $string, (int) $start, (int) $length ); }
        $slice = null === $length ? array_slice( $chars, (int) $start ) : array_slice( $chars, (int) $start, (int) $length );
        return implode( '', $slice );
    }
}
if ( ! function_exists( 'mb_strtolower' ) ) {
    function mb_strtolower( $string, $encoding = null ) { // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedFunctionFound
        return strtolower( (string) $string );
    }
}
if ( ! function_exists( 'mb_stripos' ) ) {
    function mb_stripos( $haystack, $needle, $offset = 0, $encoding = null ) { // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedFunctionFound
        return stripos( (string) $haystack, (string) $needle, (int) $offset );
    }
}
