<?php

defined( 'ABSPATH' ) || exit;

/**
 * Guarded AI completion layer.
 *
 * Important safety rule: AI may improve descriptive/SEO fields but may not invent
 * transactional or identifier truth (price, stock, SKU, GTIN, MPN, model, dimensions).
 * Those fields remain authoritative from WooCommerce/user evidence unless a cited,
 * high-confidence value is explicitly returned and the user approves it.
 */
final class K20AI_AI_Orchestrator {
    private const PREVIEW_PREFIX = 'k20ai_ai_preview_';
    private const PREVIEW_TTL = 900;

    private K20AI_SEO_OS $seo;
    private K20AI_Connection_Center $connections;

    public function __construct( K20AI_SEO_OS $seo, K20AI_Connection_Center $connections ) {
        $this->seo = $seo;
        $this->connections = $connections;
    }

    /** @return array<int,array<string,mixed>> */
    public function providers(): array {
        $out = array();
        foreach ( $this->connections->snapshot() as $row ) {
            if ( 'ai' !== (string) ( $row['category'] ?? '' ) ) continue;
            $out[] = array(
                'key' => (string) $row['key'],
                'label' => (string) $row['label'],
                'status' => (string) $row['status'],
                'model' => $this->provider_model( (string) $row['key'] ),
                'last_test_at' => $row['last_test_at'] ?? null,
                'last_error' => $row['last_error'] ?? null,
            );
        }
        return $out;
    }

    /** @return array<string,mixed>|WP_Error */
    public function preview( string $kind, int $id, array $options = array() ): array|WP_Error {
        $kind = sanitize_key( $kind );
        $id = absint( $id );
        if ( $id <= 0 ) return new WP_Error( 'invalid_entity', __( 'The requested entity is invalid.', 'k20-ai-press' ), array( 'status' => 400 ) );
        $access_error = K20AI_Entity_Access::edit_error( $kind, $id );
        if ( is_wp_error( $access_error ) ) return $access_error;

        $detail = $this->seo->entity_detail( $kind, $id );
        if ( empty( $detail['evidence'] ) ) return new WP_Error( 'entity_not_found', __( 'داده قابل تحلیل برای این موجودیت پیدا نشد.', 'k20-ai-press' ), array( 'status' => 404 ) );

        $provider = sanitize_key( (string) ( $options['provider'] ?? '' ) );
        if ( '' === $provider ) $provider = $this->first_connected_provider();
        if ( '' === $provider ) return new WP_Error( 'ai_not_connected', __( 'هیچ موتور AI با تست اتصال موفق فعال نیست. ابتدا از «سیستم ← مرکز اتصال» یک Provider را متصل و تست کنید.', 'k20-ai-press' ), array( 'status' => 409 ) );
        $connection = $this->connections->get( $provider, false );
        if ( 'connected' !== (string) ( $connection['status'] ?? '' ) ) return new WP_Error( 'ai_not_connected', __( 'Provider انتخاب‌شده اتصال تست‌شده ندارد.', 'k20-ai-press' ), array( 'status' => 409 ) );

        $evidence = (array) $detail['evidence'];
        $edit = (array) ( $detail['edit'] ?? array() );
        $research = ! empty( $options['research'] ) && 'openai' === $provider;
        $target = sanitize_key( (string) ( $options['target'] ?? 'missing_and_weak' ) );
        if ( ! in_array( $target, array( 'missing_only','missing_and_weak','seo_only','content_only' ), true ) ) $target = 'missing_and_weak';

        $request = array(
            'system' => $this->system_prompt( $kind ),
            'prompt' => $this->entity_prompt( $kind, $id, $evidence, $edit, $target, $research ),
            'web_search' => $research,
            'schema' => $this->completion_schema( $kind ),
        );
        $generated = $this->connections->ai_generate( $provider, $request );
        if ( is_wp_error( $generated ) ) return $generated;

        $parsed = $this->normalize_ai_result( $kind, $evidence, $edit, (array) ( $generated['data'] ?? array() ), (array) ( $generated['sources'] ?? array() ) );
        if ( is_wp_error( $parsed ) ) return $parsed;
        $fields = (array) $parsed['fields'];
        if ( empty( $fields ) ) return new WP_Error( 'no_safe_changes', __( 'مدل تغییر قابل‌اعتماد و قابل‌اعمالی پیشنهاد نکرد.', 'k20-ai-press' ), array( 'status' => 422 ) );

        $diff = $this->build_diff( $kind, $evidence, $fields );
        $preview_id = wp_generate_uuid4();
        set_transient( self::PREVIEW_PREFIX . $preview_id, array(
            'user_id' => get_current_user_id(),
            'kind' => $kind,
            'id' => $id,
            'provider' => $provider,
            'model' => (string) ( $generated['model'] ?? $this->provider_model( $provider ) ),
            'fields' => $fields,
            'diff' => $diff,
            'sources' => (array) ( $generated['sources'] ?? array() ),
            'warnings' => (array) $parsed['warnings'],
            'reasoning' => (array) $parsed['reasoning'],
            'created_at' => time(),
        ), self::PREVIEW_TTL );

        return array(
            'preview_id' => $preview_id,
            'provider' => $provider,
            'model' => (string) ( $generated['model'] ?? $this->provider_model( $provider ) ),
            'entity' => array( 'kind' => $kind, 'id' => $id, 'title' => (string) ( $evidence['title'] ?? '' ) ),
            'fields' => $fields,
            'diff' => $diff,
            'sources' => (array) ( $generated['sources'] ?? array() ),
            'warnings' => (array) $parsed['warnings'],
            'reasoning' => (array) $parsed['reasoning'],
            'expires_in' => self::PREVIEW_TTL,
            'requires_human_approval' => true,
        );
    }

    /** @return array<string,mixed>|WP_Error */
    public function apply_preview( string $preview_id, array $selected_fields = array() ): array|WP_Error {
        $preview_id = sanitize_text_field( $preview_id );
        $payload = get_transient( self::PREVIEW_PREFIX . $preview_id );
        if ( ! is_array( $payload ) ) return new WP_Error( 'preview_expired', __( 'پیش‌نمایش منقضی شده است؛ دوباره «تکمیل با AI» را اجرا کنید.', 'k20-ai-press' ), array( 'status' => 410 ) );
        if ( (int) ( $payload['user_id'] ?? 0 ) !== get_current_user_id() ) return new WP_Error( 'preview_owner', __( 'This preview belongs to another user.', 'k20-ai-press' ), array( 'status' => 403 ) );
        $access_error = K20AI_Entity_Access::edit_error( (string) ( $payload['kind'] ?? '' ), (int) ( $payload['id'] ?? 0 ) );
        if ( is_wp_error( $access_error ) ) return $access_error;

        $fields = (array) ( $payload['fields'] ?? array() );
        if ( $selected_fields ) {
            $allowed = array_map( 'sanitize_key', $selected_fields );
            $fields = array_intersect_key( $fields, array_flip( $allowed ) );
        }
        if ( empty( $fields ) ) return new WP_Error( 'no_fields', __( 'هیچ فیلدی برای اعمال انتخاب نشده است.', 'k20-ai-press' ), array( 'status' => 422 ) );

        $result = $this->seo->update_entity( (string) $payload['kind'], (int) $payload['id'], $fields );
        if ( is_wp_error( $result ) ) return $result;
        delete_transient( self::PREVIEW_PREFIX . $preview_id );
        return array(
            'status' => 'applied',
            'provider' => $payload['provider'],
            'model' => $payload['model'],
            'applied_fields' => array_keys( $fields ),
            'entity' => $result,
        );
    }

    private function first_connected_provider(): string {
        $preferred = array( 'openai','gemini','anthropic','deepseek','custom_ai' );
        $snapshot = array();
        foreach ( $this->connections->snapshot() as $row ) $snapshot[ (string) $row['key'] ] = $row;
        foreach ( $preferred as $key ) if ( 'connected' === (string) ( $snapshot[ $key ]['status'] ?? '' ) ) return $key;
        return '';
    }

    private function provider_model( string $provider ): string {
        $row = $this->connections->get( $provider, false );
        return (string) ( $row['config']['model'] ?? '' );
    }

    private function system_prompt( string $kind ): string {
        return implode( "\n", array(
            'You are a guarded ecommerce SEO/GEO data enrichment engine for a Persian WooCommerce/WordPress site.',
            'Return ONE valid JSON object only. Do not include markdown.',
            'Never invent price, stock, SKU, GTIN, MPN, model, dimensions, certifications, country of origin, usage dosage, safety claims, registrations or technical specifications.',
            'Preserve authoritative existing values unless a correction is explicitly supported by supplied evidence or cited web source.',
            'Taxonomy choices must use only allowed IDs supplied in the prompt. Never create an unknown category, brand, or attribute term.',
            'Persian visible copy must be natural, professional, useful, non-spammy and people-first.',
            'For uncertain fields return null and explain in warnings. It is better to leave a field empty than fabricate.',
            'Output schema: {"fields":object,"reasoning":object,"warnings":array}.',
            'Reasoning must be short field-level explanations, not hidden chain-of-thought.',
            'For image ALT describe the actual supplied image context/title when available; never keyword-stuff.',
            'Entity kind: ' . $kind,
        ) );
    }

    /** @return array<string,mixed> */
    private function completion_schema( string $kind ): array {
        $nullable_string = array( 'type' => array( 'string', 'null' ) );
        $field_properties = array();
        if ( 'product' === $kind ) {
            foreach ( array( 'title','seo_title','meta_description','short_description','description','gtin','mpn','model','weight','length','width','height' ) as $key ) {
                $field_properties[ $key ] = $nullable_string;
            }
            $field_properties['categories'] = array( 'type' => array( 'array','null' ), 'items' => array( 'type' => 'integer' ) );
            $field_properties['brand_id'] = array( 'type' => array( 'integer','null' ) );
            $field_properties['attribute_terms'] = array( 'type' => array( 'object','null' ), 'additionalProperties' => array( 'type' => 'array', 'items' => array( 'type' => 'integer' ) ) );
            $field_properties['image_alts'] = array( 'type' => array( 'object','null' ), 'additionalProperties' => array( 'type' => 'string' ) );
        } elseif ( 'media' === $kind ) {
            $field_properties = array( 'title' => $nullable_string, 'alt' => $nullable_string );
        } else {
            foreach ( array( 'title','seo_title','meta_description','excerpt','content' ) as $key ) $field_properties[ $key ] = $nullable_string;
        }
        return array(
            'type' => 'object',
            'properties' => array(
                'fields' => array( 'type' => 'object', 'properties' => $field_properties, 'additionalProperties' => false ),
                'reasoning' => array( 'type' => 'object', 'additionalProperties' => array( 'type' => 'string' ) ),
                'warnings' => array( 'type' => 'array', 'items' => array( 'type' => 'string' ) ),
            ),
            'required' => array( 'fields','reasoning','warnings' ),
            'additionalProperties' => false,
        );
    }

    /** @param array<string,mixed> $evidence @param array<string,mixed> $edit */
    private function entity_prompt( string $kind, int $id, array $evidence, array $edit, string $target, bool $research ): string {
        $safe_evidence = $evidence;
        unset( $safe_evidence['content'] );
        $content = wp_strip_all_tags( (string) ( $evidence['content'] ?? '' ) );
        $content = mb_substr( $content, 0, 12000 );
        $safe_evidence['content_excerpt_for_context'] = $content;

        $allowed = array(
            'categories' => array_values( (array) ( $edit['categories'] ?? array() ) ),
            'brands' => array_values( (array) ( $edit['brands'] ?? array() ) ),
            'attributes' => array_values( (array) ( $edit['attributes'] ?? array() ) ),
        );
        $shape = 'product' === $kind
            ? array( 'title','seo_title','meta_description','short_description','description','categories','brand_id','attribute_terms','image_alts','gtin','mpn','model','weight','length','width','height' )
            : ( 'media' === $kind ? array( 'title','alt' ) : array( 'title','seo_title','meta_description','excerpt','content' ) );

        return "Task: enrich entity {$kind}:{$id}.\n" .
            'Mode: ' . $target . '. Research enabled: ' . ( $research ? 'yes' : 'no' ) . ".\n" .
            'Only propose these field keys: ' . implode( ', ', $shape ) . ".\n" .
            "For identifiers/measurements (gtin/mpn/model/weight/length/width/height), only return a value when it is already present in authoritative evidence or a cited official source. Otherwise null.\n" .
            "For price/stock/SKU: never propose changes.\n" .
            "For category/brand/attribute terms use allowed IDs only.\n" .
            "For content fields, improve only when the page is thin/missing or target requests it; preserve verified facts.\n" .
            "Current evidence JSON:\n" . wp_json_encode( $safe_evidence, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . "\n" .
            "Allowed taxonomy JSON:\n" . wp_json_encode( $allowed, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
    }

    /** @return array<string,mixed>|WP_Error */
    private function normalize_ai_result( string $kind, array $evidence, array $edit, array $data, array $sources ): array|WP_Error {
        $raw_fields = isset( $data['fields'] ) && is_array( $data['fields'] ) ? $data['fields'] : array();
        $fields = array();
        $warnings = isset( $data['warnings'] ) && is_array( $data['warnings'] ) ? array_map( 'sanitize_text_field', $data['warnings'] ) : array();
        $reasoning = isset( $data['reasoning'] ) && is_array( $data['reasoning'] ) ? array_map( 'sanitize_text_field', $data['reasoning'] ) : array();

        $text_keys = 'product' === $kind
            ? array( 'title','seo_title','meta_description','short_description','description' )
            : ( 'media' === $kind ? array( 'title','alt' ) : array( 'title','seo_title','meta_description','excerpt','content' ) );
        foreach ( $text_keys as $key ) {
            if ( ! isset( $raw_fields[ $key ] ) || null === $raw_fields[ $key ] ) continue;
            $value = (string) $raw_fields[ $key ];
            if ( in_array( $key, array( 'description','content' ), true ) ) $value = K20AI_Data_Integrity::clean_html( $value );
            elseif ( in_array( $key, array( 'meta_description','short_description','excerpt' ), true ) ) $value = K20AI_Data_Integrity::clean_textarea( $value );
            else $value = K20AI_Data_Integrity::clean_text( $value );
            if ( '' !== trim( $value ) ) $fields[ $key ] = $value;
        }

        if ( 'product' === $kind ) {
            $category_ids = array_column( (array) ( $edit['categories'] ?? array() ), 'id' );
            $category_ids = array_map( 'absint', $category_ids );
            if ( isset( $raw_fields['categories'] ) && is_array( $raw_fields['categories'] ) ) {
                $candidate = array_values( array_intersect( array_map( 'absint', $raw_fields['categories'] ), $category_ids ) );
                if ( $candidate ) $fields['categories'] = $candidate;
            }
            $brand_ids = array_map( 'absint', array_column( (array) ( $edit['brands'] ?? array() ), 'id' ) );
            if ( isset( $raw_fields['brand_id'] ) ) {
                $brand = absint( $raw_fields['brand_id'] );
                if ( $brand && in_array( $brand, $brand_ids, true ) ) $fields['brand_id'] = $brand;
            }
            if ( isset( $raw_fields['attribute_terms'] ) && is_array( $raw_fields['attribute_terms'] ) ) {
                $allowed_terms = array();
                foreach ( (array) ( $edit['attributes'] ?? array() ) as $attr ) {
                    $taxonomy = sanitize_key( (string) ( $attr['taxonomy'] ?? '' ) );
                    if ( ! str_starts_with( $taxonomy, 'pa_' ) ) continue;
                    $allowed_terms[ $taxonomy ] = array_map( 'absint', array_column( (array) ( $attr['terms'] ?? array() ), 'id' ) );
                }
                $mapped = array();
                foreach ( $raw_fields['attribute_terms'] as $taxonomy => $ids ) {
                    $taxonomy = sanitize_key( (string) $taxonomy );
                    if ( ! isset( $allowed_terms[ $taxonomy ] ) ) continue;
                    $safe = array_values( array_intersect( array_map( 'absint', (array) $ids ), $allowed_terms[ $taxonomy ] ) );
                    if ( $safe ) $mapped[ $taxonomy ] = $safe;
                }
                if ( $mapped ) $fields['attribute_terms'] = $mapped;
            }
            if ( isset( $raw_fields['image_alts'] ) && is_array( $raw_fields['image_alts'] ) ) {
                $allowed_images = array_map( 'absint', (array) ( $evidence['image_ids'] ?? array() ) );
                $alts = array();
                foreach ( $raw_fields['image_alts'] as $image_id => $alt ) {
                    $image_id = absint( $image_id );
                    if ( $image_id && in_array( $image_id, $allowed_images, true ) && '' !== trim( (string) $alt ) ) $alts[ $image_id ] = K20AI_Data_Integrity::clean_text( $alt );
                }
                if ( $alts ) $fields['image_alts'] = $alts;
            }

            // High-risk product truth is never written from free-form model output.
            // It may be researched and displayed as a warning, but must enter WooCommerce
            // through verified manufacturer/GS1/supplier evidence or explicit manual input.
            foreach ( array( 'gtin','mpn','model','weight','length','width','height' ) as $key ) {
                if ( ! isset( $raw_fields[ $key ] ) || null === $raw_fields[ $key ] || '' === trim( (string) $raw_fields[ $key ] ) ) continue;
                $candidate = K20AI_Data_Integrity::clean_text( $raw_fields[ $key ] );
                $existing = trim( (string) ( $evidence[ $key ] ?? '' ) );
                if ( '' !== $existing && $candidate === $existing ) continue;
                $warnings[] = "{$key}: مقدار پیشنهادی AI فقط برای بازبینی نمایش داده شد و به‌دلیل نیاز به منبع ساختاریافتهٔ معتبر قابل اعمال نیست.";
            }
        }
        return array( 'fields' => $fields, 'warnings' => array_values( array_unique( $warnings ) ), 'reasoning' => $reasoning );
    }

    /** @return array<int,array<string,mixed>> */
    private function build_diff( string $kind, array $evidence, array $fields ): array {
        $diff = array();
        foreach ( $fields as $key => $after ) {
            $before_key = $key;
            if ( 'description' === $key || 'short_description' === $key ) $before_key = 'content';
            elseif ( 'categories' === $key ) $before_key = 'category_ids';
            elseif ( 'brand_id' === $key ) $before_key = 'brand_term_ids';
            elseif ( 'image_alts' === $key ) $before_key = 'image_items';
            $before = $evidence[ $before_key ] ?? null;
            $diff[] = array( 'field' => $key, 'before' => $before, 'after' => $after, 'changed' => wp_json_encode( $before ) !== wp_json_encode( $after ) );
        }
        return array_values( array_filter( $diff, static fn( $row ) => ! empty( $row['changed'] ) ) );
    }
}
