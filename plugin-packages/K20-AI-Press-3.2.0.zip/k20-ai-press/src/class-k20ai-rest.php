<?php

defined( 'ABSPATH' ) || exit;

final class K20AI_REST {
    private K20AI_Services $services;
    private K20AI_Ability_Registry $registry;
    private K20AI_Advanced $advanced;

    public function __construct( K20AI_Services $services, K20AI_Ability_Registry $registry, K20AI_Advanced $advanced ) {
        $this->services = $services;
        $this->registry = $registry;
        $this->advanced = $advanced;
    }

    public function register(): void {
        register_rest_route( 'k20-ai/v1', '/dashboard', array( 'methods' => WP_REST_Server::READABLE, 'permission_callback' => array( $this, 'can_view' ), 'callback' => fn() => rest_ensure_response( $this->services->dashboard() ) ) );
        register_rest_route( 'k20-ai/v1', '/audit', array( 'methods' => WP_REST_Server::CREATABLE, 'permission_callback' => array( $this, 'can_view' ), 'callback' => fn() => rest_ensure_response( $this->services->execute( 'audit.run' ) ) ) );
        register_rest_route( 'k20-ai/v1', '/settings', array(
            array( 'methods' => WP_REST_Server::READABLE, 'permission_callback' => array( $this, 'can_view' ), 'callback' => fn() => rest_ensure_response( $this->services->settings() ) ),
            array( 'methods' => WP_REST_Server::EDITABLE, 'permission_callback' => array( $this, 'can_system' ), 'callback' => fn( WP_REST_Request $r ) => rest_ensure_response( $this->services->save_settings( (array) $r->get_json_params() ) ) ),
        ) );
        register_rest_route( 'k20-ai/v1', '/abilities', array( 'methods' => WP_REST_Server::READABLE, 'permission_callback' => array( $this, 'can_view' ), 'callback' => fn() => rest_ensure_response( array_values( $this->registry->visible() ) ) ) );
        register_rest_route( 'k20-ai/v1', '/abilities/(?P<ability>[A-Za-z0-9_.-]+)', array(
            'methods'             => WP_REST_Server::CREATABLE,
            'permission_callback' => array( $this, 'can_execute_ability' ),
            'callback'            => function( WP_REST_Request $request ) {
                $ability   = sanitize_text_field( (string) $request['ability'] );
                $body      = (array) $request->get_json_params();
                $input     = isset( $body['input'] ) && is_array( $body['input'] ) ? $body['input'] : array();
                $confirmed = ! empty( $body['confirmed'] );
                $result    = $this->services->execute( $ability, $input, $confirmed );
                return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
            },
        ) );
        register_rest_route( 'k20-ai/v1', '/openapi', array( 'methods' => WP_REST_Server::READABLE, 'permission_callback' => '__return_true', 'callback' => fn() => rest_ensure_response( $this->openapi() ) ) );
        register_rest_route( 'k20-ai/v1', '/health', array( 'methods' => WP_REST_Server::READABLE, 'permission_callback' => '__return_true', 'callback' => fn() => rest_ensure_response( $this->public_health() ) ) );
        register_rest_route( 'k20-ai/v1', '/feeds/acp', array(
            'methods' => WP_REST_Server::READABLE,
            'permission_callback' => array( $this, 'public_feed_rate_limit' ),
            'args' => array( 'limit' => array( 'sanitize_callback' => 'absint', 'default' => 100 ) ),
            'callback' => fn( WP_REST_Request $r ) => rest_ensure_response( $this->advanced->feed_acp( absint( $r->get_param( 'limit' ) ?: 100 ) ) ),
        ) );
        register_rest_route( 'k20-ai/v1', '/ucp', array( 'methods' => WP_REST_Server::READABLE, 'permission_callback' => '__return_true', 'callback' => fn() => rest_ensure_response( $this->advanced->ucp_profile() ) ) );
        register_rest_route( 'k20-ai/v1', '/ucp/catalog/search', array(
            'methods' => WP_REST_Server::CREATABLE,
            'permission_callback' => array( $this, 'public_catalog_rate_limit' ),
            'callback' => function( WP_REST_Request $r ) {
                $result = $this->advanced->ucp_catalog_search( (array) $r->get_json_params() );
                return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
            },
        ) );
        register_rest_route( 'k20-ai/v1', '/ucp/catalog/lookup', array(
            'methods' => WP_REST_Server::CREATABLE,
            'permission_callback' => array( $this, 'public_catalog_rate_limit' ),
            'callback' => function( WP_REST_Request $r ) {
                $result = $this->advanced->ucp_catalog_lookup( (array) $r->get_json_params() );
                return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
            },
        ) );
        register_rest_route( 'k20-ai/v1', '/ucp/catalog/product', array(
            'methods' => WP_REST_Server::CREATABLE,
            'permission_callback' => array( $this, 'public_catalog_rate_limit' ),
            'callback' => function( WP_REST_Request $r ) {
                $result = $this->advanced->ucp_catalog_product( (array) $r->get_json_params() );
                return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
            },
        ) );
        register_rest_route( 'k20-ai/v1', '/citation-pack', array(
            'methods' => WP_REST_Server::READABLE,
            'permission_callback' => array( $this, 'public_citation_rate_limit' ),
            'args' => array( 'url' => array( 'required' => true, 'sanitize_callback' => 'esc_url_raw' ) ),
            'callback' => function( WP_REST_Request $r ) {
                $result = $this->advanced->citation_pack( esc_url_raw( (string) $r->get_param( 'url' ) ) );
                return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
            },
        ) );
        register_rest_route( 'k20-ai/v1', '/rag/search', array(
            'methods' => WP_REST_Server::READABLE,
            'permission_callback' => array( $this, 'can_view' ),
            'args' => array( 'q' => array( 'required' => true, 'sanitize_callback' => 'sanitize_text_field' ), 'limit' => array( 'sanitize_callback' => 'absint', 'default' => 8 ) ),
            'callback' => fn( WP_REST_Request $r ) => rest_ensure_response( $this->advanced->rag_search( (string) $r->get_param( 'q' ), absint( $r->get_param( 'limit' ) ?: 8 ) ) ),
        ) );
        register_rest_route( 'k20-ai/v1', '/observability', array( 'methods' => WP_REST_Server::READABLE, 'permission_callback' => array( $this, 'can_view' ), 'callback' => fn() => rest_ensure_response( $this->advanced->observability() ) ) );
        register_rest_route( 'k20-ai/v1', '/mcp/status', array( 'methods' => WP_REST_Server::READABLE, 'permission_callback' => array( $this, 'can_view' ), 'callback' => fn() => rest_ensure_response( $this->advanced->mcp_status() ) ) );
    }

    public function can_view(): bool {
        return K20AI_Security::can_view();
    }

    public function can_system(): bool {
        return K20AI_Security::can_manage_system();
    }

    public function can_execute_ability( WP_REST_Request $request ): bool|WP_Error {
        $name = sanitize_text_field( (string) $request['ability'] );
        $ability = $this->registry->get( $name );
        if ( ! is_array( $ability ) ) {
            return new WP_Error( 'k20ai_ability_not_found', __( 'Ability not found.', 'k20-ai-press' ), array( 'status' => 404 ) );
        }
        if ( ! K20AI_Security::ability_permission( $ability ) ) {
            return new WP_Error( 'k20ai_ability_forbidden', __( 'Insufficient permission for this ability.', 'k20-ai-press' ), array( 'status' => 403 ) );
        }
        return true;
    }

    public function public_catalog_rate_limit(): bool|WP_Error {
        return $this->public_rate_limit( 'ucp', 60 );
    }

    public function public_feed_rate_limit(): bool|WP_Error {
        return $this->public_rate_limit( 'feed', 15 );
    }

    public function public_citation_rate_limit(): bool|WP_Error {
        return $this->public_rate_limit( 'citation', 30 );
    }

    private function public_rate_limit( string $bucket, int $limit ): bool|WP_Error {
        $ip = sanitize_text_field( (string) ( $_SERVER['REMOTE_ADDR'] ?? 'unknown' ) );
        $ua = substr( sanitize_text_field( (string) ( $_SERVER['HTTP_USER_AGENT'] ?? '' ) ), 0, 160 );
        $window = gmdate( 'YmdHi' );
        $key = 'k20ai_public_rl_' . substr( hash_hmac( 'sha256', $bucket . '|' . $ip . '|' . $ua . '|' . $window, wp_salt( 'nonce' ) ), 0, 32 );
        $limit = max( 1, $limit );

        if ( function_exists( 'wp_using_ext_object_cache' ) && wp_using_ext_object_cache() ) {
            $group = 'k20ai_public_rate_limit';
            if ( ! wp_cache_add( $key, 0, $group, MINUTE_IN_SECONDS + 5 ) ) {
                $existing = wp_cache_get( $key, $group );
                if ( false === $existing ) wp_cache_set( $key, 0, $group, MINUTE_IN_SECONDS + 5 );
            }
            $count = wp_cache_incr( $key, 1, $group );
            if ( false === $count ) {
                wp_cache_set( $key, 1, $group, MINUTE_IN_SECONDS + 5 );
                $count = 1;
            }
            if ( (int) $count > $limit ) return new WP_Error( 'rate_limited', __( 'Public API rate limit exceeded.', 'k20-ai-press' ), array( 'status' => 429 ) );
            return true;
        }

        $count = (int) get_transient( $key );
        if ( $count >= $limit ) return new WP_Error( 'rate_limited', __( 'Public API rate limit exceeded.', 'k20-ai-press' ), array( 'status' => 429 ) );
        set_transient( $key, $count + 1, MINUTE_IN_SECONDS + 5 );
        return true;
    }

    private function public_health(): array {
        $health = array( 'status' => 'ok' );
        if ( K20AI_Security::can_view() ) {
            $health['version'] = K20AI_PRESS_VERSION;
            $health['db_version'] = K20AI_Database::DB_VERSION;
            $health['mode'] = $this->services->settings()['mode'];
        }
        return $health;
    }

    private function openapi(): array {
        $paths = array(
            '/health' => array( 'get' => array( 'summary' => 'Health', 'responses' => array( '200' => array( 'description' => 'OK' ) ) ) ),
            '/feeds/acp' => array( 'get' => array( 'summary' => 'ACP-ready product feed snapshot', 'responses' => array( '200' => array( 'description' => 'OK' ) ) ) ),
            '/ucp' => array( 'get' => array( 'summary' => 'UCP profile', 'responses' => array( '200' => array( 'description' => 'OK' ) ) ) ),
            '/ucp/catalog/search' => array( 'post' => array( 'summary' => 'UCP catalog search', 'responses' => array( '200' => array( 'description' => 'OK' ), '400' => array( 'description' => 'Invalid request' ) ) ) ),
            '/ucp/catalog/lookup' => array( 'post' => array( 'summary' => 'UCP catalog lookup', 'responses' => array( '200' => array( 'description' => 'OK' ) ) ) ),
            '/ucp/catalog/product' => array( 'post' => array( 'summary' => 'UCP catalog product', 'responses' => array( '200' => array( 'description' => 'Product detail or UCP application-level error' ), '400' => array( 'description' => 'Invalid request' ) ) ) ),
            '/citation-pack' => array( 'get' => array( 'summary' => 'Citation Pack', 'responses' => array( '200' => array( 'description' => 'OK' ) ) ) ),
        );
        foreach ( $this->registry->visible() as $ability ) {
            if ( ! K20AI_Security::ability_public_readonly( (string) $ability['name'] ) ) continue;
            $paths[ '/abilities/' . $ability['name'] ] = array(
                'post' => array(
                    'summary' => $ability['description'],
                    'x-risk-class' => $ability['risk_class'],
                    'x-requires-confirmation' => $ability['requires_confirmation'],
                    'requestBody' => array(
                        'required' => false,
                        'content' => array( 'application/json' => array( 'schema' => array( 'type' => 'object', 'properties' => array( 'input' => $ability['input_schema'], 'confirmed' => array( 'type' => 'boolean' ) ) ) ) ),
                    ),
                    'responses' => array( '200' => array( 'description' => 'Success' ), '4XX' => array( 'description' => 'Validation/permission error' ) ),
                ),
            );
        }
        return array(
            'openapi' => '3.1.0',
            'info'    => array( 'title' => 'K20 AI Press API', 'version' => '1.0.0' ),
            'servers' => array( array( 'url' => rest_url( 'k20-ai/v1' ) ) ),
            'paths'   => $paths,
        );
    }
}
