<?php

defined( 'ABSPATH' ) || exit;

/**
 * Explainable, product-level readiness scoring.
 *
 * Scores are based only on locally measured WooCommerce/Product Truth fields
 * and explicitly verified evidence. Unmeasured dimensions remain null.
 */
final class K20AI_Product_Intelligence {
    private K20AI_Services $services;
    private K20AI_Advanced $advanced;

    public function __construct( K20AI_Services $services, K20AI_Advanced $advanced ) {
        $this->services = $services;
        $this->advanced = $advanced;
    }

    /** @return array<string,mixed>|WP_Error */
    public function score_product( int $product_id ): array|WP_Error {
        $access = K20AI_Entity_Access::read_error( 'product', $product_id );
        if ( is_wp_error( $access ) ) return $access;
        $truth = $this->services->product_truth( $product_id );
        if ( is_wp_error( $truth ) ) return $truth;
        $completeness = (array) ( $truth['completeness'] ?? array() );
        $fields = (array) ( $completeness['fields'] ?? array() );
        $groups = (array) ( $completeness['groups'] ?? array() );

        $components = array();
        $components['completeness'] = $this->component(
            __( 'Product completeness', 'k20-ai-press' ),
            $this->numeric_or_null( $completeness['score'] ?? null ),
            $this->missing_reasons( $completeness['missing_fields'] ?? array(), $fields ),
            'product_truth'
        );

        $merchant_checks = array( 'name', 'images', 'price', 'stock', 'brand', 'identifier', 'category' );
        $components['merchant'] = $this->checks_component( __( 'Merchant readiness', 'k20-ai-press' ), $merchant_checks, $fields, 'product_truth' );

        $answer_checks = array(
            'name'       => '' !== trim( (string) ( $truth['name'] ?? '' ) ),
            'brand'      => '' !== trim( (string) ( $truth['brand'] ?? '' ) ),
            'category'   => ! empty( $truth['category'] ),
            'attributes' => ! empty( $truth['attributes'] ),
            'model'      => '' !== trim( (string) ( $truth['model'] ?? '' ) ),
            'summary'    => '' !== trim( (string) ( $truth['short_description'] ?? '' ) ),
            'content'    => '' !== trim( (string) ( $truth['description'] ?? '' ) ),
        );
        $components['ai_answer'] = $this->boolean_component( __( 'AI answer readiness', 'k20-ai-press' ), $answer_checks, 'product_truth' );

        $evidence_stats = $this->evidence_stats( $product_id, $truth );
        if ( null === $evidence_stats['score'] ) {
            $components['evidence'] = $this->unmeasured_component( __( 'Evidence readiness', 'k20-ai-press' ), __( 'No product-linked claim/evidence records are measured yet.', 'k20-ai-press' ) );
            $components['citation'] = $this->unmeasured_component( __( 'Citation readiness', 'k20-ai-press' ), __( 'Citation readiness is not scored without verified product evidence.', 'k20-ai-press' ) );
        } else {
            $components['evidence'] = $this->component( __( 'Evidence readiness', 'k20-ai-press' ), $evidence_stats['score'], $evidence_stats['reasons'], 'verified_evidence' );
            $citation_score = $evidence_stats['verified'] > 0 ? min( 100, (int) round( 60 + 40 * min( 1, $evidence_stats['verified'] / max( 1, $evidence_stats['claims'] ) ) ) ) : 0;
            $citation_reasons = $evidence_stats['verified'] > 0 ? array() : array( __( 'No verified evidence is linked to this product.', 'k20-ai-press' ) );
            $components['citation'] = $this->component( __( 'Citation readiness', 'k20-ai-press' ), $citation_score, $citation_reasons, 'verified_evidence' );
        }

        $compatibility_present = '' !== trim( (string) ( $truth['compatibility'] ?? '' ) );
        if ( $compatibility_present ) {
            $components['compatibility'] = $this->component( __( 'Compatibility readiness', 'k20-ai-press' ), 100, array(), 'product_truth' );
        } else {
            $components['compatibility'] = $this->unmeasured_component( __( 'Compatibility readiness', 'k20-ai-press' ), __( 'No product compatibility fact or reviewed rule is linked yet.', 'k20-ai-press' ) );
        }

        $components['schema'] = $this->group_component( __( 'Schema readiness', 'k20-ai-press' ), $groups['schema'] ?? array(), 'product_truth' );
        $components['feed'] = $this->group_component( __( 'Feed readiness', 'k20-ai-press' ), $groups['feed'] ?? array(), 'product_truth' );

        $measured = array_values( array_filter( $components, static fn( array $row ): bool => null !== $row['score'] ) );
        $overall = $measured ? (int) round( array_sum( array_column( $measured, 'score' ) ) / count( $measured ) ) : null;
        $coverage = (int) round( 100 * count( $measured ) / max( 1, count( $components ) ) );
        $deductions = array();
        foreach ( $components as $key => $component ) {
            foreach ( (array) ( $component['reasons'] ?? array() ) as $reason ) {
                $deductions[] = array( 'component' => $key, 'reason' => $reason );
            }
        }

        return array(
            'product_id'           => $product_id,
            'product_name'         => (string) ( $truth['name'] ?? '' ),
            'overall'              => $overall,
            'measurement_coverage' => $coverage,
            'components'           => $components,
            'deductions'           => $deductions,
            'truth_updated_at'     => $truth['updated_at'] ?? null,
            'note'                 => __( 'Scores are internal readiness measures derived from measured site data; they do not guarantee search, merchant, or AI-engine eligibility.', 'k20-ai-press' ),
        );
    }

    /** @return array<string,mixed> */
    public function backlog( int $limit = 30 ): array {
        if ( ! function_exists( 'wc_get_products' ) ) return array( 'items' => array(), 'total_considered' => 0, 'note' => __( 'WooCommerce is unavailable.', 'k20-ai-press' ) );
        $limit = max( 1, min( 100, $limit ) );
        $ids = wc_get_products( array( 'status' => array( 'publish', 'draft', 'private' ), 'limit' => min( 200, max( 30, $limit * 3 ) ), 'return' => 'ids', 'orderby' => 'modified', 'order' => 'DESC' ) );
        $items = array();
        foreach ( array_map( 'absint', (array) $ids ) as $id ) {
            if ( ! K20AI_Entity_Access::can_read( 'product', $id ) ) continue;
            $row = $this->score_product( $id );
            if ( is_wp_error( $row ) ) continue;
            $overall = $row['overall'];
            $items[] = array(
                'product_id'           => $id,
                'product_name'         => $row['product_name'],
                'overall'              => $overall,
                'measurement_coverage' => $row['measurement_coverage'],
                'opportunity'          => null === $overall ? null : max( 0, 100 - (int) $overall ),
                'top_gaps'             => array_slice( (array) $row['deductions'], 0, 5 ),
                'components'           => $row['components'],
            );
        }
        usort(
            $items,
            static function( array $a, array $b ): int {
                $ao = null === $a['opportunity'] ? -1 : (int) $a['opportunity'];
                $bo = null === $b['opportunity'] ? -1 : (int) $b['opportunity'];
                if ( $ao === $bo ) return (int) $b['measurement_coverage'] <=> (int) $a['measurement_coverage'];
                return $bo <=> $ao;
            }
        );
        return array(
            'items'            => array_slice( $items, 0, $limit ),
            'total_considered' => count( $items ),
            'note'             => __( 'Opportunity is the gap to 100 among measured readiness dimensions only.', 'k20-ai-press' ),
        );
    }

    /** @return array<string,mixed> */
    private function evidence_stats( int $product_id, array $truth ): array {
        global $wpdb;
        $t = K20AI_Database::tables();
        $subjects = array_values( array_unique( array_filter( array(
            'product:' . $product_id,
            (string) $product_id,
            trim( (string) ( $truth['name'] ?? '' ) ),
            trim( (string) ( $truth['sku'] ?? '' ) ),
        ) ) ) );
        if ( ! $subjects ) return array( 'score' => null, 'claims' => 0, 'verified' => 0, 'reasons' => array() );
        $placeholders = implode( ',', array_fill( 0, count( $subjects ), '%s' ) );
        $claims = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t['claims']} WHERE subject IN ({$placeholders})", ...$subjects ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        if ( 0 === $claims ) return array( 'score' => null, 'claims' => 0, 'verified' => 0, 'reasons' => array() );
        $verified = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(DISTINCT c.id) FROM {$t['claims']} c INNER JOIN {$t['evidence']} e ON e.claim_id=c.id WHERE c.subject IN ({$placeholders}) AND c.status='VERIFIED' AND e.status='VERIFIED'", ...$subjects ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $score = (int) round( 100 * $verified / max( 1, $claims ) );
        $reasons = $verified < $claims ? array( sprintf( /* translators: 1: verified claims, 2: total claims. */ __( '%1$d of %2$d linked claims have verified evidence.', 'k20-ai-press' ), $verified, $claims ) ) : array();
        return array( 'score' => $score, 'claims' => $claims, 'verified' => $verified, 'reasons' => $reasons );
    }

    /** @return array<string,mixed> */
    private function checks_component( string $label, array $keys, array $fields, string $source ): array {
        $checks = array();
        foreach ( $keys as $key ) $checks[ $key ] = ! empty( $fields[ $key ]['filled'] );
        return $this->boolean_component( $label, $checks, $source );
    }

    /** @return array<string,mixed> */
    private function boolean_component( string $label, array $checks, string $source ): array {
        $total = count( $checks );
        if ( 0 === $total ) return $this->unmeasured_component( $label, __( 'No measurable checks are available.', 'k20-ai-press' ) );
        $passed = count( array_filter( $checks ) );
        $reasons = array();
        foreach ( $checks as $key => $ok ) if ( ! $ok ) $reasons[] = sprintf( /* translators: %s: missing check key. */ __( 'Missing or unmeasured: %s', 'k20-ai-press' ), $key );
        return $this->component( $label, (int) round( 100 * $passed / $total ), $reasons, $source );
    }

    /** @return array<string,mixed> */
    private function group_component( string $label, array $group, string $source ): array {
        if ( ! array_key_exists( 'value', $group ) || null === $group['value'] ) return $this->unmeasured_component( $label, __( 'No measurable group data is available.', 'k20-ai-press' ) );
        $reasons = array();
        foreach ( (array) ( $group['missing_labels'] ?? array() ) as $missing ) $reasons[] = sprintf( /* translators: %s: missing field. */ __( 'Missing: %s', 'k20-ai-press' ), $missing );
        return $this->component( $label, (int) $group['value'], $reasons, $source );
    }

    /** @return array<string,mixed> */
    private function component( string $label, ?int $score, array $reasons, string $source ): array {
        return array( 'label' => $label, 'score' => null === $score ? null : max( 0, min( 100, $score ) ), 'measured' => null !== $score, 'source' => $source, 'reasons' => array_values( $reasons ) );
    }

    /** @return array<string,mixed> */
    private function unmeasured_component( string $label, string $reason ): array {
        return array( 'label' => $label, 'score' => null, 'measured' => false, 'source' => null, 'reasons' => array( $reason ) );
    }

    /** @return array<int,string> */
    private function missing_reasons( array $missing, array $fields ): array {
        $reasons = array();
        foreach ( $missing as $key ) $reasons[] = sprintf( /* translators: %s: missing field label. */ __( 'Missing: %s', 'k20-ai-press' ), (string) ( $fields[ $key ]['label'] ?? $key ) );
        return $reasons;
    }

    private function numeric_or_null( mixed $value ): ?int {
        return is_numeric( $value ) ? max( 0, min( 100, (int) round( (float) $value ) ) ) : null;
    }
}
