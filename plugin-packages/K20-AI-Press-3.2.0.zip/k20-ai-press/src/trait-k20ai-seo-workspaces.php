<?php

defined( 'ABSPATH' ) || exit;

trait K20AI_SEO_Workspaces_Trait {
    /**
     * Enforce WordPress object-level read permissions on any workspace row that
     * references a post-backed K20 entity. Aggregate/non-entity rows pass through.
     *
     * @param array<string,mixed> $row
     */
    private function workspace_entity_row_readable( array $row ): bool {
        $kind = sanitize_key( (string) ( $row['entity_kind'] ?? $row['kind'] ?? '' ) );
        $id   = absint( $row['entity_id'] ?? $row['id'] ?? 0 );
        if ( $id <= 0 || ! in_array( $kind, K20AI_Entity_Access::supported_kinds(), true ) ) return true;
        return K20AI_Entity_Access::can_read( $kind, $id );
    }

    /** @param array<int,array<string,mixed>> $rows @return array<int,array<string,mixed>> */
    private function filter_workspace_entity_rows( array $rows, int $limit = 0 ): array {
        $out = array();
        foreach ( $rows as $row ) {
            if ( ! is_array( $row ) || ! $this->workspace_entity_row_readable( $row ) ) continue;
            $out[] = $row;
            if ( $limit > 0 && count( $out ) >= $limit ) break;
        }
        return $out;
    }

    private function workspace_page( array $filters, string $key = 'paged', int $default = 1 ): int {
        return max( 1, absint( $filters[ $key ] ?? $default ) );
    }

    private function workspace_per_page( array $filters, int $default = 20, int $max = 100 ): int {
        $per_page = absint( $filters['per_page'] ?? $default );
        if ( $per_page <= 0 ) $per_page = $default;
        return max( 1, min( $max, $per_page ) );
    }

    /** @return array<string,mixed> */
    private function workspace_pagination( int $total, int $paged, int $per_page ): array {
        $pages = max( 1, (int) ceil( max( 0, $total ) / max( 1, $per_page ) ) );
        $paged = max( 1, min( $pages, $paged ) );
        return array(
            'total'     => max( 0, $total ),
            'paged'     => $paged,
            'per_page'  => $per_page,
            'pages'     => $pages,
            'has_prev'  => $paged > 1,
            'has_next'  => $paged < $pages,
            'prev_page' => max( 1, $paged - 1 ),
            'next_page' => min( $pages, $paged + 1 ),
            'from'      => $total ? ( ( $paged - 1 ) * $per_page ) + 1 : 0,
            'to'        => min( $total, $paged * $per_page ),
        );
    }

    /** @param array<int,array<string,mixed>> $rows @return array<int,array<string,mixed>> */
    private function workspace_slice_rows( array $rows, array $pagination ): array {
        return array_slice( $rows, max( 0, ( (int) $pagination['paged'] - 1 ) * (int) $pagination['per_page'] ), (int) $pagination['per_page'] );
    }

    /**
     * Build a readable catalog directly from WordPress, not only from analyzed profiles.
     * This keeps selectors truthful when new/unmeasured entities have not been scanned yet.
     *
     * @return array<int,array<string,mixed>>
     */
    private function workspace_entity_catalog( string $kind, string $search = '' ): array {
        global $wpdb;
        $kind = K20AI_Entity_Access::normalize_kind( $kind );
        if ( '' === $kind ) return array();
        $search = trim( sanitize_text_field( $search ) );
        if ( 'product' === $kind ) $post_types = array( 'product' );
        elseif ( 'page' === $kind ) $post_types = array( 'page' );
        elseif ( 'media' === $kind ) $post_types = array( 'attachment' );
        else {
            $post_types = array_values( array_filter( (array) get_post_types( array( 'show_ui' => true ), 'names' ), static fn( string $type ): bool => ! in_array( $type, array( 'attachment','product','product_variation','page','revision','nav_menu_item','shop_order','shop_order_refund','shop_coupon' ), true ) ) );
            if ( ! in_array( 'post', $post_types, true ) ) $post_types[] = 'post';
        }
        $args = array(
            'post_type' => $post_types,
            'post_status' => 'media' === $kind ? array( 'inherit','publish' ) : array( 'publish','draft','pending','future','private' ),
            'posts_per_page' => -1,
            'fields' => 'ids',
            'orderby' => 'title',
            'order' => 'ASC',
            'no_found_rows' => true,
            'suppress_filters' => false,
        );
        if ( '' !== $search ) $args['s'] = $search;
        if ( 'media' === $kind ) $args['post_mime_type'] = 'image';
        $ids = array_map( 'absint', (array) get_posts( $args ) );
        $ids = array_values( array_filter( $ids, static fn( int $id ): bool => $id > 0 ) );
        $profile_map = array();
        $t = K20AI_Database::tables();
        if ( $ids && $this->table_exists( $t['seo_profiles'] ) ) {
            foreach ( array_chunk( $ids, 200 ) as $chunk ) {
                $placeholders = implode( ',', array_fill( 0, count( $chunk ), '%d' ) );
                $sql = $wpdb->prepare( "SELECT entity_id,score_total,analyzed_at FROM {$t['seo_profiles']} WHERE entity_kind=%s AND entity_id IN ($placeholders)", $kind, ...$chunk ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                foreach ( (array) $wpdb->get_results( $sql, ARRAY_A ) as $row ) $profile_map[ (int) $row['entity_id'] ] = $row;
            }
        }
        $out = array();
        foreach ( $ids as $id ) {
            if ( K20AI_Entity_Access::resolve_kind( $id ) !== $kind || ! K20AI_Entity_Access::can_read( $kind, $id ) ) continue;
            $post = get_post( $id );
            if ( ! $post ) continue;
            $title = html_entity_decode( (string) get_the_title( $id ) );
            if ( '' === trim( $title ) && 'media' === $kind ) {
                $file = get_attached_file( $id );
                $title = $file ? wp_basename( $file ) : '#' . $id;
            }
            $profile = $profile_map[ $id ] ?? null;
            $out[] = array(
                'id' => $id,
                'kind' => $kind,
                'title' => $title ?: '#' . $id,
                'status' => (string) $post->post_status,
                'score_total' => $profile ? (int) $profile['score_total'] : null,
                'measured' => (bool) $profile,
                'analyzed_at' => $profile ? (string) $profile['analyzed_at'] : null,
                'url' => admin_url( 'admin.php?page=k20-ai-press&workspace=live-editor&kind=' . $kind . '&id=' . $id ),
            );
        }
        return $out;
    }


    /** @return array<string,mixed> */
    private function normalize_profile( array $row ): array {
        $evidence = $this->json( $row['payload'] ?? array() );
        return array(
            'id'              => (int) ( $row['id'] ?? 0 ),
            'entity_kind'     => sanitize_key( (string) ( $row['entity_kind'] ?? $evidence['kind'] ?? '' ) ),
            'entity_id'       => (int) ( $row['entity_id'] ?? $evidence['entity_id'] ?? 0 ),
            'entity_key'      => (string) ( $row['entity_key'] ?? $evidence['entity_key'] ?? '' ),
            'url'             => (string) ( $row['url'] ?? $evidence['url'] ?? '' ),
            'title'           => (string) ( $row['title'] ?? $evidence['title'] ?? '' ),
            'score_total'     => (int) ( $row['score_total'] ?? 0 ),
            'score_technical' => (int) ( $row['score_technical'] ?? 0 ),
            'score_content'   => (int) ( $row['score_content'] ?? 0 ),
            'score_schema'    => (int) ( $row['score_schema'] ?? 0 ),
            'score_media'     => (int) ( $row['score_media'] ?? 0 ),
            'score_commerce'  => (int) ( $row['score_commerce'] ?? 0 ),
            'evidence'        => $evidence,
            'analyzed_at'     => (string) ( $row['analyzed_at'] ?? '' ),
            'updated_at'      => (string) ( $row['updated_at'] ?? '' ),
        );
    }

    /** @return array<string,int> */
    private function crawl_code_distribution(): array {
        global $wpdb;
        $t = K20AI_Database::tables();
        $out = array( '2xx' => 0, '3xx' => 0, '4xx' => 0, '5xx' => 0, 'other' => 0 );
        if ( ! $this->table_exists( $t['seo_crawl'] ) ) return $out;
        $rows = (array) $wpdb->get_results( "SELECT http_status,COUNT(*) total FROM {$t['seo_crawl']} GROUP BY http_status", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        foreach ( $rows as $row ) {
            $code = (int) ( $row['http_status'] ?? 0 );
            $count = (int) ( $row['total'] ?? 0 );
            $bucket = $code >= 200 && $code < 300 ? '2xx' : ( $code >= 300 && $code < 400 ? '3xx' : ( $code >= 400 && $code < 500 ? '4xx' : ( $code >= 500 && $code < 600 ? '5xx' : 'other' ) ) );
            $out[ $bucket ] += $count;
        }
        return $out;
    }

    /** @return array<int,array<string,string>> */
    private function technical_checks(): array {
        global $wpdb;
        $t = K20AI_Database::tables();
        $crawl_count = $this->table_exists( $t['seo_crawl'] ) ? (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t['seo_crawl']}" ) : 0; // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        return array(
            array( 'label' => 'HTTPS', 'status' => is_ssl() ? 'pass' : 'warning', 'detail' => is_ssl() ? 'سایت با HTTPS اجرا شده است.' : 'صفحه مدیریت فعلی HTTPS نیست.' ),
            array( 'label' => 'Indexing setting', 'status' => get_option( 'blog_public' ) ? 'pass' : 'critical', 'detail' => get_option( 'blog_public' ) ? 'نمایش سایت برای موتورهای جست‌وجو فعال است.' : 'گزینه جلوگیری از ایندکس WordPress فعال است.' ),
            array( 'label' => 'Crawl evidence', 'status' => $crawl_count ? 'pass' : 'waiting-data', 'detail' => $crawl_count ? number_format_i18n( $crawl_count ) . ' مشاهده HTTP ذخیره شده است.' : 'هنوز Crawl واقعی ثبت نشده است.' ),
        );
    }

    private function first_readable_profile_id( string $kind, string $order_by = 'score_total' ): int {
        global $wpdb;
        $t = K20AI_Database::tables();
        $kind = K20AI_Entity_Access::normalize_kind( $kind );
        if ( '' === $kind ) return 0;
        $allowed_order = array( 'score_total', 'score_schema', 'score_content', 'score_media', 'analyzed_at' );
        if ( ! in_array( $order_by, $allowed_order, true ) ) $order_by = 'score_total';
        $rows = $wpdb->get_results(
            $wpdb->prepare( "SELECT entity_kind,entity_id FROM {$t['seo_profiles']} WHERE entity_kind=%s ORDER BY {$order_by} ASC", $kind ),
            ARRAY_A
        ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        foreach ( (array) $rows as $row ) {
            if ( $this->workspace_entity_row_readable( $row ) ) return (int) $row['entity_id'];
        }
        return 0;
    }
/** @return array<int,array<string,mixed>> */
    public function priority_queue( int $limit = 20, ?string $kind = null ): array {
        global $wpdb;
        $t = K20AI_Database::tables();
        if ( ! $this->table_exists( $t['seo_recommendations'] ) ) return array();
        $where = "r.status='open'";
        $params = array();
        if ( $kind ) {
            $where .= ' AND r.entity_kind=%s';
            $params[] = sanitize_key( $kind );
        }
        $limit = max( 1, min( 100, $limit ) );
        $params[] = min( 300, max( $limit, $limit * 4 ) );
        $sql = "SELECT r.*,p.title entity_title,p.url entity_url,p.score_total FROM {$t['seo_recommendations']} r LEFT JOIN {$t['seo_profiles']} p ON p.entity_kind=r.entity_kind AND p.entity_id=r.entity_id WHERE $where ORDER BY FIELD(r.priority,'critical','high','medium','low'), r.seo_score ASC, r.id DESC LIMIT %d";
        $rows = $wpdb->get_results( $wpdb->prepare( $sql, ...$params ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $rows = $this->filter_workspace_entity_rows( (array) $rows, $limit );
        return array_map( array( $this, 'normalize_recommendation' ), $rows );
    }

    /** @return array<string,mixed> */
    private function normalize_recommendation( array $row ): array {
        foreach ( array( 'id','entity_id','business_score','commerce_score','seo_score','source_trust','score_total' ) as $key ) if ( isset( $row[ $key ] ) ) $row[ $key ] = (int) $row[ $key ];
        $row['payload'] = $this->json( $row['payload'] ?? null );
        return $row;
    }

    /** @return array<int,array<string,mixed>> */
    public function health_trend( int $days = 30 ): array {
        global $wpdb;
        $t = K20AI_Database::tables();
        $days = max( 7, min( 90, $days ) );
        $since = gmdate( 'Y-m-d 00:00:00', time() - ( $days - 1 ) * DAY_IN_SECONDS );
        $scan_rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT DATE(completed_at) d,AVG(health_score) score,COUNT(*) scans FROM {$t['seo_scans']} WHERE status='completed' AND health_score IS NOT NULL AND completed_at>=%s GROUP BY DATE(completed_at)",
            $since
        ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $by_day = array();
        foreach ( (array) $scan_rows as $row ) $by_day[ $row['d'] ] = array( 'score' => max( 0, min( 100, (int) round( $row['score'] ) ) ), 'scans' => (int) $row['scans'] );
        $series = array();
        foreach ( $by_day as $day => $row ) {
            $series[] = array( 'date' => $day, 'score' => (int) $row['score'], 'scans' => (int) $row['scans'] );
        }
        usort( $series, static fn( array $a, array $b ): int => strcmp( (string) $a['date'], (string) $b['date'] ) );
        return $series;
    }

    /** @return array<string,mixed> */
    public function workspace( string $mode, array $filters = array() ): array {
        if ( ! isset( $this->workspace_config[ $mode ] ) ) $mode = 'overview';
        $base = array(
            'mode'         => $mode,
            'config'       => $this->workspace_config[ $mode ],
            'generated_at' => gmdate( DATE_ATOM ),
            'scan'         => $this->latest_scan(),
            'integrations' => $this->integration_status(),
        );
        $data = match ( $mode ) {
            'overview'         => $this->workspace_overview(),
            'products'         => $this->workspace_products( $filters ),
            'product-intelligence' => $this->workspace_product_intelligence( $filters ),
            'categories-links' => $this->workspace_categories_links( $filters ),
            'keywords-content' => $this->workspace_keywords_content( $filters ),
            'technical-health' => $this->workspace_technical_health( $filters ),
            'schema-preview'   => $this->workspace_schema_preview( $filters ),
            'competitors-serp' => $this->workspace_competitors( $filters ),
            'images-alt'       => $this->workspace_images( $filters ),
            'rank-tracking'    => $this->workspace_rank_tracking( $filters ),
            'ai-visibility'    => $this->workspace_ai_visibility(),
            'content-refresh'  => $this->workspace_content_refresh( $filters ),
            'control-tower'    => $this->workspace_control_tower( $filters ),
            'crawl-monitoring' => $this->workspace_crawl_monitoring( $filters ),
            'live-editor'      => $this->workspace_live_editor( $filters ),
            'market-radar'     => $this->workspace_market_radar(),
            'content-engines'  => $this->workspace_content_engines(),
            'reports'          => $this->workspace_reports(),
            'connections'      => $this->workspace_connections(),
            'settings'         => $this->workspace_settings(),
            'setup-commercial' => $this->workspace_setup_commercial(),
            default            => $this->workspace_overview(),
        };
        return array_merge( $base, $data );
    }

    /** @return array<string,mixed> */
    private function workspace_overview(): array {
        $dash = $this->dashboard();
        return array(
            'dashboard' => $dash,
            'external_data' => $this->external_data_snapshot(),
            'kpis' => array(
                array( 'label' => 'سلامت کل سئو', 'value' => $dash['health']['score'], 'suffix' => '/100', 'tone' => $dash['health']['score'] >= 85 ? 'success' : 'warning', 'hint' => 'میانگین موجودیت‌های تحلیل‌شده' ),
                array( 'label' => 'نیازمند اقدام', 'value' => $dash['recommendations']['open'], 'tone' => $dash['recommendations']['critical'] ? 'danger' : 'warning', 'hint' => 'پیشنهادهای باز و واقعی' ),
                array( 'label' => 'صفحات/موجودیت‌ها', 'value' => $dash['entities']['total_content'], 'tone' => 'default', 'hint' => 'محصول + نوشته + صفحه + خبر + محتوای سفارشی' ),
                array( 'label' => 'خطاهای بحرانی', 'value' => $dash['issues']['critical'], 'tone' => $dash['issues']['critical'] ? 'danger' : 'success', 'hint' => 'Issueهای باز' ),
                array( 'label' => 'اقدامات منتظر تأیید', 'value' => $dash['actions']['proposed'], 'tone' => 'info', 'hint' => 'هیچ تغییر پرریسک بدون تأیید اجرا نمی‌شود' ),
                array( 'label' => 'موجودیت تحلیل‌شده', 'value' => $dash['health']['analyzed'], 'tone' => 'success', 'hint' => 'پوشش ممیزی محلی' ),
            ),
        );
    }

    /** @return array<string,mixed> */
    private function workspace_products( array $filters ): array {
        global $wpdb;
        $t = K20AI_Database::tables();
        $profile_rows = $this->table_exists( $t['seo_profiles'] ) ? (array) $wpdb->get_results( "SELECT * FROM {$t['seo_profiles']} WHERE entity_kind='product'", ARRAY_A ) : array(); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        $profiles = array();
        foreach ( $profile_rows as $row ) $profiles[ (int) $row['entity_id'] ] = $this->normalize_profile( $row );
        $issue_counts = array();
        if ( $this->table_exists( $t['seo_issues'] ) ) {
            foreach ( (array) $wpdb->get_results( "SELECT entity_id,COUNT(*) total FROM {$t['seo_issues']} WHERE entity_kind='product' AND status='open' GROUP BY entity_id", ARRAY_A ) as $row ) $issue_counts[ (int) $row['entity_id'] ] = (int) $row['total']; // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        }
        $status = sanitize_key( (string) ( $filters['status'] ?? 'all' ) );
        $search = sanitize_text_field( (string) ( $filters['query'] ?? $filters['q'] ?? '' ) );
        $category_filter = absint( $filters['category_id'] ?? 0 );
        $categories = array();
        $terms = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false, 'number' => 0, 'orderby' => 'name', 'order' => 'ASC' ) );
        if ( ! is_wp_error( $terms ) ) foreach ( $terms as $term ) $categories[] = array( 'id' => (int) $term->term_id, 'label' => (string) $term->name, 'count' => (int) $term->count );
        $rows = array();
        foreach ( $this->site_product_ids( 5000 ) as $product_id ) {
            if ( ! K20AI_Entity_Access::can_read( 'product', $product_id ) ) continue;
            $product = function_exists( 'wc_get_product' ) ? wc_get_product( $product_id ) : null;
            if ( ! $product ) continue;
            $title = html_entity_decode( (string) $product->get_name() );
            $sku = (string) $product->get_sku();
            if ( '' !== $search && false === mb_stripos( $title . ' ' . $sku, $search ) ) continue;
            $product_terms = get_the_terms( $product_id, 'product_cat' );
            $term_ids = array();
            if ( is_array( $product_terms ) ) foreach ( $product_terms as $term ) $term_ids[] = (int) $term->term_id;
            if ( $category_filter && ! in_array( $category_filter, $term_ids, true ) ) continue;
            $profile = $profiles[ $product_id ] ?? null;
            $score = $profile ? (int) $profile['score_total'] : null;
            $status_key = null === $score ? 'unmeasured' : ( $score < 60 ? 'critical' : ( $score < 85 ? 'improve' : 'healthy' ) );
            if ( in_array( $status, array( 'critical','improve','healthy','unmeasured' ), true ) && $status !== $status_key ) continue;
            $image_ids = array_values( array_unique( array_filter( array_merge( array( $product->get_image_id() ), $product->get_gallery_image_ids() ) ) ) );
            $alt_count = 0;
            foreach ( $image_ids as $image_id ) if ( '' !== trim( (string) get_post_meta( $image_id, '_wp_attachment_image_alt', true ) ) ) ++$alt_count;
            $gtin_raw = method_exists( $product, 'get_global_unique_id' ) ? (string) $product->get_global_unique_id() : (string) $this->first_meta( $product_id, array( '_global_unique_id','_wc_gtin','_gtin','gtin' ) );
            $brand = (string) $this->product_brand( $product_id );
            $missing = array();
            if ( '' === $sku ) $missing[] = 'sku';
            if ( '' === trim( $brand ) ) $missing[] = 'brand';
            if ( null === K20AI_Data_Integrity::normalize_gtin( $gtin_raw ) ) $missing[] = 'gtin';
            if ( $image_ids && $alt_count < count( $image_ids ) ) $missing[] = 'alt';
            if ( ! $image_ids ) $missing[] = 'images';
            if ( '' === (string) $product->get_price() || '' === (string) $product->get_stock_status() ) $missing[] = 'offer';
            $rows[] = array(
                'id' => $product_id,
                'title' => $title ?: '#' . $product_id,
                'sku' => $sku,
                'brand' => $brand,
                'score' => $score,
                'status_key' => $status_key,
                'images' => count( $image_ids ),
                'alt' => $alt_count,
                'price' => (string) $product->get_price(),
                'stock' => (string) $product->get_stock_status(),
                'issues' => (int) ( $issue_counts[ $product_id ] ?? 0 ),
                'missing' => $missing,
            );
        }
        usort( $rows, static function( array $a, array $b ): int {
            if ( null === $a['score'] && null !== $b['score'] ) return 1;
            if ( null !== $a['score'] && null === $b['score'] ) return -1;
            if ( null !== $a['score'] && null !== $b['score'] && $a['score'] !== $b['score'] ) return $a['score'] <=> $b['score'];
            return strcasecmp( (string) $a['title'], (string) $b['title'] );
        } );
        $all_rows = $rows;
        // Counts must reflect the whole catalog/search/category scope before the status subset is applied.
        $count_base = array();
        foreach ( $this->site_product_ids( 5000 ) as $pid ) {
            if ( ! K20AI_Entity_Access::can_read( 'product', $pid ) ) continue;
            $prod = function_exists( 'wc_get_product' ) ? wc_get_product( $pid ) : null;
            if ( ! $prod ) continue;
            $title = html_entity_decode( (string) $prod->get_name() ); $sku = (string) $prod->get_sku();
            if ( '' !== $search && false === mb_stripos( $title . ' ' . $sku, $search ) ) continue;
            if ( $category_filter ) { $ids = wp_get_post_terms( $pid, 'product_cat', array( 'fields' => 'ids' ) ); if ( is_wp_error( $ids ) || ! in_array( $category_filter, array_map( 'intval', $ids ), true ) ) continue; }
            $profile = $profiles[ $pid ] ?? null; $score = $profile ? (int) $profile['score_total'] : null;
            $count_base[] = null === $score ? 'unmeasured' : ( $score < 60 ? 'critical' : ( $score < 85 ? 'improve' : 'healthy' ) );
        }
        $counts = array( 'all' => count( $count_base ), 'critical' => 0, 'improve' => 0, 'healthy' => 0, 'unmeasured' => 0 );
        foreach ( $count_base as $key ) ++$counts[ $key ];
        $paged = $this->workspace_page( $filters );
        $per_page = $this->workspace_per_page( $filters, 20, 100 );
        $pagination = $this->workspace_pagination( count( $rows ), $paged, $per_page );
        $measured_profiles = array_values( $profiles );
        $avg_for = static function( array $list, string $key ): ?int { if ( ! $list ) return null; return (int) round( array_sum( array_map( static fn( $r ) => (int) ( $r[ $key ] ?? 0 ), $list ) ) / count( $list ) ); };
        $field_coverage = $this->catalog_field_map();
        $completeness_groups = array(
            array( 'label' => 'هویت محصول', 'percent' => $this->field_percent( $field_coverage, array( 'sku','name','brand','category' ) ), 'filled' => $this->field_filled( $field_coverage, array( 'sku','name','brand','category' ) ), 'total' => $this->field_total( $field_coverage, array( 'sku','name','brand','category' ) ) ),
            array( 'label' => 'شناسه‌ها', 'percent' => $this->field_percent( $field_coverage, array( 'gtin','mpn' ) ), 'filled' => $this->field_filled( $field_coverage, array( 'gtin','mpn' ) ), 'total' => $this->field_total( $field_coverage, array( 'gtin','mpn' ) ) ),
            array( 'label' => 'رسانه', 'percent' => $this->field_percent( $field_coverage, array( 'images','alt' ) ), 'filled' => $this->field_filled( $field_coverage, array( 'images','alt' ) ), 'total' => $this->field_total( $field_coverage, array( 'images','alt' ) ) ),
            array( 'label' => 'قیمت و فروش', 'percent' => $this->field_percent( $field_coverage, array( 'price','stock' ) ), 'filled' => $this->field_filled( $field_coverage, array( 'price','stock' ) ), 'total' => $this->field_total( $field_coverage, array( 'price','stock' ) ) ),
        );
        return array(
            'summary' => array(
                'avg_score' => $avg_for( $measured_profiles, 'score_total' ),
                'health' => $avg_for( $measured_profiles, 'score_total' ),
                'technical' => $avg_for( $measured_profiles, 'score_technical' ),
                'content' => $avg_for( $measured_profiles, 'score_content' ),
                'schema' => $avg_for( $measured_profiles, 'score_schema' ),
                'media' => $avg_for( $measured_profiles, 'score_media' ),
                'commerce' => $avg_for( $measured_profiles, 'score_commerce' ),
            ),
            'items' => $this->workspace_slice_rows( $rows, $pagination ),
            'status' => $status,
            'query' => $search,
            'category_id' => $category_filter,
            'categories' => $categories,
            'counts' => $counts,
            'pagination' => $pagination,
            'field_coverage' => $field_coverage,
            'completeness_groups' => $completeness_groups,
            'variant_health' => $this->variant_health(),
            'evidence_coverage' => $this->product_evidence_coverage(),
            'queue' => $this->product_queue( $all_rows ),
            'reload_token' => time(),
        );
    }

    private function workspace_product_intelligence( array $filters ): array {
        global $wpdb;
        $t = K20AI_Database::tables();
        $profile_rows = $wpdb->get_results( "SELECT * FROM {$t['seo_profiles']} WHERE entity_kind='product'", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        $profiles = array();
        foreach ( (array) $profile_rows as $row ) $profiles[ (int) $row['entity_id'] ] = $this->normalize_profile( $row );

        $category_filter = absint( $filters['category_id'] ?? 0 );
        $search = sanitize_text_field( (string) ( $filters['query'] ?? $filters['q'] ?? '' ) );
        $status = sanitize_key( (string) ( $filters['status'] ?? 'all' ) );
        $all_ids = array_map( 'absint', $this->site_product_ids() );
        $categories = array();
        $terms = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false, 'orderby' => 'name', 'order' => 'ASC' ) );
        if ( ! is_wp_error( $terms ) ) foreach ( (array) $terms as $term ) $categories[] = array( 'id' => (int) $term->term_id, 'label' => (string) $term->name );

        $base_items = array();
        foreach ( $all_ids as $product_id ) {
            if ( $product_id <= 0 || ! K20AI_Entity_Access::can_read( 'product', $product_id ) ) continue;
            $product = function_exists( 'wc_get_product' ) ? wc_get_product( $product_id ) : null;
            if ( ! $product ) continue;
            $title = html_entity_decode( (string) $product->get_name() );
            $sku = (string) $product->get_sku();
            if ( '' !== $search && false === mb_stripos( $title . ' ' . $sku, $search ) ) continue;
            $term_names = array();
            $term_ids = array();
            $product_terms = get_the_terms( $product_id, 'product_cat' );
            if ( is_array( $product_terms ) ) foreach ( $product_terms as $term ) { $term_ids[] = (int) $term->term_id; $term_names[] = (string) $term->name; }
            if ( $category_filter && ! in_array( $category_filter, $term_ids, true ) ) continue;

            $profile = $profiles[ $product_id ] ?? array();
            $score = $profile ? (int) $profile['score_total'] : null;
            $gtin_raw = method_exists( $product, 'get_global_unique_id' ) ? (string) $product->get_global_unique_id() : '';
            if ( '' === trim( $gtin_raw ) ) $gtin_raw = (string) $this->first_meta( $product_id, array( '_global_unique_id','_wc_gtin','_gtin','gtin' ) );
            $has_gtin = null !== K20AI_Data_Integrity::normalize_gtin( $gtin_raw );
            $brand = (string) $this->product_brand( $product_id );
            $image_ids = array_values( array_unique( array_filter( array_merge( array( $product->get_image_id() ), $product->get_gallery_image_ids() ) ) ) );
            $alt_count = 0;
            foreach ( $image_ids as $image_id ) if ( '' !== trim( (string) get_post_meta( $image_id, '_wp_attachment_image_alt', true ) ) ) ++$alt_count;
            $has_gallery = ! empty( $image_ids );
            $has_alt = $has_gallery && $alt_count === count( $image_ids );
            $has_offer = '' !== (string) $product->get_price() && '' !== (string) $product->get_stock_status();
            $signals = array( $has_gtin, '' !== trim( $brand ), $has_gallery, $has_alt, $has_offer );
            $coverage = (int) round( ( count( array_filter( $signals ) ) / count( $signals ) ) * 100 );
            if ( ! $has_gtin ) $issue = 'GTIN معتبر ثبت نشده است';
            elseif ( '' === trim( $brand ) ) $issue = 'برند ثبت نشده است';
            elseif ( ! $has_gallery ) $issue = 'تصویر محصول ثبت نشده است';
            elseif ( ! $has_alt ) $issue = 'ALT همه تصاویر کامل نیست';
            elseif ( ! $has_offer ) $issue = 'قیمت یا وضعیت موجودی کامل نیست';
            elseif ( null === $score ) $issue = 'داده زنده موجود است؛ امتیاز هنوز اسکن نشده';
            else $issue = 'شکاف بحرانی در داده پایه دیده نشد';
            $status_key = null === $score ? 'unmeasured' : ( $score < 60 ? 'critical' : ( $score < 85 ? 'improve' : 'healthy' ) );
            $base_items[] = array(
                'entity_kind' => 'product',
                'entity_id' => $product_id,
                'product_id' => $product_id,
                'title' => $title,
                'sku' => $sku,
                'categories' => $term_names,
                'main_issue' => $issue,
                'coverage' => $coverage,
                'overall' => $score,
                'opportunity' => null === $score ? null : max( 0, 100 - $score ),
                'status_key' => $status_key,
                'status_label' => 'unmeasured' === $status_key ? 'اندازه‌گیری نشده' : ( 'critical' === $status_key ? 'بحرانی' : ( 'improve' === $status_key ? 'نیاز به بهبود' : 'سالم' ) ),
                'editor_url' => admin_url( 'admin.php?page=k20-ai-press&workspace=live-editor&kind=product&id=' . $product_id ),
                'control_tower_url' => admin_url( 'admin.php?page=k20-ai-press&workspace=products&kind=product&id=' . $product_id ),
            );
        }
        $counts = array(
            'all' => count( $base_items ),
            'critical' => count( array_filter( $base_items, static fn( array $row ): bool => 'critical' === $row['status_key'] ) ),
            'improve' => count( array_filter( $base_items, static fn( array $row ): bool => 'improve' === $row['status_key'] ) ),
            'healthy' => count( array_filter( $base_items, static fn( array $row ): bool => 'healthy' === $row['status_key'] ) ),
            'unmeasured' => count( array_filter( $base_items, static fn( array $row ): bool => 'unmeasured' === $row['status_key'] ) ),
            'measured' => count( array_filter( $base_items, static fn( array $row ): bool => null !== $row['overall'] ) ),
            'backlog' => count( array_filter( $base_items, static fn( array $row ): bool => null === $row['overall'] || (int) $row['overall'] < 85 ) ),
            'coverage75' => count( array_filter( $base_items, static fn( array $row ): bool => (int) $row['coverage'] >= 75 ) ),
        );
        $items_all = $base_items;
        if ( in_array( $status, array( 'critical','improve','healthy','unmeasured' ), true ) ) {
            $items_all = array_values( array_filter( $items_all, static fn( array $row ): bool => $row['status_key'] === $status ) );
        } elseif ( 'measured' === $status ) {
            $items_all = array_values( array_filter( $items_all, static fn( array $row ): bool => null !== $row['overall'] ) );
        } elseif ( 'backlog' === $status ) {
            $items_all = array_values( array_filter( $items_all, static fn( array $row ): bool => null === $row['overall'] || (int) $row['overall'] < 85 ) );
        } elseif ( 'coverage75' === $status ) {
            $items_all = array_values( array_filter( $items_all, static fn( array $row ): bool => (int) $row['coverage'] >= 75 ) );
        }
        usort( $items_all, static function( array $a, array $b ): int {
            if ( null === $a['overall'] && null !== $b['overall'] ) return 1;
            if ( null !== $a['overall'] && null === $b['overall'] ) return -1;
            if ( null !== $a['overall'] && null !== $b['overall'] && $a['overall'] !== $b['overall'] ) return $a['overall'] <=> $b['overall'];
            return strcmp( (string) $a['title'], (string) $b['title'] );
        } );
        $paged = $this->workspace_page( $filters );
        $per_page = $this->workspace_per_page( $filters, 20, 100 );
        $pagination = $this->workspace_pagination( count( $items_all ), $paged, $per_page );
        $measured = array_values( array_filter( $base_items, static fn( array $row ): bool => null !== $row['overall'] ) );
        $avg_score = $measured ? (int) round( array_sum( array_column( $measured, 'overall' ) ) / count( $measured ) ) : null;
        return array(
            'items' => $this->workspace_slice_rows( $items_all, $pagination ),
            'categories' => $categories,
            'category_id' => $category_filter,
            'status' => $status,
            'query' => $search,
            'pagination' => $pagination,
            'reload_token' => time(),
            'products_total' => count( $base_items ),
            'products_scanned' => $counts['measured'],
            'coverage_75' => $counts['coverage75'],
            'average_readiness' => $avg_score,
            'open_backlog' => $counts['backlog'],
            'filters' => $counts,
        );
    }

    private function workspace_ai_visibility(): array {
        $result = $this->legacy->execute( 'visibility.observatory', array( 'days' => 30, 'limit' => 250 ) );
        return is_wp_error( $result ) ? array( 'mode' => 'not_measured', 'current' => array(), 'error' => $result->get_error_message() ) : $result;
    }

    /** @return array<string,mixed> */
    private function workspace_setup_commercial(): array {
        $onboarding = $this->legacy->execute( 'onboarding.status' );
        $license = $this->legacy->execute( 'license.status' );
        $diagnostics = $this->legacy->execute( 'diagnostics.bundle' );
        return array(
            'onboarding' => is_wp_error( $onboarding ) ? array() : $onboarding,
            'license' => is_wp_error( $license ) ? array( 'status' => 'unavailable' ) : $license,
            'diagnostics' => is_wp_error( $diagnostics ) ? array() : $diagnostics,
        );
    }

    /** @return array<string,mixed> */
    private function workspace_crawl_monitoring( array $filters = array() ): array {
        global $wpdb;
        $t = K20AI_Database::tables();
        $runs = $wpdb->get_results( "SELECT * FROM {$t['seo_scans']} WHERE scan_type='crawl' ORDER BY id DESC LIMIT 50", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $observations_all = $wpdb->get_results( "SELECT * FROM {$t['seo_crawl']} ORDER BY fetched_at DESC", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $paged = $this->workspace_page( $filters );
        $per_page = $this->workspace_per_page( $filters, 20, 100 );
        $pagination = $this->workspace_pagination( count( $observations_all ), $paged, $per_page );
        return array( 'runs' => $runs, 'observations' => $this->workspace_slice_rows( (array) $observations_all, $pagination ), 'observations_total' => count( $observations_all ), 'pagination' => $pagination, 'codes' => $this->crawl_code_distribution(), 'checks' => $this->technical_checks() );
    }

    /** @return array<string,mixed> */
    private function workspace_live_editor( array $filters ): array {
        $kind = sanitize_key( (string) ( $filters['kind'] ?? 'product' ) );
        $kind = K20AI_Entity_Access::normalize_kind( $kind );
        if ( '' === $kind ) $kind = 'product';
        $search = sanitize_text_field( (string) ( $filters['entity_query'] ?? $filters['query'] ?? $filters['q'] ?? '' ) );
        $all = $this->workspace_entity_catalog( $kind, $search );
        $paged = max( 1, absint( $filters['entity_paged'] ?? $filters['paged'] ?? 1 ) );
        $per_page = 20;
        $pagination = $this->workspace_pagination( count( $all ), $paged, $per_page );
        $options = $this->workspace_slice_rows( $all, $pagination );
        $id = absint( $filters['id'] ?? 0 );
        if ( $id && ! K20AI_Entity_Access::can_read( $kind, $id ) ) $id = 0;
        if ( ! $id && ! empty( $options[0]['id'] ) ) $id = (int) $options[0]['id'];
        $entity = $id && K20AI_Entity_Access::can_read( $kind, $id ) ? $this->entity_detail( $kind, $id ) : array();
        return array(
            'entity' => $entity,
            'selected' => array( 'kind' => $kind, 'id' => $id ),
            'available_kinds' => array( 'product','content_post','page','news','media' ),
            'entity_options' => $options,
            'entity_query' => $search,
            'entity_pagination' => $pagination,
            'entity_total' => count( $all ),
            'reload_token' => time(),
        );
    }

    /** @return array<string,mixed> */
    private function workspace_market_radar(): array {
        global $wpdb;
        $t = K20AI_Database::tables();
        $signals = $wpdb->get_results( "SELECT * FROM {$t['seo_signals']} ORDER BY observed_at DESC LIMIT 80", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        foreach ( $signals as &$row ) $row['payload'] = $this->json( $row['payload'] );
        unset( $row );
        $source_count = count( (array) $this->settings()['radar_sources'] );
        return array( 'signals' => $signals, 'source_count' => $source_count, 'competitors' => $this->workspace_competitors()['competitors'], 'local' => $this->local_market_signals(), 'note' => $source_count ? 'RSSهای تنظیم‌شده با منبع و زمان مشاهده ذخیره می‌شوند.' : 'رادار محلی فعال است؛ برای خبر بیرونی RSSهای مورد اعتماد را در تنظیمات اضافه کنید.' );
    }

    /** @return array<int,array<string,mixed>> */
    private function local_market_signals(): array {
        $signals = array();
        if ( function_exists( 'wc_get_products' ) ) {
            $low = wc_get_products( array( 'status' => array( 'publish' ), 'stock_status' => 'instock', 'limit' => 20, 'orderby' => 'modified', 'order' => 'DESC' ) );
            foreach ( $low as $product ) {
                if ( ! is_object( $product ) ) continue;
                $qty = $product->get_stock_quantity();
                if ( null !== $qty && $qty <= 5 ) $signals[] = array( 'type' => 'inventory', 'title' => 'موجودی کم: ' . $product->get_name(), 'score' => 80, 'url' => get_permalink( $product->get_id() ), 'observed_at' => gmdate( DATE_ATOM ) );
            }
        }
        $recent = get_posts( array( 'post_type' => array( 'post' ), 'post_status' => 'publish', 'posts_per_page' => 10, 'orderby' => 'modified', 'order' => 'DESC' ) );
        foreach ( $recent as $post ) $signals[] = array( 'type' => 'content', 'title' => 'محتوای به‌روزرسانی‌شده: ' . $post->post_title, 'score' => 50, 'url' => get_permalink( $post ), 'observed_at' => K20AI_Security::normalize_mysql_datetime_to_iso( $post->post_modified_gmt, $post->post_modified ) );
        return array_slice( $signals, 0, 20 );
    }

    /** @return array<string,mixed> */
    private function workspace_content_engines(): array {
        if ( ! $this->content_engines ) return array( 'available' => false, 'engines' => array(), 'runs' => array() );
        return array_merge( array( 'available' => true ), $this->content_engines->status() );
    }

    /** @return array<string,mixed> */
    private function workspace_reports(): array {
        global $wpdb;
        $t = K20AI_Database::tables();
        $by_kind = $wpdb->get_results( "SELECT entity_kind,COUNT(*) total,ROUND(AVG(score_total)) avg_score,ROUND(AVG(score_technical)) technical,ROUND(AVG(score_content)) content,ROUND(AVG(score_schema)) schema,ROUND(AVG(score_media)) media,ROUND(AVG(score_commerce)) commerce FROM {$t['seo_profiles']} GROUP BY entity_kind ORDER BY total DESC", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $by_rule = $wpdb->get_results( "SELECT rule_code,severity,component,COUNT(*) total FROM {$t['seo_issues']} WHERE status='open' GROUP BY rule_code,severity,component ORDER BY total DESC LIMIT 30", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        return array( 'summary' => $this->dashboard(), 'by_kind' => $by_kind, 'top_issues' => $by_rule, 'exports' => array( 'csv', 'json', 'print' ) );
    }

    /** @return array<string,mixed> */
    private function workspace_settings(): array {
        return array(
            'settings'        => $this->settings(),
            'integrations'    => $this->integration_status(),
            'engines'         => $this->engines(),
            'bot_control'     => $this->bot_control(),
            'legacy_settings' => $this->legacy->settings(),
        );
    }

    /** @return array<string,mixed> */
    private function workspace_connections(): array {
        $connections = $this->connection_center ? $this->connection_center->snapshot() : array();
        $local_keys = array( 'wordpress','woocommerce','yoast','bridge','indexnow' );
        $local_integrations = array_values( array_filter( $this->integration_status(), static fn( $row ) => in_array( (string) ( $row['key'] ?? '' ), $local_keys, true ) ) );
        return array(
            'connections' => $connections,
            'local_integrations' => $local_integrations,
            'groups' => array(
                'data' => array( 'label' => 'داده و جست‌وجو', 'description' => 'Search Console، GA4، Merchant، Bing و PageSpeed' ),
                'ai' => array( 'label' => 'موتورهای هوش مصنوعی', 'description' => 'Providerهای واقعی برای تحلیل و تکمیل داده با پیش‌نمایش و تأیید انسانی' ),
                'delivery' => array( 'label' => 'کد و تحویل', 'description' => 'GitHub Repository و Actions برای اجرای Workflowهای کدنویسی/استقرار' ),
            ),
            'bridge' => $this->bridge ? $this->bridge->contract() : array(),
            'security' => array(
                'encrypted_at_rest' => true,
                'secrets_returned_to_browser' => false,
                'fail_closed' => true,
                'human_approval_for_ai_apply' => true,
            ),
        );
    }

    /**
     * Normalize the latest synced external snapshots so workspaces can consume
     * real connector output without knowing provider-specific response shapes.
     *
     * @return array<string,mixed>
     */
    private function external_data_snapshot(): array {
        $ga4_raw = get_option( 'k20ai_ga4_last_snapshot', array() );
        $merchant_raw = get_option( 'k20ai_merchant_last_snapshot', array() );
        $pagespeed_raw = get_option( 'k20ai_pagespeed_last_snapshot', array() );
        $ga4_raw = is_array( $ga4_raw ) ? $ga4_raw : array();
        $merchant_raw = is_array( $merchant_raw ) ? $merchant_raw : array();
        $pagespeed_raw = is_array( $pagespeed_raw ) ? $pagespeed_raw : array();

        $sessions = 0;
        $pageviews = 0;
        $engagement_weighted = 0.0;
        $engagement_weight = 0;
        foreach ( (array) ( $ga4_raw['rows'] ?? array() ) as $row ) {
            if ( ! is_array( $row ) ) continue;
            $metrics = (array) ( $row['metricValues'] ?? array() );
            $row_sessions = isset( $metrics[0]['value'] ) ? (int) $metrics[0]['value'] : 0;
            $row_views = isset( $metrics[1]['value'] ) ? (int) $metrics[1]['value'] : 0;
            $row_engagement = isset( $metrics[2]['value'] ) ? (float) $metrics[2]['value'] : null;
            $sessions += $row_sessions;
            $pageviews += $row_views;
            if ( null !== $row_engagement && $row_sessions > 0 ) {
                $engagement_weighted += $row_engagement * $row_sessions;
                $engagement_weight += $row_sessions;
            }
        }
        $merchant_issues = (array) ( $merchant_raw['issues']['accountIssues'] ?? array() );
        $merchant_severity = array( 'CRITICAL' => 0, 'ERROR' => 0, 'SUGGESTION' => 0, 'OTHER' => 0 );
        foreach ( $merchant_issues as $issue ) {
            $severity = strtoupper( (string) ( is_array( $issue ) ? ( $issue['severity'] ?? 'OTHER' ) : 'OTHER' ) );
            if ( ! isset( $merchant_severity[ $severity ] ) ) $severity = 'OTHER';
            ++$merchant_severity[ $severity ];
        }

        return array(
            'ga4' => array(
                'available' => ! empty( $ga4_raw ),
                'at' => $ga4_raw['at'] ?? null,
                'property' => $ga4_raw['property'] ?? null,
                'sessions' => $sessions,
                'pageviews' => $pageviews,
                'engagement_rate' => $engagement_weight > 0 ? round( 100 * $engagement_weighted / $engagement_weight, 2 ) : null,
            ),
            'merchant' => array(
                'available' => ! empty( $merchant_raw ),
                'at' => $merchant_raw['at'] ?? null,
                'account' => $merchant_raw['account'] ?? null,
                'issue_count' => count( $merchant_issues ),
                'severity' => $merchant_severity,
            ),
            'pagespeed' => array(
                'available' => ! empty( $pagespeed_raw ),
                'at' => $pagespeed_raw['at'] ?? null,
                'score' => isset( $pagespeed_raw['score'] ) ? (int) $pagespeed_raw['score'] : null,
                'url' => $pagespeed_raw['url'] ?? null,
            ),
        );
    }

    /** @return array<string,mixed> */

    /** @return array<int,array<string,mixed>> */
    private function catalog_field_map(): array {
        global $wpdb;
        $t = K20AI_Database::tables();
        $rows = $wpdb->get_results( "SELECT payload FROM {$t['seo_profiles']} WHERE entity_kind='product'", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        $total = max( 1, count( (array) $rows ) );
        $defs = array('sku'=>'SKU','name'=>'نام محصول','gtin'=>'GTIN','mpn'=>'MPN','brand'=>'برند','model'=>'مدل','features'=>'ویژگی‌ها','category'=>'دسته‌بندی','images'=>'تصاویر','dimensions'=>'ابعاد/وزن','price'=>'قیمت','alt'=>'ALT تصاویر','stock'=>'موجودی');
        $filled = array_fill_keys( array_keys( $defs ), 0 );
        foreach ( (array) $rows as $row ) {
            $e = $this->json( $row['payload'] ?? array() );
            $checks = array(
                'sku' => ! empty( $e['sku'] ), 'name' => ! empty( $e['title'] ) || ! empty( $e['name'] ), 'gtin' => ! empty( $e['gtin'] ), 'mpn' => ! empty( $e['mpn'] ), 'brand' => ! empty( $e['brand'] ), 'model' => ! empty( $e['model'] ), 'features' => ! empty( $e['attributes_count'] ) || ! empty( $e['short_description'] ), 'category' => ! empty( $e['category'] ) || ! empty( $e['categories'] ), 'images' => ! empty( $e['gallery_count'] ), 'dimensions' => ! empty( $e['weight'] ) || ! empty( $e['dimensions'] ), 'price' => '' !== (string) ( $e['price'] ?? '' ), 'alt' => ! empty( $e['gallery_count'] ) && empty( $e['media_missing_alt'] ), 'stock' => '' !== (string) ( $e['stock_status'] ?? '' ),
            );
            foreach ( $checks as $key => $ok ) if ( $ok ) $filled[$key]++;
        }
        $out = array();
        foreach ( $defs as $key => $label ) $out[] = array( 'key' => $key, 'label' => $label, 'percent' => (int) round( ( $filled[$key] / $total ) * 100 ), 'filled' => (int) $filled[$key], 'total' => (int) $total );
        return $out;
    }
    private function field_percent( array $rows, array $keys ): int { $subset = array_values( array_filter( $rows, static fn( array $row ): bool => in_array( $row['key'], $keys, true ) ) ); return empty( $subset ) ? 0 : (int) round( array_sum( array_column( $subset, 'percent' ) ) / count( $subset ) ); }
    private function field_filled( array $rows, array $keys ): int { $sum = 0; foreach ( $rows as $row ) if ( in_array( $row['key'], $keys, true ) ) $sum += (int) $row['filled']; return $sum; }
    private function field_total( array $rows, array $keys ): int { $sum = 0; foreach ( $rows as $row ) if ( in_array( $row['key'], $keys, true ) ) $sum += (int) $row['total']; return $sum; }
    private function variant_health(): array {
        if ( ! function_exists( 'wc_get_products' ) ) return array( 'total' => 0, 'ready' => 0, 'parents' => 0, 'health' => null, 'rows' => array() );
        $variable_ids = wc_get_products( array( 'status' => array( 'publish','draft','pending','private' ), 'type' => 'variable', 'limit' => -1, 'return' => 'ids' ) );
        $rows = array(); $total = 0; $ready = 0;
        foreach ( (array) $variable_ids as $product_id ) {
            $product = wc_get_product( $product_id );
            if ( ! $product || ! K20AI_Entity_Access::can_read( 'product', (int) $product_id ) ) continue;
            $children = method_exists( $product, 'get_children' ) ? (array) $product->get_children() : array();
            $parent_total = count( $children ); $parent_ready = 0;
            foreach ( $children as $cid ) {
                $child = wc_get_product( $cid );
                if ( $child && '' !== (string) $child->get_price() && in_array( (string) $child->get_stock_status(), array( 'instock','outofstock','onbackorder' ), true ) ) $parent_ready++;
            }
            $total += $parent_total; $ready += $parent_ready;
            $rows[] = array( 'product_id' => (int) $product_id, 'title' => (string) $product->get_name(), 'total' => $parent_total, 'ready' => $parent_ready, 'missing' => max( 0, $parent_total - $parent_ready ), 'health' => $parent_total ? (int) round( 100 * $parent_ready / $parent_total ) : null );
        }
        return array( 'total' => $total, 'ready' => $ready, 'parents' => count( $rows ), 'health' => $total ? (int) round( 100 * $ready / $total ) : null, 'rows' => $rows );
    }

    private function product_evidence_coverage(): array {
        global $wpdb;
        $t = K20AI_Database::tables();
        $product_ids = array_map( 'absint', $this->site_product_ids() );
        $product_ids = array_values( array_filter( $product_ids, static fn( int $id ): bool => $id > 0 && K20AI_Entity_Access::can_read( 'product', $id ) ) );
        $total = count( $product_ids );
        if ( ! $total || ! $this->table_exists( $t['claims'] ) || ! $this->table_exists( $t['evidence'] ) ) return array( 'percent' => $total ? 0 : null, 'supported' => 0, 'total' => $total );
        $subjects = array_map( static fn( int $id ): string => 'post:' . $id, $product_ids );
        $supported_subjects = array();
        foreach ( array_chunk( $subjects, 200 ) as $chunk ) {
            $placeholders = implode( ',', array_fill( 0, count( $chunk ), '%s' ) );
            $sql = $wpdb->prepare( "SELECT DISTINCT c.subject FROM {$t['claims']} c INNER JOIN {$t['evidence']} e ON e.claim_id=c.id WHERE c.subject IN ($placeholders) AND c.status IN ('VERIFIED','PARTIAL') AND e.status IN ('VERIFIED','MANUFACTURER_VERIFIED','SITE_VERIFIED','SUPPLIER_VERIFIED','USER_CONFIRMED','PARTIAL')", ...$chunk ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            foreach ( (array) $wpdb->get_col( $sql ) as $subject ) $supported_subjects[ (string) $subject ] = true;
        }
        $supported = count( $supported_subjects );
        return array( 'percent' => $total ? (int) round( ( $supported / $total ) * 100 ) : null, 'supported' => $supported, 'total' => $total );
    }

    private function product_queue( array $items ): array {
        $out = array();
        foreach ( array_slice( $items, 0, 20 ) as $row ) {
            if ( empty( $row['missing'] ) && (int) ( $row['score'] ?? 0 ) >= 85 ) continue;
            $reason = ! empty( $row['missing'] ) ? 'نیاز به تکمیل: ' . implode( '، ', array_slice( (array) $row['missing'], 0, 3 ) ) : 'امتیاز سلامت محصول نیازمند بازبینی است.';
            $out[] = array( 'priority' => (int) ( $row['score'] ?? 0 ) < 60 ? 'critical' : 'high', 'engine' => 'product-quality', 'entity_title' => (string) ( $row['title'] ?? '' ), 'title' => (string) ( $row['title'] ?? '' ), 'reason' => $reason, 'seo_score' => (int) ( $row['score'] ?? 0 ), 'source_trust' => max( 0, min( 100, 100 - ( 12 * count( (array) ( $row['missing'] ?? array() ) ) ) ) ), 'entity_kind' => 'product', 'entity_id' => (int) ( $row['id'] ?? 0 ) );
        }
        return $out;
    }


    private function workspace_images( array $filters ): array {
        global $wpdb;
        $t = K20AI_Database::tables();
        $kind = sanitize_key( (string) ( $filters['kind'] ?? '' ) );
        $entity_id = absint( $filters['id'] ?? 0 );
        $status = sanitize_key( (string) ( $filters['status'] ?? 'all' ) );
        $query = sanitize_text_field( (string) ( $filters['query'] ?? $filters['q'] ?? '' ) );

        $attachment_ids = get_posts( array(
            'post_type'      => 'attachment',
            'post_status'    => 'inherit',
            'post_mime_type' => 'image',
            'posts_per_page' => -1,
            'fields'         => 'ids',
            'orderby'        => 'ID',
            'order'          => 'DESC',
        ) );
        $items = array();
        $sum = 0;
        $missing_alt = 0;
        $large = 0;
        $missing_dimensions = 0;
        $duplicate_buckets = array();
        foreach ( array_map( 'absint', (array) $attachment_ids ) as $attachment_id ) {
            if ( ! $attachment_id || ! K20AI_Entity_Access::can_read( 'media', $attachment_id ) ) continue;
            $parent_id = (int) wp_get_post_parent_id( $attachment_id );
            if ( $entity_id && $parent_id !== $entity_id ) continue;
            if ( $entity_id && $kind && 'media' !== $kind && get_post_type( $parent_id ) !== ( 'content_post' === $kind ? 'post' : $kind ) ) continue;
            $title = html_entity_decode( (string) get_the_title( $attachment_id ) );
            $alt = (string) get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );
            if ( '' !== $query && false === mb_stripos( $title . ' ' . $alt, $query ) ) continue;
            if ( 'missing-alt' === $status && '' !== trim( $alt ) ) continue;
            if ( 'with-alt' === $status && '' === trim( $alt ) ) continue;
            $meta = wp_get_attachment_metadata( $attachment_id );
            $file = get_attached_file( $attachment_id );
            $filesize = is_string( $file ) && is_file( $file ) ? (int) filesize( $file ) : 0;
            $width = (int) ( is_array( $meta ) ? ( $meta['width'] ?? 0 ) : 0 );
            $height = (int) ( is_array( $meta ) ? ( $meta['height'] ?? 0 ) : 0 );
            $score = 100;
            if ( '' === trim( $alt ) ) $score -= 45;
            if ( ! $width || ! $height ) $score -= 25;
            if ( $filesize > 512000 ) $score -= 20;
            $score = max( 0, min( 100, $score ) );
            $hash = trim( (string) get_post_meta( $attachment_id, '_k20ai_media_hash_sha256', true ) );
            $item = array(
                'id'           => $attachment_id,
                'title'        => $title ?: '#' . $attachment_id,
                'parent_id'    => $parent_id,
                'parent_title' => $parent_id ? html_entity_decode( (string) get_the_title( $parent_id ) ) : '',
                'parent_url'   => $parent_id ? get_edit_post_link( $parent_id, 'raw' ) : '',
                'thumb_url'    => (string) wp_get_attachment_image_url( $attachment_id, 'thumbnail' ),
                'url'          => (string) wp_get_attachment_image_url( $attachment_id, 'medium' ),
                'mime_type'    => (string) get_post_mime_type( $attachment_id ),
                'width'        => $width,
                'height'       => $height,
                'filesize'     => $filesize,
                'alt'          => $alt,
                'score'        => $score,
                'hash'         => $hash,
                'edit_url'     => get_edit_post_link( $attachment_id, 'raw' ),
                'filename'     => is_string( $file ) && '' !== $file ? wp_basename( $file ) : wp_basename( (string) get_attached_file( $attachment_id ) ),
            );
            if ( '' === trim( $alt ) ) $missing_alt++;
            if ( $filesize > 512000 ) $large++;
            if ( ! $width || ! $height ) $missing_dimensions++;
            $sum += $score;
            $items[] = $item;
            if ( '' !== $hash ) $duplicate_buckets[ $hash ][] = $item;
        }
        $groups = array_values( array_filter( $duplicate_buckets, static fn( array $group ): bool => count( $group ) > 1 ) );
        $paged = $this->workspace_page( $filters );
        $per_page = $this->workspace_per_page( $filters, 20, 100 );
        $pagination = $this->workspace_pagination( count( $items ), $paged, $per_page );
        return array(
            'summary' => array(
                'media'              => count( $items ) ? (int) round( $sum / count( $items ) ) : null,
                'total'              => count( $items ),
                'missing_alt'        => $missing_alt,
                'large_files'        => $large,
                'missing_dimensions' => $missing_dimensions,
            ),
            'items'      => $this->workspace_slice_rows( $items, $pagination ),
            'duplicates' => array( 'groups' => $groups, 'group_count' => count( $groups ) ),
            'gallery'    => array_slice( array_values( array_filter( $items, static fn( array $i ): bool => ! empty( $i['thumb_url'] ) ) ), 0, 12 ),
            'pagination' => $pagination,
            'status'     => $status,
            'query'      => $query,
            'reload_token' => time(),
        );
    }

    private function workspace_schema_preview( array $filters ): array {
        $kind = sanitize_key( (string) ( $filters['kind'] ?? 'product' ) );
        $kind = K20AI_Entity_Access::normalize_kind( $kind );
        if ( ! in_array( $kind, array( 'product','content_post','page','news' ), true ) ) $kind = 'product';
        $query = sanitize_text_field( (string) ( $filters['query'] ?? $filters['q'] ?? '' ) );
        $all = $this->workspace_entity_catalog( $kind, $query );
        $paged = $this->workspace_page( $filters );
        $per_page = $this->workspace_per_page( $filters, 20, 50 );
        $pagination = $this->workspace_pagination( count( $all ), $paged, $per_page );
        $candidates = $this->workspace_slice_rows( $all, $pagination );
        $id = absint( $filters['id'] ?? 0 );
        if ( $id && ! K20AI_Entity_Access::can_read( $kind, $id ) ) $id = 0;
        if ( ! $id && ! empty( $candidates[0]['id'] ) ) $id = (int) $candidates[0]['id'];
        $entity = $id ? $this->entity_detail( $kind, $id ) : array();
        $schema = (array) ( $entity['schema'] ?? array() );
        return array(
            'selected' => array( 'kind' => $kind, 'id' => $id ),
            'candidates' => $candidates,
            'pagination' => $pagination,
            'query' => $query,
            'entity' => $entity,
            'schema' => $schema,
            'reload_token' => time(),
        );
    }

    private function workspace_categories_links( array $filters ): array {
        global $wpdb;
        $t = K20AI_Database::tables();
        $taxonomies = array();
        foreach ( array( 'product_cat' => 'دسته محصولات', 'product_tag' => 'برچسب محصولات' ) as $taxonomy => $label ) {
            if ( ! taxonomy_exists( $taxonomy ) ) continue;
            $terms = get_terms( array( 'taxonomy' => $taxonomy, 'hide_empty' => false, 'number' => 0 ) );
            $total = 0; $thin = 0;
            if ( ! is_wp_error( $terms ) ) {
                foreach ( $terms as $term ) {
                    ++$total;
                    $words = $this->word_count( (string) $term->description );
                    if ( (int) $term->count <= 0 || $words < 25 ) ++$thin;
                }
            }
            $health = $total ? max( 0, min( 100, (int) round( 100 * ( $total - $thin ) / $total ) ) ) : null;
            $taxonomies[] = array( 'taxonomy' => $taxonomy, 'label' => $label, 'total' => $total, 'thin' => $thin, 'health' => $health );
        }
        $brand_tax = $this->brand_taxonomy();
        if ( $brand_tax && taxonomy_exists( $brand_tax ) ) {
            $terms = get_terms( array( 'taxonomy' => $brand_tax, 'hide_empty' => false, 'number' => 0 ) );
            $total = 0; $thin = 0;
            if ( ! is_wp_error( $terms ) ) foreach ( $terms as $term ) { ++$total; if ( (int) $term->count <= 0 || $this->word_count( (string) $term->description ) < 25 ) ++$thin; }
            $taxonomies[] = array( 'taxonomy' => $brand_tax, 'label' => 'برندها', 'total' => $total, 'thin' => $thin, 'health' => $total ? (int) round( 100 * ( $total - $thin ) / $total ) : null );
        }
        $link_summary = array( 'total' => 0, 'sources' => 0, 'targets' => 0 );
        if ( $this->table_exists( $t['seo_links'] ) ) {
            $row = (array) $wpdb->get_row( "SELECT COUNT(*) total,COUNT(DISTINCT source_id) sources,COUNT(DISTINCT COALESCE(target_post_id,target_url)) targets FROM {$t['seo_links']} WHERE status='active'", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
            $link_summary = array_map( 'intval', wp_parse_args( $row, $link_summary ) );
        }
        $orphan_rows = array();
        if ( $this->table_exists( $t['seo_profiles'] ) ) {
            $sql = $this->table_exists( $t['seo_links'] )
                ? "SELECT p.entity_kind,p.entity_id,p.title,p.url,p.score_total FROM {$t['seo_profiles']} p LEFT JOIN {$t['seo_links']} l ON l.target_post_id=p.entity_id AND l.status='active' WHERE p.entity_kind IN ('product','content_post','page','news') AND l.id IS NULL ORDER BY p.score_total ASC,p.entity_id DESC"
                : "SELECT p.entity_kind,p.entity_id,p.title,p.url,p.score_total FROM {$t['seo_profiles']} p WHERE p.entity_kind IN ('product','content_post','page','news') ORDER BY p.score_total ASC,p.entity_id DESC";
            foreach ( (array) $wpdb->get_results( $sql, ARRAY_A ) as $row ) {
                if ( ! $this->workspace_entity_row_readable( $row ) ) continue;
                $orphan_rows[] = array( 'entity_kind' => (string) $row['entity_kind'], 'entity_id' => (int) $row['entity_id'], 'title' => (string) $row['title'], 'url' => (string) $row['url'], 'score_total' => (int) $row['score_total'] );
            }
        }
        $paged = $this->workspace_page( $filters );
        $per_page = $this->workspace_per_page( $filters, 20, 100 );
        $pagination = $this->workspace_pagination( count( $orphan_rows ), $paged, $per_page );
        return array(
            'taxonomy' => $taxonomies,
            'links' => $link_summary,
            'orphans' => $this->workspace_slice_rows( $orphan_rows, $pagination ),
            'orphans_total' => count( $orphan_rows ),
            'pagination' => $pagination,
            'reload_token' => time(),
        );
    }

    private function keyword_rows( int $limit = 250 ): array {
        global $wpdb;
        $t = K20AI_Database::tables();
        $limit = max( 1, min( 1000, $limit ) );
        if ( ! $this->table_exists( $t['seo_keywords'] ) ) return array();
        $rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t['seo_keywords']} ORDER BY COALESCE(checked_at,updated_at,created_at) DESC,id DESC LIMIT %d", $limit ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        foreach ( (array) $rows as &$row ) {
            foreach ( array( 'current_position','previous_position','ctr' ) as $key ) $row[ $key ] = null === $row[ $key ] ? null : (float) $row[ $key ];
            foreach ( array( 'impressions','clicks','target_id' ) as $key ) $row[ $key ] = null === $row[ $key ] ? null : (int) $row[ $key ];
        }
        unset( $row );
        return (array) $rows;
    }

    private function workspace_keywords_content( array $filters ): array {
        global $wpdb;
        $t = K20AI_Database::tables();
        $keywords_all = $this->keyword_rows( 1000 );
        $content_rows = $wpdb->get_results( "SELECT * FROM {$t['seo_profiles']} WHERE entity_kind IN ('content_post','page','news') ORDER BY score_content ASC, analyzed_at DESC", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        $content_all = array();
        foreach ( $this->filter_workspace_entity_rows( (array) $content_rows ) as $row ) {
            $p = $this->normalize_profile( $row );
            $updated = (string) ( $p['evidence']['modified_at'] ?? $p['evidence']['modified_gmt'] ?? $p['evidence']['modified'] ?? $p['updated_at'] ?? $p['analyzed_at'] ?? '' );
            $ts = $updated ? strtotime( $updated ) : false;
            $stale_days = array_key_exists( 'stale_days', (array) $p['evidence'] ) && null !== $p['evidence']['stale_days'] ? max( 0, (int) $p['evidence']['stale_days'] ) : ( $ts ? max( 0, (int) floor( ( time() - $ts ) / DAY_IN_SECONDS ) ) : 0 );
            $content_all[] = array(
                'entity_kind'   => $p['entity_kind'],
                'entity_id'     => (int) $p['entity_id'],
                'title'         => $p['title'],
                'word_count'    => (int) ( $p['evidence']['word_count'] ?? 0 ),
                'stale_days'    => $stale_days,
                'score_content' => (int) $p['score_content'],
            );
        }
        $per_page = $this->workspace_per_page( $filters, 20, 100 );
        $keyword_page = max( 1, absint( $filters['keyword_paged'] ?? 1 ) );
        $content_page = max( 1, absint( $filters['content_paged'] ?? 1 ) );
        $keyword_pagination = $this->workspace_pagination( count( $keywords_all ), $keyword_page, $per_page );
        $content_pagination = $this->workspace_pagination( count( $content_all ), $content_page, $per_page );
        return array(
            'keywords' => $this->workspace_slice_rows( $keywords_all, $keyword_pagination ),
            'content' => $this->workspace_slice_rows( $content_all, $content_pagination ),
            'keyword_pagination' => $keyword_pagination,
            'content_pagination' => $content_pagination,
            'keyword_total' => count( $keywords_all ),
            'content_total' => count( $content_all ),
            'source_count' => count( array_unique( array_filter( array_column( $keywords_all, 'source' ) ) ) ),
            'reload_token' => time(),
        );
    }

    private function workspace_technical_health( array $filters = array() ): array {
        global $wpdb;
        $t = K20AI_Database::tables();
        $observations = $this->table_exists( $t['seo_crawl'] ) ? (array) $wpdb->get_results( "SELECT * FROM {$t['seo_crawl']} ORDER BY fetched_at DESC", ARRAY_A ) : array(); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        $codes = array( '2xx' => 0, '3xx' => 0, '4xx' => 0, '5xx' => 0, 'other' => 0 );
        foreach ( $observations as $row ) {
            $code = (int) ( $row['http_status'] ?? 0 );
            $bucket = $code >= 200 && $code < 300 ? '2xx' : ( $code >= 300 && $code < 400 ? '3xx' : ( $code >= 400 && $code < 500 ? '4xx' : ( $code >= 500 && $code < 600 ? '5xx' : 'other' ) ) );
            $codes[ $bucket ]++;
        }
        $issues_all = $this->table_exists( $t['seo_issues'] ) ? (array) $wpdb->get_results( "SELECT * FROM {$t['seo_issues']} WHERE status='open' AND component IN ('technical','crawl','indexability') ORDER BY FIELD(severity,'critical','warning','info'),id DESC", ARRAY_A ) : array(); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        foreach ( $issues_all as &$issue ) $issue['entity_title'] = (string) get_the_title( (int) ( $issue['entity_id'] ?? 0 ) );
        unset( $issue );
        $paged = $this->workspace_page( $filters );
        $per_page = $this->workspace_per_page( $filters, 20, 100 );
        $pagination = $this->workspace_pagination( count( $issues_all ), $paged, $per_page );
        return array( 'observations' => $observations, 'codes' => $codes, 'issues' => $this->workspace_slice_rows( $issues_all, $pagination ), 'issues_total' => count( $issues_all ), 'issues_critical_total' => count( array_filter( $issues_all, static fn( array $row ): bool => 'critical' === (string) ( $row['severity'] ?? '' ) ) ), 'pagination' => $pagination, 'trend' => $this->health_trend( 30 ), 'checks' => $this->technical_checks(), 'reload_token' => time() );
    }

    private function workspace_competitors( array $filters = array() ): array {
        global $wpdb;
        $t = K20AI_Database::tables();
        $competitors = $this->table_exists( $t['seo_competitors'] ) ? (array) $wpdb->get_results( "SELECT * FROM {$t['seo_competitors']} ORDER BY enabled DESC,updated_at DESC,id DESC", ARRAY_A ) : array(); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        foreach ( $competitors as &$row ) { $row['id'] = (int) $row['id']; $row['enabled'] = (bool) $row['enabled']; $row['metrics'] = $this->json( $row['metrics'] ?? '{}' ); }
        unset( $row );
        $keywords_all = $this->keyword_rows( 1000 );
        $paged = $this->workspace_page( $filters );
        $per_page = $this->workspace_per_page( $filters, 20, 100 );
        $pagination = $this->workspace_pagination( count( $keywords_all ), $paged, $per_page );
        $serpapi = $this->connection_center ? (array) $this->connection_center->get( 'serpapi' ) : array();
        return array( 'competitors' => $competitors, 'keywords' => $this->workspace_slice_rows( $keywords_all, $pagination ), 'keywords_total' => count( $keywords_all ), 'pagination' => $pagination, 'serpapi_status' => (string) ( $serpapi['status'] ?? 'disconnected' ), 'note' => $competitors ? '' : 'رقیبی با منبع معتبر ثبت نشده است.' );
    }

    private function workspace_rank_tracking( array $filters = array() ): array {
        $rows_all = $this->keyword_rows( 1000 );
        $positions = array_values( array_filter( array_column( $rows_all, 'current_position' ), static fn( $v ): bool => null !== $v ) );
        $top10 = 0; $improved = 0; $declined = 0; $impressions = 0;
        foreach ( $rows_all as $row ) {
            if ( null !== $row['current_position'] && (float) $row['current_position'] <= 10 ) $top10++;
            if ( null !== $row['current_position'] && null !== $row['previous_position'] ) {
                if ( (float) $row['current_position'] < (float) $row['previous_position'] ) $improved++;
                elseif ( (float) $row['current_position'] > (float) $row['previous_position'] ) $declined++;
            }
            $impressions += (int) ( $row['impressions'] ?? 0 );
        }
        $paged = $this->workspace_page( $filters );
        $per_page = $this->workspace_per_page( $filters, 20, 100 );
        $pagination = $this->workspace_pagination( count( $rows_all ), $paged, $per_page );
        return array( 'keywords' => $this->workspace_slice_rows( $rows_all, $pagination ), 'pagination' => $pagination, 'metrics' => array( 'tracked' => count( $rows_all ), 'avg_position' => $positions ? round( array_sum( $positions ) / count( $positions ), 2 ) : null, 'top10' => $top10, 'improved' => $improved, 'declined' => $declined, 'impressions' => $impressions ), 'reload_token' => time() );
    }

    private function workspace_content_refresh( array $filters ): array {
        global $wpdb;
        $t = K20AI_Database::tables();
        $rows = $wpdb->get_results( "SELECT * FROM {$t['seo_profiles']} WHERE entity_kind IN ('content_post','page','news') ORDER BY score_content ASC, analyzed_at DESC", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        $rows = $this->filter_workspace_entity_rows( (array) $rows );
        $all = array();
        foreach ( $rows as $row ) {
            $p = $this->normalize_profile( $row );
            $updated = (string) ( $p['evidence']['modified_at'] ?? $p['evidence']['modified_gmt'] ?? $p['evidence']['modified'] ?? $p['updated_at'] ?? $p['analyzed_at'] ?? '' );
            $ts = $updated ? strtotime( $updated ) : false;
            $stale_days = array_key_exists( 'stale_days', (array) $p['evidence'] ) && null !== $p['evidence']['stale_days'] ? max( 0, (int) $p['evidence']['stale_days'] ) : ( $ts ? max( 0, (int) floor( ( time() - $ts ) / DAY_IN_SECONDS ) ) : 0 );
            $all[] = array( 'id' => (int) $p['entity_id'], 'kind' => $p['entity_kind'], 'title' => $p['title'], 'score' => (int) $p['score_content'], 'stale_days' => $stale_days, 'word_count' => (int) ( $p['evidence']['word_count'] ?? 0 ) );
        }
        $paged = $this->workspace_page( $filters );
        $per_page = $this->workspace_per_page( $filters, 20, 100 );
        $pagination = $this->workspace_pagination( count( $all ), $paged, $per_page );
        $calendar_types = array( 'post','page','shop_coupon' );
        foreach ( (array) get_post_types( array( 'show_ui' => true ), 'names' ) as $post_type ) {
            if ( in_array( $post_type, array( 'attachment','revision','nav_menu_item','product' ), true ) ) continue;
            if ( false !== stripos( $post_type, 'news' ) || false !== stripos( $post_type, 'article' ) ) $calendar_types[] = $post_type;
        }
        $calendar_types = array_values( array_unique( array_filter( $calendar_types, 'post_type_exists' ) ) );
        $posts = get_posts( array( 'post_type' => $calendar_types, 'post_status' => array( 'draft','pending','future' ), 'posts_per_page' => -1, 'orderby' => 'date', 'order' => 'ASC' ) );
        $calendar = array();
        foreach ( (array) $posts as $post ) {
            if ( ! current_user_can( 'edit_post', $post->ID ) ) continue;
            $calendar[] = array( 'id' => (int) $post->ID, 'title' => get_the_title( $post ), 'status' => $post->post_status, 'type' => $post->post_type, 'date' => $post->post_date, 'edit_url' => get_edit_post_link( $post->ID, 'raw' ) );
        }
        $queue = array_values( array_filter( $all, static fn( array $row ): bool => $row['score'] < 80 || $row['stale_days'] >= 180 ) );
        return array( 'items' => $this->workspace_slice_rows( $all, $pagination ), 'pagination' => $pagination, 'calendar' => $calendar, 'queue' => $queue, 'stale_count' => count( array_filter( $all, static fn( array $row ): bool => $row['stale_days'] >= 180 ) ), 'low_content' => count( array_filter( $all, static fn( array $row ): bool => $row['score'] < 60 ) ), 'reload_token' => time() );
    }

    private function workspace_control_tower( array $filters ): array {
        $result = $this->legacy->execute( 'command.center' );
        return array( 'command_center' => is_wp_error( $result ) ? array( 'error' => $result->get_error_message(), 'metrics' => array() ) : $result, 'reload_token' => time() );
    }


}
