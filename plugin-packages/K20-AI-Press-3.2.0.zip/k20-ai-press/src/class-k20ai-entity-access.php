<?php

defined( 'ABSPATH' ) || exit;

/**
 * Exact-object authorization and entity-kind validation.
 *
 * Broad plugin capabilities decide whether a user may enter K20 AI Press; WordPress
 * meta capabilities decide whether that same user may read or edit the exact target.
 */
final class K20AI_Entity_Access {
    /** @return array<int,string> */
    public static function supported_kinds(): array {
        return array( 'product', 'content_post', 'page', 'news', 'media' );
    }

    public static function normalize_kind( mixed $kind ): string {
        $kind = sanitize_key( (string) $kind );
        return in_array( $kind, self::supported_kinds(), true ) ? $kind : '';
    }

    public static function resolve_kind( int $id ): string {
        $post = get_post( $id );
        if ( ! $post instanceof WP_Post ) return '';

        $post_type = (string) $post->post_type;
        if ( 'product' === $post_type ) return 'product';
        if ( 'attachment' === $post_type ) return 'media';
        if ( 'page' === $post_type ) return 'page';

        $object = get_post_type_object( $post_type );
        if ( ! $object ) return '';
        if ( ! in_array( $post_type, array( 'post' ), true ) && empty( $object->publicly_queryable ) && empty( $object->public ) ) return '';

        $label = strtolower( (string) ( $object->label ?? '' ) );
        $slug  = strtolower( $post_type );
        if ( str_contains( $slug, 'news' ) || str_contains( $slug, 'press' ) || str_contains( $label, 'news' ) || str_contains( $label, 'خبر' ) ) {
            return 'news';
        }
        return 'content_post';
    }

    public static function kind_matches( string $kind, int $id ): bool {
        $kind = self::normalize_kind( $kind );
        return '' !== $kind && $kind === self::resolve_kind( $id );
    }

    public static function can_read( string $kind, int $id ): bool {
        if ( ! K20AI_Security::can_view() || $id <= 0 || ! self::kind_matches( $kind, $id ) ) return false;
        return current_user_can( 'read_post', $id );
    }

    public static function can_edit( string $kind, int $id ): bool {
        if ( ! K20AI_Security::can_edit_content() || $id <= 0 || ! self::kind_matches( $kind, $id ) ) return false;
        return current_user_can( 'edit_post', $id );
    }

    public static function read_error( string $kind, int $id ): ?WP_Error {
        if ( $id <= 0 || '' === self::normalize_kind( $kind ) ) {
            return new WP_Error( 'invalid_entity', __( 'The requested entity is invalid.', 'k20-ai-press' ), array( 'status' => 400 ) );
        }
        if ( ! self::kind_matches( $kind, $id ) ) {
            return new WP_Error( 'entity_not_found', __( 'The requested entity was not found.', 'k20-ai-press' ), array( 'status' => 404 ) );
        }
        if ( ! self::can_read( $kind, $id ) ) {
            return new WP_Error( 'forbidden_entity', __( 'You do not have permission to read this entity.', 'k20-ai-press' ), array( 'status' => 403 ) );
        }
        return null;
    }

    public static function edit_error( string $kind, int $id ): ?WP_Error {
        if ( $id <= 0 || '' === self::normalize_kind( $kind ) ) {
            return new WP_Error( 'invalid_entity', __( 'The requested entity is invalid.', 'k20-ai-press' ), array( 'status' => 400 ) );
        }
        if ( ! self::kind_matches( $kind, $id ) ) {
            return new WP_Error( 'entity_not_found', __( 'The requested entity was not found.', 'k20-ai-press' ), array( 'status' => 404 ) );
        }
        if ( ! self::can_edit( $kind, $id ) ) {
            return new WP_Error( 'forbidden_entity', __( 'You do not have permission to edit this entity.', 'k20-ai-press' ), array( 'status' => 403 ) );
        }
        return null;
    }
}
