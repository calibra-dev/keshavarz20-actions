<?php

defined( 'ABSPATH' ) || exit;

/**
 * Measured AI-search visibility observatory.
 *
 * This service never scrapes or invents AI-engine results. It stores query
 * definitions and observations supplied by a connected/verified collector.
 */
final class K20AI_AI_Visibility {
    private const ENGINES = array( 'google-ai', 'chatgpt-search', 'gemini', 'perplexity', 'copilot-bing', 'openai-web-search-api' );
    private ?K20AI_Connection_Center $connections = null;

    public function set_connection_center( K20AI_Connection_Center $connections ): void {
        $this->connections = $connections;
    }

    /** @return array<int,string> */
    public static function engines(): array {
        return self::ENGINES;
    }
    /** @return array<string,mixed> */
    public function collector_status(): array {
        $openai = $this->connections ? $this->connections->get( 'openai', false ) : array();
        $config = is_array( $openai['config'] ?? null ) ? $openai['config'] : array();
        $ready = $this->connections && 'connected' === (string) ( $openai['status'] ?? '' ) && ! empty( $config['web_search'] );
        return array(
            'scheduler' => 'k20ai_v3_hourly_tick',
            'automatic_collector' => $ready ? 'openai-web-search-api' : null,
            'openai_web_search_ready' => (bool) $ready,
            'external_collectors_supported' => array( 'google-ai', 'chatgpt-search', 'gemini', 'perplexity', 'copilot-bing' ),
            'truth_boundary' => __( 'OpenAI Web Search API observations are labelled separately and are not presented as consumer ChatGPT Search measurements. Other engines require a verified external collector.', 'k20-ai-press' ),
        );
    }

    /** @return array<string,mixed>|WP_Error */
    public function collect_now( int $limit = 5 ): array|WP_Error {
        if ( ! $this->connections ) return new WP_Error( 'visibility_collector_unavailable', __( 'AI Visibility collector is not connected to the connection center.', 'k20-ai-press' ), array( 'status' => 503 ) );
        $status = $this->collector_status();
        if ( empty( $status['openai_web_search_ready'] ) ) return new WP_Error( 'visibility_collector_not_ready', __( 'Automatic visibility collection requires a verified OpenAI connection with Web Search enabled.', 'k20-ai-press' ), array( 'status' => 409 ) );
        $queries = array_slice( $this->queries( true ), 0, max( 1, min( 20, $limit ) ) );
        $results = array();
        foreach ( $queries as $query ) {
            $results[] = $this->collect_openai_web_search( $query );
        }
        $ok = count( array_filter( $results, static fn( $row ): bool => ! is_wp_error( $row ) ) );
        return array( 'collector' => 'openai-web-search-api', 'attempted' => count( $results ), 'stored' => $ok, 'results' => array_map( static function( $row ) { return is_wp_error( $row ) ? array( 'ok' => false, 'code' => $row->get_error_code(), 'message' => $row->get_error_message() ) : array( 'ok' => true, 'observation' => $row ); }, $results ) );
    }

    public function scheduled_collect( array $settings ): void {
        if ( empty( $settings['visibility_auto_collect'] ) ) return;
        $last = (int) get_option( 'k20ai_visibility_last_auto_collect', 0 );
        if ( $last && time() - $last < 6 * HOUR_IN_SECONDS ) return;
        update_option( 'k20ai_visibility_last_auto_collect', time(), false );
        $result = $this->collect_now( 5 );
        if ( is_wp_error( $result ) ) K20AI_Logger::warning( 'AI Visibility scheduled collection skipped.', array( 'code' => $result->get_error_code() ) );
    }

    /** @param array<string,mixed> $query @return array<string,mixed>|WP_Error */
    private function collect_openai_web_search( array $query ): array|WP_Error {
        $query_text = trim( (string) ( $query['query_text'] ?? '' ) );
        if ( '' === $query_text ) return new WP_Error( 'visibility_query_empty', __( 'Visibility query is empty.', 'k20-ai-press' ) );
        $schema = array(
            'type' => 'object', 'additionalProperties' => false,
            'properties' => array(
                'mentioned' => array( 'type' => 'boolean' ),
                'competitor' => array( 'type' => 'string' ),
                'position_label' => array( 'type' => 'string' ),
                'note' => array( 'type' => 'string' ),
            ),
            'required' => array( 'mentioned', 'competitor', 'position_label', 'note' ),
        );
        $system = 'Measure the supplied search query using web search. Report only what the retrieved web evidence supports. Do not invent citations. Return JSON only.';
        $prompt = "Query: " . $query_text . "\nTarget site: " . home_url() . "\nLocale: " . (string) ( $query['locale'] ?? '' ) . "\nCountry: " . (string) ( $query['country'] ?? '' );
        $generated = $this->connections->ai_generate( 'openai', array( 'system' => $system, 'prompt' => $prompt, 'schema' => $schema, 'web_search' => true ) );
        if ( is_wp_error( $generated ) ) return $generated;
        $sources = array_values( array_filter( (array) ( $generated['sources'] ?? array() ), static fn( $src ): bool => is_array( $src ) && ! empty( $src['url'] ) ) );
        $target_host = strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
        $cited_url = '';
        foreach ( $sources as $source ) {
            $host = strtolower( (string) wp_parse_url( (string) $source['url'], PHP_URL_HOST ) );
            if ( $host && $target_host && ( $host === $target_host || str_ends_with( $host, '.' . $target_host ) ) ) { $cited_url = (string) $source['url']; break; }
        }
        $data = (array) ( $generated['data'] ?? array() );
        return $this->ingest_observation( array(
            'query_id' => (int) $query['id'],
            'engine' => 'openai-web-search-api',
            'mentioned' => ! empty( $data['mentioned'] ) || '' !== $cited_url,
            'cited' => '' !== $cited_url,
            'cited_url' => $cited_url,
            'competitor' => sanitize_text_field( (string) ( $data['competitor'] ?? '' ) ),
            'position_label' => sanitize_text_field( (string) ( $data['position_label'] ?? '' ) ),
            'evidence' => array( 'provider' => 'openai', 'model' => (string) ( $generated['model'] ?? '' ), 'sources' => $sources, 'note' => sanitize_text_field( (string) ( $data['note'] ?? '' ) ) ),
            'collector' => 'openai-web-search-api',
            'collector_ref' => (string) ( $generated['model'] ?? '' ),
        ) );
    }


    /** @return array<int,array<string,mixed>> */
    public function queries( bool $enabled_only = false ): array {
        global $wpdb;
        $t = K20AI_Database::tables();
        $where = $enabled_only ? 'WHERE enabled=1' : '';
        $rows = $wpdb->get_results(
            "SELECT id,query_key,query_text,locale,country,enabled,tags,created_at,updated_at FROM {$t['visibility_queries']} {$where} ORDER BY enabled DESC,id DESC LIMIT 500",
            ARRAY_A
        ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        foreach ( (array) $rows as &$row ) {
            $row['id'] = (int) $row['id'];
            $row['enabled'] = (bool) $row['enabled'];
            $decoded = json_decode( (string) ( $row['tags'] ?? '' ), true );
            $row['tags'] = is_array( $decoded ) ? array_values( array_map( 'sanitize_text_field', $decoded ) ) : array();
        }
        unset( $row );
        return is_array( $rows ) ? $rows : array();
    }

    /** @return array<string,mixed>|WP_Error */
    public function upsert_query( array $input ): array|WP_Error {
        global $wpdb;
        $text = trim( wp_strip_all_tags( (string) ( $input['query'] ?? '' ) ) );
        if ( mb_strlen( $text ) < 2 || mb_strlen( $text ) > 500 ) {
            return new WP_Error( 'invalid_query', __( 'Visibility query must contain 2 to 500 characters.', 'k20-ai-press' ), array( 'status' => 422 ) );
        }
        $locale = sanitize_text_field( (string) ( $input['locale'] ?? determine_locale() ) );
        $country = strtoupper( substr( preg_replace( '/[^A-Za-z]/', '', (string) ( $input['country'] ?? '' ) ) ?: '', 0, 2 ) );
        $key = hash( 'sha256', mb_strtolower( $text ) . '|' . $locale . '|' . $country );
        $tags = array_values( array_unique( array_filter( array_map( 'sanitize_text_field', (array) ( $input['tags'] ?? array() ) ) ) ) );
        $enabled = array_key_exists( 'enabled', $input ) ? ( ! empty( $input['enabled'] ) ? 1 : 0 ) : 1;
        $now = current_time( 'mysql', true );
        $t = K20AI_Database::tables();
        $existing = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t['visibility_queries']} WHERE query_key=%s LIMIT 1", $key ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $data = array(
            'query_text' => $text,
            'locale'     => $locale,
            'country'    => $country,
            'enabled'    => $enabled,
            'tags'       => wp_json_encode( $tags, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ),
            'updated_at' => $now,
        );
        if ( $existing ) {
            $written = $wpdb->update( $t['visibility_queries'], $data, array( 'id' => $existing ) );
            if ( false === $written ) return new WP_Error( 'visibility_query_write_failed', __( 'Visibility query could not be updated.', 'k20-ai-press' ), array( 'status' => 500 ) );
            $id = $existing;
        } else {
            $data['query_key'] = $key;
            $data['created_by'] = get_current_user_id() ?: null;
            $data['created_at'] = $now;
            $written = $wpdb->insert( $t['visibility_queries'], $data );
            if ( false === $written || ! $wpdb->insert_id ) return new WP_Error( 'visibility_query_write_failed', __( 'Visibility query could not be created.', 'k20-ai-press' ), array( 'status' => 500 ) );
            $id = (int) $wpdb->insert_id;
        }
        return array( 'id' => $id, 'query_key' => $key, 'query' => $text, 'enabled' => (bool) $enabled, 'tags' => $tags );
    }

    /** @return array<string,mixed>|WP_Error */
    public function ingest_observation( array $input ): array|WP_Error {
        global $wpdb;
        $query_id = absint( $input['query_id'] ?? 0 );
        $engine = sanitize_key( (string) ( $input['engine'] ?? '' ) );
        if ( ! $query_id || ! in_array( $engine, self::ENGINES, true ) ) {
            return new WP_Error( 'invalid_visibility_observation', __( 'A valid query ID and supported AI engine are required.', 'k20-ai-press' ), array( 'status' => 422 ) );
        }
        $t = K20AI_Database::tables();
        $query = $wpdb->get_row( $wpdb->prepare( "SELECT id,query_text FROM {$t['visibility_queries']} WHERE id=%d LIMIT 1", $query_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        if ( ! $query ) return new WP_Error( 'visibility_query_not_found', __( 'Visibility query was not found.', 'k20-ai-press' ), array( 'status' => 404 ) );

        $mentioned = ! empty( $input['mentioned'] );
        $cited = ! empty( $input['cited'] );
        $cited_url = esc_url_raw( (string) ( $input['cited_url'] ?? '' ), array( 'http', 'https' ) );
        if ( $cited && ! $cited_url ) {
            return new WP_Error( 'citation_url_required', __( 'A cited observation must include the cited URL.', 'k20-ai-press' ), array( 'status' => 422 ) );
        }
        $source_url = esc_url_raw( (string) ( $input['source_url'] ?? '' ), array( 'http', 'https' ) );
        $evidence = (array) ( $input['evidence'] ?? array() );
        if ( ! $source_url && empty( $evidence ) ) {
            return new WP_Error( 'visibility_evidence_required', __( 'Measured visibility observations require a source URL or evidence payload.', 'k20-ai-press' ), array( 'status' => 422 ) );
        }
        $collector = sanitize_key( (string) ( $input['collector'] ?? 'manual' ) );
        if ( '' === $collector ) $collector = 'manual';
        $collector_ref = substr( sanitize_text_field( (string) ( $input['collector_ref'] ?? '' ) ), 0, 191 );
        $evidence = K20AI_Logger::sanitize_context( $evidence );
        $evidence['_attribution'] = array(
            'collector'     => $collector,
            'collector_ref' => '' !== $collector_ref ? $collector_ref : null,
        );
        $observed = sanitize_text_field( (string) ( $input['observed_at'] ?? '' ) );
        if ( '' === $observed || false === strtotime( $observed ) ) $observed = current_time( 'mysql', true );
        else $observed = gmdate( 'Y-m-d H:i:s', strtotime( $observed ) );

        $written = $wpdb->insert( $t['visibility_observations'], array(
            'query_id'       => $query_id,
            'engine'         => $engine,
            'mentioned'      => $mentioned ? 1 : 0,
            'cited'          => $cited ? 1 : 0,
            'cited_url'      => $cited_url ?: null,
            'competitor'     => sanitize_text_field( (string) ( $input['competitor'] ?? '' ) ),
            'position_label' => sanitize_text_field( (string) ( $input['position_label'] ?? '' ) ),
            'source_url'     => $source_url ?: null,
            'evidence'       => wp_json_encode( $evidence, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ),
            'observed_at'    => $observed,
            'created_at'     => current_time( 'mysql', true ),
        ) );
        if ( false === $written || ! $wpdb->insert_id ) return new WP_Error( 'visibility_observation_write_failed', __( 'Visibility observation could not be stored.', 'k20-ai-press' ), array( 'status' => 500 ) );
        return array( 'id' => (int) $wpdb->insert_id, 'query_id' => $query_id, 'engine' => $engine, 'measured' => true, 'attribution' => $evidence['_attribution'] );
    }

    /** @return array<string,mixed> */
    public function observatory( int $days = 30, int $limit = 100 ): array {
        global $wpdb;
        $t = K20AI_Database::tables();
        $days = max( 1, min( 365, $days ) );
        $limit = max( 1, min( 500, $limit ) );
        $since = gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS );
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT o.*,q.query_text,q.locale,q.country FROM {$t['visibility_observations']} o INNER JOIN {$t['visibility_queries']} q ON q.id=o.query_id WHERE o.observed_at>=%s ORDER BY o.observed_at DESC,o.id DESC LIMIT %d",
                $since,
                $limit
            ),
            ARRAY_A
        ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $rows = is_array( $rows ) ? $rows : array();
        $latest = array();
        $previous = array();
        $engine_totals = array();
        foreach ( $rows as &$row ) {
            $row['id'] = (int) $row['id'];
            $row['query_id'] = (int) $row['query_id'];
            $row['mentioned'] = (bool) $row['mentioned'];
            $row['cited'] = (bool) $row['cited'];
            $decoded_evidence = json_decode( (string) ( $row['evidence'] ?? '' ), true );
            $decoded_evidence = is_array( $decoded_evidence ) ? $decoded_evidence : array();
            $row['attribution'] = is_array( $decoded_evidence['_attribution'] ?? null ) ? $decoded_evidence['_attribution'] : array( 'collector' => 'legacy', 'collector_ref' => null );
            unset( $decoded_evidence['_attribution'] );
            $row['evidence'] = $decoded_evidence;
            $key = $row['query_id'] . '|' . $row['engine'];
            if ( ! isset( $latest[ $key ] ) ) $latest[ $key ] = $row;
            elseif ( ! isset( $previous[ $key ] ) ) $previous[ $key ] = $row;
            if ( ! isset( $engine_totals[ $row['engine'] ] ) ) $engine_totals[ $row['engine'] ] = array( 'samples' => 0, 'mentions' => 0, 'citations' => 0 );
            ++$engine_totals[ $row['engine'] ]['samples'];
            if ( $row['mentioned'] ) ++$engine_totals[ $row['engine'] ]['mentions'];
            if ( $row['cited'] ) ++$engine_totals[ $row['engine'] ]['citations'];
        }
        unset( $row );

        $current = array();
        foreach ( $latest as $key => $row ) {
            $prior = $previous[ $key ] ?? null;
            $change = 'new';
            if ( $prior ) {
                if ( ! empty( $row['cited'] ) && empty( $prior['cited'] ) ) $change = 'citation_gain';
                elseif ( empty( $row['cited'] ) && ! empty( $prior['cited'] ) ) $change = 'citation_loss';
                elseif ( ! empty( $row['mentioned'] ) && empty( $prior['mentioned'] ) ) $change = 'mention_gain';
                elseif ( empty( $row['mentioned'] ) && ! empty( $prior['mentioned'] ) ) $change = 'mention_loss';
                else $change = 'stable';
            }
            $row['change'] = $change;
            $current[] = $row;
        }
        foreach ( $engine_totals as &$summary ) {
            $summary['mention_rate'] = $summary['samples'] ? round( 100 * $summary['mentions'] / $summary['samples'], 2 ) : null;
            $summary['citation_rate'] = $summary['samples'] ? round( 100 * $summary['citations'] / $summary['samples'], 2 ) : null;
        }
        unset( $summary );
        return array(
            'mode'          => $rows ? 'measured' : 'not_measured',
            'period_days'   => $days,
            'queries'       => $this->queries( true ),
            'current'       => array_values( $current ),
            'engine_totals' => $engine_totals,
            'observations'  => $rows,
            'note'          => $rows ? __( 'All values are derived from ingested measured observations.', 'k20-ai-press' ) : __( 'No measured AI-search observations have been ingested yet.', 'k20-ai-press' ),
        );
    }
}
