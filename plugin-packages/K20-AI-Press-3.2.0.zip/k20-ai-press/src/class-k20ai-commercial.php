<?php

defined( 'ABSPATH' ) || exit;

/** Commercial licensing/updater boundary. Fail closed unless explicitly configured. */
final class K20AI_Commercial {
    private const OPTION = 'k20ai_commercial';
    private const MANIFEST_TRANSIENT = 'k20ai_update_manifest_311';

    public function register_hooks(): void {
        add_filter( 'pre_set_site_transient_update_plugins', array( $this, 'inject_update' ) );
        add_filter( 'plugins_api', array( $this, 'plugin_information' ), 20, 3 );
        add_action( 'k20ai_license_sync', array( $this, 'scheduled_sync' ) );
    }

    public function scheduled_sync(): void {
        if ( ! $this->configured() ) return;
        $state = $this->state();
        if ( '' === $this->license_key( $state ) ) return;
        $result = $this->sync();
        if ( is_wp_error( $result ) ) K20AI_Logger::warning( 'Scheduled commercial license sync failed.', array( 'code' => $result->get_error_code() ) );
    }

    /** @return array<string,mixed> */
    public function status(): array {
        $state = $this->state();
        $configured = $this->configured();
        return array(
            'configured' => $configured,
            'status'     => $configured ? (string) ( $state['status'] ?? 'inactive' ) : 'unconfigured',
            'plan'       => (string) ( $state['plan'] ?? '' ),
            'expires_at' => $state['expires_at'] ?? null,
            'site'       => home_url(),
            'updates_entitled' => $configured && 'active' === (string) ( $state['status'] ?? '' ) && ! empty( $state['updates_entitled'] ),
            'last_sync'  => $state['last_sync'] ?? null,
            'grace_until'=> $state['grace_until'] ?? null,
        );
    }

    /** @return array<string,mixed>|WP_Error */
    public function activate( string $license_key ): array|WP_Error {
        if ( ! $this->configured() ) return $this->not_configured();
        $license_key = trim( $license_key );
        if ( strlen( $license_key ) < 8 || strlen( $license_key ) > 255 ) return new WP_Error( 'invalid_license_key', __( 'License key format is invalid.', 'k20-ai-press' ), array( 'status' => 422 ) );
        $response = $this->request( '/v1/license/activate', array( 'license_key' => $license_key, 'site' => home_url(), 'plugin_version' => K20AI_PRESS_VERSION ) );
        if ( is_wp_error( $response ) ) return $response;
        $payload = $this->verify_signed_response( $response );
        if ( is_wp_error( $payload ) ) return $payload;
        $encrypted = K20AI_Crypto::encrypt_string( $license_key, 'commercial-license' );
        if ( is_wp_error( $encrypted ) ) return $encrypted;
        $state = array(
            'license_key' => $encrypted,
            'status' => sanitize_key( (string) ( $payload['status'] ?? 'invalid' ) ),
            'plan' => sanitize_key( (string) ( $payload['plan'] ?? '' ) ),
            'expires_at' => sanitize_text_field( (string) ( $payload['expires_at'] ?? '' ) ),
            'updates_entitled' => ! empty( $payload['updates_entitled'] ),
            'grace_until' => sanitize_text_field( (string) ( $payload['grace_until'] ?? '' ) ),
            'last_sync' => current_time( DATE_ATOM, true ),
        );
        update_option( self::OPTION, $state, false );
        delete_site_transient( self::MANIFEST_TRANSIENT );
        return $this->status();
    }

    /** @return array<string,mixed>|WP_Error */
    public function deactivate(): array|WP_Error {
        $state = $this->state();
        if ( ! $this->configured() ) { delete_option( self::OPTION ); return $this->status(); }
        $key = $this->license_key( $state );
        if ( $key ) {
            $response = $this->request( '/v1/license/deactivate', array( 'license_key' => $key, 'site' => home_url() ) );
            if ( is_wp_error( $response ) ) return $response;
            $verified = $this->verify_signed_response( $response );
            if ( is_wp_error( $verified ) ) return $verified;
        }
        delete_option( self::OPTION );
        delete_site_transient( self::MANIFEST_TRANSIENT );
        return $this->status();
    }

    /** @return array<string,mixed>|WP_Error */
    public function sync(): array|WP_Error {
        if ( ! $this->configured() ) return $this->not_configured();
        $state = $this->state();
        $key = $this->license_key( $state );
        if ( ! $key ) return new WP_Error( 'license_missing', __( 'No license is activated.', 'k20-ai-press' ), array( 'status' => 409 ) );
        $response = $this->request( '/v1/license/status', array( 'license_key' => $key, 'site' => home_url(), 'plugin_version' => K20AI_PRESS_VERSION ) );
        if ( is_wp_error( $response ) ) return $response;
        $payload = $this->verify_signed_response( $response );
        if ( is_wp_error( $payload ) ) return $payload;
        foreach ( array( 'status', 'plan', 'expires_at', 'grace_until' ) as $field ) if ( isset( $payload[ $field ] ) ) $state[ $field ] = sanitize_text_field( (string) $payload[ $field ] );
        if ( array_key_exists( 'updates_entitled', $payload ) ) $state['updates_entitled'] = (bool) $payload['updates_entitled'];
        $state['last_sync'] = current_time( DATE_ATOM, true );
        update_option( self::OPTION, $state, false );
        if ( ! empty( $payload['manifest'] ) && is_array( $payload['manifest'] ) ) $this->cache_manifest( $payload['manifest'] );
        return $this->status();
    }

    public function inject_update( mixed $transient ): mixed {
        if ( ! is_object( $transient ) || empty( $transient->checked ) ) return $transient;
        $status = $this->status();
        if ( empty( $status['updates_entitled'] ) ) return $transient;
        $manifest = get_site_transient( self::MANIFEST_TRANSIENT );
        if ( ! is_array( $manifest ) || empty( $manifest['version'] ) || empty( $manifest['package'] ) ) return $transient;
        if ( version_compare( K20AI_PRESS_VERSION, (string) $manifest['version'], '>=' ) ) return $transient;
        $plugin = plugin_basename( K20AI_PRESS_FILE );
        $transient->response[ $plugin ] = (object) array( 'id' => 'k20-ai-press', 'slug' => dirname( $plugin ), 'plugin' => $plugin, 'new_version' => sanitize_text_field( (string) $manifest['version'] ), 'url' => 'https://keshavarz20.com/', 'package' => esc_url_raw( (string) $manifest['package'] ), 'tested' => sanitize_text_field( (string) ( $manifest['tested'] ?? '' ) ), 'requires_php' => sanitize_text_field( (string) ( $manifest['requires_php'] ?? '8.3' ) ) );
        return $transient;
    }

    public function plugin_information( mixed $result, string $action, mixed $args ): mixed {
        if ( 'plugin_information' !== $action || ! is_object( $args ) || 'k20-ai-press' !== (string) ( $args->slug ?? '' ) ) return $result;
        $manifest = get_site_transient( self::MANIFEST_TRANSIENT );
        if ( ! is_array( $manifest ) ) return $result;
        return (object) array( 'name' => 'K20 AI Press', 'slug' => 'k20-ai-press', 'version' => (string) ( $manifest['version'] ?? K20AI_PRESS_VERSION ), 'author' => '<a href="https://keshavarz20.com/">کشاورز بیست</a>', 'homepage' => 'https://keshavarz20.com/', 'requires' => '7.1', 'requires_php' => '8.3', 'sections' => array( 'description' => wp_kses_post( (string) ( $manifest['description'] ?? '' ) ), 'changelog' => wp_kses_post( (string) ( $manifest['changelog'] ?? '' ) ) ), 'download_link' => esc_url_raw( (string) ( $manifest['package'] ?? '' ) ) );
    }

    /** @return array<string,mixed> */
    public function diagnostics( K20AI_Ability_Registry $registry, K20AI_Services $services ): array {
        global $wp_version, $wpdb;
        $tables = K20AI_Database::tables();
        $queue = array();
        foreach ( array( 'agent_runs', 'jobs', 'seo_scans' ) as $key ) {
            if ( empty( $tables[ $key ] ) ) continue;
            $queue[ $key ] = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$tables[$key]}" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        }
        return array(
            'plugin_version' => K20AI_PRESS_VERSION,
            'db_version' => K20AI_Database::DB_VERSION,
            'wordpress' => (string) $wp_version,
            'php' => PHP_VERSION,
            'woocommerce' => defined( 'WC_VERSION' ) ? WC_VERSION : null,
            'site_url_hash' => hash( 'sha256', strtolower( home_url() ) ),
            'abilities' => count( $registry->visible() ),
            'mode' => $services->settings()['mode'],
            'queue_counts' => $queue,
            'cron' => array( 'recovery' => (bool) wp_next_scheduled( 'k20ai_recovery_tick' ), 'hourly' => (bool) wp_next_scheduled( 'k20ai_v3_hourly_tick' ), 'daily' => (bool) wp_next_scheduled( 'k20ai_v3_daily_tick' ), 'privacy' => (bool) wp_next_scheduled( 'k20ai_privacy_cleanup' ), 'license_sync' => (bool) wp_next_scheduled( 'k20ai_license_sync' ) ),
            'license' => $this->status(),
            'object_cache' => array( 'persistent' => function_exists( 'wp_using_ext_object_cache' ) && wp_using_ext_object_cache() ),
            'visibility_auto_collect' => ! empty( $services->settings()['visibility_auto_collect'] ),
            'yoast' => array( 'core' => defined( 'WPSEO_VERSION' ) ? WPSEO_VERSION : null, 'premium' => defined( 'WPSEO_PREMIUM_VERSION' ) ? WPSEO_PREMIUM_VERSION : null ),
            'logging_enabled' => ! empty( $services->settings()['diagnostic_logging_enabled'] ),
            'generated_at' => current_time( DATE_ATOM, true ),
        );
    }

    private function configured(): bool {
        return defined( 'K20AI_LICENSE_API_URL' ) && defined( 'K20AI_LICENSE_PUBLIC_KEY' ) && '' !== trim( (string) K20AI_LICENSE_API_URL ) && '' !== trim( (string) K20AI_LICENSE_PUBLIC_KEY ) && wp_http_validate_url( (string) K20AI_LICENSE_API_URL );
    }

    private function not_configured(): WP_Error { return new WP_Error( 'license_not_configured', __( 'Commercial license service is not configured for this build.', 'k20-ai-press' ), array( 'status' => 501 ) ); }
    /** @return array<string,mixed> */ private function state(): array { $state = get_option( self::OPTION, array() ); return is_array( $state ) ? $state : array(); }
    private function license_key( array $state ): string { if ( empty( $state['license_key'] ) ) return ''; $plain = K20AI_Crypto::decrypt_string( (string) $state['license_key'], 'commercial-license' ); return is_wp_error( $plain ) ? '' : trim( (string) $plain ); }

    /** @return array<string,mixed>|WP_Error */
    private function request( string $path, array $payload ): array|WP_Error {
        $base = trailingslashit( (string) K20AI_LICENSE_API_URL );
        $url = $base . ltrim( $path, '/' );
        if ( ! wp_http_validate_url( $url ) || 'https' !== strtolower( (string) wp_parse_url( $url, PHP_URL_SCHEME ) ) ) return new WP_Error( 'unsafe_license_url', __( 'License endpoint must be a valid HTTPS URL.', 'k20-ai-press' ), array( 'status' => 500 ) );
        $response = wp_safe_remote_post( $url, array( 'timeout' => 12, 'redirection' => 0, 'reject_unsafe_urls' => true, 'headers' => array( 'Content-Type' => 'application/json', 'Accept' => 'application/json' ), 'body' => wp_json_encode( $payload ) ) );
        if ( is_wp_error( $response ) ) return $response;
        $code = (int) wp_remote_retrieve_response_code( $response );
        $decoded = json_decode( (string) wp_remote_retrieve_body( $response ), true );
        if ( $code < 200 || $code >= 300 || ! is_array( $decoded ) ) return new WP_Error( 'license_service_error', __( 'License service returned an invalid response.', 'k20-ai-press' ), array( 'status' => 502, 'http_status' => $code ) );
        return $decoded;
    }

    /** @return array<string,mixed>|WP_Error */
    private function verify_signed_response( array $response ): array|WP_Error {
        $payload_b64 = (string) ( $response['payload_b64'] ?? '' );
        $signature = (string) ( $response['signature'] ?? '' );
        if ( '' === $payload_b64 || '' === $signature || ! function_exists( 'sodium_crypto_sign_verify_detached' ) ) return new WP_Error( 'license_signature_missing', __( 'A raw signed license payload is required.', 'k20-ai-press' ), array( 'status' => 502 ) );
        $public = base64_decode( (string) K20AI_LICENSE_PUBLIC_KEY, true );
        $sig = base64_decode( $signature, true );
        $message = base64_decode( $payload_b64, true );
        if ( false === $public || false === $sig || false === $message || SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES !== strlen( $public ) || SODIUM_CRYPTO_SIGN_BYTES !== strlen( $sig ) || strlen( $message ) > 262144 ) return new WP_Error( 'license_signature_invalid', __( 'License signature encoding is invalid.', 'k20-ai-press' ), array( 'status' => 502 ) );
        if ( ! sodium_crypto_sign_verify_detached( $sig, $message, $public ) ) return new WP_Error( 'license_signature_invalid', __( 'License signature verification failed.', 'k20-ai-press' ), array( 'status' => 502 ) );
        $payload = json_decode( $message, true );
        if ( ! is_array( $payload ) ) return new WP_Error( 'license_payload_invalid', __( 'Signed license payload is not valid JSON.', 'k20-ai-press' ), array( 'status' => 502 ) );
        return K20AI_Logger::sanitize_context( $payload );
    }

    private function cache_manifest( array $manifest ): void {
        $package = esc_url_raw( (string) ( $manifest['package'] ?? '' ) );
        $version = trim( (string) ( $manifest['version'] ?? '' ) );
        if ( '' === $package || ! wp_http_validate_url( $package ) || 'https' !== strtolower( (string) wp_parse_url( $package, PHP_URL_SCHEME ) ) ) return;
        if ( ! preg_match( '/^\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?$/D', $version ) ) return;
        $manifest['package'] = $package;
        $manifest['version'] = $version;
        $manifest['requires_php'] = sanitize_text_field( (string) ( $manifest['requires_php'] ?? '8.3' ) );
        $manifest['tested'] = sanitize_text_field( (string) ( $manifest['tested'] ?? '7.1' ) );
        set_site_transient( self::MANIFEST_TRANSIENT, K20AI_Logger::sanitize_context( $manifest ), 12 * HOUR_IN_SECONDS );
    }
}
