<?php

defined( 'ABSPATH' ) || exit;

/** Product/catalog truth, enrichment and commerce-domain helpers. */
trait K20AI_Services_Product_Trait {
    public function product_summary(): array {
        $empty = array(
            'count' => 0,
            'sample_count' => 0,
            'score' => null,
            'missing' => array(),
            'missing_labels' => array(),
            'needs_completion_count' => 0,
            'items' => array(),
            'coverage' => array(),
            'field_stats' => array(),
            'variant_health' => null,
            'variants' => array(),
            'schema_readiness' => null,
            'feed_readiness' => null,
            'recent_changes' => array(),
        );
        if ( ! function_exists( 'wc_get_products' ) ) {
            return $empty;
        }

        $limit = 200;
        $items = wc_get_products(
            array(
                'limit'  => $limit,
                'status' => array( 'publish', 'draft', 'private' ),
                'return' => 'objects',
            )
        );
        if ( ! is_array( $items ) ) {
            $items = array();
        }

        $counts = function_exists( 'wp_count_posts' ) ? wp_count_posts( 'product' ) : null;
        $total_count = 0;
        if ( is_object( $counts ) ) {
            foreach ( array( 'publish', 'draft', 'private' ) as $status ) {
                $total_count += (int) ( $counts->{$status} ?? 0 );
            }
        }
        if ( $total_count <= 0 ) {
            $total_count = count( $items );
        }

        $labels = array(
            'name'          => 'نام محصول',
            'sku'           => 'SKU',
            'gtin'          => 'GTIN',
            'mpn'           => 'MPN',
            'brand'         => 'برند',
            'model'         => 'مدل',
            'category'      => 'دسته‌بندی',
            'attributes'    => 'ویژگی‌ها',
            'dimensions'    => 'ابعاد یا وزن',
            'images'        => 'تصاویر',
            'image_alt'     => 'ALT تصاویر',
            'price'         => 'قیمت',
            'stock'         => 'وضعیت موجودی',
            'identifier'    => 'GTIN یا MPN',
        );
        $tracked = array( 'name', 'sku', 'gtin', 'mpn', 'brand', 'model', 'category', 'attributes', 'dimensions', 'images', 'image_alt', 'price', 'stock' );
        $field_counts = array_fill_keys( $tracked, 0 );
        $missing_counts = array();
        $out = array();
        $needs_completion_count = 0;
        $core_filled = 0;
        $core_total = 0;
        $evidence_supported = 0;
        $variant_total = 0;
        $variant_ready = 0;
        $variant_rows = array();
        global $wpdb;
        $tables = K20AI_Database::tables();

        $group_defs = array(
            'identity'   => array( 'label' => 'اطلاعات هویتی', 'fields' => array( 'name', 'sku', 'brand' ) ),
            'core'       => array( 'label' => 'مشخصات اصلی', 'fields' => array( 'attributes', 'dimensions' ) ),
            'attributes' => array( 'label' => 'ویژگی‌های محصول', 'fields' => array( 'attributes' ) ),
            'media'      => array( 'label' => 'تصاویر و مدیا', 'fields' => array( 'images', 'image_alt' ) ),
            'commerce'   => array( 'label' => 'قیمت و موجودی', 'fields' => array( 'price', 'stock' ) ),
            'taxonomy'   => array( 'label' => 'دسته‌بندی و برند', 'fields' => array( 'category', 'brand' ) ),
        );
        $group_counts = array();
        foreach ( $group_defs as $key => $group ) {
            $group_counts[ $key ] = array( 'filled' => 0, 'total' => 0 );
        }
        $schema_filled = 0;
        $schema_total = 0;
        $feed_filled = 0;
        $feed_total = 0;

        foreach ( $items as $product ) {
            if ( ! is_object( $product ) || ! method_exists( $product, 'get_id' ) ) {
                continue;
            }
            $id = (int) $product->get_id();
            $image_ids = array_values( array_filter( array_map( 'absint', array_merge( array( $product->get_image_id() ), $product->get_gallery_image_ids() ) ) ) );
            $all_alt = ! empty( $image_ids );
            foreach ( $image_ids as $image_id ) {
                if ( '' === trim( (string) get_post_meta( $image_id, '_wp_attachment_image_alt', true ) ) ) {
                    $all_alt = false;
                    break;
                }
            }
            $brand = $this->first_term_name( $id, array( 'product_brand', 'pwb-brand' ) );
            if ( ! $brand ) {
                $brand = $this->first_meta( $id, array( '_brand', 'brand', '_manufacturer' ) ) ?: null;
            }
            $gtin = method_exists( $product, 'get_global_unique_id' )
                ? ( $product->get_global_unique_id() ?: null )
                : ( $this->first_meta( $id, array( '_global_unique_id', '_gtin', 'gtin' ) ) ?: null );
            $mpn = $this->first_meta( $id, array( '_mpn', 'mpn', '_manufacturer_part_number' ) ) ?: null;
            $model = $this->first_meta( $id, array( '_model', 'model' ) ) ?: null;
            $categories = wp_get_post_terms( $id, 'product_cat', array( 'fields' => 'ids' ) );
            if ( is_wp_error( $categories ) ) {
                $categories = array();
            }
            $attributes = $product->get_attributes();
            $has_dimensions = '' !== (string) $product->get_weight()
                || '' !== (string) $product->get_length()
                || '' !== (string) $product->get_width()
                || '' !== (string) $product->get_height();
            $field_values = array(
                'name'       => '' !== trim( (string) $product->get_name() ),
                'sku'        => '' !== trim( (string) $product->get_sku() ),
                'gtin'       => null !== K20AI_Data_Integrity::normalize_gtin( $gtin ),
                'mpn'        => null !== $mpn && '' !== trim( (string) $mpn ),
                'brand'      => null !== $brand && '' !== trim( (string) $brand ),
                'model'      => null !== $model && '' !== trim( (string) $model ),
                'category'   => ! empty( $categories ),
                'attributes' => is_array( $attributes ) && ! empty( $attributes ),
                'dimensions' => $has_dimensions,
                'images'     => ! empty( $image_ids ),
                'image_alt'  => $all_alt,
                'price'      => '' !== (string) $product->get_price(),
                'stock'      => '' !== (string) $product->get_stock_status(),
            );

            foreach ( $tracked as $field ) {
                if ( ! empty( $field_values[ $field ] ) ) {
                    ++$field_counts[ $field ];
                }
            }
            foreach ( $group_defs as $key => $group ) {
                foreach ( $group['fields'] as $field ) {
                    ++$group_counts[ $key ]['total'];
                    if ( ! empty( $field_values[ $field ] ) ) {
                        ++$group_counts[ $key ]['filled'];
                    }
                }
            }

            foreach ( array( 'name', 'sku', 'brand', 'category', 'attributes', 'images', 'price', 'stock', 'dimensions' ) as $field ) {
                ++$core_total;
                if ( ! empty( $field_values[ $field ] ) ) {
                    ++$core_filled;
                }
            }

            $identifier_ok = ! empty( $field_values['gtin'] ) || ! empty( $field_values['mpn'] );
            $product_claim_count = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$tables['claims']} WHERE subject = %s AND status IN ('VERIFIED','PARTIAL')", 'post:' . $id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            if ( $product_claim_count > 0 ) {
                ++$evidence_supported;
            }
            foreach ( array( $field_values['name'], $field_values['images'], $field_values['price'], $field_values['stock'], $field_values['brand'], $identifier_ok ) as $ok ) {
                ++$schema_total;
                if ( $ok ) { ++$schema_filled; }
            }
            foreach ( array( $field_values['name'], $field_values['images'], $field_values['price'], $field_values['stock'], ( $field_values['brand'] || $identifier_ok ) ) as $ok ) {
                ++$feed_total;
                if ( $ok ) { ++$feed_filled; }
            }

            $row_missing = array();
            foreach ( array( 'name', 'sku', 'brand', 'model', 'category', 'attributes', 'dimensions', 'images', 'image_alt', 'price', 'stock' ) as $field ) {
                if ( empty( $field_values[ $field ] ) ) {
                    $row_missing[] = $field;
                    $missing_counts[ $field ] = ( $missing_counts[ $field ] ?? 0 ) + 1;
                }
            }
            if ( ! $identifier_ok ) {
                $row_missing[] = 'identifier';
                $missing_counts['identifier'] = ( $missing_counts['identifier'] ?? 0 ) + 1;
            }
            if ( $row_missing ) {
                ++$needs_completion_count;
            }

            if ( method_exists( $product, 'is_type' ) && $product->is_type( 'variable' ) && method_exists( $product, 'get_children' ) ) {
                $children = array_map( 'absint', (array) $product->get_children() );
                $ready = 0;
                foreach ( $children as $child_id ) {
                    $child = wc_get_product( $child_id );
                    if ( $child && '' !== (string) $child->get_price() && '' !== (string) $child->get_stock_status() ) {
                        ++$ready;
                    }
                }
                $variant_total += count( $children );
                $variant_ready += $ready;
                $variant_rows[] = array(
                    'product_id' => $id,
                    'name'       => $product->get_name(),
                    'total'      => count( $children ),
                    'ready'      => $ready,
                    'health'     => count( $children ) ? (int) round( 100 * $ready / count( $children ) ) : null,
                );
            }

            $out[] = array(
                'id'             => $id,
                'name'           => $product->get_name(),
                'sku'            => $product->get_sku(),
                'stock'          => $product->get_stock_status(),
                'price'          => $product->get_price(),
                'missing'        => $row_missing,
                'missing_labels' => array_values( array_map( static fn( $key ) => $labels[ $key ] ?? $key, $row_missing ) ),
                'missing_count'  => count( $row_missing ),
                'stable_id'      => 'wc-' . $id,
            );
        }

        usort(
            $out,
            static function( array $a, array $b ): int {
                $cmp = (int) ( $b['missing_count'] ?? 0 ) <=> (int) ( $a['missing_count'] ?? 0 );
                return 0 !== $cmp ? $cmp : strnatcasecmp( (string) ( $a['name'] ?? '' ), (string) ( $b['name'] ?? '' ) );
            }
        );

        $sample_count = count( $items );
        $field_stats = array();
        foreach ( $tracked as $field ) {
            $field_stats[ $field ] = array(
                'label'    => $labels[ $field ] ?? $field,
                'filled'   => (int) ( $field_counts[ $field ] ?? 0 ),
                'total'    => $sample_count,
                'coverage' => $sample_count ? (int) round( 100 * (int) ( $field_counts[ $field ] ?? 0 ) / $sample_count ) : null,
            );
        }
        $coverage = array();
        foreach ( $group_defs as $key => $group ) {
            $total = (int) $group_counts[ $key ]['total'];
            $coverage[ $key ] = array(
                'label' => $group['label'],
                'value' => $total ? (int) round( 100 * (int) $group_counts[ $key ]['filled'] / $total ) : null,
            );
        }
        $schema_readiness = $schema_total ? (int) round( 100 * $schema_filled / $schema_total ) : null;
        $feed_readiness = $feed_total ? (int) round( 100 * $feed_filled / $feed_total ) : null;
        $coverage['schema'] = array( 'label' => 'اسکیما و شناسه‌ها', 'value' => $schema_readiness );
        $coverage['feed'] = array( 'label' => 'آمادگی فید فروش', 'value' => $feed_readiness );

        $recent_changes = array();
        $recent_ids = get_posts(
            array(
                'post_type'      => 'product',
                'post_status'    => array( 'publish', 'draft', 'private' ),
                'posts_per_page' => 8,
                'orderby'        => 'modified',
                'order'          => 'DESC',
                'fields'         => 'ids',
            )
        );
        foreach ( is_array( $recent_ids ) ? $recent_ids : array() as $recent_id ) {
            $recent_product = wc_get_product( absint( $recent_id ) );
            if ( ! $recent_product ) { continue; }
            $recent_changes[] = array(
                'id'         => (int) $recent_product->get_id(),
                'name'       => (string) $recent_product->get_name(),
                'status'     => (string) $recent_product->get_status(),
                'modified_at'=> (string) get_post_modified_time( 'Y-m-d H:i:s', false, $recent_product->get_id() ),
            );
        }

        return array(
            'count'                  => $total_count,
            'sample_count'           => $sample_count,
            'score'                  => $core_total ? (int) round( 100 * $core_filled / $core_total ) : null,
            'missing'                => $missing_counts,
            'missing_labels'         => $labels,
            'needs_completion_count' => $needs_completion_count,
            'items'                  => $out,
            'coverage'               => $coverage,
            'field_stats'            => $field_stats,
            'variant_health'         => $variant_total ? (int) round( 100 * $variant_ready / $variant_total ) : null,
            'variants'               => array_slice( $variant_rows, 0, 24 ),
            'schema_readiness'       => $schema_readiness,
            'feed_readiness'         => $feed_readiness,
            'evidence_coverage'      => $sample_count ? (int) round( 100 * $evidence_supported / $sample_count ) : null,
            'recent_changes'         => array_slice( $recent_changes, 0, 12 ),
        );
    }

    private function supplier_import_preview(): array {
        global $wpdb;
        $t = K20AI_Database::tables();
        $rows = $wpdb->get_results(
            "SELECT id,supplier_id,submission_type,product_ref,status,created_at FROM {$t['supplier_submissions']} ORDER BY id DESC LIMIT 20",
            ARRAY_A
        ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $status_counts = $this->status_counts( $t['supplier_submissions'], 'status' );
        $provider_route = $this->advanced->provider_route( 'classification' );
        $provider_matrix = $this->advanced->provider_matrix();
        return array(
            'source'                      => 'internal_supplier_submissions',
            'internal_source_connected'   => true,
            'external_provider_connected' => 'READY' === (string) ( $provider_route['status'] ?? '' ),
            'provider_route'              => $provider_route,
            'provider_matrix'             => $provider_matrix,
            'total'                       => array_sum( $status_counts ),
            'status_counts'               => $status_counts,
            'latest'                      => is_array( $rows ) ? $rows : array(),
            'note'                        => 'خواندن داده‌های تأمین‌کنندگان از ثبت‌های داخلی همین سایت فعال است. Provider هوشمند فقط در صورت کشف Route آماده نمایش داده می‌شود و برای مشاهده این گزارش الزامی نیست.',
        );
    }

    private function product_enrichment_backlog(): array {
        $summary = $this->product_summary();
        return array(
            'catalog_count'          => (int) ( $summary['count'] ?? 0 ),
            'sample_count'           => (int) ( $summary['sample_count'] ?? 0 ),
            'needs_completion_count' => (int) ( $summary['needs_completion_count'] ?? 0 ),
            'completeness_score'     => $summary['score'] ?? null,
            'missing_fields'         => $summary['missing'] ?? array(),
            'products'               => $summary['items'] ?? array(),
        );
    }

    /** @return array<string,mixed> */
    private function evidence_workspace_snapshot(): array {
        global $wpdb;
        $t = K20AI_Database::tables();

        $library_rows = $wpdb->get_results(
            "SELECT e.id,e.title,e.source_type,e.status,e.valid_until,e.updated_at,c.subject,c.status AS claim_status,c.predicate
             FROM {$t['evidence']} e
             LEFT JOIN {$t['claims']} c ON c.id = e.claim_id
             ORDER BY e.updated_at DESC, e.id DESC
             LIMIT 12",
            ARRAY_A
        ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

        $queue_rows = $wpdb->get_results(
            "SELECT id,subject,predicate,status,updated_at,valid_until
             FROM {$t['claims']}
             WHERE status IN ('UNKNOWN','CONFLICTING','PARTIAL')
             ORDER BY updated_at DESC, id DESC
             LIMIT 12",
            ARRAY_A
        ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

        $type_rows = $wpdb->get_results(
            "SELECT source_type, COUNT(*) total FROM {$t['evidence']} GROUP BY source_type ORDER BY total DESC",
            ARRAY_A
        ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

        $link_rows = $wpdb->get_results(
            "SELECT c.subject, COUNT(*) total
             FROM {$t['claims']} c
             INNER JOIN {$t['evidence']} e ON e.claim_id = c.id
             GROUP BY c.subject
             ORDER BY total DESC
             LIMIT 6",
            ARRAY_A
        ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

        $library = array();
        foreach ( is_array( $library_rows ) ? $library_rows : array() as $row ) {
            $library[] = array(
                'id'           => (int) ( $row['id'] ?? 0 ),
                'title'        => (string) ( $row['title'] ?: ( $row['predicate'] ?: 'بدون عنوان' ) ),
                'source_type'  => (string) ( $row['source_type'] ?: 'unknown' ),
                'status'       => (string) ( $row['status'] ?: 'UNKNOWN' ),
                'claim_status' => (string) ( $row['claim_status'] ?: 'UNKNOWN' ),
                'subject'      => (string) ( $row['subject'] ?: '' ),
                'updated_at'   => (string) ( $row['updated_at'] ?: '' ),
                'valid_until'  => (string) ( $row['valid_until'] ?: '' ),
            );
        }

        $queue = array();
        foreach ( is_array( $queue_rows ) ? $queue_rows : array() as $row ) {
            $queue[] = array(
                'id'         => (int) ( $row['id'] ?? 0 ),
                'subject'    => (string) ( $row['subject'] ?: '' ),
                'predicate'  => (string) ( $row['predicate'] ?: '' ),
                'status'     => (string) ( $row['status'] ?: 'UNKNOWN' ),
                'updated_at' => (string) ( $row['updated_at'] ?: '' ),
                'valid_until'=> (string) ( $row['valid_until'] ?: '' ),
            );
        }

        $source_types = array();
        foreach ( is_array( $type_rows ) ? $type_rows : array() as $row ) {
            $source_types[] = array(
                'label' => (string) ( $row['source_type'] ?: 'unknown' ),
                'count' => (int) ( $row['total'] ?? 0 ),
            );
        }

        $provenance = array();
        foreach ( is_array( $link_rows ) ? $link_rows : array() as $row ) {
            $subject = (string) ( $row['subject'] ?? '' );
            $label   = $subject;
            if ( str_starts_with( $subject, 'post:' ) ) {
                $post_id = (int) substr( $subject, 5 );
                $post = get_post( $post_id );
                if ( $post ) {
                    $label = $post->post_title ?: $subject;
                }
            }
            $provenance[] = array(
                'subject' => $subject,
                'label'   => $label,
                'count'   => (int) ( $row['total'] ?? 0 ),
            );
        }

        return array(
            'library'      => $library,
            'queue'        => $queue,
            'source_types' => $source_types,
            'provenance'   => $provenance,
        );
    }

    private function compatibility_score(): ?int {
        global $wpdb;
        $t = K20AI_Database::tables();
        $all = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t['compat_rules']}" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        if ( 0 === $all ) {
            return null;
        }
        $active = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t['compat_rules']} WHERE status = 'VERIFIED'" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        return (int) round( 100 * $active / $all );
    }

    private function rag_score(): ?int {
        global $wpdb;
        $t = K20AI_Database::tables();
        $all = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t['vectors_meta']}" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        if ( 0 === $all ) {
            return null;
        }
        $ok = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t['vectors_meta']} WHERE status = 'INDEXED'" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        return (int) round( 100 * $ok / $all );
    }

    private function commerce_score( array $feed_health ): ?int {
        $channels = isset( $feed_health['channels'] ) && is_array( $feed_health['channels'] ) ? $feed_health['channels'] : array();
        if ( ! $channels ) {
            return null;
        }
        $scores = array();
        foreach ( $channels as $channel ) {
            $items = max( 0, (int) ( $channel['item_count'] ?? 0 ) );
            $errors = max( 0, (int) ( $channel['error_count'] ?? 0 ) );
            $total = $items + $errors;
            if ( $total > 0 ) {
                $scores[] = 100 * $items / $total;
            }
        }
        return $scores ? (int) round( array_sum( $scores ) / count( $scores ) ) : null;
    }

    private function reliability_score( array $jobs ): ?int {
        global $wpdb;
        $t = K20AI_Database::tables();
        $latest = $wpdb->get_row( "SELECT pass_rate,result FROM {$t['eval_runs']} ORDER BY id DESC LIMIT 1", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        if ( ! is_array( $latest ) || ! isset( $latest['pass_rate'] ) ) {
            return null;
        }
        $checks = array(
            (float) $latest['pass_rate'] >= 100.0,
            0 === (int) ( $jobs['DEAD_LETTER'] ?? 0 ),
            0 === (int) ( $jobs['RUNNING'] ?? 0 ),
        );
        return (int) round( 100 * count( array_filter( $checks ) ) / count( $checks ) );
    }

    private function security_score(): ?int {
        $checks = array(
            is_ssl(),
            defined( 'DISALLOW_FILE_EDIT' ) && DISALLOW_FILE_EDIT,
            current_user_can( 'manage_options' ),
            true === $this->settings()['fail_closed'],
        );
        return (int) round( 100 * count( array_filter( $checks ) ) / count( $checks ) );
    }

    private function brand_taxonomy(): string {
        foreach ( array( 'product_brand', 'pwb-brand' ) as $taxonomy ) {
            if ( taxonomy_exists( $taxonomy ) ) {
                return $taxonomy;
            }
        }
        return '';
    }

    private function normalize_string_list( mixed $value ): array {
        if ( is_array( $value ) ) {
            $items = $value;
        } else {
            $items = preg_split( '/[
,،|]+/u', (string) $value ) ?: array();
        }
        $out = array();
        foreach ( $items as $item ) {
            $item = trim( (string) $item );
            if ( '' !== $item ) {
                $out[] = $item;
            }
        }
        return array_values( array_unique( $out ) );
    }

    private function set_brand_value( int $product_id, string $brand ): void {
        $brand = trim( $brand );
        if ( '' === $brand ) {
            return;
        }
        $taxonomy = $this->brand_taxonomy();
        if ( '' !== $taxonomy ) {
            wp_set_post_terms( $product_id, array( $brand ), $taxonomy, false );
        }
        update_post_meta( $product_id, '_brand', $brand );
        update_post_meta( $product_id, 'brand', $brand );
    }


    private function taxonomy_term_options( string $taxonomy, int $limit = 250 ): array {
        if ( '' === $taxonomy || ! taxonomy_exists( $taxonomy ) ) {
            return array();
        }
        $terms = get_terms(
            array(
                'taxonomy'   => $taxonomy,
                'hide_empty' => false,
                'number'     => $limit,
                'orderby'    => 'name',
                'order'      => 'ASC',
            )
        );
        if ( is_wp_error( $terms ) || ! is_array( $terms ) ) {
            return array();
        }
        $out = array();
        foreach ( $terms as $term ) {
            if ( ! $term instanceof WP_Term ) {
                continue;
            }
            $out[] = array(
                'id'    => (int) $term->term_id,
                'name'  => (string) $term->name,
                'slug'  => (string) $term->slug,
                'count' => (int) $term->count,
            );
        }
        return $out;
    }

    private function flattened_product_attribute_values( WC_Product $product ): array {
        $values = array();
        foreach ( (array) $product->get_attributes() as $attribute ) {
            if ( ! $attribute instanceof WC_Product_Attribute ) {
                continue;
            }
            if ( $attribute->is_taxonomy() ) {
                $term_names = wc_get_product_terms( $product->get_id(), $attribute->get_name(), array( 'fields' => 'names' ) );
                if ( is_array( $term_names ) ) {
                    foreach ( $term_names as $term_name ) {
                        $term_name = trim( (string) $term_name );
                        if ( '' !== $term_name ) {
                            $values[] = $term_name;
                        }
                    }
                }
            } else {
                foreach ( (array) $attribute->get_options() as $option ) {
                    $option = trim( (string) $option );
                    if ( '' !== $option ) {
                        $values[] = $option;
                    }
                }
            }
        }
        return array_values( array_unique( $values ) );
    }

    private function attribute_value_options( WC_Product $product ): array {
        $values = $this->flattened_product_attribute_values( $product );
        if ( function_exists( 'wc_get_attribute_taxonomies' ) ) {
            foreach ( (array) wc_get_attribute_taxonomies() as $attribute_taxonomy ) {
                if ( empty( $attribute_taxonomy->attribute_name ) ) {
                    continue;
                }
                $taxonomy = wc_attribute_taxonomy_name( (string) $attribute_taxonomy->attribute_name );
                if ( ! taxonomy_exists( $taxonomy ) ) {
                    continue;
                }
                $terms = get_terms(
                    array(
                        'taxonomy'   => $taxonomy,
                        'hide_empty' => false,
                        'number'     => 0,
                        'orderby'    => 'name',
                        'order'      => 'ASC',
                    )
                );
                if ( is_wp_error( $terms ) || ! is_array( $terms ) ) {
                    continue;
                }
                foreach ( $terms as $term ) {
                    if ( ! $term instanceof WP_Term ) {
                        continue;
                    }
                    $term_name = trim( (string) $term->name );
                    if ( '' !== $term_name ) {
                        $values[] = $term_name;
                    }
                }
            }
        }
        natcasesort( $values );
        $values = array_values( array_unique( array_filter( array_map( 'trim', $values ) ) ) );
        return array_map(
            static fn( string $value ): array => array(
                'value' => $value,
                'label' => $value,
            ),
            $values
        );
    }

    private function product_media_items( WC_Product $product ): array {
        $image_ids = array_values( array_unique( array_filter( array_merge( array( $product->get_image_id() ), $product->get_gallery_image_ids() ) ) ) );
        $items = array();
        foreach ( $image_ids as $index => $image_id ) {
            $image_id = absint( $image_id );
            if ( $image_id <= 0 ) {
                continue;
            }
            $alt = trim( (string) get_post_meta( $image_id, '_wp_attachment_image_alt', true ) );
            $items[] = array(
                'id'          => $image_id,
                'position'    => $index,
                'title'       => (string) get_the_title( $image_id ),
                'url'         => (string) wp_get_attachment_image_url( $image_id, 'medium' ),
                'full_url'    => (string) wp_get_attachment_image_url( $image_id, 'full' ),
                'alt'         => $alt,
                'missing_alt' => '' === $alt,
            );
        }
        return array(
            'has_images'        => ! empty( $items ),
            'featured_image_id' => absint( $product->get_image_id() ),
            'items'             => $items,
            'missing_alt_count' => count( array_filter( $items, static fn( array $item ): bool => ! empty( $item['missing_alt'] ) ) ),
        );
    }

    private function product_option_sets( WC_Product $product ): array {
        return array(
            'stock_status' => array(
                array( 'value' => 'instock', 'label' => 'موجود' ),
                array( 'value' => 'outofstock', 'label' => 'ناموجود' ),
                array( 'value' => 'onbackorder', 'label' => 'پیش‌سفارش / Backorder' ),
            ),
            'categories'       => $this->taxonomy_term_options( 'product_cat' ),
            'brands'           => $this->taxonomy_term_options( $this->brand_taxonomy() ),
            'attribute_values' => $this->attribute_value_options( $product ),
        );
    }

    private function image_alt_text( string $product_name, int $position = 1, int $total = 1 ): string {
        $product_name = trim( $product_name );
        if ( '' === $product_name ) {
            $product_name = 'تصویر محصول';
        }
        return $total > 1 ? sprintf( '%s - تصویر %d', $product_name, $position ) : $product_name;
    }

    private function fill_missing_image_alts( array $image_ids, string $product_name ): int {
        $filled = 0;
        $total = count( $image_ids );
        foreach ( array_values( array_map( 'absint', $image_ids ) ) as $index => $image_id ) {
            if ( $image_id <= 0 ) {
                continue;
            }
            $current = trim( (string) get_post_meta( $image_id, '_wp_attachment_image_alt', true ) );
            if ( '' !== $current ) {
                continue;
            }
            update_post_meta( $image_id, '_wp_attachment_image_alt', $this->image_alt_text( $product_name, $index + 1, $total ) );
            ++$filled;
        }
        return $filled;
    }

    private function build_product_meta( $p ): array {
        $gtin_raw = method_exists( $p, 'get_global_unique_id' ) ? (string) $p->get_global_unique_id() : '';
        if ( '' === trim( $gtin_raw ) ) $gtin_raw = (string) ( $this->first_meta( $p->get_id(), array( '_global_unique_id', '_gtin', 'gtin' ) ) ?: '' );
        $gtin = K20AI_Data_Integrity::normalize_gtin( $gtin_raw );
        return array(
            'name'              => $p->get_name(),
            'product_type'      => $p->get_type(),
            'stable_product_id' => 'wc-' . $p->get_id(),
            'product_id'        => $p->get_id(),
            'variant_id'        => $p->is_type( 'variation' ) ? $p->get_id() : null,
            'sku'               => $p->get_sku() ?: null,
            'gtin'              => $gtin,
            'gtin_raw'          => '' !== trim( $gtin_raw ) ? $gtin_raw : null,
            'gtin_valid'        => null !== $gtin,
            'mpn'               => $this->first_meta( $p->get_id(), array( '_mpn', 'mpn', '_manufacturer_part_number' ) ) ?: null,
            'brand'             => $this->first_term_name( $p->get_id(), array( 'product_brand', 'pwb-brand' ) ) ?: ( $this->first_meta( $p->get_id(), array( '_brand', 'brand', '_manufacturer' ) ) ?: null ),
            'model'             => $this->first_meta( $p->get_id(), array( '_model', 'model' ) ) ?: null,
            'category'          => wp_get_post_terms( $p->get_id(), 'product_cat', array( 'fields' => 'names' ) ),
            'attributes'        => $this->attributes_to_array( $p->get_id(), $p->get_attributes() ),
            'dimensions'        => array( 'length' => $p->get_length(), 'width' => $p->get_width(), 'height' => $p->get_height(), 'weight' => $p->get_weight() ),
            'pressure'          => $this->first_meta( $p->get_id(), array( '_pressure', 'pressure', '_working_pressure' ) ) ?: null,
            'flow'              => $this->first_meta( $p->get_id(), array( '_flow', 'flow', '_flow_rate' ) ) ?: null,
            'material'          => $this->first_meta( $p->get_id(), array( '_material', 'material' ) ) ?: null,
            'compatibility'     => $this->first_meta( $p->get_id(), array( '_compatibility', 'compatibility' ) ) ?: null,
            'packaging'         => $this->first_meta( $p->get_id(), array( '_packaging', 'packaging' ) ) ?: null,
            'shipping_properties'=> array( 'weight' => $p->get_weight(), 'length' => $p->get_length(), 'width' => $p->get_width(), 'height' => $p->get_height(), 'shipping_class_id' => $p->get_shipping_class_id() ),
            'images'            => array_values( array_filter( array_merge( array( $p->get_image_id() ), $p->get_gallery_image_ids() ) ) ),
            'media'             => $this->product_media_items( $p ),
            'options'           => $this->product_option_sets( $p ),
            'price'             => '' !== (string) $p->get_price() ? $p->get_price() : null,
            'stock'             => $p->get_stock_quantity(),
            'availability'      => $p->get_stock_status(),
            'manufacturer'      => $this->first_meta( $p->get_id(), array( '_manufacturer', 'manufacturer' ) ) ?: null,
            'supplier'          => $this->first_meta( $p->get_id(), array( '_supplier', 'supplier' ) ) ?: null,
            'warranty'          => $this->first_meta( $p->get_id(), array( '_warranty', 'warranty' ) ) ?: null,
            'lifecycle_state'   => $p->get_status(),
            'created_at'        => get_post_time( DATE_ATOM, true, $p->get_id() ),
            'updated_at'        => get_post_modified_time( DATE_ATOM, true, $p->get_id() ),
        );
    }

    private function product_completeness( array $meta ): array {
        $product_id = absint( $meta['product_id'] ?? 0 );
        $image_ids = array_values( array_map( 'absint', (array) ( $meta['images'] ?? array() ) ) );
        $all_alt = ! empty( $image_ids );
        $missing_alt_ids = array();
        foreach ( $image_ids as $image_id ) {
            if ( '' === trim( (string) get_post_meta( $image_id, '_wp_attachment_image_alt', true ) ) ) {
                $all_alt = false;
                $missing_alt_ids[] = $image_id;
            }
        }
        $categories = is_wp_error( $meta['category'] ?? null ) ? array() : (array) ( $meta['category'] ?? array() );
        $attributes = (array) ( $meta['attributes'] ?? array() );
        $dimensions = is_array( $meta['dimensions'] ?? null ) ? (array) $meta['dimensions'] : array();
        $has_dimensions = array_filter( array_map( static fn( $v ) => trim( (string) $v ), array( $dimensions['length'] ?? '', $dimensions['width'] ?? '', $dimensions['height'] ?? '', $dimensions['weight'] ?? '' ) ) );
        $gtin_valid = null !== K20AI_Data_Integrity::normalize_gtin( $meta['gtin'] ?? $meta['gtin_raw'] ?? null );
        $identifier_ok = $gtin_valid || '' !== trim( (string) ( $meta['mpn'] ?? '' ) );
        $fields = array(
            'name'       => array( 'label' => 'نام محصول', 'filled' => '' !== trim( (string) ( $meta['name'] ?? '' ) ), 'value' => $meta['name'] ?? null ),
            'sku'        => array( 'label' => 'SKU', 'filled' => '' !== trim( (string) ( $meta['sku'] ?? '' ) ), 'value' => $meta['sku'] ?? null, 'editable' => true ),
            'gtin'       => array( 'label' => 'GTIN', 'filled' => $gtin_valid, 'valid' => $gtin_valid, 'value' => $meta['gtin'] ?? $meta['gtin_raw'] ?? null, 'editable' => true ),
            'mpn'        => array( 'label' => 'MPN', 'filled' => '' !== trim( (string) ( $meta['mpn'] ?? '' ) ), 'value' => $meta['mpn'] ?? null, 'editable' => true ),
            'brand'      => array( 'label' => 'برند', 'filled' => '' !== trim( (string) ( $meta['brand'] ?? '' ) ), 'value' => $meta['brand'] ?? null, 'editable' => true ),
            'model'      => array( 'label' => 'مدل', 'filled' => '' !== trim( (string) ( $meta['model'] ?? '' ) ), 'value' => $meta['model'] ?? null, 'editable' => true ),
            'category'   => array( 'label' => 'دسته‌بندی', 'filled' => ! empty( $categories ), 'value' => $categories, 'editable' => true ),
            'attributes' => array( 'label' => 'ویژگی‌ها', 'filled' => ! empty( $attributes ), 'value' => count( $attributes ) ? array_map( static fn( $attr ) => ( $attr['label'] ?? $attr['key'] ?? 'ویژگی' ) . ': ' . implode( ' | ', (array) ( $attr['values'] ?? array() ) ), $attributes ) : array() ),
            'dimensions' => array( 'label' => 'ابعاد یا وزن', 'filled' => ! empty( $has_dimensions ), 'value' => $dimensions, 'editable' => true ),
            'images'     => array( 'label' => 'تصاویر', 'filled' => ! empty( $image_ids ), 'value' => count( $image_ids ) ),
            'image_alt'  => array( 'label' => 'ALT تصاویر', 'filled' => $all_alt, 'value' => array( 'total_images' => count( $image_ids ), 'missing_alt' => count( $missing_alt_ids ) ), 'editable' => true ),
            'price'      => array( 'label' => 'قیمت', 'filled' => '' !== trim( (string) ( $meta['price'] ?? '' ) ), 'value' => $meta['price'] ?? null, 'editable' => false, 'protected' => true ),
            'stock'      => array( 'label' => 'وضعیت موجودی', 'filled' => '' !== trim( (string) ( $meta['availability'] ?? '' ) ), 'value' => $meta['availability'] ?? null, 'editable' => false, 'protected' => true ),
            'stock_qty'  => array( 'label' => 'موجودی عددی', 'filled' => null !== ( $meta['stock'] ?? null ) && '' !== trim( (string) ( $meta['stock'] ?? '' ) ), 'value' => $meta['stock'] ?? null, 'editable' => false, 'protected' => true ),
            'identifier' => array( 'label' => 'GTIN یا MPN', 'filled' => $identifier_ok, 'value' => $identifier_ok ? 'OK' : null ),
        );
        $groups = array(
            'identity'   => array( 'label' => 'اطلاعات هویتی', 'fields' => array( 'name', 'sku', 'brand' ) ),
            'core'       => array( 'label' => 'مشخصات اصلی', 'fields' => array( 'dimensions', 'model' ) ),
            'attributes' => array( 'label' => 'ویژگی‌های محصول', 'fields' => array( 'attributes' ) ),
            'media'      => array( 'label' => 'تصاویر و مدیا', 'fields' => array( 'images', 'image_alt' ) ),
            'commerce'   => array( 'label' => 'قیمت و موجودی', 'fields' => array( 'price', 'stock' ) ),
            'taxonomy'   => array( 'label' => 'دسته‌بندی و برند', 'fields' => array( 'category', 'brand' ) ),
            'schema'     => array( 'label' => 'اسکیما و شناسه‌ها', 'fields' => array( 'name', 'images', 'price', 'stock', 'brand', 'identifier' ) ),
            'feed'       => array( 'label' => 'آمادگی فید فروش', 'fields' => array( 'name', 'images', 'price', 'stock', 'brand' ) ),
        );
        foreach ( $groups as $key => $group ) {
            $filled = 0;
            $missing = array();
            foreach ( $group['fields'] as $field_key ) {
                if ( ! empty( $fields[ $field_key ]['filled'] ) ) {
                    ++$filled;
                } else {
                    $missing[] = $field_key;
                }
            }
            $groups[ $key ]['filled_count'] = $filled;
            $groups[ $key ]['total_count'] = count( $group['fields'] );
            $groups[ $key ]['value'] = count( $group['fields'] ) ? (int) round( 100 * $filled / count( $group['fields'] ) ) : null;
            $groups[ $key ]['missing'] = $missing;
            $groups[ $key ]['missing_labels'] = array_values( array_map( static fn( $field_key ) => $fields[ $field_key ]['label'] ?? $field_key, $missing ) );
        }
        $filled_total = count( array_filter( $fields, static fn( $row ) => ! empty( $row['filled'] ) ) );
        $suggestions = array();
        foreach ( $fields as $field_key => $row ) {
            if ( ! empty( $row['filled'] ) ) {
                continue;
            }
            $suggestions[] = sprintf( 'فیلد «%s» هنوز تکمیل نشده است.', (string) ( $row['label'] ?? $field_key ) );
        }
        return array(
            'score' => count( $fields ) ? (int) round( 100 * $filled_total / count( $fields ) ) : null,
            'fields' => $fields,
            'groups' => $groups,
            'missing_fields' => array_values( array_keys( array_filter( $fields, static fn( $row ) => empty( $row['filled'] ) ) ) ),
            'missing_alt_image_ids' => $missing_alt_ids,
            'suggestions' => $suggestions,
            'editable_fields' => array( 'sku', 'gtin', 'mpn', 'brand', 'model', 'category', 'dimensions', 'image_alt' ),
            'protected_readonly_fields' => array( 'price', 'stock', 'stock_qty' ),
            'product_id' => $product_id,
        );
    }

    private function update_product_fields( int $product_id, array $fields ): array|WP_Error {
        if ( ! function_exists( 'wc_get_product' ) ) {
            return new WP_Error( 'woocommerce_missing', __( 'WooCommerce در دسترس نیست.', 'k20-ai-press' ), array( 'status' => 503 ) );
        }
        $product = wc_get_product( $product_id );
        if ( ! $product ) {
            return new WP_Error( 'product_not_found', __( 'محصول پیدا نشد.', 'k20-ai-press' ), array( 'status' => 404 ) );
        }
        $protected = K20AI_Security::protected_fields_error( $fields );
        if ( is_wp_error( $protected ) ) return $protected;
        $updated = array();
        $post_update = array( 'ID' => $product_id );
        if ( array_key_exists( 'name', $fields ) ) {
            $name = trim( (string) $fields['name'] );
            if ( '' !== $name ) {
                $post_update['post_title'] = $name;
                $updated[] = 'name';
            }
        }
        if ( count( $post_update ) > 1 ) {
            wp_update_post( $post_update );
        }
        if ( array_key_exists( 'sku', $fields ) ) {
            $product->set_sku( trim( (string) $fields['sku'] ) );
            $updated[] = 'sku';
        }
        if ( array_key_exists( 'dimensions', $fields ) && is_array( $fields['dimensions'] ) ) {
            $dims = $fields['dimensions'];
            foreach ( array( 'length', 'width', 'height', 'weight' ) as $dim_key ) {
                if ( array_key_exists( $dim_key, $dims ) ) {
                    $value = trim( (string) $dims[ $dim_key ] );
                    if ( 'weight' === $dim_key ) {
                        $product->set_weight( $value );
                    } else {
                        $setter = 'set_' . $dim_key;
                        if ( method_exists( $product, $setter ) ) {
                            $product->{$setter}( $value );
                        }
                    }
                }
            }
            $updated[] = 'dimensions';
        }
        if ( array_key_exists( 'gtin', $fields ) ) {
            $raw_gtin = trim( (string) $fields['gtin'] );
            $gtin = '' === $raw_gtin ? '' : K20AI_Data_Integrity::normalize_gtin( $raw_gtin );
            if ( '' !== $raw_gtin && null === $gtin ) {
                return new WP_Error( 'invalid_gtin', __( 'GTIN باید 8، 12، 13 یا 14 رقم و دارای رقم کنترل معتبر GS1 باشد.', 'k20-ai-press' ), array( 'status' => 422 ) );
            }
            if ( method_exists( $product, 'set_global_unique_id' ) ) {
                $product->set_global_unique_id( (string) $gtin );
            }
            update_post_meta( $product_id, '_global_unique_id', (string) $gtin );
            update_post_meta( $product_id, '_gtin', (string) $gtin );
            update_post_meta( $product_id, 'gtin', (string) $gtin );
            $updated[] = 'gtin';
        }
        if ( array_key_exists( 'mpn', $fields ) ) {
            $mpn = trim( (string) $fields['mpn'] );
            update_post_meta( $product_id, '_mpn', $mpn );
            update_post_meta( $product_id, 'mpn', $mpn );
            update_post_meta( $product_id, '_manufacturer_part_number', $mpn );
            $updated[] = 'mpn';
        }
        if ( array_key_exists( 'model', $fields ) ) {
            $model = trim( (string) $fields['model'] );
            update_post_meta( $product_id, '_model', $model );
            update_post_meta( $product_id, 'model', $model );
            $updated[] = 'model';
        }
        if ( array_key_exists( 'brand', $fields ) ) {
            $this->set_brand_value( $product_id, (string) $fields['brand'] );
            $updated[] = 'brand';
        }
        if ( array_key_exists( 'category', $fields ) ) {
            $categories = $this->normalize_string_list( $fields['category'] );
            if ( taxonomy_exists( 'product_cat' ) ) {
                wp_set_post_terms( $product_id, $categories, 'product_cat', false );
            }
            $updated[] = 'category';
        }
        if ( array_key_exists( 'attributes', $fields ) && class_exists( 'WC_Product_Attribute' ) ) {
            $attribute_values = $this->normalize_string_list( $fields['attributes'] );
            $existing_attributes = array();
            foreach ( (array) $product->get_attributes() as $attribute ) {
                if ( ! $attribute instanceof WC_Product_Attribute ) {
                    continue;
                }
                $name = (string) $attribute->get_name();
                $label = function_exists( 'wc_attribute_label' ) ? wc_attribute_label( $name ) : $name;
                if ( in_array( $name, array( 'ویژگی‌ها', 'ویژگی ها', 'features' ), true ) || in_array( $label, array( 'ویژگی‌ها', 'ویژگی ها', 'Features' ), true ) ) {
                    continue;
                }
                $existing_attributes[] = $attribute;
            }
            if ( ! empty( $attribute_values ) ) {
                $feature_attribute = new WC_Product_Attribute();
                $feature_attribute->set_name( 'ویژگی‌ها' );
                $feature_attribute->set_options( $attribute_values );
                $feature_attribute->set_position( count( $existing_attributes ) );
                $feature_attribute->set_visible( true );
                $feature_attribute->set_variation( false );
                $existing_attributes[] = $feature_attribute;
            }
            $product->set_attributes( $existing_attributes );
            $updated[] = 'attributes';
        }
        if ( array_key_exists( 'image_alts', $fields ) && is_array( $fields['image_alts'] ) ) {
            foreach ( $fields['image_alts'] as $image_id => $alt_text ) {
                $image_id = absint( $image_id );
                if ( $image_id <= 0 ) {
                    continue;
                }
                update_post_meta( $image_id, '_wp_attachment_image_alt', trim( (string) $alt_text ) );
            }
            $updated[] = 'image_alt';
        }
        if ( array_key_exists( 'image_alt', $fields ) ) {
            $images = array_values( array_filter( array_merge( array( $product->get_image_id() ), $product->get_gallery_image_ids() ) ) );
            $template = trim( (string) $fields['image_alt'] );
            $total = count( $images );
            foreach ( array_values( array_map( 'absint', $images ) ) as $index => $image_id ) {
                if ( $image_id <= 0 ) {
                    continue;
                }
                $text = '' !== $template ? ( $total > 1 ? sprintf( '%s - تصویر %d', $template, $index + 1 ) : $template ) : $this->image_alt_text( (string) $product->get_name(), $index + 1, $total );
                update_post_meta( $image_id, '_wp_attachment_image_alt', $text );
            }
            $updated[] = 'image_alt';
        }
        $product->save();
        clean_post_cache( $product_id );
        $result = $this->product_truth( $product_id );
        if ( is_wp_error( $result ) ) {
            return $result;
        }
        $result['updated_fields'] = array_values( array_unique( $updated ) );
        $result['message'] = $updated ? 'فیلدهای محصول با موفقیت به‌روزرسانی شد.' : 'تغییری برای ذخیره ارسال نشده بود.';
        return $result;
    }

    private function autofix_product( int $product_id, string $scope = 'safe' ): array|WP_Error {
        $truth = $this->product_truth( $product_id );
        if ( is_wp_error( $truth ) ) {
            return $truth;
        }
        $changes = array();
        $image_ids = array_values( array_map( 'absint', (array) ( $truth['images'] ?? array() ) ) );
        // Brand, MPN, model and GTIN are identity data. Never infer them from
        // a title or local SKU; unknown identifiers must remain unknown until
        // an authoritative source or a human supplies them.
        $filled_alt = $this->fill_missing_image_alts( $image_ids, (string) ( $truth['name'] ?? '' ) );
        if ( $filled_alt > 0 ) {
            $changes['image_alt'] = sprintf( '%d تصویر', $filled_alt );
        }
        clean_post_cache( $product_id );
        $result = $this->product_truth( $product_id );
        if ( is_wp_error( $result ) ) {
            return $result;
        }
        $result['autofix'] = array(
            'scope' => $scope,
            'applied' => $changes,
            'applied_count' => count( $changes ),
            'note' => $changes ? 'اصلاح خودکار فقط روی داده‌های نمایشی کم‌ریسک انجام شد؛ شناسه و هویت محصول هرگز حدس زده نمی‌شود.' : 'برای این محصول اصلاح خودکار امنی پیدا نشد؛ داده هویتی حدس زده نشد.'
        );
        return $result;
    }

    public function product_truth( int $product_id ): array|WP_Error {
        if ( ! function_exists( 'wc_get_product' ) ) {
            return new WP_Error( 'woocommerce_missing', __( 'WooCommerce در دسترس نیست.', 'k20-ai-press' ), array( 'status' => 503 ) );
        }
        $p = wc_get_product( $product_id );
        if ( ! $p ) {
            return new WP_Error( 'product_not_found', __( 'محصول پیدا نشد.', 'k20-ai-press' ), array( 'status' => 404 ) );
        }
        $meta = $this->build_product_meta( $p );
        $meta['completeness'] = $this->product_completeness( $meta );
        return $meta;
    }
    private function first_meta( int $post_id, array $keys ): string {
        foreach ( $keys as $key ) {
            $value = get_post_meta( $post_id, $key, true );
            if ( is_scalar( $value ) && '' !== trim( (string) $value ) ) {
                return (string) $value;
            }
        }
        return '';
    }

    private function first_term_name( int $post_id, array $taxonomies ): ?string {
        foreach ( $taxonomies as $taxonomy ) {
            if ( taxonomy_exists( $taxonomy ) ) {
                $terms = wp_get_post_terms( $post_id, $taxonomy, array( 'fields' => 'names' ) );
                if ( ! is_wp_error( $terms ) && ! empty( $terms[0] ) ) {
                    return (string) $terms[0];
                }
            }
        }
        return null;
    }

    private function attributes_to_array( int $product_id, array $attributes ): array {
        $out = array();
        foreach ( $attributes as $key => $attribute ) {
            if ( ! is_object( $attribute ) || ! method_exists( $attribute, 'get_options' ) ) {
                continue;
            }
            $name = method_exists( $attribute, 'get_name' ) ? (string) $attribute->get_name() : (string) $key;
            $label = function_exists( 'wc_attribute_label' ) ? (string) wc_attribute_label( $name ) : rawurldecode( (string) $key );
            if ( '' === trim( $label ) ) {
                $label = rawurldecode( (string) $key );
            }
            $values = array();
            if ( method_exists( $attribute, 'is_taxonomy' ) && $attribute->is_taxonomy() && taxonomy_exists( $name ) ) {
                $terms = wp_get_post_terms( $product_id, $name, array( 'fields' => 'names' ) );
                if ( ! is_wp_error( $terms ) ) {
                    $values = array_values( array_map( 'strval', (array) $terms ) );
                }
            }
            if ( ! $values ) {
                foreach ( (array) $attribute->get_options() as $option ) {
                    if ( is_scalar( $option ) ) {
                        $values[] = rawurldecode( (string) $option );
                    }
                }
            }
            $out[] = array(
                'key'    => rawurldecode( (string) $name ),
                'label'  => $label,
                'values' => $values,
            );
        }
        return $out;
    }

}
