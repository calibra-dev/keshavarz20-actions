<?php

defined( 'ABSPATH' ) || exit;

/**
 * Embedded Universal Bridge 3.3 control plane.
 *
 * This is intentionally allow-listed. It exposes high-value WordPress,
 * WooCommerce, SEO, content, media, cache, snapshot and engine operations while
 * refusing credential/user/role/arbitrary-code and price/payment mutations.
 */
final class K20AI_Bridge {
    public const CONTRACT = '3.3';
    public const NAMESPACE = 'k20-ai/v3';

    private K20AI_SEO_OS $seo;
    private K20AI_Connection_Center $connections;
    private K20AI_Content_Engines $engines;

    /** @var array<int,string> */
    private array $actions = array(
        'api.contract', 'system.info', 'rest.proxy',
        'seo.read', 'seo.update',
        'content.search', 'content.patch', 'content.block.inspect', 'content.block.patch',
        'elementor.inspect', 'elementor.search', 'elementor.edit',
        'media.metadata', 'media.hash', 'media.duplicates', 'media.optimize',
        'asset.featured.set', 'asset.gallery.append', 'asset.gallery.replace', 'asset.content.insert',
        'cache.status', 'cache.purge', 'audit.tail', 'batch',
        'snapshot.list', 'snapshot.rollback',
        'observability.status', 'selftest.run',
        'engine.status', 'engine.run', 'gitops.profile',
    );

    /** @var array<int,string> */
    private array $forbidden = array(
        'price', 'regular_price', 'sale_price', 'date_on_sale_from', 'date_on_sale_to',
        'stock', 'stock_status', 'stock_quantity', 'manage_stock',
        'discount', 'coupon', 'payment_method', 'tax_class',
        'password', 'application_password', 'token', 'secret', 'api_key',
        'consumer_key', 'consumer_secret', 'role', 'roles', 'capability', 'capabilities',
        'user_id', 'customer_id', 'billing', 'shipping_address', 'orders', 'author', 'post_author',
        'sql', 'query_sql', 'php', 'command', 'shell', 'code',
    );

    public function __construct( K20AI_SEO_OS $seo, K20AI_Connection_Center $connections, K20AI_Content_Engines $engines ) {
        $this->seo = $seo;
        $this->connections = $connections;
        $this->engines = $engines;
    }

    /** @return array<string,mixed> */
    public function contract(): array {
        return array(
            'ok' => true,
            'bridge' => 'K20 AI Press Universal Bridge',
            'version' => K20AI_PRESS_VERSION,
            'contract' => self::CONTRACT,
            'namespace' => '/' . self::NAMESPACE,
            'execute_endpoint' => '/' . self::NAMESPACE . '/bridge/execute',
            'asset_endpoint' => '/' . self::NAMESPACE . '/bridge/asset',
            'actions' => $this->actions,
            'hard_guards' => array(
                'no price/stock/discount/coupon/payment mutations',
                'no users/roles/capabilities mutations',
                'no credentials/secrets readback',
                'no arbitrary PHP/SQL/shell/filesystem execution',
                'system/Bridge actions require WordPress Administrator capability and are audited',
                'dotted action names are strictly validated and preserved',
            ),
            'authentication' => array( 'wp_rest_cookie_nonce', 'wordpress_application_password' ),
            'features' => array( 'strict_action_validation', 'rate_limit', 'idempotent_request_id', 'expected_sha_write_guard', 'snapshots', 'rollback', 'batch_max_20', 'asset_upload', 'gutenberg_blocks', 'elementor_content', 'media_hash_dedupe_optimize', 'content_engines', 'github_runner' ),
        );
    }

    /** @return array<string,mixed>|WP_Error */
    public function execute( array $request ): array|WP_Error {
        $action = K20AI_Security::normalize_bridge_action( $request['action'] ?? '' );
        if ( '' === $action || ! in_array( $action, $this->actions, true ) ) return new WP_Error( 'bridge_action_not_allowed', __( 'Bridge action is not allow-listed.', 'k20-ai-press' ), array( 'status' => 403 ) );
        $rate = K20AI_Security::bridge_rate_limit( $action, $request );
        if ( is_wp_error( $rate ) ) return $rate;
        $guard = $this->guard_payload( $request );
        if ( is_wp_error( $guard ) ) return $guard;

        $request_id = trim( (string) ( $request['request_id'] ?? '' ) );
        if ( '' !== $request_id && ( strlen( $request_id ) > 128 || ! preg_match( '/^[A-Za-z0-9._:-]+$/D', $request_id ) ) ) {
            return new WP_Error( 'bridge_invalid_request_id', __( 'request_id contains invalid characters.', 'k20-ai-press' ), array( 'status' => 422 ) );
        }
        if ( $this->is_write_action( $action, $request ) && '' === $request_id ) {
            return new WP_Error( 'bridge_request_id_required', __( 'request_id is required for write actions.', 'k20-ai-press' ), array( 'status' => 422 ) );
        }
        if ( '' !== $request_id ) {
            $cache_key = 'k20ai_bridge_' . md5( $request_id );
            $cached = get_transient( $cache_key );
            if ( is_array( $cached ) ) return array_merge( $cached, array( 'idempotent_replay' => true ) );
        }

        $started = microtime( true );
        $result = match ( $action ) {
            'api.contract' => $this->contract(),
            'system.info' => $this->system_info(),
            'rest.proxy' => $this->rest_proxy( $request ),
            'seo.read' => $this->seo_read( $request ),
            'seo.update' => $this->seo_update( $request ),
            'content.search' => $this->content_search( $request ),
            'content.patch' => $this->content_patch( $request ),
            'content.block.inspect' => $this->content_block_inspect( $request ),
            'content.block.patch' => $this->content_block_patch( $request ),
            'elementor.inspect' => $this->elementor_inspect( $request ),
            'elementor.search' => $this->elementor_search( $request ),
            'elementor.edit' => $this->elementor_edit( $request ),
            'media.metadata' => $this->media_metadata( $request ),
            'media.hash' => $this->media_hash( $request ),
            'media.duplicates' => $this->media_duplicates( $request ),
            'media.optimize' => $this->media_optimize( $request ),
            'asset.featured.set' => $this->asset_featured( $request ),
            'asset.gallery.append' => $this->asset_gallery( $request, false ),
            'asset.gallery.replace' => $this->asset_gallery( $request, true ),
            'asset.content.insert' => $this->asset_content_insert( $request ),
            'cache.status' => $this->cache_status(),
            'cache.purge' => $this->cache_purge(),
            'audit.tail' => $this->audit_tail( $request ),
            'batch' => $this->batch( $request ),
            'snapshot.list' => $this->snapshot_list( $request ),
            'snapshot.rollback' => $this->snapshot_rollback( $request ),
            'observability.status' => $this->observability_status(),
            'selftest.run' => $this->selftest(),
            'engine.status' => $this->engine_status( $request ),
            'engine.run' => $this->engine_run( $request ),
            'gitops.profile' => $this->gitops_profile(),
            default => new WP_Error( 'bridge_unhandled_action', __( 'Bridge action has no handler.', 'k20-ai-press' ), array( 'status' => 501 ) ),
        };

        if ( is_wp_error( $result ) ) {
            $this->audit( $action, 'ERROR', array( 'request_id' => $request_id, 'error' => $result->get_error_message() ) );
            return $result;
        }
        $response = array(
            'ok' => true,
            'action' => $action,
            'request_id' => $request_id,
            'contract' => self::CONTRACT,
            'version' => K20AI_PRESS_VERSION,
            'result' => $result,
            'latency_ms' => (int) round( ( microtime( true ) - $started ) * 1000 ),
            'executed_at_utc' => gmdate( DATE_ATOM ),
        );
        if ( '' !== $request_id ) set_transient( $cache_key, $response, 15 * MINUTE_IN_SECONDS );
        $this->audit( $action, 'OK', array( 'request_id' => $request_id, 'latency_ms' => $response['latency_ms'] ) );
        return $response;
    }

    /** @return array<string,mixed>|WP_Error */
    public function upload_asset( array $file, array $params = array() ): array|WP_Error {
        if ( empty( $file['tmp_name'] ) || empty( $file['name'] ) ) return new WP_Error( 'bridge_asset_missing', __( 'Asset file is missing.', 'k20-ai-press' ), array( 'status' => 400 ) );
        $allowed = array( 'image/jpeg', 'image/png', 'image/webp' );
        $check = wp_check_filetype_and_ext( $file['tmp_name'], $file['name'] );
        $mime = (string) ( $check['type'] ?? $file['type'] ?? '' );
        if ( ! in_array( $mime, $allowed, true ) ) return new WP_Error( 'bridge_asset_type', __( 'Only JPEG, PNG and WebP images are accepted.', 'k20-ai-press' ), array( 'status' => 415 ) );
        if ( ! empty( $file['size'] ) && (int) $file['size'] > 20 * MB_IN_BYTES ) return new WP_Error( 'bridge_asset_size', __( 'Asset exceeds the 20 MiB limit.', 'k20-ai-press' ), array( 'status' => 413 ) );
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
        $post_id = absint( $params['post_id'] ?? 0 );
        $upload = wp_handle_sideload( $file, array( 'test_form' => false ) );
        if ( isset( $upload['error'] ) ) return new WP_Error( 'bridge_asset_upload', sanitize_text_field( (string) $upload['error'] ), array( 'status' => 500 ) );
        $attachment_id = wp_insert_attachment( array(
            'post_mime_type' => (string) $upload['type'],
            'post_title' => sanitize_text_field( (string) ( $params['title'] ?? pathinfo( $file['name'], PATHINFO_FILENAME ) ) ),
            'post_content' => '',
            'post_status' => 'inherit',
        ), (string) $upload['file'], $post_id, true );
        if ( is_wp_error( $attachment_id ) ) return $attachment_id;
        $meta = wp_generate_attachment_metadata( $attachment_id, (string) $upload['file'] );
        wp_update_attachment_metadata( $attachment_id, $meta );
        if ( isset( $params['alt_text'] ) ) update_post_meta( $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( (string) $params['alt_text'] ) );
        if ( isset( $params['caption'] ) ) wp_update_post( array( 'ID' => $attachment_id, 'post_excerpt' => sanitize_textarea_field( (string) $params['caption'] ) ) );
        return array( 'attachment_id' => (int) $attachment_id, 'mime' => (string) $upload['type'], 'url' => wp_get_attachment_url( $attachment_id ), 'bytes' => filesize( (string) $upload['file'] ) ?: null );
    }


    private function is_write_action( string $action, array $request = array() ): bool {
        return K20AI_Security::bridge_action_is_write( $action, $request );
    }

    /** @return bool|WP_Error */
    private function guard_payload( $value, string $path = 'request' ) {
        if ( is_array( $value ) ) {
            // WooCommerce and WordPress both accept meta arrays shaped like
            // {key: "_price", value: ...}. Guard the semantic meta key too so
            // restricted fields cannot be reached indirectly through meta_data.
            if ( isset( $value['key'] ) && is_scalar( $value['key'] ) && $this->forbidden_meta_key( (string) $value['key'] ) ) {
                return new WP_Error( 'bridge_forbidden_meta', sprintf( /* translators: %s: metadata path. */ __( 'Forbidden metadata key at %s', 'k20-ai-press' ), $path ), array( 'status' => 403 ) );
            }
            if ( isset( $value['status'] ) && is_scalar( $value['status'] ) && in_array( strtolower( trim( (string) $value['status'] ) ), array( 'trash', 'deleted', 'delete' ), true ) ) {
                return new WP_Error( 'bridge_forbidden_status', __( 'Trash/delete status changes are not exposed by the Bridge.', 'k20-ai-press' ), array( 'status' => 403 ) );
            }
            foreach ( $value as $key => $child ) {
                $name = strtolower( (string) $key );
                if ( in_array( $name, $this->forbidden, true ) ) return new WP_Error( 'bridge_forbidden_key', sprintf( /* translators: %s: bridge key path. */ __( 'Forbidden bridge key at %s', 'k20-ai-press' ), $path . '.' . $name ), array( 'status' => 403 ) );
                $safe = $this->guard_payload( $child, $path . '.' . $name );
                if ( is_wp_error( $safe ) ) return $safe;
            }
        }
        return true;
    }

    private function forbidden_meta_key( string $key ): bool {
        $key = strtolower( trim( $key ) );
        if ( '' === $key ) return false;
        $exact = array(
            '_price', '_regular_price', '_sale_price', '_sale_price_dates_from', '_sale_price_dates_to',
            '_billing_email', '_billing_phone', '_wp_capabilities', 'wp_capabilities', 'wp_user_level',
        );
        if ( in_array( $key, $exact, true ) ) return true;
        foreach ( array( 'password', 'token', 'secret', 'api_key', 'consumer_key', 'consumer_secret', 'capabilit', 'application_password' ) as $needle ) {
            if ( str_contains( $key, $needle ) ) return true;
        }
        return str_starts_with( $key, '_billing_' ) || str_starts_with( $key, '_shipping_' );
    }

    /** @return array<string,mixed> */
    private function system_info(): array {
        $plugins = get_option( 'active_plugins', array() );
        return array(
            'site_url' => home_url(), 'site_name' => get_bloginfo( 'name' ), 'locale' => determine_locale(),
            'wp_version' => get_bloginfo( 'version' ), 'php_version' => PHP_VERSION,
            'woocommerce' => defined( 'WC_VERSION' ) ? WC_VERSION : null,
            'yoast' => defined( 'WPSEO_VERSION' ) ? WPSEO_VERSION : null,
            'active_plugins' => is_array( $plugins ) ? count( $plugins ) : 0,
            'timezone' => wp_timezone_string(),
            'bridge_contract' => self::CONTRACT,
        );
    }

    /** @return array<string,mixed>|WP_Error */
    private function rest_proxy( array $request ): array|WP_Error {
        $method = strtoupper( sanitize_text_field( (string) ( $request['method'] ?? 'GET' ) ) );
        $path = '/' . ltrim( sanitize_text_field( (string) ( $request['path'] ?? '' ) ), '/' );
        if ( ! in_array( $method, array( 'GET', 'POST', 'PUT', 'PATCH' ), true ) ) return new WP_Error( 'bridge_rest_method', __( 'REST method is not allowed.', 'k20-ai-press' ), array( 'status' => 405 ) );

        // GET is intentionally limited to public content/catalog families. Do
        // not proxy users, customers, orders, settings, reports or other private
        // REST collections just because they share the wp/v2 or wc/v3 prefix.
        $read_allowed = (bool) preg_match(
            '#^/(?:wp/v2/(?:posts|pages|media|categories|tags)(?:/[0-9]+)?|wc/v3/products(?:/[0-9]+|/categories(?:/[0-9]+)?|/tags(?:/[0-9]+)?|/attributes(?:/[0-9]+(?:/terms(?:/[0-9]+)?)?)?)?)$#',
            $path
        );
        if ( 'GET' === $method && ! $read_allowed ) return new WP_Error( 'bridge_rest_path', __( 'REST read path is outside the public content/catalog allow-list.', 'k20-ai-press' ), array( 'status' => 403 ) );

        $write_allowed = (bool) preg_match( '#^/(?:wp/v2/(?:posts|pages|media)/[0-9]+|wc/v3/products/[0-9]+)$#', $path );
        if ( 'GET' !== $method && ! $write_allowed ) return new WP_Error( 'bridge_rest_write_path', __( 'REST write path is outside the allow-list.', 'k20-ai-press' ), array( 'status' => 403 ) );

        $payload = isset( $request['payload'] ) && is_array( $request['payload'] ) ? $request['payload'] : array();
        $guard = $this->guard_payload( $payload, 'payload' );
        if ( is_wp_error( $guard ) ) return $guard;
        $wp_request = new WP_REST_Request( $method, $path );
        foreach ( $payload as $key => $value ) $wp_request->set_param( $key, $value );
        $response = rest_do_request( $wp_request );
        $status = $response->get_status();
        if ( $status < 200 || $status >= 300 ) return new WP_Error( 'bridge_rest_upstream', sprintf( /* translators: %d: HTTP status code. */ __( 'Internal REST request failed with HTTP %d', 'k20-ai-press' ), $status ), array( 'status' => $status, 'data' => $response->get_data() ) );
        return array( 'method' => $method, 'path' => $path, 'status' => $status, 'data' => $response->get_data() );
    }

    /** @return array<string,mixed>|WP_Error */
    private function seo_read( array $request ): array|WP_Error {
        $id = absint( $request['id'] ?? 0 );
        if ( ! $id || ! get_post( $id ) ) return new WP_Error( 'bridge_post_missing', __( 'Post not found.', 'k20-ai-press' ), array( 'status' => 404 ) );
        return array(
            'id' => $id,
            'title' => (string) get_post_meta( $id, '_yoast_wpseo_title', true ),
            'description' => (string) get_post_meta( $id, '_yoast_wpseo_metadesc', true ),
            'focus_keyword' => (string) get_post_meta( $id, '_yoast_wpseo_focuskw', true ),
            'canonical' => (string) get_post_meta( $id, '_yoast_wpseo_canonical', true ),
            'noindex' => '1' === (string) get_post_meta( $id, '_yoast_wpseo_meta-robots-noindex', true ),
        );
    }

    /** @return array<string,mixed>|WP_Error */
    private function seo_update( array $request ): array|WP_Error {
        $id = absint( $request['id'] ?? 0 );
        $payload = isset( $request['payload'] ) && is_array( $request['payload'] ) ? $request['payload'] : array();
        if ( ! $id || ! get_post( $id ) ) return new WP_Error( 'bridge_post_missing', __( 'Post not found.', 'k20-ai-press' ), array( 'status' => 404 ) );
        $before = $this->seo_read( array( 'id' => $id ) );
        if ( is_wp_error( $before ) ) return $before;
        $snapshot = $this->snapshot( 'seo.update', 'seo', $id, $before );
        $map = array( 'title' => '_yoast_wpseo_title', 'description' => '_yoast_wpseo_metadesc', 'focus_keyword' => '_yoast_wpseo_focuskw', 'canonical' => '_yoast_wpseo_canonical' );
        foreach ( $map as $key => $meta_key ) if ( array_key_exists( $key, $payload ) ) update_post_meta( $id, $meta_key, sanitize_text_field( (string) $payload[ $key ] ) );
        if ( array_key_exists( 'noindex', $payload ) ) update_post_meta( $id, '_yoast_wpseo_meta-robots-noindex', ! empty( $payload['noindex'] ) ? '1' : '' );
        return array( 'id' => $id, 'snapshot_id' => $snapshot, 'after' => $this->seo_read( array( 'id' => $id ) ) );
    }

    /** @return array<string,mixed>|WP_Error */
    private function content_search( array $request ): array|WP_Error {
        $payload = isset( $request['payload'] ) && is_array( $request['payload'] ) ? $request['payload'] : array();
        $post_id = absint( $payload['post_id'] ?? $request['id'] ?? 0 );
        $field = sanitize_key( (string) ( $payload['field'] ?? 'post_content' ) );
        $pattern = (string) ( $payload['pattern'] ?? '' );
        if ( ! in_array( $field, array( 'post_title', 'post_excerpt', 'post_content' ), true ) || '' === $pattern ) return new WP_Error( 'bridge_content_search_input', __( 'Content search input is invalid.', 'k20-ai-press' ), array( 'status' => 400 ) );
        $post = get_post( $post_id );
        if ( ! $post ) return new WP_Error( 'bridge_post_missing', __( 'Post not found.', 'k20-ai-press' ), array( 'status' => 404 ) );
        $content = (string) $post->{$field};
        return array( 'post_id' => $post_id, 'field' => $field, 'matches' => substr_count( $content, $pattern ), 'sha256' => hash( 'sha256', $content ) );
    }

    /** @return array<string,mixed>|WP_Error */
    private function content_patch( array $request ): array|WP_Error {
        $payload = isset( $request['payload'] ) && is_array( $request['payload'] ) ? $request['payload'] : array();
        $post_id = absint( $payload['post_id'] ?? $request['id'] ?? 0 );
        $field = sanitize_key( (string) ( $payload['field'] ?? 'post_content' ) );
        if ( ! in_array( $field, array( 'post_title', 'post_excerpt', 'post_content' ), true ) ) return new WP_Error( 'bridge_content_field', __( 'Content field is not allow-listed.', 'k20-ai-press' ), array( 'status' => 400 ) );
        $post = get_post( $post_id );
        if ( ! $post ) return new WP_Error( 'bridge_post_missing', __( 'Post not found.', 'k20-ai-press' ), array( 'status' => 404 ) );
        $before = (string) $post->{$field};
        $expected = strtolower( sanitize_text_field( (string) ( $payload['expected_sha256'] ?? '' ) ) );
        if ( $expected && ! hash_equals( hash( 'sha256', $before ), $expected ) ) return new WP_Error( 'bridge_stale_write', __( 'Expected content hash does not match the current value.', 'k20-ai-press' ), array( 'status' => 409 ) );
        $old = (string) ( $payload['old_content'] ?? '' );
        $new = (string) ( $payload['new_content'] ?? '' );
        if ( '' === $old || 1 !== substr_count( $before, $old ) ) return new WP_Error( 'bridge_patch_match', __( 'Patch requires exactly one old-content match.', 'k20-ai-press' ), array( 'status' => 409 ) );
        $after = str_replace( $old, $new, $before, $count );
        if ( 1 !== $count ) return new WP_Error( 'bridge_patch_match', __( 'Patch did not produce exactly one replacement.', 'k20-ai-press' ), array( 'status' => 409 ) );
        $snapshot = $this->snapshot( 'content.patch', 'post_field:' . $field, $post_id, array( 'value' => $before ) );
        $value = 'post_content' === $field ? wp_kses_post( $after ) : ( 'post_excerpt' === $field ? sanitize_textarea_field( $after ) : sanitize_text_field( $after ) );
        $updated = wp_update_post( array( 'ID' => $post_id, $field => $value ), true );
        if ( is_wp_error( $updated ) ) return $updated;
        return array( 'post_id' => $post_id, 'field' => $field, 'changed' => true, 'before_sha256' => hash( 'sha256', $before ), 'after_sha256' => hash( 'sha256', $value ), 'snapshot_id' => $snapshot );
    }

    /** @return array<string,mixed>|WP_Error */
    private function content_block_inspect( array $request ): array|WP_Error {
        $payload = isset( $request['payload'] ) && is_array( $request['payload'] ) ? $request['payload'] : array();
        $post_id = absint( $payload['post_id'] ?? $request['id'] ?? 0 );
        $path = array_values( array_map( 'absint', (array) ( $payload['block_path'] ?? array() ) ) );
        $post = get_post( $post_id );
        if ( ! $post ) return new WP_Error( 'bridge_post_missing', __( 'Post not found.', 'k20-ai-press' ), array( 'status' => 404 ) );
        if ( ! function_exists( 'parse_blocks' ) ) return new WP_Error( 'bridge_blocks_unavailable', __( 'Gutenberg block parser is unavailable.', 'k20-ai-press' ), array( 'status' => 501 ) );
        $blocks = parse_blocks( (string) $post->post_content );
        $block = $this->block_at_path( $blocks, $path );
        if ( is_wp_error( $block ) ) return $block;
        return array(
            'post_id' => $post_id,
            'block_path' => $path,
            'block_name' => (string) ( $block['blockName'] ?? '' ),
            'attrs' => is_array( $block['attrs'] ?? null ) ? $block['attrs'] : array(),
            'inner_html' => (string) ( $block['innerHTML'] ?? '' ),
            'sha256' => hash( 'sha256', (string) $post->post_content ),
        );
    }

    /** @return array<string,mixed>|WP_Error */
    private function content_block_patch( array $request ): array|WP_Error {
        $payload = isset( $request['payload'] ) && is_array( $request['payload'] ) ? $request['payload'] : array();
        $post_id = absint( $payload['post_id'] ?? $request['id'] ?? 0 );
        $path = array_values( array_map( 'absint', (array) ( $payload['block_path'] ?? array() ) ) );
        $post = get_post( $post_id );
        if ( ! $post ) return new WP_Error( 'bridge_post_missing', __( 'Post not found.', 'k20-ai-press' ), array( 'status' => 404 ) );
        if ( ! function_exists( 'parse_blocks' ) || ! function_exists( 'serialize_blocks' ) ) return new WP_Error( 'bridge_blocks_unavailable', __( 'Gutenberg block serializer is unavailable.', 'k20-ai-press' ), array( 'status' => 501 ) );
        $before = (string) $post->post_content;
        $expected = strtolower( sanitize_text_field( (string) ( $payload['expected_sha256'] ?? '' ) ) );
        if ( $expected && ! hash_equals( hash( 'sha256', $before ), $expected ) ) return new WP_Error( 'bridge_stale_write', __( 'Expected content hash does not match the current value.', 'k20-ai-press' ), array( 'status' => 409 ) );
        $old = (string) ( $payload['old_content'] ?? '' );
        $new = (string) ( $payload['new_content'] ?? '' );
        if ( '' === $old ) return new WP_Error( 'bridge_block_patch_input', __( 'old_content is required.', 'k20-ai-press' ), array( 'status' => 400 ) );
        $blocks = parse_blocks( $before );
        $ref = &$this->block_ref_at_path( $blocks, $path );
        if ( ! is_array( $ref ) ) return new WP_Error( 'bridge_block_path', __( 'Block path was not found.', 'k20-ai-press' ), array( 'status' => 404 ) );
        $inner = (string) ( $ref['innerHTML'] ?? '' );
        if ( 1 !== substr_count( $inner, $old ) ) return new WP_Error( 'bridge_patch_match', __( 'Block patch requires exactly one old-content match in the selected block.', 'k20-ai-press' ), array( 'status' => 409 ) );
        $ref['innerHTML'] = str_replace( $old, $new, $inner, $count );
        if ( isset( $ref['innerContent'] ) && is_array( $ref['innerContent'] ) ) {
            foreach ( $ref['innerContent'] as $idx => $piece ) {
                if ( is_string( $piece ) && str_contains( $piece, $old ) ) $ref['innerContent'][ $idx ] = str_replace( $old, $new, $piece );
            }
        }
        $after = serialize_blocks( $blocks );
        $snapshot = $this->snapshot( 'content.block.patch', 'post_field:post_content', $post_id, array( 'value' => $before ) );
        $updated = wp_update_post( array( 'ID' => $post_id, 'post_content' => wp_kses_post( $after ) ), true );
        if ( is_wp_error( $updated ) ) return $updated;
        return array( 'post_id' => $post_id, 'block_path' => $path, 'changed' => true, 'before_sha256' => hash( 'sha256', $before ), 'after_sha256' => hash( 'sha256', (string) get_post_field( 'post_content', $post_id ) ), 'snapshot_id' => $snapshot );
    }

    /** @return array<string,mixed>|WP_Error */
    private function block_at_path( array $blocks, array $path ): array|WP_Error {
        $cursor = $blocks;
        $block = null;
        foreach ( $path as $index ) {
            if ( ! isset( $cursor[ $index ] ) || ! is_array( $cursor[ $index ] ) ) return new WP_Error( 'bridge_block_path', __( 'Block path was not found.', 'k20-ai-press' ), array( 'status' => 404 ) );
            $block = $cursor[ $index ];
            $cursor = is_array( $block['innerBlocks'] ?? null ) ? $block['innerBlocks'] : array();
        }
        if ( null === $block ) {
            if ( ! isset( $blocks[0] ) || ! is_array( $blocks[0] ) ) return new WP_Error( 'bridge_block_path', __( 'Block path was not found.', 'k20-ai-press' ), array( 'status' => 404 ) );
            $block = $blocks[0];
        }
        return $block;
    }

    /** @return mixed */
    private function &block_ref_at_path( array &$blocks, array $path ) {
        static $missing = null;
        $cursor = &$blocks;
        if ( empty( $path ) ) {
            if ( isset( $cursor[0] ) && is_array( $cursor[0] ) ) return $cursor[0];
            return $missing;
        }
        $last = count( $path ) - 1;
        foreach ( $path as $depth => $index ) {
            if ( ! isset( $cursor[ $index ] ) || ! is_array( $cursor[ $index ] ) ) return $missing;
            if ( $depth === $last ) return $cursor[ $index ];
            if ( ! isset( $cursor[ $index ]['innerBlocks'] ) || ! is_array( $cursor[ $index ]['innerBlocks'] ) ) return $missing;
            $cursor = &$cursor[ $index ]['innerBlocks'];
        }
        return $missing;
    }

    /** @return array<string,mixed>|WP_Error */
    private function elementor_inspect( array $request ): array|WP_Error {
        $id = absint( $request['id'] ?? $request['payload']['post_id'] ?? 0 );
        if ( ! $id || ! get_post( $id ) ) return new WP_Error( 'bridge_post_missing', __( 'Post not found.', 'k20-ai-press' ), array( 'status' => 404 ) );
        $raw = (string) get_post_meta( $id, '_elementor_data', true );
        if ( '' === $raw ) return new WP_Error( 'bridge_elementor_missing', __( 'Elementor data was not found for this post.', 'k20-ai-press' ), array( 'status' => 404 ) );
        $decoded = json_decode( $raw, true );
        if ( ! is_array( $decoded ) ) return new WP_Error( 'bridge_elementor_invalid', __( 'Elementor data is not valid JSON.', 'k20-ai-press' ), array( 'status' => 422 ) );
        return array( 'id' => $id, 'sha256' => hash( 'sha256', $raw ), 'bytes' => strlen( $raw ), 'element_count' => $this->count_elementor_nodes( $decoded ) );
    }

    /** @return array<string,mixed>|WP_Error */
    private function elementor_search( array $request ): array|WP_Error {
        $payload = isset( $request['payload'] ) && is_array( $request['payload'] ) ? $request['payload'] : array();
        $id = absint( $request['id'] ?? $payload['post_id'] ?? 0 );
        $pattern = (string) ( $payload['pattern'] ?? '' );
        if ( '' === $pattern ) return new WP_Error( 'bridge_elementor_search_input', __( 'Elementor search pattern is required.', 'k20-ai-press' ), array( 'status' => 400 ) );
        $raw = (string) get_post_meta( $id, '_elementor_data', true );
        if ( '' === $raw ) return new WP_Error( 'bridge_elementor_missing', __( 'Elementor data was not found for this post.', 'k20-ai-press' ), array( 'status' => 404 ) );
        return array( 'id' => $id, 'matches' => substr_count( $raw, $pattern ), 'sha256' => hash( 'sha256', $raw ) );
    }

    /** @return array<string,mixed>|WP_Error */
    private function elementor_edit( array $request ): array|WP_Error {
        $payload = isset( $request['payload'] ) && is_array( $request['payload'] ) ? $request['payload'] : array();
        $id = absint( $request['id'] ?? $payload['post_id'] ?? 0 );
        if ( ! $id || ! get_post( $id ) ) return new WP_Error( 'bridge_post_missing', __( 'Post not found.', 'k20-ai-press' ), array( 'status' => 404 ) );
        $before = (string) get_post_meta( $id, '_elementor_data', true );
        if ( '' === $before ) return new WP_Error( 'bridge_elementor_missing', __( 'Elementor data was not found for this post.', 'k20-ai-press' ), array( 'status' => 404 ) );
        $expected = strtolower( sanitize_text_field( (string) ( $payload['expected_sha256'] ?? '' ) ) );
        if ( $expected && ! hash_equals( hash( 'sha256', $before ), $expected ) ) return new WP_Error( 'bridge_stale_write', __( 'Expected Elementor hash does not match the current value.', 'k20-ai-press' ), array( 'status' => 409 ) );
        $old = (string) ( $payload['old_content'] ?? '' );
        $new = (string) ( $payload['new_content'] ?? '' );
        if ( '' === $old || 1 !== substr_count( $before, $old ) ) return new WP_Error( 'bridge_patch_match', __( 'Elementor edit requires exactly one old-content match.', 'k20-ai-press' ), array( 'status' => 409 ) );
        $after = str_replace( $old, $new, $before, $count );
        if ( 1 !== $count || ! is_array( json_decode( $after, true ) ) ) return new WP_Error( 'bridge_elementor_invalid', __( 'Edited Elementor payload is not valid JSON.', 'k20-ai-press' ), array( 'status' => 422 ) );
        $snapshot = $this->snapshot( 'elementor.edit', 'elementor_data', $id, array( 'value' => $before ) );
        update_post_meta( $id, '_elementor_data', wp_slash( $after ) );
        if ( class_exists( '\Elementor\Plugin' ) ) {
            try { \Elementor\Plugin::$instance->files_manager->clear_cache(); } catch ( Throwable $e ) { /* Cache clear is best-effort. */ }
        }
        $readback = (string) get_post_meta( $id, '_elementor_data', true );
        return array( 'id' => $id, 'changed' => true, 'before_sha256' => hash( 'sha256', $before ), 'after_sha256' => hash( 'sha256', $readback ), 'snapshot_id' => $snapshot );
    }

    private function count_elementor_nodes( array $nodes ): int {
        $count = 0;
        foreach ( $nodes as $node ) {
            if ( ! is_array( $node ) ) continue;
            ++$count;
            if ( ! empty( $node['elements'] ) && is_array( $node['elements'] ) ) $count += $this->count_elementor_nodes( $node['elements'] );
        }
        return $count;
    }

    /** @return array<string,mixed>|WP_Error */
    private function media_hash( array $request ): array|WP_Error {
        $payload = isset( $request['payload'] ) && is_array( $request['payload'] ) ? $request['payload'] : array();
        $id = absint( $payload['attachment_id'] ?? $request['id'] ?? 0 );
        $file = $id ? get_attached_file( $id ) : '';
        if ( ! $id || ! $file || ! is_file( $file ) ) return new WP_Error( 'bridge_media_missing', __( 'Attachment file not found.', 'k20-ai-press' ), array( 'status' => 404 ) );
        $sha = hash_file( 'sha256', $file );
        return array( 'attachment_id' => $id, 'sha256' => $sha ?: null, 'bytes' => filesize( $file ) ?: 0, 'mime' => get_post_mime_type( $id ) ?: null );
    }

    /** @return array<string,mixed> */
    private function media_duplicates( array $request ): array {
        $limit = max( 1, min( 500, absint( $request['payload']['limit'] ?? 200 ) ) );
        $ids = get_posts( array( 'post_type' => 'attachment', 'post_mime_type' => 'image', 'post_status' => 'inherit', 'posts_per_page' => $limit, 'fields' => 'ids', 'orderby' => 'ID', 'order' => 'DESC', 'no_found_rows' => true ) );
        $groups = array();
        foreach ( (array) $ids as $id ) {
            $file = get_attached_file( (int) $id );
            if ( ! $file || ! is_file( $file ) ) continue;
            $sha = hash_file( 'sha256', $file );
            if ( ! $sha ) continue;
            $groups[ $sha ][] = (int) $id;
        }
        $duplicates = array();
        foreach ( $groups as $sha => $group ) if ( count( $group ) > 1 ) $duplicates[] = array( 'sha256' => $sha, 'attachment_ids' => $group, 'count' => count( $group ) );
        return array( 'scanned' => count( (array) $ids ), 'duplicate_groups' => $duplicates, 'duplicate_group_count' => count( $duplicates ) );
    }

    /** @return array<string,mixed>|WP_Error */
    private function media_optimize( array $request ): array|WP_Error {
        $payload = isset( $request['payload'] ) && is_array( $request['payload'] ) ? $request['payload'] : array();
        $id = absint( $payload['attachment_id'] ?? $request['id'] ?? 0 );
        $file = $id ? get_attached_file( $id ) : '';
        if ( ! $id || ! $file || ! is_file( $file ) || ! wp_attachment_is_image( $id ) ) return new WP_Error( 'bridge_media_missing', __( 'Image attachment file not found.', 'k20-ai-press' ), array( 'status' => 404 ) );
        $quality = max( 40, min( 95, absint( $payload['quality'] ?? 82 ) ) );
        $max_dimension = max( 256, min( 4096, absint( $payload['max_dimension'] ?? 1920 ) ) );
        $mime = sanitize_mime_type( (string) ( $payload['mime'] ?? 'image/webp' ) );
        if ( ! in_array( $mime, array( 'image/jpeg', 'image/png', 'image/webp' ), true ) ) return new WP_Error( 'bridge_media_type', __( 'Output MIME is not allowed.', 'k20-ai-press' ), array( 'status' => 415 ) );
        require_once ABSPATH . 'wp-admin/includes/image.php';
        $editor = wp_get_image_editor( $file );
        if ( is_wp_error( $editor ) ) return $editor;
        $size = $editor->get_size();
        if ( ! empty( $size['width'] ) && ! empty( $size['height'] ) && max( (int) $size['width'], (int) $size['height'] ) > $max_dimension ) $editor->resize( $max_dimension, $max_dimension, false );
        $editor->set_quality( $quality );
        $uploads = wp_upload_dir();
        if ( ! empty( $uploads['error'] ) ) return new WP_Error( 'bridge_upload_dir', sanitize_text_field( (string) $uploads['error'] ), array( 'status' => 500 ) );
        $extension = 'image/png' === $mime ? 'png' : ( 'image/jpeg' === $mime ? 'jpg' : 'webp' );
        $base = sanitize_file_name( pathinfo( $file, PATHINFO_FILENAME ) . '-k20-optimized-' . wp_generate_password( 6, false, false ) . '.' . $extension );
        $dest = trailingslashit( (string) $uploads['path'] ) . $base;
        $saved = $editor->save( $dest, $mime );
        if ( is_wp_error( $saved ) ) return $saved;
        $attachment_id = wp_insert_attachment( array( 'post_mime_type' => (string) ( $saved['mime-type'] ?? $mime ), 'post_title' => sanitize_text_field( get_the_title( $id ) . ' optimized' ), 'post_status' => 'inherit', 'post_parent' => (int) wp_get_post_parent_id( $id ) ), (string) $saved['path'], 0, true );
        if ( is_wp_error( $attachment_id ) ) return $attachment_id;
        $meta = wp_generate_attachment_metadata( $attachment_id, (string) $saved['path'] );
        wp_update_attachment_metadata( $attachment_id, $meta );
        $alt = (string) get_post_meta( $id, '_wp_attachment_image_alt', true );
        if ( '' !== $alt ) update_post_meta( $attachment_id, '_wp_attachment_image_alt', $alt );
        return array( 'source_attachment_id' => $id, 'new_attachment_id' => (int) $attachment_id, 'mime' => (string) ( $saved['mime-type'] ?? $mime ), 'bytes' => filesize( (string) $saved['path'] ) ?: null, 'width' => $saved['width'] ?? null, 'height' => $saved['height'] ?? null, 'quality' => $quality );
    }

    /** @return array<string,mixed>|WP_Error */
    private function media_metadata( array $request ): array|WP_Error {
        $payload = isset( $request['payload'] ) && is_array( $request['payload'] ) ? $request['payload'] : array();
        $id = absint( $payload['attachment_id'] ?? $request['id'] ?? 0 );
        $post = get_post( $id );
        if ( ! $post || 'attachment' !== $post->post_type ) return new WP_Error( 'bridge_media_missing', __( 'Attachment not found.', 'k20-ai-press' ), array( 'status' => 404 ) );
        $before = array( 'alt_text' => (string) get_post_meta( $id, '_wp_attachment_image_alt', true ), 'caption' => (string) $post->post_excerpt, 'title' => (string) $post->post_title );
        $snapshot = $this->snapshot( 'media.metadata', 'media_meta', $id, $before );
        if ( array_key_exists( 'alt_text', $payload ) ) update_post_meta( $id, '_wp_attachment_image_alt', sanitize_text_field( (string) $payload['alt_text'] ) );
        $update = array( 'ID' => $id );
        if ( array_key_exists( 'caption', $payload ) ) $update['post_excerpt'] = sanitize_textarea_field( (string) $payload['caption'] );
        if ( array_key_exists( 'title', $payload ) ) $update['post_title'] = sanitize_text_field( (string) $payload['title'] );
        if ( count( $update ) > 1 ) wp_update_post( $update );
        return array( 'attachment_id' => $id, 'snapshot_id' => $snapshot, 'alt_text' => (string) get_post_meta( $id, '_wp_attachment_image_alt', true ) );
    }

    /** @return array<string,mixed>|WP_Error */
    private function asset_featured( array $request ): array|WP_Error {
        $payload = isset( $request['payload'] ) && is_array( $request['payload'] ) ? $request['payload'] : array();
        $id = absint( $payload['target_id'] ?? $request['id'] ?? 0 );
        $attachment = absint( $payload['attachment_id'] ?? 0 );
        if ( ! $id || ! get_post( $id ) || ! wp_attachment_is_image( $attachment ) ) return new WP_Error( 'bridge_asset_target', __( 'Target or image attachment is invalid.', 'k20-ai-press' ), array( 'status' => 400 ) );
        $before = get_post_thumbnail_id( $id );
        $snapshot = $this->snapshot( 'asset.featured.set', 'featured', $id, array( 'attachment_id' => $before ) );
        if ( ! set_post_thumbnail( $id, $attachment ) ) return new WP_Error( 'bridge_featured_failed', __( 'Featured image could not be updated.', 'k20-ai-press' ), array( 'status' => 500 ) );
        return array( 'target_id' => $id, 'previous_attachment_id' => $before, 'featured_attachment_id' => $attachment, 'snapshot_id' => $snapshot );
    }

    /** @return array<string,mixed>|WP_Error */
    private function asset_gallery( array $request, bool $replace ): array|WP_Error {
        $payload = isset( $request['payload'] ) && is_array( $request['payload'] ) ? $request['payload'] : array();
        $id = absint( $payload['target_id'] ?? $request['id'] ?? 0 );
        $ids = array_values( array_unique( array_filter( array_map( 'absint', (array) ( $payload['attachment_ids'] ?? array() ) ) ) ) );
        if ( ! function_exists( 'wc_get_product' ) || ! $id || ! $ids ) return new WP_Error( 'bridge_gallery_input', __( 'Product target and image attachment IDs are required.', 'k20-ai-press' ), array( 'status' => 400 ) );
        foreach ( $ids as $attachment ) if ( ! wp_attachment_is_image( $attachment ) ) return new WP_Error( 'bridge_gallery_media', __( 'Gallery includes a non-image attachment.', 'k20-ai-press' ), array( 'status' => 400 ) );
        $product = wc_get_product( $id );
        if ( ! $product ) return new WP_Error( 'bridge_product_missing', __( 'Product not found.', 'k20-ai-press' ), array( 'status' => 404 ) );
        $before = array_map( 'intval', $product->get_gallery_image_ids() );
        $after = $replace ? $ids : array_values( array_unique( array_merge( $before, $ids ) ) );
        $snapshot = $this->snapshot( $replace ? 'asset.gallery.replace' : 'asset.gallery.append', 'gallery', $id, array( 'attachment_ids' => $before ) );
        $product->set_gallery_image_ids( $after );
        $product->save();
        return array( 'target_id' => $id, 'before_gallery_image_ids' => $before, 'gallery_image_ids' => array_map( 'intval', wc_get_product( $id )->get_gallery_image_ids() ), 'snapshot_id' => $snapshot );
    }

    /** @return array<string,mixed>|WP_Error */
    private function asset_content_insert( array $request ): array|WP_Error {
        $payload = isset( $request['payload'] ) && is_array( $request['payload'] ) ? $request['payload'] : array();
        $post_id = absint( $payload['target_id'] ?? $payload['post_id'] ?? $request['id'] ?? 0 );
        $attachment_id = absint( $payload['attachment_id'] ?? 0 );
        $post = get_post( $post_id );
        if ( ! $post || ! wp_attachment_is_image( $attachment_id ) ) return new WP_Error( 'bridge_asset_target', __( 'Target post or image attachment is invalid.', 'k20-ai-press' ), array( 'status' => 400 ) );
        $before = (string) $post->post_content;
        $expected = strtolower( sanitize_text_field( (string) ( $payload['expected_sha256'] ?? '' ) ) );
        if ( $expected && ! hash_equals( hash( 'sha256', $before ), $expected ) ) return new WP_Error( 'bridge_stale_write', __( 'Expected content hash does not match the current value.', 'k20-ai-press' ), array( 'status' => 409 ) );
        $html = wp_get_attachment_image( $attachment_id, 'full', false, array( 'loading' => 'lazy' ) );
        if ( ! $html ) return new WP_Error( 'bridge_asset_html', __( 'Image HTML could not be generated.', 'k20-ai-press' ), array( 'status' => 500 ) );
        $block = "\n<!-- wp:image {\"id\":" . $attachment_id . "} -->\n<figure class=\"wp-block-image\">" . $html . "</figure>\n<!-- /wp:image -->\n";
        $position = sanitize_key( (string) ( $payload['position'] ?? 'append' ) );
        $after_text = (string) ( $payload['after_text'] ?? '' );
        if ( 'after_text' === $position ) {
            if ( '' === $after_text || 1 !== substr_count( $before, $after_text ) ) return new WP_Error( 'bridge_insert_anchor', __( 'after_text insertion requires exactly one anchor match.', 'k20-ai-press' ), array( 'status' => 409 ) );
            $after = str_replace( $after_text, $after_text . $block, $before, $count );
        } elseif ( 'prepend' === $position ) {
            $after = $block . $before;
        } elseif ( 'append' === $position ) {
            $after = $before . $block;
        } else {
            return new WP_Error( 'bridge_insert_position', __( 'position must be append, prepend or after_text.', 'k20-ai-press' ), array( 'status' => 400 ) );
        }
        $snapshot = $this->snapshot( 'asset.content.insert', 'post_field:post_content', $post_id, array( 'value' => $before ) );
        $updated = wp_update_post( array( 'ID' => $post_id, 'post_content' => wp_kses_post( $after ) ), true );
        if ( is_wp_error( $updated ) ) return $updated;
        return array( 'target_id' => $post_id, 'attachment_id' => $attachment_id, 'changed' => true, 'snapshot_id' => $snapshot, 'after_sha256' => hash( 'sha256', (string) get_post_field( 'post_content', $post_id ) ) );
    }

    /** @return array<string,mixed> */
    private function cache_status(): array {
        return array( 'wp_cache' => defined( 'WP_CACHE' ) && WP_CACHE, 'wp_cache_flush_available' => function_exists( 'wp_cache_flush' ), 'litespeed_active' => has_action( 'litespeed_purge_all' ) || defined( 'LSCWP_V' ) );
    }

    /** @return array<string,mixed> */
    private function cache_purge(): array {
        $purged = array();
        if ( function_exists( 'wp_cache_flush' ) ) { wp_cache_flush(); $purged[] = 'object-cache'; }
        if ( has_action( 'litespeed_purge_all' ) || defined( 'LSCWP_V' ) ) { do_action( 'litespeed_purge_all' ); $purged[] = 'litespeed'; }
        do_action( 'k20ai_bridge_cache_purge' );
        return array( 'purged' => $purged, 'count' => count( $purged ) );
    }

    /** @return array<int,array<string,mixed>> */
    private function audit_tail( array $request ): array {
        global $wpdb;
        $t = K20AI_Database::tables();
        $limit = max( 1, min( 100, absint( $request['limit'] ?? $request['payload']['limit'] ?? 30 ) ) );
        return (array) $wpdb->get_results( $wpdb->prepare( "SELECT id,actor_id,actor_type,action_name,target_type,target_id,result,trace_id,created_at FROM {$t['audit_log']} ORDER BY id DESC LIMIT %d", $limit ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
    }

    /** @return array<string,mixed>|WP_Error */
    private function batch( array $request ): array|WP_Error {
        $items = isset( $request['payload']['items'] ) && is_array( $request['payload']['items'] ) ? $request['payload']['items'] : array();
        if ( empty( $items ) || count( $items ) > 20 ) return new WP_Error( 'bridge_batch_size', __( 'Batch must contain 1..20 items.', 'k20-ai-press' ), array( 'status' => 400 ) );
        $out = array();
        foreach ( $items as $index => $item ) {
            if ( ! is_array( $item ) || 'batch' === ( $item['action'] ?? '' ) ) { $out[] = array( 'index' => $index, 'ok' => false, 'error' => 'invalid_batch_item' ); continue; }
            $result = $this->execute( $item );
            $out[] = is_wp_error( $result ) ? array( 'index' => $index, 'ok' => false, 'error' => $result->get_error_message() ) : array( 'index' => $index, 'ok' => true, 'result' => $result['result'] ?? $result );
        }
        return array( 'items' => $out, 'success' => count( array_filter( $out, static fn( $row ) => ! empty( $row['ok'] ) ) ), 'failed' => count( array_filter( $out, static fn( $row ) => empty( $row['ok'] ) ) ) );
    }

    private function snapshot( string $action, string $type, int $id, array $before ): string {
        global $wpdb;
        $t = K20AI_Database::tables();
        $key = wp_generate_uuid4();
        $wpdb->insert( $t['bridge_snapshots'], array( 'snapshot_key' => $key, 'action' => $action, 'object_type' => $type, 'object_id' => $id, 'before_payload' => wp_json_encode( $before, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ), 'actor_id' => get_current_user_id() ?: null, 'created_at' => current_time( 'mysql', true ) ) );
        return $key;
    }

    /** @return array<int,array<string,mixed>> */
    private function snapshot_list( array $request ): array {
        global $wpdb;
        $t = K20AI_Database::tables();
        $payload = isset( $request['payload'] ) && is_array( $request['payload'] ) ? $request['payload'] : array();
        $id = absint( $payload['object_id'] ?? 0 );
        $limit = max( 1, min( 100, absint( $payload['limit'] ?? 20 ) ) );
        if ( $id ) return (array) $wpdb->get_results( $wpdb->prepare( "SELECT snapshot_key,action,object_type,object_id,actor_id,created_at,rolled_back_at FROM {$t['bridge_snapshots']} WHERE object_id=%d ORDER BY id DESC LIMIT %d", $id, $limit ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        return (array) $wpdb->get_results( $wpdb->prepare( "SELECT snapshot_key,action,object_type,object_id,actor_id,created_at,rolled_back_at FROM {$t['bridge_snapshots']} ORDER BY id DESC LIMIT %d", $limit ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
    }

    /** @return array<string,mixed>|WP_Error */
    private function snapshot_rollback( array $request ): array|WP_Error {
        global $wpdb;
        $t = K20AI_Database::tables();
        $payload = isset( $request['payload'] ) && is_array( $request['payload'] ) ? $request['payload'] : array();
        $key = sanitize_text_field( (string) ( $payload['snapshot_id'] ?? $request['snapshot_id'] ?? '' ) );
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t['bridge_snapshots']} WHERE snapshot_key=%s", $key ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        if ( ! $row ) return new WP_Error( 'bridge_snapshot_missing', __( 'Snapshot not found.', 'k20-ai-press' ), array( 'status' => 404 ) );
        if ( ! empty( $row['rolled_back_at'] ) ) return new WP_Error( 'bridge_snapshot_used', __( 'Snapshot has already been rolled back.', 'k20-ai-press' ), array( 'status' => 409 ) );
        $before = json_decode( (string) $row['before_payload'], true );
        $before = is_array( $before ) ? $before : array();
        $id = (int) $row['object_id'];
        $type = (string) $row['object_type'];
        if ( str_starts_with( $type, 'post_field:' ) ) {
            $field = substr( $type, strlen( 'post_field:' ) );
            wp_update_post( array( 'ID' => $id, $field => (string) ( $before['value'] ?? '' ) ) );
        } elseif ( 'seo' === $type ) {
            $map = array( 'title' => '_yoast_wpseo_title', 'description' => '_yoast_wpseo_metadesc', 'focus_keyword' => '_yoast_wpseo_focuskw', 'canonical' => '_yoast_wpseo_canonical' );
            foreach ( $map as $name => $meta ) update_post_meta( $id, $meta, (string) ( $before[ $name ] ?? '' ) );
            update_post_meta( $id, '_yoast_wpseo_meta-robots-noindex', ! empty( $before['noindex'] ) ? '1' : '' );
        } elseif ( 'featured' === $type ) {
            $attachment = absint( $before['attachment_id'] ?? 0 );
            $attachment ? set_post_thumbnail( $id, $attachment ) : delete_post_thumbnail( $id );
        } elseif ( 'gallery' === $type && function_exists( 'wc_get_product' ) ) {
            $product = wc_get_product( $id );
            if ( $product ) { $product->set_gallery_image_ids( array_map( 'absint', (array) ( $before['attachment_ids'] ?? array() ) ) ); $product->save(); }
        } elseif ( 'media_meta' === $type ) {
            update_post_meta( $id, '_wp_attachment_image_alt', (string) ( $before['alt_text'] ?? '' ) );
            wp_update_post( array( 'ID' => $id, 'post_excerpt' => (string) ( $before['caption'] ?? '' ), 'post_title' => (string) ( $before['title'] ?? '' ) ) );
        } elseif ( 'elementor_data' === $type ) {
            update_post_meta( $id, '_elementor_data', wp_slash( (string) ( $before['value'] ?? '' ) ) );
            if ( class_exists( '\\Elementor\\Plugin' ) ) { try { \Elementor\Plugin::$instance->files_manager->clear_cache(); } catch ( Throwable $e ) {} }
        } else return new WP_Error( 'bridge_snapshot_type', __( 'Snapshot type is not rollback-capable.', 'k20-ai-press' ), array( 'status' => 422 ) );
        $wpdb->update( $t['bridge_snapshots'], array( 'rolled_back_at' => current_time( 'mysql', true ) ), array( 'id' => (int) $row['id'] ) );
        return array( 'snapshot_id' => $key, 'rolled_back' => true, 'object_type' => $type, 'object_id' => $id );
    }

    /** @return array<string,mixed> */
    private function observability_status(): array {
        global $wpdb;
        $t = K20AI_Database::tables();
        return array( 'audit_rows' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t['audit_log']}" ), 'engine_runs' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t['engine_runs']}" ), 'snapshots' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t['bridge_snapshots']}" ), 'cache' => $this->cache_status() ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
    }

    /** @return array<string,mixed> */
    private function selftest(): array {
        return array( 'contract' => self::CONTRACT, 'rest' => function_exists( 'rest_do_request' ), 'database' => K20AI_Database::DB_VERSION, 'woocommerce' => function_exists( 'wc_get_product' ), 'media' => function_exists( 'wp_get_attachment_url' ), 'engines' => $this->engines->status()['engines'] );
    }

    /** @return array<string,mixed>|WP_Error */
    private function engine_status( array $request ): array|WP_Error {
        $name = sanitize_key( (string) ( $request['engine'] ?? $request['payload']['engine'] ?? '' ) );
        $status = $this->engines->status();
        if ( '' === $name ) return $status;
        if ( ! isset( $status['engines'][ $name ] ) ) return new WP_Error( 'bridge_engine_unknown', __( 'Unknown engine.', 'k20-ai-press' ), array( 'status' => 404 ) );
        return array( 'engine' => $status['engines'][ $name ], 'runs' => array_values( array_filter( $status['runs'], static fn( $row ) => $name === (string) ( $row['engine'] ?? '' ) ) ) );
    }

    /** @return array<string,mixed>|WP_Error */
    private function engine_run( array $request ): array|WP_Error {
        $name = sanitize_key( (string) ( $request['engine'] ?? $request['payload']['engine'] ?? '' ) );
        if ( ! in_array( $name, array( 'news', 'article' ), true ) ) return new WP_Error( 'bridge_engine_unknown', __( 'Only news and article engines are embedded in this release.', 'k20-ai-press' ), array( 'status' => 404 ) );
        return $this->engines->run( $name, 'bridge' );
    }

    /** @return array<string,mixed> */
    private function gitops_profile(): array {
        $github = $this->connections->get( 'github', false );
        return array( 'profile' => 'universal-bridge-3.3', 'primary_path' => 'WordPress -> K20 AI Press Bridge -> local action or GitHub Actions runner -> readback', 'github_status' => $github['status'] ?? 'disconnected', 'repository' => $github['config']['repository'] ?? '', 'engines' => array( 'news', 'article' ), 'contract' => self::CONTRACT );
    }

    private function audit( string $action, string $result, array $meta ): void {
        global $wpdb;
        $t = K20AI_Database::tables();
        $wpdb->insert( $t['audit_log'], array( 'actor_id' => get_current_user_id() ?: null, 'actor_type' => get_current_user_id() ? 'human' : 'system', 'action_name' => 'bridge.' . $action, 'target_type' => 'bridge', 'target_id' => '', 'result' => $result, 'trace_id' => function_exists( 'wp_generate_uuid4' ) ? wp_generate_uuid4() : null, 'meta' => wp_json_encode( $meta ), 'created_at' => current_time( 'mysql', true ) ) );
    }
}
