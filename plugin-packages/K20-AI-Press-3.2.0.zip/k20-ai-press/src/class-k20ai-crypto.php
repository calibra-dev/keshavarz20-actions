<?php

defined( 'ABSPATH' ) || exit;

/**
 * Small authenticated-encryption service for plugin-owned secrets.
 *
 * The connection-center context intentionally reproduces the 3.0.x key
 * derivation so existing encrypted credentials remain readable after upgrade.
 */
final class K20AI_Crypto {
    /** @return string|WP_Error */
    public static function encrypt_json( array $data, string $context ): string|WP_Error {
        $plain = wp_json_encode( $data );
        if ( ! is_string( $plain ) ) return new WP_Error( 'crypto_encode_failed', __( 'Secret data could not be encoded.', 'k20-ai-press' ) );
        return self::encrypt_plaintext( $plain, $context );
    }

    /** @return array<string,mixed> */
    public static function decrypt_json( string $blob, string $context ): array {
        $plain = self::decrypt_plaintext( $blob, $context );
        if ( null === $plain ) return array();
        $decoded = json_decode( $plain, true );
        return is_array( $decoded ) ? $decoded : array();
    }

    /** @return string|WP_Error */
    public static function encrypt_string( string $value, string $context ): string|WP_Error {
        return self::encrypt_plaintext( $value, $context );
    }

    public static function decrypt_string( string $blob, string $context ): ?string {
        return self::decrypt_plaintext( $blob, $context );
    }

    /** @return string|WP_Error */
    private static function encrypt_plaintext( string $plain, string $context ): string|WP_Error {
        $key = self::key( $context );
        if ( function_exists( 'sodium_crypto_secretbox' ) ) {
            try {
                $nonce = random_bytes( SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
                $cipher = sodium_crypto_secretbox( $plain, $nonce, $key );
                return 's1:' . base64_encode( $nonce . $cipher );
            } catch ( Throwable $error ) {
                return new WP_Error( 'crypto_random_failed', __( 'Secure secret encryption failed.', 'k20-ai-press' ) );
            }
        }
        if ( function_exists( 'openssl_encrypt' ) ) {
            try {
                $iv = random_bytes( 12 );
            } catch ( Throwable $error ) {
                return new WP_Error( 'crypto_random_failed', __( 'Secure secret encryption failed.', 'k20-ai-press' ) );
            }
            $tag = '';
            $cipher = openssl_encrypt( $plain, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag );
            if ( false !== $cipher ) return 'o1:' . base64_encode( $iv . $tag . $cipher );
        }
        return new WP_Error( 'crypto_unavailable', __( 'Sodium or OpenSSL is required to store secrets securely.', 'k20-ai-press' ) );
    }

    private static function decrypt_plaintext( string $blob, string $context ): ?string {
        if ( '' === $blob ) return null;
        $key = self::key( $context );
        $plain = false;
        if ( str_starts_with( $blob, 's1:' ) && function_exists( 'sodium_crypto_secretbox_open' ) ) {
            $raw = base64_decode( substr( $blob, 3 ), true );
            if ( false !== $raw && strlen( $raw ) > SODIUM_CRYPTO_SECRETBOX_NONCEBYTES ) {
                $plain = sodium_crypto_secretbox_open( substr( $raw, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES ), substr( $raw, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES ), $key );
            }
        } elseif ( str_starts_with( $blob, 'o1:' ) && function_exists( 'openssl_decrypt' ) ) {
            $raw = base64_decode( substr( $blob, 3 ), true );
            if ( false !== $raw && strlen( $raw ) > 28 ) {
                $iv = substr( $raw, 0, 12 );
                $tag = substr( $raw, 12, 16 );
                $cipher = substr( $raw, 28 );
                $plain = openssl_decrypt( $cipher, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag );
            }
        }
        return false !== $plain ? (string) $plain : null;
    }

    private static function key( string $context ): string {
        $context = preg_replace( '/[^a-z0-9_-]+/i', '-', strtolower( $context ) ) ?: 'generic';
        return hash( 'sha256', wp_salt( 'auth' ) . '|k20ai-' . $context, true );
    }
}
