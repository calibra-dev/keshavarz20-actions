<?php

defined( 'ABSPATH' ) || exit;

/**
 * Opt-in diagnostics with aggressive secret/PII redaction.
 */
final class K20AI_Logger {
    private const SOURCE = 'k20-ai-press';

    public static function enabled(): bool {
        $settings = get_option( 'k20ai_settings', array() );
        return is_array( $settings ) && ! empty( $settings['diagnostic_logging_enabled'] );
    }

    /** @param array<string,mixed> $context */
    public static function log( string $level, string $message, array $context = array() ): void {
        if ( ! self::enabled() ) return;

        $allowed = array( 'emergency', 'alert', 'critical', 'error', 'warning', 'notice', 'info', 'debug' );
        $level = in_array( $level, $allowed, true ) ? $level : 'info';
        $safe_context = self::redact( $context );
        $safe_message = self::redact_string( $message );

        if ( function_exists( 'wc_get_logger' ) ) {
            $logger = wc_get_logger();
            if ( is_object( $logger ) && method_exists( $logger, 'log' ) ) {
                $logger->log( $level, $safe_message, array_merge( array( 'source' => self::SOURCE ), $safe_context ) );
                return;
            }
        }

        if ( defined( 'WP_DEBUG' ) && WP_DEBUG && function_exists( 'error_log' ) ) {
            $suffix = $safe_context ? ' ' . wp_json_encode( $safe_context, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) : '';
            error_log( '[K20 AI Press][' . $level . '] ' . $safe_message . $suffix ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
        }
    }

    /** @param array<string,mixed> $context @return array<string,mixed> */
    public static function sanitize_context( array $context ): array {
        $safe = self::redact( $context );
        return is_array( $safe ) ? $safe : array();
    }

    /** @param array<string,mixed> $context */
    public static function error( string $message, array $context = array() ): void {
        self::log( 'error', $message, $context );
    }

    /** @param array<string,mixed> $context */
    public static function warning( string $message, array $context = array() ): void {
        self::log( 'warning', $message, $context );
    }

    /** @param array<string,mixed> $context */
    public static function info( string $message, array $context = array() ): void {
        self::log( 'info', $message, $context );
    }

    private static function sensitive_key( string $key ): bool {
        return (bool) preg_match( '/(?:secret|token|password|passwd|authorization|api[_-]?key|license[_-]?key|private[_-]?key|client[_-]?secret|refresh|access[_-]?token|cookie|email|e-mail|ip(?:_address)?|user[_-]?agent)/i', $key );
    }

    private static function redact_string( string $value ): string {
        $value = preg_replace( '/\bBearer\s+[A-Za-z0-9._~+\/-]+=*\b/i', 'Bearer [REDACTED]', $value ) ?? $value;
        $value = preg_replace( '/([?&](?:token|key|secret|password|api_key|license_key|private_key|access_token|refresh_token)=)[^&\s]+/i', '$1[REDACTED]', $value ) ?? $value;
        $value = preg_replace( '/\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/i', '[EMAIL-REDACTED]', $value ) ?? $value;
        $value = preg_replace( '/(?<![A-F0-9:])\b(?:\d{1,3}\.){3}\d{1,3}\b(?![A-F0-9:])/i', '[IP-REDACTED]', $value ) ?? $value;
        if ( strlen( $value ) > 4000 ) $value = substr( $value, 0, 4000 ) . '…';
        return $value;
    }

    private static function redact( mixed $value, string $parent_key = '' ): mixed {
        if ( '' !== $parent_key && self::sensitive_key( $parent_key ) ) return '[REDACTED]';
        if ( is_array( $value ) ) {
            $out = array();
            foreach ( $value as $key => $item ) {
                $key_string = (string) $key;
                $out[ $key ] = self::redact( $item, $key_string );
            }
            return $out;
        }
        if ( is_object( $value ) ) return '[OBJECT]';
        if ( is_string( $value ) ) return self::redact_string( $value );
        return $value;
    }
}
