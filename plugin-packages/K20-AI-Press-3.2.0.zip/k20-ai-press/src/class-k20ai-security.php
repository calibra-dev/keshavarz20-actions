<?php

defined( 'ABSPATH' ) || exit;

/**
 * Central security/integrity policy for K20 AI Press.
 *
 * Keep authorization rules and protected-commerce guards in one place so REST,
 * Abilities, Bridge and background workers cannot silently drift apart.
 */
final class K20AI_Security {
    private const PROTECTED_COMMERCE_FIELDS = array(
        'price', 'regular_price', 'sale_price', 'sale_price_dates_from', 'sale_price_dates_to',
        'stock', 'stock_status', 'stock_quantity', 'manage_stock',
        'coupon', 'discount', 'payment', 'payment_method', 'tax_status', 'tax_class',
    );

    public static function can_view(): bool {
        return current_user_can( 'manage_options' ) || current_user_can( 'manage_woocommerce' );
    }

    public static function can_edit_content(): bool {
        return current_user_can( 'manage_options' ) || current_user_can( 'manage_woocommerce' );
    }

    public static function can_manage_system(): bool {
        return current_user_can( 'manage_options' );
    }

    public static function normalize_bridge_action( mixed $value ): string {
        $action = strtolower( trim( (string) $value ) );
        if ( '' === $action || strlen( $action ) > 64 ) return '';
        return preg_match( '/^[a-z0-9][a-z0-9._-]{0,63}$/D', $action ) ? $action : '';
    }

    /** @return array<int,string> */
    public static function protected_commerce_fields(): array {
        return self::PROTECTED_COMMERCE_FIELDS;
    }

    /** @return array<int,string> */
    public static function protected_fields_present( array $fields ): array {
        $present = array();
        foreach ( self::PROTECTED_COMMERCE_FIELDS as $key ) {
            if ( array_key_exists( $key, $fields ) ) $present[] = $key;
        }
        return $present;
    }

    public static function protected_fields_error( array $fields ): ?WP_Error {
        $present = self::protected_fields_present( $fields );
        if ( ! $present ) return null;
        return new WP_Error( 'k20ai_protected_commerce_field', __( 'Price, stock, discount, tax and payment fields are read-only in K20 AI Press automation paths.', 'k20-ai-press' ),
            array( 'status' => 403, 'fields' => $present )
        );
    }

    public static function action_scheduler_available(): bool {
        if ( ! function_exists( 'as_enqueue_async_action' ) ) return false;
        return ! function_exists( 'did_action' ) || did_action( 'action_scheduler_init' ) > 0 || did_action( 'init' ) > 0;
    }

    public static function enqueue_unique_action( string $hook, array $args = array(), int $timestamp = 0, string $group = 'k20-ai-press', bool $unique = true ): bool {
        if ( self::action_scheduler_available() ) {
            if ( $timestamp > time() && function_exists( 'as_schedule_single_action' ) ) {
                $id = as_schedule_single_action( $timestamp, $hook, $args, $group, $unique );
            } else {
                $id = as_enqueue_async_action( $hook, $args, $group, $unique );
            }
            return false !== $id && 0 !== (int) $id;
        }
        if ( $unique && wp_next_scheduled( $hook, $args ) ) return true;
        return (bool) wp_schedule_single_event( $timestamp > time() ? $timestamp : time() + 5, $hook, $args );
    }

    public static function normalize_mysql_datetime_to_iso( mixed $gmt_value, mixed $local_value = null ): ?string {
        $candidates = array(
            array( trim( (string) $gmt_value ), new DateTimeZone( 'UTC' ) ),
            array( trim( (string) $local_value ), function_exists( 'wp_timezone' ) ? wp_timezone() : new DateTimeZone( 'UTC' ) ),
        );
        foreach ( $candidates as $candidate ) {
            list( $value, $tz ) = $candidate;
            if ( '' === $value || str_starts_with( $value, '0000-00-00' ) || ! preg_match( '/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/D', $value ) ) continue;
            $dt = DateTimeImmutable::createFromFormat( '!Y-m-d H:i:s', $value, $tz );
            $errors = DateTimeImmutable::getLastErrors();
            if ( ! $dt || ( is_array( $errors ) && ( (int) $errors['warning_count'] > 0 || (int) $errors['error_count'] > 0 ) ) ) continue;
            if ( (int) $dt->format( 'Y' ) < 1970 ) continue;
            return $dt->format( DATE_ATOM );
        }
        return null;
    }

    public static function ability_required_capability( string $name, bool $side_effect ): string {
        $system_prefixes = array( 'mode.', 'admin.', 'bot.', 'webhook.', 'budget.', 'slo.', 'setup.', 'provider.', 'eval.', 'system.', 'agent.', 'migration.', 'license.', 'onboarding.', 'diagnostics.', 'visibility.', 'command.', 'mcp.' );
        foreach ( $system_prefixes as $prefix ) {
            if ( str_starts_with( $name, $prefix ) ) return 'manage_options';
        }
        return $side_effect ? 'manage_woocommerce' : 'manage_woocommerce';
    }

    public static function ability_permission( array $ability ): bool {
        $required = self::ability_required_capability(
            (string) ( $ability['name'] ?? '' ),
            ! empty( $ability['side_effect'] )
        );
        return 'manage_options' === $required ? self::can_manage_system() : self::can_view();
    }

    public static function ability_public_readonly( string $name ): bool {
        return in_array(
            $name,
            array(
                'engineering.convert_units',
                'engineering.calculate_drip_tape',
                'engineering.calculate_pipe',
                'engineering.calculate_filter',
            ),
            true
        );
    }


    public static function ability_mcp_exposed( string $name, bool $side_effect ): bool {
        $allow = array(
            'command.center', 'agent.plan', 'agent.status', 'agent.list',
            'product.intelligence', 'product.intelligence.backlog', 'visibility.query.list', 'visibility.observatory',
            'onboarding.status', 'license.status', 'diagnostics.bundle', 'audit.run', 'observability.status', 'mcp.status',
        );
        if ( in_array( $name, $allow, true ) ) return true;
        return ! $side_effect && self::ability_public_readonly( $name );
    }

    /** @return array<int,string> */
    public static function bridge_write_actions(): array {
        return array(
            'seo.update', 'content.patch', 'content.block.patch', 'elementor.edit',
            'media.metadata', 'media.optimize', 'asset.featured.set', 'asset.gallery.append',
            'asset.gallery.replace', 'asset.content.insert', 'cache.purge', 'snapshot.rollback',
            'engine.run', 'batch',
        );
    }

    public static function bridge_action_is_write( string $action, array $request = array() ): bool {
        if ( 'rest.proxy' === $action ) {
            return 'GET' !== strtoupper( trim( (string) ( $request['method'] ?? 'GET' ) ) );
        }
        return in_array( $action, self::bridge_write_actions(), true );
    }

    public static function bridge_rate_limit( string $action, array $request = array() ): bool|WP_Error {
        $is_write = self::bridge_action_is_write( $action, $request );
        $limit = $is_write ? 30 : 120;
        $bucket = gmdate( 'YmdHi' );
        $key = 'k20ai_bridge_rl_' . md5( get_current_user_id() . '|' . $bucket . '|' . ( $is_write ? 'w' : 'r' ) );

        // Persistent object caches provide an atomic increment. On hosts without
        // one, fall back to transients; authorization + idempotency remain the
        // primary security boundary and this limiter is defense-in-depth.
        if ( function_exists( 'wp_using_ext_object_cache' ) && wp_using_ext_object_cache() ) {
            $group = 'k20ai_bridge_rate_limit';
            if ( ! wp_cache_add( $key, 0, $group, MINUTE_IN_SECONDS + 5 ) ) {
                $existing = wp_cache_get( $key, $group );
                if ( false === $existing ) wp_cache_set( $key, 0, $group, MINUTE_IN_SECONDS + 5 );
            }
            $count = wp_cache_incr( $key, 1, $group );
            if ( false === $count ) {
                wp_cache_set( $key, 1, $group, MINUTE_IN_SECONDS + 5 );
                $count = 1;
            }
            if ( (int) $count > $limit ) return new WP_Error( 'k20ai_bridge_rate_limited', __( 'Bridge rate limit exceeded.', 'k20-ai-press' ), array( 'status' => 429 ) );
            return true;
        }

        $count = (int) get_transient( $key );
        if ( $count >= $limit ) return new WP_Error( 'k20ai_bridge_rate_limited', __( 'Bridge rate limit exceeded.', 'k20-ai-press' ), array( 'status' => 429 ) );
        set_transient( $key, $count + 1, MINUTE_IN_SECONDS + 5 );
        return true;
    }
}
