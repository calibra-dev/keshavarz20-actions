<?php

defined( 'ABSPATH' ) || exit;

final class K20AI_Admin {
    private K20AI_Services $services;
    private K20AI_Ability_Registry $registry;
    private K20AI_SEO_OS $seo;
    private string $hook = '';

    public function __construct( K20AI_Services $services, K20AI_Ability_Registry $registry, K20AI_SEO_OS $seo ) {
        $this->services = $services;
        $this->registry = $registry;
        $this->seo = $seo;
    }

    public function menu(): void {
        $capability = current_user_can( 'manage_woocommerce' ) ? 'manage_woocommerce' : 'manage_options';
        $this->hook = add_menu_page(
            'K20 AI Press ' . K20AI_PRESS_VERSION,
            'K20 AI Press',
            $capability,
            'k20-ai-press',
            array( $this, 'render' ),
            'dashicons-superhero-alt',
            3
        );
    }

    public function assets( string $hook ): void {
        if ( $hook !== $this->hook ) return;
        wp_enqueue_style( 'dashicons' );
        wp_enqueue_style( 'k20ai-admin-v3', K20AI_PRESS_URL . 'assets/v3-admin.css', array(), K20AI_PRESS_VERSION );
        wp_enqueue_script( 'k20ai-admin-v31-workflows', K20AI_PRESS_URL . 'assets/v31-workflows.js', array( 'wp-i18n' ), K20AI_PRESS_VERSION, true );
        wp_enqueue_script( 'k20ai-admin-v3', K20AI_PRESS_URL . 'assets/v3-admin.js', array( 'wp-i18n', 'k20ai-admin-v31-workflows' ), K20AI_PRESS_VERSION, true );
        wp_set_script_translations( 'k20ai-admin-v31-workflows', 'k20-ai-press', K20AI_PRESS_DIR . 'languages' );
        wp_set_script_translations( 'k20ai-admin-v3', 'k20-ai-press', K20AI_PRESS_DIR . 'languages' );
        wp_localize_script(
            'k20ai-admin-v3',
            'K20AI_V3_BOOT',
            array(
                'restBase'      => esc_url_raw( rest_url( 'k20-ai/v3' ) ),
                'legacyRestBase'=> esc_url_raw( rest_url( 'k20-ai/v1' ) ),
                'nonce'         => wp_create_nonce( 'wp_rest' ),
                'workspace'     => $this->current_workspace(),
                'site'          => home_url(),
                'version'       => K20AI_PRESS_VERSION,
                'uiTheme'       => in_array( get_user_meta( get_current_user_id(), 'k20ai_ui_theme', true ), array( 'light', 'dark' ), true ) ? get_user_meta( get_current_user_id(), 'k20ai_ui_theme', true ) : 'light',
                'uiLanguage'    => K20AI_I18n::user_ui_language(),
                'workspaces'    => $this->seo->workspaces(),
                'adminUrl'      => admin_url( 'admin.php?page=k20-ai-press' ),
                'user'          => array(
                    'id'      => get_current_user_id(),
                    'name'    => wp_get_current_user()->display_name,
                    'canEdit' => K20AI_Security::can_edit_content(),
                    'canSystem' => K20AI_Security::can_manage_system(),
                ),
                'i18n'          => array(
                    'loading'       => K20AI_I18n::pair( 'در حال دریافت داده واقعی…', 'Loading verified data…' ),
                    'error'         => K20AI_I18n::pair( 'دریافت داده ناموفق بود.', 'Data request failed.' ),
                    'saved'         => K20AI_I18n::pair( 'تغییرات ذخیره شد.', 'Changes saved.' ),
                    'confirmApply'  => K20AI_I18n::pair( 'این تغییر روی سایت اجرا شود؟', 'Apply this change to the site?' ),
                    'confirmRollback'=> K20AI_I18n::pair( 'این اقدام به وضعیت قبل بازگردد؟', 'Roll this action back?' ),
                    'noData'        => K20AI_I18n::pair( 'برای این بخش هنوز داده اندازه‌گیری‌شده وجود ندارد.', 'No measured data is available for this section yet.' ),
                ),
            )
        );
    }

    public function admin_bar_shortcuts( $wp_admin_bar ): void {
        if ( ! is_admin() || ! is_object( $wp_admin_bar ) || ! method_exists( $wp_admin_bar, 'add_node' ) ) return;
        $screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
        if ( ! $screen || $screen->id !== $this->hook ) return;
        $items = array(
            array( 'id' => 'k20ai-dashboard', 'title' => K20AI_I18n::pair( 'پیشخوان', 'Dashboard' ), 'href' => admin_url(), 'cap' => 'read' ),
            array( 'id' => 'k20ai-plugins', 'title' => K20AI_I18n::pair( 'افزونه‌ها', 'Plugins' ), 'href' => admin_url( 'plugins.php' ), 'cap' => 'activate_plugins' ),
            array( 'id' => 'k20ai-posts', 'title' => K20AI_I18n::pair( 'نوشته‌ها', 'Posts' ), 'href' => admin_url( 'edit.php' ), 'cap' => 'edit_posts' ),
            array( 'id' => 'k20ai-widgets', 'title' => K20AI_I18n::pair( 'ابزارک‌ها', 'Widgets' ), 'href' => admin_url( 'widgets.php' ), 'cap' => 'edit_theme_options' ),
            array( 'id' => 'k20ai-menus', 'title' => K20AI_I18n::pair( 'فهرست‌ها', 'Menus' ), 'href' => admin_url( 'nav-menus.php' ), 'cap' => 'edit_theme_options' ),
            array( 'id' => 'k20ai-products', 'title' => K20AI_I18n::pair( 'محصولات', 'Products' ), 'href' => admin_url( 'edit.php?post_type=product' ), 'cap' => 'edit_products' ),
        );
        foreach ( $items as $item ) {
            if ( current_user_can( $item['cap'] ) ) {
                $wp_admin_bar->add_node( array( 'id' => $item['id'], 'parent' => 'site-name', 'title' => $item['title'], 'href' => $item['href'] ) );
            }
        }
    }

    public function body_class( string $classes ): string {
        $screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
        if ( $screen && $screen->id === $this->hook ) $classes .= ' k20ai-screen k20ai-v3-screen';
        return $classes;
    }

    private function current_workspace(): string {
        $workspace = isset( $_GET['workspace'] ) ? sanitize_key( wp_unslash( $_GET['workspace'] ) ) : 'overview'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        return isset( $this->seo->workspaces()[ $workspace ] ) ? $workspace : 'overview';
    }

    public function render(): void {
        if ( ! current_user_can( 'manage_woocommerce' ) && ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'شما اجازه دسترسی به این بخش را ندارید.', 'k20-ai-press' ) );
        }
        $workspace = $this->current_workspace();
        $filters = array();
        foreach ( array( 'id','kind','limit','q','status','page','paged','per_page','category_id','query','entity_query','entity_paged','keyword_paged','content_paged' ) as $key ) {
            if ( isset( $_GET[ $key ] ) ) $filters[ $key ] = sanitize_text_field( wp_unslash( $_GET[ $key ] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        }
        $data = $this->seo->workspace( $workspace, $filters );
        $workspaces = $this->seo->workspaces();
        $settings = $this->seo->settings();
        $legacy_settings = $this->services->settings();
        require K20AI_PRESS_DIR . 'templates/admin-v3.php';
    }
}
