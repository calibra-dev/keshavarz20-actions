<?php

defined( 'ABSPATH' ) || exit;

/**
 * Deterministic data-integrity helpers.
 *
 * This class deliberately refuses to infer globally assigned identifiers from
 * local SKUs or names. Unknown data stays unknown until authoritative evidence
 * exists.
 */
final class K20AI_Data_Integrity {

    /** Remove invisible control/tag artifacts while preserving Persian ZWNJ (U+200C). */
    public static function strip_hidden_unicode( mixed $value ): string {
        $text = (string) $value;
        $clean = preg_replace(
            '/[\x{200B}\x{200D}-\x{200F}\x{202A}-\x{202E}\x{2060}-\x{206F}\x{FEFF}\x{E0000}-\x{E007F}]/u',
            '',
            $text
        );
        return is_string( $clean ) ? $clean : '';
    }

    public static function clean_text( mixed $value ): string {
        return sanitize_text_field( self::strip_hidden_unicode( $value ) );
    }

    public static function clean_textarea( mixed $value ): string {
        return sanitize_textarea_field( self::strip_hidden_unicode( $value ) );
    }

    public static function clean_html( mixed $value ): string {
        return wp_kses_post( self::strip_hidden_unicode( $value ) );
    }

    public static function normalize_gtin( mixed $value ): ?string {
        $raw = trim( (string) $value );
        if ( '' === $raw ) return null;
        $digits = preg_replace( '/[\s-]+/', '', $raw );
        if ( ! is_string( $digits ) || ! ctype_digit( $digits ) ) return null;
        if ( ! in_array( strlen( $digits ), array( 8, 12, 13, 14 ), true ) ) return null;
        return self::gtin_check_digit_valid( $digits ) ? $digits : null;
    }

    public static function gtin_check_digit_valid( string $digits ): bool {
        if ( ! ctype_digit( $digits ) || ! in_array( strlen( $digits ), array( 8, 12, 13, 14 ), true ) ) return false;
        $check = (int) substr( $digits, -1 );
        $body = substr( $digits, 0, -1 );
        $sum = 0;
        $weight = 3;
        for ( $i = strlen( $body ) - 1; $i >= 0; --$i ) {
            $sum += (int) $body[ $i ] * $weight;
            $weight = 3 === $weight ? 1 : 3;
        }
        return ( 10 - ( $sum % 10 ) ) % 10 === $check;
    }

    public static function normalize_mpn( mixed $value ): ?string {
        $mpn = trim( wp_strip_all_tags( self::strip_hidden_unicode( $value ) ) );
        if ( '' === $mpn ) return null;
        if ( mb_strlen( $mpn ) > 100 ) return null;
        return $mpn;
    }

    public static function redact_sensitive_text( mixed $value, int $max_length = 1000 ): string {
        $text = wp_strip_all_tags( self::strip_hidden_unicode( $value ) );
        $text = preg_replace( '/\bBearer\s+[A-Za-z0-9._~+\/-]+=*\b/i', 'Bearer [REDACTED]', $text ) ?? $text;
        $text = preg_replace( '/([?&](?:token|key|secret|password|api_key|access_token|refresh_token)=)[^&\s]+/i', '$1[REDACTED]', $text ) ?? $text;
        $text = preg_replace( '/\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/i', '[EMAIL-REDACTED]', $text ) ?? $text;
        $text = preg_replace( '/(?<![A-F0-9:])\b(?:\d{1,3}\.){3}\d{1,3}\b(?![A-F0-9:])/i', '[IP-REDACTED]', $text ) ?? $text;
        $max_length = max( 64, min( 10000, $max_length ) );
        return mb_strlen( $text ) > $max_length ? mb_substr( $text, 0, $max_length ) . '…' : $text;
    }

    public static function valid_http_url( mixed $value ): ?string {
        $url = esc_url_raw( trim( (string) $value ), array( 'http', 'https' ) );
        if ( '' === $url ) return null;
        $parts = wp_parse_url( $url );
        if ( ! is_array( $parts ) || empty( $parts['scheme'] ) || empty( $parts['host'] ) ) return null;
        if ( ! in_array( strtolower( (string) $parts['scheme'] ), array( 'http', 'https' ), true ) ) return null;
        if ( isset( $parts['user'] ) || isset( $parts['pass'] ) ) return null;
        return $url;
    }

    public static function valid_external_https_url( mixed $value ): ?string {
        $url = esc_url_raw( trim( (string) $value ), array( 'https' ) );
        if ( '' === $url || ! wp_http_validate_url( $url ) ) return null;
        $parts = wp_parse_url( $url );
        if ( ! is_array( $parts ) || 'https' !== strtolower( (string) ( $parts['scheme'] ?? '' ) ) || empty( $parts['host'] ) ) return null;
        $host = strtolower( rtrim( (string) $parts['host'], '.' ) );
        if ( in_array( $host, array( 'localhost', 'localhost.localdomain' ), true ) || str_ends_with( $host, '.local' ) ) return null;
        return $url;
    }
}
