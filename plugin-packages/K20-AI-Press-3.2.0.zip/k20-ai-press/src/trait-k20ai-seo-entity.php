<?php

defined( 'ABSPATH' ) || exit;

trait K20AI_SEO_Entity_Trait {
/** @return array<string,mixed> */
    public function bot_control(): array {
        $center = method_exists( $this->advanced, 'bot_control_center' ) ? $this->advanced->bot_control_center() : array( 'policy' => array(), 'entries' => array() );
        $preview = $this->legacy->execute( 'robots.preview', array(), true );
        $center['robots_preview'] = is_wp_error( $preview ) ? array( 'error' => $preview->get_error_message() ) : $preview;
        $center['virtual_active'] = '' !== trim( (string) get_option( 'k20ai_virtual_robots', '' ) );
        return $center;
    }

    /** @return array<string,mixed> */
    public function save_bot_policy( array $input ): array {
        $policy = $this->advanced->save_bot_policy( $input );
        $this->audit_log( 'bot.policy.update', 'settings', 0, array(), $policy, get_current_user_id() );
        return $this->bot_control();
    }

    /** @return array<string,mixed>|WP_Error */
    public function apply_bot_policy(): array|WP_Error {
        $result = $this->legacy->execute( 'robots.apply_virtual', array(), true );
        if ( ! is_wp_error( $result ) ) $this->audit_log( 'robots.apply_virtual', 'settings', 0, array(), $result, get_current_user_id() );
        return $result;
    }

    /** @return array<string,mixed>|WP_Error */
    public function rollback_bot_policy(): array|WP_Error {
        $result = $this->legacy->execute( 'robots.rollback', array(), true );
        if ( ! is_wp_error( $result ) ) $this->audit_log( 'robots.rollback', 'settings', 0, array(), $result, get_current_user_id() );
        return $result;
    }

    /** @return array<string,mixed> */
    public function entity_detail( string $kind, int $id ): array {
        global $wpdb;
        $t = K20AI_Database::tables();
        $profile = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t['seo_profiles']} WHERE entity_kind=%s AND entity_id=%d ORDER BY id DESC LIMIT 1", $kind, $id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        if ( ! $profile ) {
            if ( in_array( $kind, array( 'product','content_post','page','news','media' ), true ) ) {
                $evidence = $this->collect_post_evidence( $id );
                if ( $evidence ) {
                    $analysis = $this->analyzer->analyze( $evidence );
                    $this->persist_analysis( $evidence, $analysis );
                    $profile = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t['seo_profiles']} WHERE entity_key=%s", $evidence['entity_key'] ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                }
            }
        }
        if ( ! $profile ) return array();
        $issues = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t['seo_issues']} WHERE entity_kind=%s AND entity_id=%d AND status='open' ORDER BY FIELD(severity,'critical','warning','info'),id DESC LIMIT 200", $profile['entity_kind'], $profile['entity_id'] ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        foreach ( $issues as &$issue ) { $issue['evidence'] = $this->json( $issue['evidence'] ); $issue['suggested_fix'] = $this->json( $issue['suggested_fix'] ); }
        unset( $issue );
        $evidence = $this->json( $profile['payload'] );
        $profile['id'] = (int) $profile['id'];
        $profile['entity_id'] = (int) $profile['entity_id'];
        foreach ( array( 'score_total','score_technical','score_content','score_schema','score_media','score_commerce' ) as $key ) $profile[ $key ] = (int) $profile[ $key ];
        return array( 'profile' => $profile, 'evidence' => $evidence, 'issues' => $issues, 'schema' => $this->schema_preview( $evidence ), 'edit' => $this->edit_options( $evidence ) );
    }

    /**
     * Preview an entity edit with the same analyzer used for persisted scans.
     * No source data is mutated by this method.
     *
     * @return array<string,mixed>|WP_Error
     */
    public function preview_entity_update( string $kind, int $id, array $fields ): array|WP_Error {
        $kind = K20AI_Entity_Access::normalize_kind( $kind );
        if ( '' === $kind || ! K20AI_Entity_Access::can_edit( $kind, $id ) ) {
            return new WP_Error( 'forbidden_entity', __( 'برای پیش‌نمایش این موجودیت دسترسی کافی نیست.', 'k20-ai-press' ), array( 'status' => 403 ) );
        }
        $protected = K20AI_Security::protected_fields_error( $fields );
        if ( is_wp_error( $protected ) ) return $protected;
        $fields = $this->preflight_entity_update( $kind, $id, $fields );
        if ( is_wp_error( $fields ) ) return $fields;
        $evidence = $this->collect_post_evidence( $id, false );
        if ( ! $evidence ) return new WP_Error( 'not_found', __( 'موجودیت پیدا نشد.', 'k20-ai-press' ), array( 'status' => 404 ) );

        foreach ( array( 'title','seo_title','meta_description','focus_keyword','sku','gtin','mpn','model','price','stock_status','weight','length','width','height','short_description','description','excerpt','content' ) as $key ) {
            if ( array_key_exists( $key, $fields ) ) $evidence[ $key ] = $fields[ $key ];
        }
        if ( array_key_exists( 'categories', $fields ) && 'product' === $kind ) {
            $evidence['category_ids'] = array_values( array_filter( array_map( 'absint', (array) $fields['categories'] ) ) );
            $evidence['categories'] = array();
            foreach ( $evidence['category_ids'] as $term_id ) {
                $term = get_term( $term_id, 'product_cat' );
                if ( $term instanceof WP_Term ) $evidence['categories'][] = $term->name;
            }
        }
        if ( array_key_exists( 'brand_id', $fields ) && 'product' === $kind ) {
            $evidence['brand_term_ids'] = $fields['brand_id'] ? array( absint( $fields['brand_id'] ) ) : array();
            $brand_tax = $this->brand_taxonomy();
            $term = $brand_tax && ! empty( $evidence['brand_term_ids'][0] ) ? get_term( $evidence['brand_term_ids'][0], $brand_tax ) : null;
            $evidence['brand'] = $term instanceof WP_Term ? $term->name : '';
        }
        if ( isset( $fields['image_alts'] ) && is_array( $fields['image_alts'] ) ) {
            $alts = array();
            foreach ( (array) ( $evidence['image_items'] ?? array() ) as $item ) $alts[ (int) ( $item['id'] ?? 0 ) ] = trim( (string) ( $item['alt'] ?? '' ) );
            foreach ( $fields['image_alts'] as $image_id => $alt ) $alts[ absint( $image_id ) ] = trim( (string) $alt );
            $evidence['image_alt_count'] = count( array_filter( $alts, static fn( string $alt ): bool => '' !== $alt ) );
        }
        if ( 'product' === $kind ) {
            $short = (string) ( $evidence['short_description'] ?? '' );
            $description = (string) ( $evidence['description'] ?? '' );
            $evidence['content'] = trim( $short . "\n" . $description );
        }
        if ( array_key_exists( 'content', $evidence ) ) $evidence['word_count'] = $this->word_count( (string) $evidence['content'] );
        if ( array_key_exists( 'gtin', $fields ) ) {
            $evidence['gtin_raw'] = (string) $fields['gtin'];
            $evidence['gtin'] = K20AI_Data_Integrity::normalize_gtin( (string) $fields['gtin'] );
            $evidence['gtin_valid'] = null !== $evidence['gtin'];
        }

        $analysis = $this->analyzer->analyze( $evidence );
        return array(
            'profile' => array(
                'entity_kind' => $kind,
                'entity_id' => $id,
                'score_total' => (int) $analysis['total'],
                'score_technical' => (int) $analysis['technical'],
                'score_content' => (int) $analysis['content'],
                'score_schema' => (int) $analysis['schema'],
                'score_media' => (int) $analysis['media'],
                'score_commerce' => (int) $analysis['commerce'],
            ),
            'evidence' => $evidence,
            'issues' => (array) $analysis['issues'],
            'schema' => $this->schema_preview( $evidence ),
            'preview' => true,
        );
    }

    /** @return array<string,mixed> */
    private function edit_options( array $evidence ): array {
        $out = array( 'categories' => array(), 'brands' => array(), 'stock_statuses' => array(), 'attributes' => array() );
        if ( taxonomy_exists( 'product_cat' ) ) {
            $terms = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false, 'number' => 0 ) );
            if ( ! is_wp_error( $terms ) ) foreach ( $terms as $term ) $out['categories'][] = array( 'id' => $term->term_id, 'label' => $term->name );
        }
        $brand_tax = $this->brand_taxonomy();
        if ( $brand_tax ) {
            $terms = get_terms( array( 'taxonomy' => $brand_tax, 'hide_empty' => false, 'number' => 0 ) );
            if ( ! is_wp_error( $terms ) ) foreach ( $terms as $term ) $out['brands'][] = array( 'id' => $term->term_id, 'label' => $term->name );
        }
        $out['stock_statuses'] = array( array( 'value' => 'instock', 'label' => 'موجود' ), array( 'value' => 'outofstock', 'label' => 'ناموجود' ), array( 'value' => 'onbackorder', 'label' => 'پیش‌سفارش' ) );
        if ( function_exists( 'wc_get_attribute_taxonomies' ) ) {
            foreach ( (array) wc_get_attribute_taxonomies() as $attribute ) {
                $tax = wc_attribute_taxonomy_name( $attribute->attribute_name );
                $terms = taxonomy_exists( $tax ) ? get_terms( array( 'taxonomy' => $tax, 'hide_empty' => false, 'number' => 0 ) ) : array();
                $out['attributes'][] = array( 'taxonomy' => $tax, 'label' => $attribute->attribute_label ?: $attribute->attribute_name, 'terms' => is_wp_error( $terms ) ? array() : array_map( static fn( $term ) => array( 'id' => $term->term_id, 'label' => $term->name ), $terms ) );
            }
        }
        return $out;
    }

    /** @return array<string,mixed> */
    public function update_entity( string $kind, int $id, array $fields ): array|WP_Error {
        if ( ! K20AI_Security::can_edit_content() ) return new WP_Error( 'forbidden', __( 'دسترسی کافی نیست.', 'k20-ai-press' ), array( 'status' => 403 ) );
        if ( ! current_user_can( 'edit_post', $id ) ) return new WP_Error( 'forbidden_entity', __( 'برای ویرایش این موجودیت دسترسی کافی نیست.', 'k20-ai-press' ), array( 'status' => 403 ) );
        $protected = K20AI_Security::protected_fields_error( $fields );
        if ( is_wp_error( $protected ) ) return $protected;
        $fields = $this->preflight_entity_update( $kind, $id, $fields );
        if ( is_wp_error( $fields ) ) return $fields;
        if ( 'media' === $kind ) return $this->update_media( $id, $fields );

        $post = get_post( $id );
        if ( ! $post ) return new WP_Error( 'not_found', __( 'موجودیت پیدا نشد.', 'k20-ai-press' ), array( 'status' => 404 ) );
        $before = $this->collect_post_evidence( $id );
        $product = null;

        if ( 'product' === $kind ) {
            $product = function_exists( 'wc_get_product' ) ? wc_get_product( $id ) : null;
            if ( ! $product ) return new WP_Error( 'not_found', __( 'محصول پیدا نشد.', 'k20-ai-press' ), array( 'status' => 404 ) );
            try {
                if ( array_key_exists( 'description', $fields ) ) $product->set_description( $fields['description'] );
                if ( array_key_exists( 'short_description', $fields ) ) $product->set_short_description( $fields['short_description'] );
                if ( array_key_exists( 'sku', $fields ) ) $product->set_sku( $fields['sku'] );
                if ( array_key_exists( 'price', $fields ) ) { $product->set_regular_price( $fields['price'] ); $product->set_price( $fields['price'] ); }
                if ( array_key_exists( 'stock_status', $fields ) ) $product->set_stock_status( $fields['stock_status'] );
                foreach ( array( 'weight' => 'set_weight', 'length' => 'set_length', 'width' => 'set_width', 'height' => 'set_height' ) as $field => $setter ) {
                    if ( array_key_exists( $field, $fields ) && method_exists( $product, $setter ) ) $product->{$setter}( $fields[ $field ] );
                }
                if ( isset( $fields['attribute_terms'] ) && class_exists( 'WC_Product_Attribute' ) ) {
                    $current_attributes = (array) $product->get_attributes();
                    foreach ( $fields['attribute_terms'] as $taxonomy => $term_ids ) {
                        if ( isset( $current_attributes[ $taxonomy ] ) && $current_attributes[ $taxonomy ] instanceof WC_Product_Attribute ) {
                            $current_attributes[ $taxonomy ]->set_options( $term_ids );
                        } elseif ( $term_ids ) {
                            $attribute = new WC_Product_Attribute();
                            if ( function_exists( 'wc_attribute_taxonomy_id_by_name' ) ) $attribute->set_id( (int) wc_attribute_taxonomy_id_by_name( $taxonomy ) );
                            $attribute->set_name( $taxonomy );
                            $attribute->set_options( $term_ids );
                            $attribute->set_position( count( $current_attributes ) );
                            $attribute->set_visible( true );
                            $attribute->set_variation( false );
                            $current_attributes[ $taxonomy ] = $attribute;
                        }
                    }
                    $product->set_attributes( $current_attributes );
                }
                if ( array_key_exists( 'gtin', $fields ) && method_exists( $product, 'set_global_unique_id' ) ) $product->set_global_unique_id( $fields['gtin'] );
                $product->save();
            } catch ( Throwable $error ) {
                return new WP_Error( 'product_write_failed', __( 'ذخیره محصول متوقف شد؛ هیچ خطای اعتبارسنجی نادیده گرفته نشد.', 'k20-ai-press' ), array( 'status' => 500, 'detail' => sanitize_text_field( $error->getMessage() ) ) );
            }

            foreach ( (array) ( $fields['attribute_terms'] ?? array() ) as $taxonomy => $term_ids ) {
                $term_result = wp_set_post_terms( $id, $term_ids, $taxonomy, false );
                if ( is_wp_error( $term_result ) ) return $term_result;
            }
            if ( array_key_exists( 'categories', $fields ) ) {
                $term_result = wp_set_post_terms( $id, $fields['categories'], 'product_cat', false );
                if ( is_wp_error( $term_result ) ) return $term_result;
            }
            if ( array_key_exists( 'brand_id', $fields ) ) {
                $brand_tax = $this->brand_taxonomy();
                if ( $brand_tax ) {
                    $term_result = wp_set_post_terms( $id, $fields['brand_id'] ? array( $fields['brand_id'] ) : array(), $brand_tax, false );
                    if ( is_wp_error( $term_result ) ) return $term_result;
                }
            }
            if ( array_key_exists( 'gtin', $fields ) && ! method_exists( $product, 'set_global_unique_id' ) ) update_post_meta( $id, '_global_unique_id', $fields['gtin'] );
            if ( array_key_exists( 'mpn', $fields ) ) update_post_meta( $id, '_mpn', $fields['mpn'] );
            if ( array_key_exists( 'model', $fields ) ) update_post_meta( $id, '_model', $fields['model'] );
            foreach ( (array) ( $fields['image_alts'] ?? array() ) as $image_id => $alt ) update_post_meta( (int) $image_id, '_wp_attachment_image_alt', $alt );
        }

        $post_update = array( 'ID' => $id );
        if ( array_key_exists( 'title', $fields ) ) $post_update['post_title'] = $fields['title'];
        if ( 'product' !== $kind && array_key_exists( 'content', $fields ) ) $post_update['post_content'] = $fields['content'];
        if ( 'product' !== $kind && array_key_exists( 'excerpt', $fields ) ) $post_update['post_excerpt'] = $fields['excerpt'];
        if ( count( $post_update ) > 1 ) {
            $post_result = wp_update_post( $post_update, true );
            if ( is_wp_error( $post_result ) ) return $post_result;
        }
        if ( array_key_exists( 'seo_title', $fields ) ) {
            update_post_meta( $id, '_k20ai_title', $fields['seo_title'] );
            if ( defined( 'WPSEO_VERSION' ) ) update_post_meta( $id, '_yoast_wpseo_title', $fields['seo_title'] );
        }
        if ( array_key_exists( 'meta_description', $fields ) ) {
            update_post_meta( $id, '_k20ai_description', $fields['meta_description'] );
            if ( defined( 'WPSEO_VERSION' ) ) update_post_meta( $id, '_yoast_wpseo_metadesc', $fields['meta_description'] );
        }
        if ( array_key_exists( 'focus_keyword', $fields ) ) {
            update_post_meta( $id, '_k20ai_focus_keyword', $fields['focus_keyword'] );
            if ( defined( 'WPSEO_VERSION' ) ) update_post_meta( $id, '_yoast_wpseo_focuskw', $fields['focus_keyword'] );
        }

        $after = $this->collect_post_evidence( $id );
        $analysis = $this->analyzer->analyze( $after );
        $this->persist_analysis( $after, $analysis );
        $this->log_action_event( 'entity.update', $kind, $id, $before, $after );
        return $this->entity_detail( $kind, $id );
    }

    /** @return array<string,mixed>|WP_Error */
    private function preflight_entity_update( string $kind, int $id, array $fields ): array|WP_Error {
        if ( ! in_array( $kind, array( 'product','content_post','page','news','media' ), true ) ) return new WP_Error( 'unsupported_entity', __( 'این نوع موجودیت از ویرایش مستقیم پشتیبانی نمی‌کند.', 'k20-ai-press' ), array( 'status' => 422 ) );
        $allowed = 'media' === $kind
            ? array( 'alt','title' )
            : ( 'product' === $kind
                ? array( 'title','seo_title','meta_description','focus_keyword','description','short_description','sku','price','stock_status','weight','length','width','height','attribute_terms','categories','brand_id','gtin','mpn','model','image_alts' )
                : array( 'title','seo_title','meta_description','focus_keyword','content','excerpt' ) );
        $unknown = array_values( array_diff( array_keys( $fields ), $allowed ) );
        if ( $unknown ) return new WP_Error( 'unknown_entity_field', __( 'فیلد خارج از قرارداد ویرایش ارسال شده است.', 'k20-ai-press' ), array( 'status' => 422, 'fields' => $unknown ) );
        $safe = array();
        foreach ( array( 'title','seo_title','focus_keyword','sku','model','alt' ) as $key ) if ( array_key_exists( $key, $fields ) ) $safe[ $key ] = K20AI_Data_Integrity::clean_text( $fields[ $key ] );
        foreach ( array( 'meta_description','excerpt','short_description' ) as $key ) if ( array_key_exists( $key, $fields ) ) $safe[ $key ] = K20AI_Data_Integrity::clean_textarea( $fields[ $key ] );
        foreach ( array( 'content','description' ) as $key ) if ( array_key_exists( $key, $fields ) ) $safe[ $key ] = K20AI_Data_Integrity::clean_html( $fields[ $key ] );

        if ( 'media' === $kind ) return $safe;
        if ( 'product' !== $kind ) return $safe;
        $product = function_exists( 'wc_get_product' ) ? wc_get_product( $id ) : null;
        if ( ! $product ) return new WP_Error( 'not_found', __( 'محصول پیدا نشد.', 'k20-ai-press' ), array( 'status' => 404 ) );

        if ( array_key_exists( 'sku', $safe ) && '' !== $safe['sku'] && function_exists( 'wc_get_product_id_by_sku' ) ) {
            $existing = (int) wc_get_product_id_by_sku( $safe['sku'] );
            if ( $existing && $existing !== $id ) return new WP_Error( 'duplicate_sku', __( 'SKU قبلاً به محصول دیگری اختصاص داده شده است.', 'k20-ai-press' ), array( 'status' => 409, 'product_id' => $existing ) );
        }
        foreach ( array( 'weight','length','width','height' ) as $key ) {
            if ( ! array_key_exists( $key, $fields ) ) continue;
            $raw = trim( (string) $fields[ $key ] );
            if ( '' === $raw ) { $safe[ $key ] = ''; continue; }
            $decimal = function_exists( 'wc_format_decimal' ) ? wc_format_decimal( $raw ) : $raw;
            if ( ! is_numeric( $decimal ) || (float) $decimal < 0 ) return new WP_Error( 'invalid_dimension', __( 'وزن و ابعاد باید عدد نامنفی باشند.', 'k20-ai-press' ), array( 'status' => 422, 'field' => $key ) );
            $safe[ $key ] = (string) $decimal;
        }
        if ( array_key_exists( 'price', $fields ) ) {
            $raw_price = trim( (string) $fields['price'] );
            if ( '' === $raw_price ) $safe['price'] = '';
            else {
                $decimal_price = function_exists( 'wc_format_decimal' ) ? wc_format_decimal( $raw_price ) : $raw_price;
                if ( ! is_numeric( $decimal_price ) || (float) $decimal_price < 0 ) return new WP_Error( 'invalid_price', __( 'قیمت باید عدد نامنفی باشد.', 'k20-ai-press' ), array( 'status' => 422, 'field' => 'price' ) );
                $safe['price'] = (string) $decimal_price;
            }
        }
        if ( array_key_exists( 'stock_status', $fields ) ) {
            $stock_status = sanitize_key( (string) $fields['stock_status'] );
            if ( ! in_array( $stock_status, array( 'instock','outofstock','onbackorder' ), true ) ) return new WP_Error( 'invalid_stock_status', __( 'وضعیت موجودی معتبر نیست.', 'k20-ai-press' ), array( 'status' => 422, 'field' => 'stock_status' ) );
            $safe['stock_status'] = $stock_status;
        }
        if ( array_key_exists( 'gtin', $fields ) ) {
            $raw = trim( K20AI_Data_Integrity::clean_text( $fields['gtin'] ) );
            if ( '' === $raw ) $safe['gtin'] = '';
            else {
                $gtin = K20AI_Data_Integrity::normalize_gtin( $raw );
                if ( null === $gtin ) return new WP_Error( 'invalid_gtin', __( 'GTIN باید 8، 12، 13 یا 14 رقم و دارای رقم کنترل معتبر GS1 باشد.', 'k20-ai-press' ), array( 'status' => 422 ) );
                $safe['gtin'] = $gtin;
            }
        }
        if ( array_key_exists( 'mpn', $fields ) ) {
            $raw = trim( K20AI_Data_Integrity::strip_hidden_unicode( $fields['mpn'] ) );
            if ( '' === $raw ) $safe['mpn'] = '';
            else {
                $mpn = K20AI_Data_Integrity::normalize_mpn( $raw );
                if ( null === $mpn ) return new WP_Error( 'invalid_mpn', __( 'MPN معتبر نیست یا بیش از 100 نویسه دارد.', 'k20-ai-press' ), array( 'status' => 422 ) );
                $safe['mpn'] = $mpn;
            }
        }
        if ( array_key_exists( 'categories', $fields ) ) {
            $safe['categories'] = array_values( array_unique( array_filter( array_map( 'absint', (array) $fields['categories'] ) ) ) );
            foreach ( $safe['categories'] as $term_id ) if ( ! term_exists( $term_id, 'product_cat' ) ) return new WP_Error( 'invalid_category', __( 'یکی از دسته‌های محصول وجود ندارد.', 'k20-ai-press' ), array( 'status' => 422, 'term_id' => $term_id ) );
        }
        if ( array_key_exists( 'brand_id', $fields ) ) {
            $safe['brand_id'] = absint( $fields['brand_id'] );
            $brand_tax = $this->brand_taxonomy();
            if ( $safe['brand_id'] && ( ! $brand_tax || ! term_exists( $safe['brand_id'], $brand_tax ) ) ) return new WP_Error( 'invalid_brand', __( 'برند انتخاب‌شده وجود ندارد.', 'k20-ai-press' ), array( 'status' => 422 ) );
        }
        if ( array_key_exists( 'attribute_terms', $fields ) ) {
            $safe['attribute_terms'] = array();
            foreach ( (array) $fields['attribute_terms'] as $taxonomy => $ids ) {
                $taxonomy = sanitize_key( (string) $taxonomy );
                if ( ! str_starts_with( $taxonomy, 'pa_' ) || ! taxonomy_exists( $taxonomy ) ) return new WP_Error( 'invalid_attribute_taxonomy', __( 'Taxonomy ویژگی محصول معتبر نیست.', 'k20-ai-press' ), array( 'status' => 422, 'taxonomy' => $taxonomy ) );
                $term_ids = array_values( array_unique( array_filter( array_map( 'absint', (array) $ids ) ) ) );
                foreach ( $term_ids as $term_id ) if ( ! term_exists( $term_id, $taxonomy ) ) return new WP_Error( 'invalid_attribute_term', __( 'یکی از مقادیر ویژگی محصول وجود ندارد.', 'k20-ai-press' ), array( 'status' => 422, 'taxonomy' => $taxonomy, 'term_id' => $term_id ) );
                $safe['attribute_terms'][ $taxonomy ] = $term_ids;
            }
        }
        if ( array_key_exists( 'image_alts', $fields ) ) {
            $allowed_images = array_map( 'absint', array_values( array_unique( array_filter( array_merge( array( $product->get_image_id() ), $product->get_gallery_image_ids() ) ) ) ) );
            $safe['image_alts'] = array();
            foreach ( (array) $fields['image_alts'] as $image_id => $alt ) {
                $image_id = absint( $image_id );
                if ( ! $image_id || ! in_array( $image_id, $allowed_images, true ) ) return new WP_Error( 'invalid_product_image', __( 'ویرایش ALT فقط برای تصویر اصلی یا گالری همین محصول مجاز است.', 'k20-ai-press' ), array( 'status' => 422, 'attachment_id' => $image_id ) );
                $safe['image_alts'][ $image_id ] = K20AI_Data_Integrity::clean_text( $alt );
            }
        }
        return $safe;
    }

    /** @return array<string,mixed>|WP_Error */
    private function update_media( int $id, array $fields ): array|WP_Error {
        $post = get_post( $id );
        if ( ! $post || 'attachment' !== $post->post_type ) return new WP_Error( 'not_found', __( 'رسانه پیدا نشد.', 'k20-ai-press' ), array( 'status' => 404 ) );
        $before = $this->collect_media_evidence( $id );
        if ( array_key_exists( 'alt', $fields ) ) update_post_meta( $id, '_wp_attachment_image_alt', sanitize_text_field( $fields['alt'] ) );
        if ( array_key_exists( 'title', $fields ) ) wp_update_post( array( 'ID' => $id, 'post_title' => sanitize_text_field( $fields['title'] ) ) );
        $after = $this->collect_media_evidence( $id );
        $analysis = $this->analyzer->analyze( $after );
        $this->persist_analysis( $after, $analysis );
        $this->log_action_event( 'media.update', 'media', $id, $before, $after );
        return $this->entity_detail( 'media', $id );
    }

    /** @return array<string,mixed>|WP_Error */
    public function propose_safe_fix( string $kind, int $id, ?int $user_id = null ): array|WP_Error {
        if ( ! K20AI_Security::can_edit_content() || ! current_user_can( 'edit_post', $id ) ) return new WP_Error( 'forbidden_entity', __( 'برای ویرایش این موجودیت دسترسی کافی نیست.', 'k20-ai-press' ), array( 'status' => 403 ) );
        global $wpdb;
        $t = K20AI_Database::tables();
        $detail = $this->entity_detail( $kind, $id );
        if ( ! $detail ) return new WP_Error( 'not_found', __( 'موجودیت پیدا نشد.', 'k20-ai-press' ), array( 'status' => 404 ) );
        $before = $detail['evidence'];
        $after = array();
        $action_type = 'seo_profile';
        if ( 'media' === $kind && empty( $before['alt'] ) ) {
            $parent_title = ! empty( $before['parent_id'] ) ? get_the_title( (int) $before['parent_id'] ) : '';
            $suggested = trim( (string) ( $parent_title ?: $before['title'] ) );
            if ( '' === $suggested ) return new WP_Error( 'no_safe_fix', __( 'برای ساخت ALT امن، عنوان معتبر پیدا نشد.', 'k20-ai-press' ), array( 'status' => 422 ) );
            $after = array( 'alt' => $suggested );
            $action_type = 'media_alt';
        } elseif ( in_array( $kind, array( 'product','content_post','page','news' ), true ) && empty( $before['meta_description'] ) ) {
            $plain = wp_strip_all_tags( (string) ( $before['content'] ?? '' ) );
            $suggested = wp_trim_words( $plain, 26, '' );
            if ( mb_strlen( $suggested ) < 40 ) return new WP_Error( 'no_safe_fix', __( 'متن کافی برای پیشنهاد متا وجود ندارد.', 'k20-ai-press' ), array( 'status' => 422 ) );
            $after = array( 'meta_description' => $suggested );
            $action_type = 'meta_description';
        } else {
            return new WP_Error( 'no_safe_fix', __( 'برای این مورد اصلاح کم‌ریسک خودکار قابل اثبات پیدا نشد؛ نیازمند بازبینی انسانی است.', 'k20-ai-press' ), array( 'status' => 422 ) );
        }
        $row = array(
            'recommendation_id' => null, 'action_type' => $action_type, 'entity_kind' => $kind, 'entity_id' => $id, 'risk' => 'low', 'status' => 'proposed',
            'before_payload' => wp_json_encode( $before ), 'after_payload' => wp_json_encode( $after ), 'proposed_by' => $user_id,
            'created_at' => current_time( 'mysql', true ), 'updated_at' => current_time( 'mysql', true ),
        );
        $wpdb->insert( $t['seo_actions'], $row );
        $action_id = (int) $wpdb->insert_id;
        if ( ! $this->settings()['require_approval'] && $this->settings()['auto_safe_fixes'] ) {
            $wpdb->update( $t['seo_actions'], array( 'status' => 'approved', 'reviewed_by' => $user_id, 'reviewed_at' => current_time( 'mysql', true ) ), array( 'id' => $action_id ) );
            return $this->apply_action( $action_id, $user_id );
        }
        return $this->action( $action_id );
    }

    /** @return array<string,mixed> */
    public function action( int $id ): array {
        global $wpdb;
        $t = K20AI_Database::tables();
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t['seo_actions']} WHERE id=%d", $id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        if ( ! $row ) return array();
        $row['id'] = (int) $row['id']; $row['entity_id'] = (int) $row['entity_id'];
        $row['before_payload'] = $this->json( $row['before_payload'] ); $row['after_payload'] = $this->json( $row['after_payload'] );
        return $row;
    }

    /** @return array<string,mixed>|WP_Error */
    public function review_action( int $id, string $decision, ?string $note, ?int $user_id ): array|WP_Error {
        global $wpdb;
        $t = K20AI_Database::tables();
        $action = $this->action( $id );
        if ( ! $action ) return new WP_Error( 'not_found', __( 'اقدام پیدا نشد.', 'k20-ai-press' ), array( 'status' => 404 ) );
        if ( ! current_user_can( 'edit_post', (int) $action['entity_id'] ) ) return new WP_Error( 'forbidden_entity', __( 'برای ویرایش موجودیت هدف این اقدام دسترسی کافی نیست.', 'k20-ai-press' ), array( 'status' => 403 ) );
        if ( 'proposed' !== $action['status'] ) return new WP_Error( 'state_conflict', __( 'این اقدام قبلاً بازبینی شده است.', 'k20-ai-press' ), array( 'status' => 409 ) );
        $status = 'approve' === $decision ? 'approved' : 'rejected';
        $wpdb->update( $t['seo_actions'], array( 'status' => $status, 'reviewed_by' => $user_id, 'review_note' => sanitize_textarea_field( (string) $note ), 'reviewed_at' => current_time( 'mysql', true ), 'updated_at' => current_time( 'mysql', true ) ), array( 'id' => $id ) );
        return $this->action( $id );
    }

    /** @return array<string,mixed>|WP_Error */
    public function apply_action( int $id, ?int $user_id ): array|WP_Error {
        global $wpdb;
        $t = K20AI_Database::tables();
        $action = $this->action( $id );
        if ( ! $action ) return new WP_Error( 'not_found', __( 'اقدام پیدا نشد.', 'k20-ai-press' ), array( 'status' => 404 ) );
        if ( ! current_user_can( 'edit_post', (int) $action['entity_id'] ) ) return new WP_Error( 'forbidden_entity', __( 'برای ویرایش موجودیت هدف این اقدام دسترسی کافی نیست.', 'k20-ai-press' ), array( 'status' => 403 ) );
        if ( 'approved' !== $action['status'] ) return new WP_Error( 'approval_required', __( 'اقدام باید قبل از اجرا تأیید شود.', 'k20-ai-press' ), array( 'status' => 409 ) );
        $current = $this->entity_detail( $action['entity_kind'], (int) $action['entity_id'] );
        if ( ! $current ) return new WP_Error( 'not_found', __( 'موجودیت هدف پیدا نشد.', 'k20-ai-press' ), array( 'status' => 404 ) );
        $before_hash = hash( 'sha256', wp_json_encode( $this->stable_action_snapshot( $action['before_payload'] ) ) );
        $current_hash = hash( 'sha256', wp_json_encode( $this->stable_action_snapshot( $current['evidence'] ) ) );
        if ( $before_hash !== $current_hash ) {
            $wpdb->update( $t['seo_actions'], array( 'status' => 'failed', 'last_error' => 'Entity changed after proposal', 'updated_at' => current_time( 'mysql', true ) ), array( 'id' => $id ) );
            return new WP_Error( 'action_conflict', __( 'موجودیت بعد از ساخت پیشنهاد تغییر کرده است؛ برای جلوگیری از بازنویسی اشتباه، اجرا متوقف شد.', 'k20-ai-press' ), array( 'status' => 409 ) );
        }
        $result = $this->update_entity( $action['entity_kind'], (int) $action['entity_id'], $action['after_payload'] );
        if ( is_wp_error( $result ) ) {
            $wpdb->update( $t['seo_actions'], array( 'status' => 'failed', 'last_error' => $result->get_error_message(), 'updated_at' => current_time( 'mysql', true ) ), array( 'id' => $id ) );
            return $result;
        }
        $wpdb->update( $t['seo_actions'], array( 'status' => 'applied', 'applied_by' => $user_id, 'applied_at' => current_time( 'mysql', true ), 'updated_at' => current_time( 'mysql', true ) ), array( 'id' => $id ) );
        return $this->action( $id );
    }

    /** @return array<string,mixed>|WP_Error */
    public function rollback_action( int $id, ?int $user_id ): array|WP_Error {
        global $wpdb;
        $t = K20AI_Database::tables();
        $action = $this->action( $id );
        if ( ! $action ) return new WP_Error( 'not_found', __( 'اقدام پیدا نشد.', 'k20-ai-press' ), array( 'status' => 404 ) );
        if ( ! current_user_can( 'edit_post', (int) $action['entity_id'] ) ) return new WP_Error( 'forbidden_entity', __( 'برای ویرایش موجودیت هدف این اقدام دسترسی کافی نیست.', 'k20-ai-press' ), array( 'status' => 403 ) );
        if ( 'applied' !== $action['status'] ) return new WP_Error( 'state_conflict', __( 'فقط اقدام اجراشده قابل بازگشت است.', 'k20-ai-press' ), array( 'status' => 409 ) );
        $result = $this->update_entity( $action['entity_kind'], (int) $action['entity_id'], $this->rollback_fields( $action ) );
        if ( is_wp_error( $result ) ) return $result;
        $wpdb->update( $t['seo_actions'], array( 'status' => 'rolled_back', 'applied_by' => $user_id, 'rolled_back_at' => current_time( 'mysql', true ), 'updated_at' => current_time( 'mysql', true ) ), array( 'id' => $id ) );
        return $this->action( $id );
    }

    /** @return array<string,mixed> */
    private function rollback_fields( array $action ): array {
        $before = (array) $action['before_payload'];
        if ( 'media_alt' === $action['action_type'] ) return array( 'alt' => $before['alt'] ?? '' );
        if ( 'meta_description' === $action['action_type'] ) return array( 'meta_description' => $before['meta_description'] ?? '' );
        return array();
    }

    /** @return array<string,mixed> */
    private function stable_action_snapshot( array $evidence ): array {
        $keys = array( 'kind','entity_id','title','meta_description','alt','sku','gtin','mpn','brand','categories','price','stock_status','stock_quantity','modified_at' );
        $out = array();
        foreach ( $keys as $key ) if ( array_key_exists( $key, $evidence ) ) $out[ $key ] = $evidence[ $key ];
        return $out;
    }

    /** @return array<string,mixed>|WP_Error */
    public function import_keywords( array $rows, string $source = 'manual' ): array|WP_Error {
        global $wpdb;
        $t = K20AI_Database::tables();
        $source = sanitize_key( $source ?: 'manual' );
        $inserted = 0;
        foreach ( array_slice( $rows, 0, 5000 ) as $raw ) {
            if ( ! is_array( $raw ) ) continue;
            $phrase = sanitize_text_field( (string) ( $raw['phrase'] ?? $raw['query'] ?? '' ) );
            if ( '' === $phrase ) continue;
            $target_url = isset( $raw['target_url'] ) ? esc_url_raw( (string) $raw['target_url'] ) : null;
            $row = array(
                'phrase' => $phrase,
                'target_url' => $target_url,
                'target_kind' => isset( $raw['target_kind'] ) ? sanitize_key( $raw['target_kind'] ) : null,
                'target_id' => isset( $raw['target_id'] ) ? absint( $raw['target_id'] ) : null,
                'search_engine' => sanitize_key( (string) ( $raw['search_engine'] ?? 'google' ) ),
                'country' => isset( $raw['country'] ) ? mb_substr( sanitize_text_field( $raw['country'] ), 0, 8 ) : null,
                'device' => isset( $raw['device'] ) ? mb_substr( sanitize_key( $raw['device'] ), 0, 16 ) : null,
                'current_position' => is_numeric( $raw['current_position'] ?? null ) ? (float) $raw['current_position'] : null,
                'previous_position' => is_numeric( $raw['previous_position'] ?? null ) ? (float) $raw['previous_position'] : null,
                'impressions' => is_numeric( $raw['impressions'] ?? null ) ? max( 0, (int) $raw['impressions'] ) : null,
                'clicks' => is_numeric( $raw['clicks'] ?? null ) ? max( 0, (int) $raw['clicks'] ) : null,
                'ctr' => is_numeric( $raw['ctr'] ?? null ) ? (float) $raw['ctr'] : null,
                'source' => $source,
                'checked_at' => isset( $raw['checked_at'] ) ? sanitize_text_field( $raw['checked_at'] ) : current_time( 'mysql', true ),
                'created_at' => current_time( 'mysql', true ),
                'updated_at' => current_time( 'mysql', true ),
            );
            // No fake dedupe assumption: phrase + target + engine + device + country is the observation identity.
            $existing = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t['seo_keywords']} WHERE phrase=%s AND COALESCE(target_url,'')=%s AND search_engine=%s AND COALESCE(country,'')=%s AND COALESCE(device,'')=%s LIMIT 1", $phrase, (string) $target_url, $row['search_engine'], (string) $row['country'], (string) $row['device'] ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            if ( $existing ) { unset( $row['created_at'] ); $wpdb->update( $t['seo_keywords'], $row, array( 'id' => (int) $existing ) ); }
            else $wpdb->insert( $t['seo_keywords'], $row );
            ++$inserted;
        }
        $settings = $this->settings();
        if ( str_contains( $source, 'gsc' ) || str_contains( $source, 'search_console' ) ) $settings['gsc_imported_at'] = current_time( 'mysql', true );
        $settings['rank_imported_at'] = current_time( 'mysql', true );
        update_option( 'k20ai_v3_settings', $settings, false );
        return array( 'imported' => $inserted, 'source' => $source );
    }

    /** @return array<string,mixed>|WP_Error */
    public function add_competitor( string $domain, string $label = '', array $metrics = array(), string $source = 'manual' ): array|WP_Error {
        global $wpdb;
        $t = K20AI_Database::tables();
        $domain = strtolower( trim( preg_replace( '#^https?://#', '', sanitize_text_field( $domain ) ), '/' ) );
        if ( ! preg_match( '/^[a-z0-9.-]+\.[a-z]{2,}$/i', $domain ) ) return new WP_Error( 'invalid_domain', __( 'دامنه معتبر نیست.', 'k20-ai-press' ), array( 'status' => 422 ) );
        $now = current_time( 'mysql', true );
        $existing = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t['seo_competitors']} WHERE domain=%s", $domain ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $row = array( 'domain' => $domain, 'label' => sanitize_text_field( $label ), 'enabled' => 1, 'metrics' => wp_json_encode( $metrics ), 'source' => sanitize_key( $source ), 'last_synced_at' => $metrics ? $now : null, 'updated_at' => $now );
        if ( $existing ) { $wpdb->update( $t['seo_competitors'], $row, array( 'id' => (int) $existing ) ); $id = (int) $existing; }
        else { $row['created_at'] = $now; $wpdb->insert( $t['seo_competitors'], $row ); $id = (int) $wpdb->insert_id; }
        return (array) $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t['seo_competitors']} WHERE id=%d", $id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
    }

    public function refresh_market_radar(): array {
        $settings = $this->settings();
        $sources = (array) $settings['radar_sources'];
        $count = 0;
        if ( $sources ) {
            require_once ABSPATH . WPINC . '/feed.php';
            foreach ( array_slice( $sources, 0, 20 ) as $source ) {
                if ( ! wp_http_validate_url( $source ) ) continue;
                $feed = fetch_feed( $source );
                if ( is_wp_error( $feed ) ) continue;
                $max = $feed->get_item_quantity( 15 );
                foreach ( $feed->get_items( 0, $max ) as $item ) {
                    $title = sanitize_text_field( $item->get_title() );
                    $url = esc_url_raw( $item->get_permalink() );
                    $date = $item->get_date( 'Y-m-d H:i:s' ) ?: current_time( 'mysql', true );
                    if ( ! $title || ! $url ) continue;
                    $this->persist_signal( 'rss', 'news', $title, $url, array( 'feed' => $source, 'date' => $date ), 50, $date );
                    ++$count;
                }
            }
        }
        return array( 'sources' => count( $sources ), 'observed' => $count, 'refreshed_at' => gmdate( DATE_ATOM ) );
    }

    private function persist_signal( string $source, string $type, string $subject, string $url, array $payload, int $score, string $observed ): void {
        global $wpdb;
        $t = K20AI_Database::tables();
        $fingerprint = hash( 'sha256', $source . '|' . $type . '|' . $url . '|' . $subject );
        $row = array( 'source' => $source, 'signal_type' => $type, 'subject' => $subject, 'source_url' => $url, 'fingerprint' => $fingerprint, 'payload' => wp_json_encode( $payload ), 'score' => max( 0, min( 100, $score ) ), 'observed_at' => $observed, 'created_at' => current_time( 'mysql', true ) );
        $existing = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t['seo_signals']} WHERE fingerprint=%s", $fingerprint ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        if ( ! $existing ) $wpdb->insert( $t['seo_signals'], $row );
    }

    /** @return array<string,mixed> */
    public function export_report( string $format = 'csv' ): array {
        global $wpdb;
        $t = K20AI_Database::tables();
        $source_total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t['seo_profiles']}" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $rows = $wpdb->get_results( "SELECT p.entity_kind,p.entity_id,p.title,p.url,p.score_total,p.score_technical,p.score_content,p.score_schema,p.score_media,p.score_commerce,p.analyzed_at,(SELECT COUNT(*) FROM {$t['seo_issues']} i WHERE i.entity_kind=p.entity_kind AND i.entity_id=p.entity_id AND i.status='open') issues FROM {$t['seo_profiles']} p ORDER BY p.score_total ASC LIMIT 10000", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $rows = array_values( array_filter( (array) $rows, static function( array $row ): bool {
            $kind = sanitize_key( (string) ( $row['entity_kind'] ?? '' ) );
            $id = absint( $row['entity_id'] ?? 0 );
            if ( in_array( $kind, K20AI_Entity_Access::supported_kinds(), true ) ) {
                return K20AI_Entity_Access::can_read( $kind, $id );
            }
            return true;
        } ) );
        $meta = array( 'source_total' => $source_total, 'visible_rows' => count( $rows ), 'truncated' => $source_total > 10000 );
        if ( 'json' === $format ) {
            return array( 'mime' => 'application/json; charset=utf-8', 'filename' => 'k20-ai-press-seo-' . gmdate( 'Ymd-His' ) . '.json', 'body' => wp_json_encode( array( 'meta' => $meta, 'rows' => $rows ), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ), 'meta' => $meta );
        }
        $headers = array( 'entity_kind','entity_id','title','url','score_total','score_technical','score_content','score_schema','score_media','score_commerce','issues','analyzed_at' );
        $lines = array( implode( ',', $headers ) );
        foreach ( $rows as $row ) {
            $cells = array();
            foreach ( $headers as $header ) {
                $value = str_replace( '"', '""', (string) ( $row[ $header ] ?? '' ) );
                $cells[] = '"' . $value . '"';
            }
            $lines[] = implode( ',', $cells );
        }
        return array( 'mime' => 'text/csv; charset=utf-8', 'filename' => 'k20-ai-press-seo-' . gmdate( 'Ymd-His' ) . '.csv', 'body' => "\xEF\xBB\xBF" . implode( "\r\n", $lines ), 'meta' => $meta );
    }

    /** @return array<string,mixed> */
    public function schema_preview( array $evidence ): array {
        $kind = (string) ( $evidence['kind'] ?? '' );
        if ( 'product' === $kind ) {
            $schema = array( '@context' => 'https://schema.org', '@type' => 'Product', 'name' => (string) ( $evidence['title'] ?? '' ), 'url' => (string) ( $evidence['url'] ?? '' ) );
            if ( ! empty( $evidence['sku'] ) ) $schema['sku'] = (string) $evidence['sku'];
            if ( ! empty( $evidence['gtin'] ) ) $schema['gtin'] = (string) $evidence['gtin'];
            if ( ! empty( $evidence['mpn'] ) ) $schema['mpn'] = (string) $evidence['mpn'];
            if ( ! empty( $evidence['brand'] ) ) $schema['brand'] = array( '@type' => 'Brand', 'name' => (string) $evidence['brand'] );
            $images = array_map( 'wp_get_attachment_url', (array) ( $evidence['image_ids'] ?? array() ) );
            $images = array_values( array_filter( $images ) );
            if ( $images ) $schema['image'] = $images;
            if ( '' !== (string) ( $evidence['price'] ?? '' ) ) {
                $schema['offers'] = array( '@type' => 'Offer', 'price' => (string) $evidence['price'], 'priceCurrency' => function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : '', 'availability' => 'instock' === ( $evidence['stock_status'] ?? '' ) ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock', 'url' => (string) ( $evidence['url'] ?? '' ) );
            }
            return $schema;
        }
        if ( in_array( $kind, array( 'content_post','news','page' ), true ) ) {
            $schema = array( '@context' => 'https://schema.org', '@type' => 'page' === $kind ? 'WebPage' : 'Article', 'headline' => (string) ( $evidence['title'] ?? '' ), 'url' => (string) ( $evidence['url'] ?? '' ) );
            if ( ! empty( $evidence['author_id'] ) ) $schema['author'] = array( '@type' => 'Person', 'name' => get_the_author_meta( 'display_name', (int) $evidence['author_id'] ) );
            return $schema;
        }
        return array( '@context' => 'https://schema.org', '@type' => 'WebPage', 'name' => (string) ( $evidence['title'] ?? '' ), 'url' => (string) ( $evidence['url'] ?? '' ) );
    }

    /** @return array<int,int> */
    private function site_product_ids( int $limit = 5000 ): array {
        return $this->site_post_ids( 'product', $limit );
    }

    /** @return array<int,int> */
    private function site_media_ids( int $limit = 5000 ): array {
        return $this->site_post_ids( 'attachment', $limit );
    }

    /** @return array<int,int> */
    private function site_post_ids( string $post_type, int $limit = 5000 ): array {
        global $wpdb;
        $limit = max( 1, min( 5000, $limit ) );
        $object = get_post_type_object( $post_type );
        $can_read_private = $object && isset( $object->cap->read_private_posts ) && current_user_can( $object->cap->read_private_posts );
        $where_status = $can_read_private ? "post_status NOT IN ('trash','auto-draft')" : ( 'attachment' === $post_type ? "post_status IN ('inherit','publish')" : "post_status='publish'" );
        $fetch_limit = min( 10000, $limit * 4 );
        $rows = $wpdb->get_col( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE post_type=%s AND {$where_status} ORDER BY ID ASC LIMIT %d", $post_type, $fetch_limit ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $out = array();
        foreach ( (array) $rows as $raw_id ) {
            $id = (int) $raw_id;
            if ( $id <= 0 || ! current_user_can( 'read_post', $id ) ) continue;
            $out[] = $id;
            if ( count( $out ) >= $limit ) break;
        }
        return $out;
    }

    private function site_product_count(): int {
        return $this->site_post_count( 'product' );
    }

    private function site_media_count(): int {
        return $this->site_post_count( 'attachment' );
    }

    private function site_post_count( string $post_type ): int {
        global $wpdb;
        $object = get_post_type_object( $post_type );
        $can_read_private = $object && isset( $object->cap->read_private_posts ) && current_user_can( $object->cap->read_private_posts );
        $where_status = $can_read_private ? "post_status NOT IN ('trash','auto-draft')" : ( 'attachment' === $post_type ? "post_status IN ('inherit','publish')" : "post_status='publish'" );
        return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type=%s AND {$where_status}", $post_type ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
    }

    /** @param array<int,array<string,mixed>> $items @return array<string,mixed> */
    private function summarize_profile_items( array $items, int $real_total ): array {
        $keys = array( 'score' => 'avg_score', 'technical' => 'technical', 'content' => 'content', 'schema' => 'schema', 'media' => 'media', 'commerce' => 'commerce' );
        $out = array( 'total' => $real_total, 'avg_score' => null, 'technical' => null, 'content' => null, 'schema' => null, 'media' => null, 'commerce' => null );
        foreach ( $keys as $source => $target ) {
            $values = array();
            foreach ( $items as $item ) if ( array_key_exists( $source, $item ) && null !== $item[ $source ] && '' !== $item[ $source ] ) $values[] = (float) $item[ $source ];
            if ( $values ) $out[ $target ] = (int) round( array_sum( $values ) / count( $values ) );
        }
        return $out;
    }

    /** @return array<string,mixed> */
    private function profile_summary( string $kind ): array {
        global $wpdb;
        $t = K20AI_Database::tables();
        $row = (array) $wpdb->get_row( $wpdb->prepare( "SELECT COUNT(*) AS total,ROUND(AVG(score_total)) AS avg_score,ROUND(AVG(score_technical)) AS technical,ROUND(AVG(score_content)) AS content,ROUND(AVG(score_schema)) AS schema_score,ROUND(AVG(score_media)) AS media,ROUND(AVG(score_commerce)) AS commerce FROM {$t['seo_profiles']} WHERE entity_kind=%s", $kind ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        if ( isset( $row['schema_score'] ) ) {
            $row['schema'] = $row['schema_score'];
            unset( $row['schema_score'] );
        }
        return array_map( static fn( $v ) => null === $v ? null : (int) $v, $row );
    }

    /** @return array<string,mixed>|null */
    private function latest_scan_of_type( string $type ): ?array {
        global $wpdb;
        $t = K20AI_Database::tables();
        $id = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$t['seo_scans']} WHERE scan_type=%s ORDER BY id DESC LIMIT 1", $type ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        return $id ? $this->scan( $id ) : null;
    }

    /** @return array<string,mixed> */
    private function detected_schema_types( int $id, string $kind ): array {
        $types = array();
        if ( 'product' === $kind ) $types[] = 'Product';
        elseif ( in_array( $kind, array( 'content_post','news' ), true ) ) $types[] = 'Article';
        elseif ( 'page' === $kind ) $types[] = 'WebPage';
        return $types;
    }

    private function seo_meta( int $id, string $type, string $fallback = '' ): string {
        $map = array( 'title' => '_yoast_wpseo_title', 'description' => '_yoast_wpseo_metadesc', 'canonical' => '_yoast_wpseo_canonical' );
        $key = $map[ $type ] ?? '';
        $value = $key ? trim( (string) get_post_meta( $id, $key, true ) ) : '';
        if ( '' === $value ) {
            $plugin_key = '_k20ai_' . $type;
            $value = trim( (string) get_post_meta( $id, $plugin_key, true ) );
        }
        return '' !== $value ? $value : $fallback;
    }

    private function editor_saved_meta( int $id, string $type ): string {
        $plugin_map = array( 'title' => '_k20ai_title', 'description' => '_k20ai_description' );
        $yoast_map = array( 'title' => '_yoast_wpseo_title', 'description' => '_yoast_wpseo_metadesc' );
        $plugin_key = $plugin_map[ $type ] ?? '';
        $yoast_key = $yoast_map[ $type ] ?? '';
        $value = $plugin_key ? trim( (string) get_post_meta( $id, $plugin_key, true ) ) : '';
        if ( '' === $value && $yoast_key ) $value = trim( (string) get_post_meta( $id, $yoast_key, true ) );
        return $value;
    }

    private function save_editor_meta_value( int $id, string $type, string $value ): void {
        $plugin_map = array( 'title' => '_k20ai_title', 'description' => '_k20ai_description' );
        $yoast_map = array( 'title' => '_yoast_wpseo_title', 'description' => '_yoast_wpseo_metadesc' );
        $plugin_key = $plugin_map[ $type ] ?? '';
        $yoast_key = $yoast_map[ $type ] ?? '';
        if ( ! $plugin_key ) return;
        if ( '' === $value ) {
            delete_post_meta( $id, $plugin_key );
            if ( defined( 'WPSEO_VERSION' ) && $yoast_key ) delete_post_meta( $id, $yoast_key );
            return;
        }
        update_post_meta( $id, $plugin_key, $value );
        if ( defined( 'WPSEO_VERSION' ) && $yoast_key ) update_post_meta( $id, $yoast_key, $value );
    }

    private function first_meta( int $id, array $keys ): string {
        foreach ( $keys as $key ) {
            $value = trim( (string) get_post_meta( $id, $key, true ) );
            if ( '' !== $value ) return $value;
        }
        return '';
    }

    private function product_brand( int $id ): string {
        foreach ( get_object_taxonomies( 'product' ) as $taxonomy ) {
            if ( ! str_contains( $taxonomy, 'brand' ) ) continue;
            $names = wp_get_post_terms( $id, $taxonomy, array( 'fields' => 'names' ) );
            if ( ! is_wp_error( $names ) && $names ) return implode( '، ', $names );
        }
        return $this->first_meta( $id, array( '_brand','brand' ) );
    }

    private function brand_taxonomy(): string {
        if ( ! post_type_exists( 'product' ) ) return '';
        foreach ( get_object_taxonomies( 'product' ) as $taxonomy ) if ( str_contains( $taxonomy, 'brand' ) ) return $taxonomy;
        return '';
    }

    private function is_same_host_url( string $url ): bool {
        $home = strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
        $host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
        return $home && $host && preg_replace( '/^www\./', '', $home ) === preg_replace( '/^www\./', '', $host );
    }

    private function word_count( string $html ): int {
        $text = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( $html ) ) );
        if ( '' === $text ) return 0;
        return count( preg_split( '/\s+/u', $text, -1, PREG_SPLIT_NO_EMPTY ) ?: array() );
    }

    private function json( mixed $raw ): array {
        if ( is_array( $raw ) ) return $raw;
        if ( is_object( $raw ) ) return (array) $raw;
        if ( ! is_string( $raw ) || '' === $raw ) return array();
        $decoded = json_decode( $raw, true );
        return is_array( $decoded ) ? $decoded : array();
    }

    private function table_exists( string $table ): bool {
        global $wpdb;
        return $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table;
    }

    private function audit_log( string $action, string $kind, int $id, array $before, array $after, int $actor_id = 0 ): void {
        $this->log_action_event( $action, $kind, $id, $before, $after );
    }

    /** @return array<string,mixed>|WP_Error */
    public function live_serp_report( string $query, string $kind = '', int $id = 0 ): array|WP_Error {
        if ( ! K20AI_Security::can_edit_content() ) return new WP_Error( 'forbidden', __( 'برای Live SERP دسترسی کافی نیست.', 'k20-ai-press' ), array( 'status' => 403 ) );
        if ( ! $this->connection_center ) return new WP_Error( 'connection_center_unavailable', __( 'Connection Center در دسترس نیست.', 'k20-ai-press' ), array( 'status' => 409 ) );
        $query = trim( K20AI_Data_Integrity::clean_text( $query ) );
        $kind = K20AI_Entity_Access::normalize_kind( $kind );
        if ( $id > 0 && ( '' === $kind || ! K20AI_Entity_Access::can_read( $kind, $id ) ) ) return new WP_Error( 'forbidden_entity', __( 'موجودیت انتخابی قابل خواندن نیست.', 'k20-ai-press' ), array( 'status' => 403 ) );
        if ( '' === $query && $id > 0 ) $query = trim( (string) get_the_title( $id ) );
        if ( mb_strlen( $query ) < 2 || mb_strlen( $query ) > 180 ) return new WP_Error( 'invalid_query', __( 'عبارت جست‌وجو باید بین ۲ تا ۱۸۰ نویسه باشد.', 'k20-ai-press' ), array( 'status' => 422 ) );

        $serp = $this->connection_center->google_serp( $query, 10 );
        if ( is_wp_error( $serp ) ) return $serp;
        $site_host = strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
        $site_host = preg_replace( '/^www\./', '', $site_host );
        $observed_position = null;
        foreach ( $serp['organic_results'] as &$item ) {
            $host = strtolower( (string) wp_parse_url( (string) ( $item['link'] ?? '' ), PHP_URL_HOST ) );
            $host = preg_replace( '/^www\./', '', $host );
            $item['is_site'] = '' !== $host && $host === $site_host;
            if ( $item['is_site'] && null === $observed_position ) $observed_position = absint( $item['position'] ?? 0 ) ?: null;
        }
        unset( $item );

        $historical = array( 'available' => false, 'position' => null, 'impressions' => null, 'clicks' => null, 'ctr' => null, 'source' => null, 'checked_at' => null );
        if ( $id > 0 ) {
            global $wpdb;
            $t = K20AI_Database::tables();
            $target_url = get_permalink( $id );
            if ( $target_url && $this->table_exists( $t['seo_keywords'] ) ) {
                $rows = $wpdb->get_results( $wpdb->prepare( "SELECT current_position,impressions,clicks,ctr,source,checked_at FROM {$t['seo_keywords']} WHERE phrase=%s AND target_url=%s AND search_engine='google' ORDER BY checked_at DESC,id DESC LIMIT 200", $query, $target_url ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                if ( $rows ) {
                    $impressions = 0; $clicks = 0; $weighted_position = 0.0; $weight = 0; $positions = array();
                    foreach ( $rows as $row ) {
                        $imp = max( 0, (int) ( $row['impressions'] ?? 0 ) );
                        $clk = max( 0, (int) ( $row['clicks'] ?? 0 ) );
                        $pos = is_numeric( $row['current_position'] ?? null ) ? (float) $row['current_position'] : null;
                        $impressions += $imp; $clicks += $clk;
                        if ( null !== $pos ) { $positions[] = $pos; if ( $imp > 0 ) { $weighted_position += $pos * $imp; $weight += $imp; } }
                    }
                    $historical = array(
                        'available' => true,
                        'position' => $weight > 0 ? round( $weighted_position / $weight, 2 ) : ( $positions ? round( array_sum( $positions ) / count( $positions ), 2 ) : null ),
                        'impressions' => $impressions,
                        'clicks' => $clicks,
                        'ctr' => $impressions > 0 ? round( 100 * $clicks / $impressions, 2 ) : null,
                        'source' => (string) ( $rows[0]['source'] ?? '' ),
                        'checked_at' => (string) ( $rows[0]['checked_at'] ?? '' ),
                    );
                }
            }
        }

        $recommendations = array();
        $ai_status = 'not_connected';
        $provider = '';
        foreach ( $this->connection_center->snapshot() as $connection ) {
            $key = (string) ( $connection['key'] ?? '' );
            if ( in_array( $key, array( 'openai','gemini','anthropic','deepseek','custom_ai' ), true ) && 'connected' === (string) ( $connection['status'] ?? '' ) ) { $provider = $key; break; }
        }
        $top5 = array_slice( (array) $serp['organic_results'], 0, 5 );
        if ( $provider && $top5 ) {
            $schema = array(
                'type' => 'object',
                'properties' => array(
                    'suggestions' => array( 'type' => 'array', 'maxItems' => 12, 'items' => array( 'type' => 'object', 'properties' => array( 'keyword' => array( 'type' => 'string' ), 'reason' => array( 'type' => 'string' ) ), 'required' => array( 'keyword','reason' ), 'additionalProperties' => false ) ),
                    'summary' => array( 'type' => 'string' ),
                ),
                'required' => array( 'suggestions','summary' ),
                'additionalProperties' => false,
            );
            $source_lines = array();
            foreach ( $top5 as $row ) $source_lines[] = sprintf( '#%d | %s | %s | %s', (int) ( $row['position'] ?? 0 ), (string) ( $row['title'] ?? '' ), (string) ( $row['snippet'] ?? '' ), (string) ( $row['link'] ?? '' ) );
            $prompt = "Query: {$query}\nSelected entity: " . ( $id ? get_the_title( $id ) . ' (' . get_permalink( $id ) . ')' : 'none' ) . "\nGoogle organic sources from SerpApi:\n" . implode( "\n", $source_lines ) . "\nExtract useful related keywords/topics/entities that could improve the selected page without copying competitors. Base every suggestion only on these supplied sources.";
            $generated = $this->connection_center->ai_generate( $provider, array( 'system' => 'You are an SEO research assistant. The supplied SerpApi organic results are source evidence, not permission to copy text. Return concise source-grounded suggestions only.', 'prompt' => $prompt, 'schema' => $schema, 'web_search' => false ) );
            if ( ! is_wp_error( $generated ) ) {
                $ai_status = 'ok';
                foreach ( (array) ( $generated['data']['suggestions'] ?? array() ) as $row ) {
                    $keyword = trim( K20AI_Data_Integrity::clean_text( $row['keyword'] ?? '' ) );
                    if ( '' === $keyword ) continue;
                    $recommendations[] = array( 'keyword' => $keyword, 'reason' => K20AI_Data_Integrity::clean_textarea( $row['reason'] ?? '' ) );
                }
            } else $ai_status = $generated->get_error_message();
        }

        return array(
            'query' => $query,
            'entity' => $id ? array( 'kind' => $kind, 'id' => $id, 'title' => get_the_title( $id ), 'url' => get_permalink( $id ) ) : null,
            'serp' => $serp,
            'observed_live_position' => $observed_position,
            'historical_search_console' => $historical,
            'ai' => array( 'provider' => $provider ?: null, 'status' => $ai_status, 'suggestions' => $recommendations ),
        );
    }

    /** @return array<string,mixed>|WP_Error */
    public function serp_research( string $query ): array|WP_Error {
        if ( ! K20AI_Security::can_edit_content() ) return new WP_Error( 'forbidden', __( 'برای پژوهش زنده وب دسترسی کافی نیست.', 'k20-ai-press' ), array( 'status' => 403 ) );
        $query = trim( K20AI_Data_Integrity::clean_text( $query ) );
        if ( mb_strlen( $query ) < 2 || mb_strlen( $query ) > 180 ) return new WP_Error( 'invalid_query', __( 'عبارت جست‌وجو باید بین ۲ تا ۱۸۰ نویسه باشد.', 'k20-ai-press' ), array( 'status' => 422 ) );
        if ( ! $this->connection_center ) return new WP_Error( 'connection_center_unavailable', __( 'Connection Center در دسترس نیست.', 'k20-ai-press' ), array( 'status' => 409 ) );
        $schema = array(
            'type' => 'object',
            'properties' => array(
                'recommendations' => array( 'type' => 'array', 'items' => array( 'type' => 'string' ), 'maxItems' => 5 ),
                'research_summary' => array( 'type' => 'string' ),
            ),
            'required' => array( 'recommendations','research_summary' ),
            'additionalProperties' => false,
        );
        $system = 'You are a web research assistant for SEO. Use web search. Never claim a source is a Google organic ranking result. Return concise evidence-based recommendations only.';
        $prompt = 'Research this query on the live web: ' . $query . '. Summarize the visible themes and provide up to five SEO/content recommendations grounded in the sources you actually consulted.';
        $generated = $this->connection_center->ai_generate( 'openai', array( 'system' => $system, 'prompt' => $prompt, 'schema' => $schema, 'web_search' => true ) );
        if ( is_wp_error( $generated ) ) return $generated;
        $results = array();
        $seen = array();
        foreach ( (array) ( $generated['sources'] ?? array() ) as $source ) {
            $url = K20AI_Data_Integrity::valid_external_https_url( $source['url'] ?? '' );
            if ( ! $url || isset( $seen[ $url ] ) ) continue;
            $seen[ $url ] = true;
            $results[] = array( 'title' => K20AI_Data_Integrity::clean_text( $source['title'] ?? wp_parse_url( $url, PHP_URL_HOST ) ), 'url' => $url );
            if ( count( $results ) >= 5 ) break;
        }
        $recommendations = array();
        foreach ( (array) ( $generated['data']['recommendations'] ?? array() ) as $item ) {
            $clean = trim( K20AI_Data_Integrity::clean_text( $item ) );
            if ( '' !== $clean ) $recommendations[] = $clean;
            if ( count( $recommendations ) >= 5 ) break;
        }
        return array(
            'query' => $query,
            'measurement' => 'openai_web_search_research',
            'is_google_organic' => false,
            'provider' => (string) ( $generated['provider'] ?? 'openai' ),
            'model' => (string) ( $generated['model'] ?? '' ),
            'results' => $results,
            'recommendations' => $recommendations,
            'summary' => K20AI_Data_Integrity::clean_textarea( $generated['data']['research_summary'] ?? '' ),
            'note' => __( 'این خروجی پژوهش زنده وب با منبع است و رتبه قطعی Top 5 گوگل محسوب نمی‌شود. رتبه Google فقط از Search Console/Rank Provider دارای provenance نمایش داده می‌شود.', 'k20-ai-press' ),
        );
    }

    /** @return array<string,mixed>|WP_Error */
    public function schedule_post( int $id, string $local_datetime ): array|WP_Error {
        if ( ! K20AI_Security::can_edit_content() || ! current_user_can( 'edit_post', $id ) ) return new WP_Error( 'forbidden', __( 'برای زمان‌بندی این محتوا دسترسی کافی نیست.', 'k20-ai-press' ), array( 'status' => 403 ) );
        $post = get_post( $id );
        if ( ! $post ) return new WP_Error( 'not_found', __( 'محتوا پیدا نشد.', 'k20-ai-press' ), array( 'status' => 404 ) );
        if ( ! in_array( $post->post_status, array( 'draft','pending','future' ), true ) ) return new WP_Error( 'invalid_status', __( 'فقط Draft، Pending یا Future از این تقویم زمان‌بندی می‌شود.', 'k20-ai-press' ), array( 'status' => 422 ) );
        $allowed_types = array( 'post','page','shop_coupon' );
        if ( ! in_array( $post->post_type, $allowed_types, true ) ) {
            $obj = get_post_type_object( $post->post_type );
            if ( ! $obj || empty( $obj->show_ui ) ) return new WP_Error( 'unsupported_post_type', __( 'این نوع محتوا از زمان‌بندی پنل پشتیبانی نمی‌کند.', 'k20-ai-press' ), array( 'status' => 422 ) );
        }
        $local_datetime = sanitize_text_field( $local_datetime );
        $timezone = wp_timezone();
        $dt = \DateTimeImmutable::createFromFormat( 'Y-m-d\\TH:i', $local_datetime, $timezone );
        if ( ! $dt ) $dt = \DateTimeImmutable::createFromFormat( 'Y-m-d H:i', $local_datetime, $timezone );
        if ( ! $dt ) return new WP_Error( 'invalid_datetime', __( 'تاریخ یا ساعت معتبر نیست.', 'k20-ai-press' ), array( 'status' => 422 ) );
        $now = new \DateTimeImmutable( 'now', $timezone );
        if ( $dt <= $now ) return new WP_Error( 'past_datetime', __( 'زمان انتشار باید در آینده باشد.', 'k20-ai-press' ), array( 'status' => 422 ) );
        $before = array( 'status' => $post->post_status, 'post_date' => $post->post_date, 'post_date_gmt' => $post->post_date_gmt );
        $local = $dt->format( 'Y-m-d H:i:s' );
        $gmt = $dt->setTimezone( new \DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' );
        $result = wp_update_post( array( 'ID' => $id, 'post_status' => 'future', 'post_date' => $local, 'post_date_gmt' => $gmt, 'edit_date' => true ), true );
        if ( is_wp_error( $result ) ) return $result;
        clean_post_cache( $id );
        $after_post = get_post( $id );
        $after = array( 'status' => $after_post ? $after_post->post_status : 'future', 'post_date' => $after_post ? $after_post->post_date : $local, 'post_date_gmt' => $after_post ? $after_post->post_date_gmt : $gmt );
        $this->log_action_event( 'content.schedule', K20AI_Entity_Access::resolve_kind( $id ) ?: 'content_post', $id, $before, $after );
        return array( 'id' => $id, 'title' => get_the_title( $id ), 'status' => $after['status'], 'date' => $after['post_date'], 'date_gmt' => $after['post_date_gmt'], 'type' => get_post_type( $id ) );
    }

    private function log_action_event( string $action, string $kind, int $id, array $before, array $after ): void {
        global $wpdb;
        $t = K20AI_Database::tables();
        if ( ! $this->table_exists( $t['audit_log'] ) ) return;
        $wpdb->insert( $t['audit_log'], array(
            'actor_id'    => get_current_user_id() ?: null,
            'actor_type'  => get_current_user_id() ? 'human' : 'system',
            'action_name' => 'seo.v3.' . $action,
            'target_type' => $kind,
            'target_id'   => (string) $id,
            'result'      => 'SUCCESS',
            'trace_id'    => function_exists( 'wp_generate_uuid4' ) ? wp_generate_uuid4() : null,
            'meta'        => wp_json_encode( array( 'before_hash' => hash( 'sha256', wp_json_encode( $before ) ), 'before' => $before, 'after' => $after ) ),
            'created_at'  => current_time( 'mysql', true ),
        ) );
    }
}
