<?php

defined( 'ABSPATH' ) || exit;

/**
 * Real connection center for external data + AI providers.
 *
 * Secrets are encrypted at rest and never returned through the REST API.
 * Connections fail closed: a provider is only shown as connected after a live test.
 */
final class K20AI_Connection_Center {
    private const OPTION = 'k20ai_connection_center_v1';
    private const STATE_PREFIX = 'k20ai_oauth_state_';

    private K20AI_SEO_OS $seo;

    public function __construct( K20AI_SEO_OS $seo ) {
        $this->seo = $seo;
    }

    /** @return array<string,array<string,mixed>> */
    public function definitions(): array {
        return array(
            'google' => array(
                'label' => 'Google',
                'category' => 'data',
                'description' => 'Search Console، GA4 و Merchant API با OAuth 2.0 یکپارچه.',
                'requirements' => array(
                    'در Google Cloud یک OAuth Web Client بسازید و Redirect URI نمایش‌داده‌شده در همین کارت را عیناً ثبت کنید.',
                    'Search Console API، Google Analytics Admin/Data API و Merchant API موردنیاز را در همان Project فعال کنید.',
                    'حساب Google باید روی Propertyهای Search Console/GA4/Merchant دسترسی داشته باشد.',
                ),
                'auth' => 'oauth2',
                'icon' => 'admin-site-alt3',
                'fields' => array(
                    array( 'key' => 'client_id', 'label' => 'OAuth Client ID', 'secret' => false ),
                    array( 'key' => 'client_secret', 'label' => 'OAuth Client Secret', 'secret' => true ),
                    array( 'key' => 'gsc_site', 'label' => 'Search Console Property', 'secret' => false ),
                    array( 'key' => 'ga4_property', 'label' => 'GA4 Property ID', 'secret' => false ),
                    array( 'key' => 'merchant_account', 'label' => 'Merchant Account', 'secret' => false ),
                    array( 'key' => 'auto_sync', 'label' => 'Sync خودکار ساعتی', 'secret' => false, 'type' => 'checkbox', 'default' => true ),
                ),
                'scopes' => array(
                    'https://www.googleapis.com/auth/webmasters.readonly',
                    'https://www.googleapis.com/auth/analytics.readonly',
                ),
            ),
            'bing' => array(
                'label' => 'Bing Webmaster Tools',
                'category' => 'data',
                'description' => 'Search/Crawl/Query data از Bing Webmaster با دسترسی خواندنی.',
                'requirements' => array(
                    'از Bing Webmaster > Settings > API Access یک OAuth Client بسازید و Redirect URI کارت را دقیق ثبت کنید؛ یا API Key وارد کنید.',
                    'سایت باید در Bing Webmaster ثبت/تأیید شده باشد.',
                ),
                'auth' => 'oauth2_or_key',
                'icon' => 'search',
                'fields' => array(
                    array( 'key' => 'client_id', 'label' => 'OAuth Client ID', 'secret' => false ),
                    array( 'key' => 'client_secret', 'label' => 'OAuth Client Secret', 'secret' => true ),
                    array( 'key' => 'api_key', 'label' => 'API Key (اختیاری)', 'secret' => true ),
                    array( 'key' => 'site_url', 'label' => 'Site URL', 'secret' => false ),
                    array( 'key' => 'auto_sync', 'label' => 'Sync خودکار ساعتی', 'secret' => false, 'type' => 'checkbox', 'default' => true ),
                ),
            ),
            'pagespeed' => array(
                'label' => 'PageSpeed Insights',
                'category' => 'data',
                'description' => 'Core Web Vitals و Lighthouse metrics برای URLهای واقعی سایت.',
                'requirements' => array( 'PageSpeed Insights API را در Google Cloud فعال کنید و یک API Key معتبر بسازید.' ),
                'auth' => 'api_key',
                'icon' => 'performance',
                'fields' => array(
                    array( 'key' => 'api_key', 'label' => 'API Key', 'secret' => true ),
                    array( 'key' => 'auto_sync', 'label' => 'Sync خودکار ساعتی', 'secret' => false, 'type' => 'checkbox', 'default' => true ),
                ),
            ),
            'serpapi' => array(
                'label' => 'SerpApi · Google Live SERP',
                'category' => 'data',
                'description' => 'نتایج ارگانیک زنده Google با منبع، موقعیت و تنظیمات جغرافیایی صریح؛ جدا از Search Console.',
                'requirements' => array(
                    'یک SerpApi API Key معتبر لازم است.',
                    'Location/hl/gl/google_domain فقط برای شبیه‌سازی جست‌وجوی درخواستی استفاده می‌شوند و با داده تاریخی Search Console یکی نیستند.',
                ),
                'auth' => 'api_key',
                'icon' => 'google',
                'fields' => array(
                    array( 'key' => 'api_key', 'label' => 'SerpApi API Key', 'secret' => true ),
                    array( 'key' => 'location', 'label' => 'Location', 'secret' => false, 'default' => '' ),
                    array( 'key' => 'hl', 'label' => 'Language (hl)', 'secret' => false, 'default' => 'fa' ),
                    array( 'key' => 'gl', 'label' => 'Country (gl)', 'secret' => false, 'default' => 'ir' ),
                    array( 'key' => 'google_domain', 'label' => 'Google domain', 'secret' => false, 'default' => 'google.com' ),
                ),
            ),
            'github' => array(
                'label' => 'GitHub',
                'category' => 'delivery',
                'description' => 'Repository، Actions workflow و ثبت تغییرات کد/قوانین افزونه.',
                'requirements' => array(
                    'Fine-grained PAT یا GitHub App Installation Token با دسترسی همان Repository وارد کنید.',
                    'برای اجرای workflow، دسترسی Actions: write و یک workflow دارای workflow_dispatch لازم است.',
                    'برای Copilot، خود workflow/runner باید Copilot CLI/SDK یا Agent موردنظر را مطابق سیاست حساب GitHub پیکربندی کرده باشد.',
                ),
                'auth' => 'token',
                'icon' => 'editor-code',
                'fields' => array(
                    array( 'key' => 'token', 'label' => 'Fine-grained PAT / Installation token', 'secret' => true ),
                    array( 'key' => 'repository', 'label' => 'Repository (owner/repo)', 'secret' => false ),
                    array( 'key' => 'branch', 'label' => 'Branch', 'secret' => false, 'default' => 'main' ),
                    array( 'key' => 'workflow', 'label' => 'Workflow file (optional)', 'secret' => false ),
                    array( 'key' => 'news_workflow', 'label' => 'News Engine workflow', 'secret' => false ),
                    array( 'key' => 'article_workflow', 'label' => 'Article Engine workflow', 'secret' => false ),
                    array( 'key' => 'bridge_workflow', 'label' => 'Bridge gateway workflow', 'secret' => false ),
                ),
                'note' => 'GitHub اینجا برای Repo/Actions و اجرای workflow است. اگر Copilot CLI/SDK را داخل workflow خودتان پیکربندی کنید، افزونه می‌تواند همان workflow را dispatch کند؛ inference معمولی AI از Providerهای مستقیم انجام می‌شود.',
            ),
            'openai' => array(
                'label' => 'OpenAI / ChatGPT API',
                'category' => 'ai',
                'description' => 'Responses API + Structured Outputs؛ Web Search اختیاری برای تکمیل منبع‌دار.',
                'requirements' => array( 'OpenAI API Key و دسترسی API به مدل انتخاب‌شده لازم است؛ اشتراک ChatGPT به‌تنهایی API Key محسوب نمی‌شود.' ),
                'auth' => 'api_key',
                'icon' => 'superhero-alt',
                'fields' => array(
                    array( 'key' => 'api_key', 'label' => 'API Key', 'secret' => true ),
                    array( 'key' => 'model', 'label' => 'Model', 'secret' => false, 'default' => 'gpt-5.6' ),
                    array( 'key' => 'web_search', 'label' => 'Web Search', 'secret' => false, 'type' => 'checkbox', 'default' => true ),
                ),
            ),
            'deepseek' => array(
                'label' => 'DeepSeek',
                'category' => 'ai',
                'description' => 'OpenAI-compatible API برای تحلیل و تولید ساختاریافته.',
                'requirements' => array( 'DeepSeek API Key و دسترسی به مدل انتخاب‌شده لازم است.' ),
                'auth' => 'api_key',
                'icon' => 'superhero',
                'fields' => array(
                    array( 'key' => 'api_key', 'label' => 'API Key', 'secret' => true ),
                    array( 'key' => 'model', 'label' => 'Model', 'secret' => false, 'default' => 'deepseek-flash' ),
                ),
            ),
            'gemini' => array(
                'label' => 'Google Gemini',
                'category' => 'ai',
                'description' => 'Gemini API برای تحلیل چندرسانه‌ای و تولید محتوا.',
                'requirements' => array( 'Gemini API Key و دسترسی به مدل انتخاب‌شده لازم است.' ),
                'auth' => 'api_key',
                'icon' => 'star-filled',
                'fields' => array(
                    array( 'key' => 'api_key', 'label' => 'API Key', 'secret' => true ),
                    array( 'key' => 'model', 'label' => 'Model', 'secret' => false, 'default' => 'gemini-3.8-flash' ),
                ),
            ),
            'anthropic' => array(
                'label' => 'Anthropic Claude',
                'category' => 'ai',
                'description' => 'Messages API؛ مدل را صریحاً بر اساس حساب خود انتخاب کنید.',
                'requirements' => array( 'Anthropic API Key و Model ID معتبر حساب لازم است.' ),
                'auth' => 'api_key',
                'icon' => 'editor-quote',
                'fields' => array(
                    array( 'key' => 'api_key', 'label' => 'API Key', 'secret' => true ),
                    array( 'key' => 'model', 'label' => 'Model', 'secret' => false, 'default' => '' ),
                ),
            ),
            'custom_ai' => array(
                'label' => 'OpenAI-compatible Custom',
                'category' => 'ai',
                'description' => 'Provider خصوصی یا Gateway سازگار با Chat Completions.',
                'requirements' => array( 'Endpoint باید HTTPS معتبر و دارای /models و /chat/completions سازگار باشد.' ),
                'auth' => 'api_key',
                'icon' => 'admin-generic',
                'fields' => array(
                    array( 'key' => 'base_url', 'label' => 'Base URL', 'secret' => false ),
                    array( 'key' => 'api_key', 'label' => 'API Key', 'secret' => true ),
                    array( 'key' => 'model', 'label' => 'Model', 'secret' => false ),
                ),
            ),
        );
    }

    /** @return array<string,mixed> */
    private function all(): array {
        $stored = get_option( self::OPTION, array() );
        return is_array( $stored ) ? $stored : array();
    }

    /** @param array<string,mixed> $all */
    private function persist( array $all ): void {
        update_option( self::OPTION, $all, false );
    }

    /** @return array<string,mixed> */
    public function get( string $provider, bool $with_secrets = false ): array {
        $provider = sanitize_key( $provider );
        $all = $this->all();
        $row = isset( $all[ $provider ] ) && is_array( $all[ $provider ] ) ? $all[ $provider ] : array();
        $row = wp_parse_args( $row, array(
            'provider' => $provider,
            'status' => 'disconnected',
            'config' => array(),
            'secret' => '',
            'last_test_at' => null,
            'last_sync_at' => null,
            'last_error' => null,
            'meta' => array(),
        ) );
        $row['config'] = is_array( $row['config'] ) ? $row['config'] : array();
        $row['meta'] = is_array( $row['meta'] ) ? $row['meta'] : array();
        if ( $with_secrets ) {
            $row['secrets'] = $this->decrypt_json( (string) $row['secret'] );
        }
        unset( $row['secret'] );
        return $row;
    }

    /** @return array<int,array<string,mixed>> */
    public function snapshot(): array {
        $rows = array();
        foreach ( $this->definitions() as $key => $def ) {
            $row = $this->get( $key, false );
            $config = (array) $row['config'];
            $defs = (array) ( $def['fields'] ?? array() );
            $fields = array();
            foreach ( $defs as $field ) {
                $field_key = (string) $field['key'];
                $fields[] = array(
                    'key' => $field_key,
                    'label' => (string) $field['label'],
                    'type' => (string) ( $field['type'] ?? ( ! empty( $field['secret'] ) ? 'password' : 'text' ) ),
                    'secret' => ! empty( $field['secret'] ),
                    'value' => ! empty( $field['secret'] ) ? '' : ( $config[ $field_key ] ?? ( $field['default'] ?? '' ) ),
                    'configured' => ! empty( $config[ $field_key ] ) || ( ! empty( $field['secret'] ) && $this->has_secret( $key, $field_key ) ),
                    'options' => $this->field_options( $key, $field_key, (array) $row['meta'] ),
                );
            }
            $rows[] = array_merge( $def, array(
                'key' => $key,
                'status' => (string) $row['status'],
                'last_test_at' => $row['last_test_at'],
                'last_sync_at' => $row['last_sync_at'],
                'last_error' => $row['last_error'],
                'meta' => $row['meta'],
                'fields' => $fields,
                'oauth_url' => in_array( $def['auth'], array( 'oauth2', 'oauth2_or_key' ), true ) && $this->oauth_ready( $key ) ? $this->oauth_start_url( $key ) : null,
                'redirect_uri' => in_array( $def['auth'], array( 'oauth2', 'oauth2_or_key' ), true ) ? $this->oauth_callback_url( $key ) : null,
            ) );
        }
        return $rows;
    }

    /** @return array<int,array{value:string,label:string}> */
    private function field_options( string $provider, string $field, array $meta ): array {
        $discovery = isset( $meta['discovery'] ) && is_array( $meta['discovery'] ) ? $meta['discovery'] : array();
        $out = array();

        if ( 'google' === $provider && 'gsc_site' === $field ) {
            foreach ( (array) ( $discovery['sites'] ?? array() ) as $site ) {
                $url = trim( (string) ( $site['url'] ?? '' ) );
                if ( '' !== $url ) $out[] = array( 'value' => $url, 'label' => $url . ( ! empty( $site['permission'] ) ? ' · ' . $site['permission'] : '' ) );
            }
        } elseif ( 'google' === $provider && 'ga4_property' === $field ) {
            foreach ( (array) ( $discovery['ga4'] ?? array() ) as $account ) {
                foreach ( (array) ( $account['propertySummaries'] ?? array() ) as $property ) {
                    $name = (string) ( $property['property'] ?? '' );
                    $id = preg_replace( '#^properties/#', '', $name );
                    if ( '' !== $id ) $out[] = array( 'value' => $id, 'label' => (string) ( $property['displayName'] ?? $id ) . ' · ' . $id );
                }
            }
        } elseif ( 'google' === $provider && 'merchant_account' === $field ) {
            foreach ( (array) ( $discovery['merchant'] ?? array() ) as $account ) {
                $name = (string) ( $account['name'] ?? '' );
                $id = preg_replace( '#^accounts/#', '', $name );
                if ( '' !== $id ) $out[] = array( 'value' => $id, 'label' => (string) ( $account['accountName'] ?? $account['displayName'] ?? $id ) . ' · ' . $id );
            }
        } elseif ( 'bing' === $provider && 'site_url' === $field ) {
            foreach ( (array) ( $discovery['sites'] ?? array() ) as $site ) {
                if ( is_string( $site ) ) $url = $site;
                else $url = (string) ( $site['Url'] ?? $site['url'] ?? $site['SiteUrl'] ?? '' );
                $url = trim( $url );
                if ( '' !== $url ) $out[] = array( 'value' => $url, 'label' => $url );
            }
        } elseif ( in_array( $provider, array( 'openai','deepseek','gemini','anthropic','custom_ai' ), true ) && 'model' === $field ) {
            foreach ( (array) ( $discovery['model_ids'] ?? array() ) as $model ) {
                $model = trim( (string) $model );
                if ( '' !== $model ) $out[] = array( 'value' => $model, 'label' => $model );
            }
        }

        $unique = array();
        foreach ( $out as $option ) $unique[ $option['value'] ] = $option;
        return array_values( $unique );
    }

    public function has_secret( string $provider, string $key ): bool {
        $row = $this->get( $provider, true );
        return ! empty( $row['secrets'][ $key ] );
    }

    /** @param array<string,mixed> $input */
    public function save( string $provider, array $input ): array|WP_Error {
        $provider = sanitize_key( $provider );
        $defs = $this->definitions();
        if ( ! isset( $defs[ $provider ] ) ) {
            return new WP_Error( 'unknown_provider', __( 'Provider ناشناخته است.', 'k20-ai-press' ), array( 'status' => 404 ) );
        }
        $row = $this->get( $provider, true );
        $config = (array) $row['config'];
        $secrets = (array) ( $row['secrets'] ?? array() );
        foreach ( (array) $defs[ $provider ]['fields'] as $field ) {
            $key = (string) $field['key'];
            if ( ! array_key_exists( $key, $input ) ) continue;
            $value = $input[ $key ];
            $is_checkbox = 'checkbox' === ( $field['type'] ?? '' );
            $value = $is_checkbox ? (bool) $value : trim( (string) $value );
            if ( ! empty( $field['secret'] ) ) {
                if ( '' !== (string) $value ) $secrets[ $key ] = (string) $value;
            } else {
                if ( ! $is_checkbox ) {
                    $validated = $this->validate_config_value( $provider, $key, (string) $value );
                    if ( is_wp_error( $validated ) ) return $validated;
                    $value = $validated;
                }
                $config[ $key ] = $value;
            }
        }
        if ( isset( $input['active'] ) ) $config['active'] = (bool) $input['active'];
        $encrypted = $this->encrypt_json( $secrets );
        if ( is_wp_error( $encrypted ) ) return $encrypted;
        $all = $this->all();
        $all[ $provider ] = array(
            'provider' => $provider,
            'status' => 'configured',
            'config' => $config,
            'secret' => $encrypted,
            'last_test_at' => $row['last_test_at'],
            'last_sync_at' => $row['last_sync_at'],
            'last_error' => null,
            'meta' => (array) $row['meta'],
        );
        $this->persist( $all );
        $this->audit( 'connection.save', $provider, 'OK', array( 'fields' => array_keys( $input ) ) );
        return $this->get( $provider, false );
    }

    /** @return string|WP_Error */
    private function validate_config_value( string $provider, string $key, string $value ): string|WP_Error {
        $value = trim( $value );

        if ( 'base_url' === $key ) {
            $validated = K20AI_Data_Integrity::valid_external_https_url( $value );
            if ( '' !== $value && null === $validated ) return new WP_Error( 'invalid_base_url', __( 'Base URL باید HTTPS عمومی و معتبر باشد.', 'k20-ai-press' ), array( 'status' => 422 ) );
            return $validated ?: '';
        }

        if ( 'model' === $key ) {
            if ( mb_strlen( $value ) > 191 || ( '' !== $value && ! preg_match( '/^[A-Za-z0-9][A-Za-z0-9._:\/-]{0,190}$/D', $value ) ) ) {
                return new WP_Error( 'invalid_model', __( 'Model ID نامعتبر است.', 'k20-ai-press' ), array( 'status' => 422 ) );
            }
            return $value;
        }

        if ( 'repository' === $key && '' !== $value && ! preg_match( '#^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$#D', $value ) ) {
            return new WP_Error( 'invalid_repository', __( 'Repository باید به شکل owner/repo باشد.', 'k20-ai-press' ), array( 'status' => 422 ) );
        }

        if ( 'branch' === $key && '' !== $value && ( strlen( $value ) > 191 || ! preg_match( '#^(?!/|.*(?:\.\.|//|@\{|\\|[~^:?*\[]))(?!.*[/.]$)[A-Za-z0-9._/-]+$#D', $value ) ) ) {
            return new WP_Error( 'invalid_branch', __( 'نام Branch معتبر نیست.', 'k20-ai-press' ), array( 'status' => 422 ) );
        }

        if ( 'workflow' === $key || str_ends_with( $key, '_workflow' ) ) {
            if ( '' !== $value && ! ctype_digit( $value ) && ! preg_match( '#^[A-Za-z0-9_./-]+[.]ya?ml$#iD', $value ) ) {
                return new WP_Error( 'invalid_workflow', __( 'Workflow باید نام/مسیر فایل YAML یا شناسه عددی باشد.', 'k20-ai-press' ), array( 'status' => 422 ) );
            }
        }

        if ( 'google' === $provider && 'gsc_site' === $key && '' !== $value ) {
            if ( str_starts_with( $value, 'sc-domain:' ) ) {
                if ( ! preg_match( '/^sc-domain:[A-Za-z0-9.-]+$/D', $value ) ) return new WP_Error( 'invalid_gsc_property', __( 'Domain Property نامعتبر است.', 'k20-ai-press' ), array( 'status' => 422 ) );
            } elseif ( null === K20AI_Data_Integrity::valid_http_url( $value ) ) {
                return new WP_Error( 'invalid_gsc_property', __( 'Search Console Property باید URL معتبر یا sc-domain:example.com باشد.', 'k20-ai-press' ), array( 'status' => 422 ) );
            }
        }

        if ( 'google' === $provider && in_array( $key, array( 'ga4_property', 'merchant_account' ), true ) && '' !== $value && ! ctype_digit( $value ) ) {
            return new WP_Error( 'invalid_google_id', __( 'شناسه Google باید عددی باشد.', 'k20-ai-press' ), array( 'status' => 422 ) );
        }

        if ( 'bing' === $provider && 'site_url' === $key && '' !== $value && null === K20AI_Data_Integrity::valid_http_url( $value ) ) {
            return new WP_Error( 'invalid_bing_site', __( 'Site URL معتبر نیست.', 'k20-ai-press' ), array( 'status' => 422 ) );
        }

        if ( 'serpapi' === $provider && 'google_domain' === $key && '' !== $value && ! preg_match( '/^(?:www\.)?[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/D', $value ) ) {
            return new WP_Error( 'invalid_google_domain', __( 'Google domain معتبر نیست.', 'k20-ai-press' ), array( 'status' => 422 ) );
        }
        if ( 'serpapi' === $provider && in_array( $key, array( 'hl','gl' ), true ) && '' !== $value && ! preg_match( '/^[A-Za-z]{2,10}(?:-[A-Za-z]{2,10})?$/D', $value ) ) {
            return new WP_Error( 'invalid_serp_locale', __( 'پارامتر زبان/کشور SerpApi معتبر نیست.', 'k20-ai-press' ), array( 'status' => 422 ) );
        }
        if ( 'serpapi' === $provider && 'location' === $key && mb_strlen( $value ) > 180 ) {
            return new WP_Error( 'invalid_serp_location', __( 'Location بیش از حد طولانی است.', 'k20-ai-press' ), array( 'status' => 422 ) );
        }

        return sanitize_text_field( $value );
    }

    public function disconnect( string $provider ): array {
        $provider = sanitize_key( $provider );
        $all = $this->all();
        unset( $all[ $provider ] );
        $this->persist( $all );
        $this->audit( 'connection.disconnect', $provider, 'OK', array() );
        return array( 'provider' => $provider, 'status' => 'disconnected' );
    }

    public function oauth_ready( string $provider ): bool {
        $row = $this->get( $provider, true );
        return ! empty( $row['config']['client_id'] ) && ! empty( $row['secrets']['client_secret'] );
    }

    public function oauth_start_url( string $provider ): string {
        return wp_nonce_url(
            admin_url( 'admin-post.php?action=k20ai_oauth_start&provider=' . rawurlencode( $provider ) ),
            'k20ai_oauth_start_' . $provider
        );
    }

    public function register_hooks(): void {
        add_action( 'admin_post_k20ai_oauth_start', array( $this, 'handle_oauth_start' ) );
        add_action( 'admin_post_k20ai_oauth_callback', array( $this, 'handle_oauth_callback' ) );
        add_action( 'k20ai_v3_connection_sync', array( $this, 'cron_sync' ) );
        if ( function_exists( 'wp_next_scheduled' ) && function_exists( 'wp_schedule_event' ) && ! wp_next_scheduled( 'k20ai_v3_connection_sync' ) ) {
            wp_schedule_event( time() + 900, 'hourly', 'k20ai_v3_connection_sync' );
        }
    }

    /** @return array<int,string> */
    private function google_oauth_scopes( array $row ): array {
        $scopes = (array) ( $this->definitions()['google']['scopes'] ?? array() );
        // Merchant API currently exposes a read/write OAuth scope only. Request it
        // incrementally and only when Merchant sync is explicitly configured.
        if ( '' !== trim( (string) ( $row['config']['merchant_account'] ?? '' ) ) ) {
            $scopes[] = 'https://www.googleapis.com/auth/content';
        }
        return array_values( array_unique( array_filter( array_map( 'strval', $scopes ) ) ) );
    }

    public function handle_oauth_start(): void {
        if ( ! K20AI_Security::can_manage_system() ) wp_die( esc_html__( 'Forbidden', 'k20-ai-press' ) );
        $provider = sanitize_key( (string) ( $_GET['provider'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        check_admin_referer( 'k20ai_oauth_start_' . $provider );
        if ( ! $this->oauth_ready( $provider ) ) wp_die( esc_html__( 'OAuth credentials are not configured.', 'k20-ai-press' ) );
        $state = wp_generate_password( 48, false, false );
        set_transient( self::STATE_PREFIX . $state, array( 'provider' => $provider, 'user_id' => get_current_user_id() ), 10 * MINUTE_IN_SECONDS );
        $redirect = $this->oauth_callback_url( $provider );
        $row = $this->get( $provider, true );
        if ( 'google' === $provider ) {
            $query = array(
                'client_id' => $row['config']['client_id'],
                'redirect_uri' => $redirect,
                'response_type' => 'code',
                'scope' => implode( ' ', $this->google_oauth_scopes( $row ) ),
                'access_type' => 'offline',
                'include_granted_scopes' => 'true',
                'prompt' => 'consent',
                'state' => $state,
            );
            wp_redirect( 'https://accounts.google.com/o/oauth2/v2/auth?' . http_build_query( $query, '', '&', PHP_QUERY_RFC3986 ) );
            exit;
        }
        if ( 'bing' === $provider ) {
            $query = array(
                'response_type' => 'code',
                'client_id' => $row['config']['client_id'],
                'redirect_uri' => $redirect,
                'scope' => 'Webmaster.read',
                'state' => $state,
            );
            wp_redirect( 'https://www.bing.com/webmasters/oauth/authorize?' . http_build_query( $query, '', '&', PHP_QUERY_RFC3986 ) );
            exit;
        }
        wp_die( esc_html__( 'Unsupported OAuth provider.', 'k20-ai-press' ) );
    }

    public function handle_oauth_callback(): void {
        if ( ! K20AI_Security::can_manage_system() ) wp_die( esc_html__( 'Forbidden', 'k20-ai-press' ) );
        $provider = sanitize_key( (string) ( $_GET['provider'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $state = sanitize_text_field( (string) ( $_GET['state'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $saved = get_transient( self::STATE_PREFIX . $state );
        delete_transient( self::STATE_PREFIX . $state );
        if ( ! is_array( $saved ) || (int) ( $saved['user_id'] ?? 0 ) !== get_current_user_id() || $provider !== ( $saved['provider'] ?? '' ) ) {
            wp_die( esc_html__( 'OAuth state mismatch.', 'k20-ai-press' ) );
        }
        if ( ! empty( $_GET['error'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            $this->mark_error( $provider, sanitize_text_field( (string) $_GET['error'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            $this->redirect_connections( $provider, 'error' );
        }
        $code = sanitize_text_field( (string) ( $_GET['code'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        if ( '' === $code ) wp_die( esc_html__( 'Authorization code missing.', 'k20-ai-press' ) );
        $row = $this->get( $provider, true );
        $redirect = $this->oauth_callback_url( $provider );
        $token_url = 'google' === $provider ? 'https://oauth2.googleapis.com/token' : 'https://www.bing.com/webmasters/oauth/token';
        $response = wp_safe_remote_post( $token_url, array(
            'timeout' => 20,
            'body' => array(
                'client_id' => $row['config']['client_id'],
                'client_secret' => $row['secrets']['client_secret'],
                'code' => $code,
                'grant_type' => 'authorization_code',
                'redirect_uri' => $redirect,
            ),
        ) );
        if ( is_wp_error( $response ) ) {
            $this->mark_error( $provider, $response->get_error_message() );
            $this->redirect_connections( $provider, 'error' );
        }
        $payload = json_decode( (string) wp_remote_retrieve_body( $response ), true );
        if ( (int) wp_remote_retrieve_response_code( $response ) >= 300 || empty( $payload['access_token'] ) ) {
            $this->mark_error( $provider, sanitize_text_field( (string) ( $payload['error_description'] ?? $payload['error'] ?? 'OAuth token exchange failed' ) ) );
            $this->redirect_connections( $provider, 'error' );
        }
        $secrets = (array) ( $row['secrets'] ?? array() );
        $secrets['access_token'] = (string) $payload['access_token'];
        if ( ! empty( $payload['refresh_token'] ) ) $secrets['refresh_token'] = (string) $payload['refresh_token'];
        $config = (array) $row['config'];
        $config['token_expires_at'] = time() + max( 60, (int) ( $payload['expires_in'] ?? 3600 ) );
        $this->write_row( $provider, $config, $secrets, 'connected', null, array( 'scope' => $payload['scope'] ?? null ) );
        $test = $this->test( $provider );
        $this->redirect_connections( $provider, is_wp_error( $test ) ? 'error' : 'connected' );
    }

    private function oauth_callback_url( string $provider ): string {
        return admin_url( 'admin-post.php?action=k20ai_oauth_callback&provider=' . rawurlencode( $provider ) );
    }

    private function redirect_connections( string $provider, string $result ): never {
        wp_safe_redirect( add_query_arg( array( 'page' => 'k20-ai-press', 'workspace' => 'connections', 'provider' => $provider, 'oauth' => $result ), admin_url( 'admin.php' ) ) );
        exit;
    }

    /** @return array<string,mixed>|WP_Error */
    public function test( string $provider ): array|WP_Error {
        $provider = sanitize_key( $provider );
        $row = $this->get( $provider, true );
        $result = null;
        if ( 'google' === $provider ) $result = $this->discover_google();
        elseif ( 'bing' === $provider ) $result = $this->discover_bing();
        elseif ( 'pagespeed' === $provider ) $result = $this->test_pagespeed();
        elseif ( 'serpapi' === $provider ) $result = $this->test_serpapi();
        elseif ( 'github' === $provider ) $result = $this->test_github();
        elseif ( in_array( $provider, array( 'openai','deepseek','gemini','anthropic','custom_ai' ), true ) ) $result = $this->test_ai( $provider );
        else $result = new WP_Error( 'unsupported_provider', __( 'تست این Provider تعریف نشده است.', 'k20-ai-press' ) );
        if ( is_wp_error( $result ) ) {
            if ( in_array( $result->get_error_code(), array( 'model_required', 'selected_model_unavailable' ), true ) ) {
                $data = $result->get_error_data();
                $current = $this->get( $provider, true );
                $available = is_array( $data ) ? array_values( array_filter( array_map( 'strval', (array) ( $data['available_models'] ?? array() ) ) ) ) : array();
                $discovery = array(
                    'models' => count( $available ),
                    'model_ids' => array_slice( $available, 0, 100 ),
                    'selected_model' => is_array( $data ) ? (string) ( $data['selected_model'] ?? '' ) : '',
                    'selected_model_verified' => false,
                );
                $this->write_row( $provider, (array) $current['config'], (array) $current['secrets'], 'configured', $result->get_error_message(), array_merge( (array) $current['meta'], array( 'discovery' => $discovery ) ), true );
                $this->audit( 'connection.model_selection_required', $provider, 'CONFIG_REQUIRED', array( 'models' => count( $available ) ) );
                return $result;
            }
            $this->mark_error( $provider, $result->get_error_message() );
            return $result;
        }
        $current = $this->get( $provider, true );
        $this->write_row( $provider, (array) $current['config'], (array) $current['secrets'], 'connected', null, array_merge( (array) $current['meta'], array( 'discovery' => $result ) ), true );
        $this->audit( 'connection.test', $provider, 'OK', array( 'result_keys' => array_keys( $result ) ) );
        do_action( 'k20ai_connection_connected', $provider, $result );
        return $result;
    }

    /** @return array<string,mixed>|WP_Error */
    public function sync( string $provider ): array|WP_Error {
        $provider = sanitize_key( $provider );
        if ( 'google' === $provider ) $result = $this->sync_google();
        elseif ( 'bing' === $provider ) $result = $this->sync_bing();
        elseif ( 'pagespeed' === $provider ) $result = $this->sync_pagespeed();
        else return new WP_Error( 'not_syncable', __( 'این اتصال Sync داده‌ای ندارد.', 'k20-ai-press' ), array( 'status' => 422 ) );
        if ( is_wp_error( $result ) ) { $this->mark_error( $provider, $result->get_error_message() ); return $result; }
        $row = $this->get( $provider, true );
        $all = $this->all();
        if ( isset( $all[ $provider ] ) ) {
            $all[ $provider ]['status'] = 'connected';
            $all[ $provider ]['last_sync_at'] = current_time( 'mysql', true );
            $all[ $provider ]['last_error'] = null;
            $all[ $provider ]['meta'] = array_merge( (array) ( $all[ $provider ]['meta'] ?? array() ), array( 'last_sync' => $result ) );
            $this->persist( $all );
        }
        $this->audit( 'connection.sync', $provider, 'OK', $result );
        return $result;
    }

    /** @return array<string,mixed>|WP_Error */
    private function test_serpapi(): array|WP_Error {
        $result = $this->google_serp( 'keshavarz20.com', 1, array( 'allow_untested' => true ) );
        if ( is_wp_error( $result ) ) return $result;
        return array(
            'engine' => 'google',
            'organic_results' => count( (array) ( $result['organic_results'] ?? array() ) ),
            'search_metadata' => array_intersect_key( (array) ( $result['search_metadata'] ?? array() ), array_flip( array( 'id','status','created_at','processed_at','google_url' ) ) ),
        );
    }

    /**
     * Execute a sourced Google organic search through the configured SerpApi account.
     * This is intentionally separate from Search Console performance data.
     *
     * @return array<string,mixed>|WP_Error
     */
    public function google_serp( string $query, int $num = 10, array $overrides = array() ): array|WP_Error {
        $query = trim( sanitize_text_field( $query ) );
        if ( mb_strlen( $query ) < 2 || mb_strlen( $query ) > 180 ) {
            return new WP_Error( 'invalid_serp_query', __( 'عبارت SERP باید بین ۲ تا ۱۸۰ نویسه باشد.', 'k20-ai-press' ), array( 'status' => 422 ) );
        }
        $row = $this->get( 'serpapi', true );
        $key = (string) ( $row['secrets']['api_key'] ?? '' );
        if ( '' === $key ) return new WP_Error( 'serpapi_missing_key', __( 'SerpApi API Key ثبت نشده است.', 'k20-ai-press' ), array( 'status' => 409 ) );
        if ( 'connected' !== (string) ( $row['status'] ?? '' ) && empty( $overrides['allow_untested'] ) ) {
            return new WP_Error( 'serpapi_not_connected', __( 'اتصال SerpApi هنوز تست موفق نشده است.', 'k20-ai-press' ), array( 'status' => 409 ) );
        }
        $config = (array) ( $row['config'] ?? array() );
        $args = array(
            'engine' => 'google',
            'q' => $query,
            'api_key' => $key,
            'num' => max( 1, min( 10, $num ) ),
            'hl' => sanitize_key( (string) ( $overrides['hl'] ?? $config['hl'] ?? 'fa' ) ) ?: 'fa',
            'gl' => strtolower( sanitize_key( (string) ( $overrides['gl'] ?? $config['gl'] ?? 'ir' ) ) ) ?: 'ir',
            'google_domain' => sanitize_text_field( (string) ( $overrides['google_domain'] ?? $config['google_domain'] ?? 'google.com' ) ),
        );
        $location = trim( sanitize_text_field( (string) ( $overrides['location'] ?? $config['location'] ?? '' ) ) );
        if ( '' !== $location ) $args['location'] = $location;
        $url = 'https://serpapi.com/search.json?' . http_build_query( $args, '', '&', PHP_QUERY_RFC3986 );
        $result = $this->json_get( $url );
        if ( is_wp_error( $result ) ) return $result;
        $organic = array();
        foreach ( array_slice( (array) ( $result['organic_results'] ?? array() ), 0, max( 1, min( 10, $num ) ) ) as $item ) {
            $link = K20AI_Data_Integrity::valid_external_https_url( $item['link'] ?? '' );
            if ( ! $link ) continue;
            $organic[] = array(
                'position' => absint( $item['position'] ?? 0 ),
                'title' => sanitize_text_field( (string) ( $item['title'] ?? '' ) ),
                'link' => $link,
                'displayed_link' => sanitize_text_field( (string) ( $item['displayed_link'] ?? '' ) ),
                'snippet' => sanitize_textarea_field( (string) ( $item['snippet'] ?? '' ) ),
                'source' => sanitize_text_field( (string) ( $item['source'] ?? '' ) ),
            );
        }
        return array(
            'query' => $query,
            'provider' => 'serpapi',
            'engine' => 'google',
            'location' => $location,
            'hl' => $args['hl'],
            'gl' => $args['gl'],
            'google_domain' => $args['google_domain'],
            'observed_at' => current_time( 'mysql', true ),
            'organic_results' => $organic,
            'search_information' => array_intersect_key( (array) ( $result['search_information'] ?? array() ), array_flip( array( 'query_displayed','organic_results_state','total_results','time_taken_displayed' ) ) ),
            'search_metadata' => array_intersect_key( (array) ( $result['search_metadata'] ?? array() ), array_flip( array( 'id','status','created_at','processed_at','google_url' ) ) ),
        );
    }

    public function cron_sync(): void {
        foreach ( array( 'google','bing','pagespeed' ) as $provider ) {
            $row = $this->get( $provider, false );
            if ( 'connected' !== (string) $row['status'] ) continue;
            $config = (array) ( $row['config'] ?? array() );
            if ( array_key_exists( 'auto_sync', $config ) && empty( $config['auto_sync'] ) ) continue;
            $this->sync( $provider );
        }
    }

    /** @return array<string,mixed>|WP_Error */
    public function discover_google(): array|WP_Error {
        $token = $this->bearer_token( 'google' );
        if ( is_wp_error( $token ) ) return $token;
        $headers = array( 'Authorization' => 'Bearer ' . $token );
        $sites = $this->json_get( 'https://www.googleapis.com/webmasters/v3/sites', $headers );
        if ( is_wp_error( $sites ) ) return $sites;
        $ga = $this->json_get( 'https://analyticsadmin.googleapis.com/v1beta/accountSummaries?pageSize=200', $headers );
        if ( is_wp_error( $ga ) ) $ga = array( 'accountSummaries' => array(), 'warning' => $ga->get_error_message() );
        $merchant = $this->json_get( 'https://merchantapi.googleapis.com/accounts/v1/accounts?pageSize=100', $headers );
        if ( is_wp_error( $merchant ) ) $merchant = array( 'accounts' => array(), 'warning' => $merchant->get_error_message() );
        return array(
            'sites' => array_values( array_map( static fn( $site ) => array( 'url' => $site['siteUrl'] ?? '', 'permission' => $site['permissionLevel'] ?? '' ), (array) ( $sites['siteEntry'] ?? array() ) ) ),
            'ga4' => (array) ( $ga['accountSummaries'] ?? array() ),
            'merchant' => (array) ( $merchant['accounts'] ?? array() ),
        );
    }

    /** @return array<string,mixed>|WP_Error */
    private function sync_google(): array|WP_Error {
        $row = $this->get( 'google', true );
        $config = (array) $row['config'];
        $token = $this->bearer_token( 'google' );
        if ( is_wp_error( $token ) ) return $token;
        $headers = array( 'Authorization' => 'Bearer ' . $token, 'Content-Type' => 'application/json' );
        $out = array( 'gsc_rows' => 0, 'ga4_rows' => 0, 'merchant_accounts' => 0 );
        $site = trim( (string) ( $config['gsc_site'] ?? '' ) );
        if ( '' !== $site ) {
            $end = gmdate( 'Y-m-d', time() - DAY_IN_SECONDS );
            $start = gmdate( 'Y-m-d', time() - 28 * DAY_IN_SECONDS );
            $url = 'https://www.googleapis.com/webmasters/v3/sites/' . rawurlencode( $site ) . '/searchAnalytics/query';
            $payload = array( 'startDate' => $start, 'endDate' => $end, 'dimensions' => array( 'query','page','device','country' ), 'rowLimit' => 25000, 'dataState' => 'final' );
            $res = $this->json_request( 'POST', $url, $headers, $payload );
            if ( is_wp_error( $res ) ) return $res;
            $rows = array();
            foreach ( (array) ( $res['rows'] ?? array() ) as $item ) {
                $keys = (array) ( $item['keys'] ?? array() );
                $rows[] = array(
                    'query' => (string) ( $keys[0] ?? '' ),
                    'target_url' => (string) ( $keys[1] ?? '' ),
                    'device' => strtolower( (string) ( $keys[2] ?? '' ) ),
                    'country' => strtoupper( (string) ( $keys[3] ?? '' ) ),
                    'current_position' => $item['position'] ?? null,
                    'impressions' => $item['impressions'] ?? 0,
                    'clicks' => $item['clicks'] ?? 0,
                    'ctr' => isset( $item['ctr'] ) ? round( 100 * (float) $item['ctr'], 4 ) : null,
                    'search_engine' => 'google',
                    'checked_at' => current_time( 'mysql', true ),
                );
            }
            $import = $this->seo->import_keywords( $rows, 'gsc-live' );
            if ( is_wp_error( $import ) ) return $import;
            $out['gsc_rows'] = (int) ( $import['imported'] ?? 0 );
        }
        $property = preg_replace( '/\D+/', '', (string) ( $config['ga4_property'] ?? '' ) );
        if ( '' !== $property ) {
            $body = array(
                'dateRanges' => array( array( 'startDate' => '28daysAgo', 'endDate' => 'yesterday' ) ),
                'dimensions' => array( array( 'name' => 'pagePath' ) ),
                'metrics' => array( array( 'name' => 'sessions' ), array( 'name' => 'screenPageViews' ), array( 'name' => 'engagementRate' ) ),
                'limit' => 10000,
            );
            $ga = $this->json_request( 'POST', 'https://analyticsdata.googleapis.com/v1beta/properties/' . rawurlencode( $property ) . ':runReport', $headers, $body );
            if ( ! is_wp_error( $ga ) ) {
                $out['ga4_rows'] = count( (array) ( $ga['rows'] ?? array() ) );
                update_option( 'k20ai_ga4_last_snapshot', array( 'at' => current_time( 'mysql', true ), 'property' => $property, 'rows' => array_slice( (array) ( $ga['rows'] ?? array() ), 0, 1000 ) ), false );
            } else {
                $out['ga4_warning'] = $ga->get_error_message();
            }
        }
        $merchant_account = trim( (string) ( $config['merchant_account'] ?? '' ) );
        if ( '' !== $merchant_account ) {
            $merchant_account = str_starts_with( $merchant_account, 'accounts/' ) ? $merchant_account : 'accounts/' . preg_replace( '/\D+/', '', $merchant_account );
            $issues = $this->json_get( 'https://merchantapi.googleapis.com/accounts/v1/' . $merchant_account . '/issues?pageSize=100', array( 'Authorization' => 'Bearer ' . $token ) );
            if ( ! is_wp_error( $issues ) ) {
                $out['merchant_accounts'] = 1;
                update_option( 'k20ai_merchant_last_snapshot', array( 'at' => current_time( 'mysql', true ), 'account' => $merchant_account, 'issues' => $issues ), false );
            } else $out['merchant_warning'] = $issues->get_error_message();
        }
        return $out;
    }

    /** @return array<string,mixed>|WP_Error */
    public function discover_bing(): array|WP_Error {
        $row = $this->get( 'bing', true );
        $headers = array();
        $url = 'https://www.bing.com/webmaster/api.svc/json/GetUserSites';
        if ( ! empty( $row['secrets']['api_key'] ) ) $url .= '?apikey=' . rawurlencode( (string) $row['secrets']['api_key'] );
        else {
            $token = $this->bearer_token( 'bing' );
            if ( is_wp_error( $token ) ) return $token;
            $headers['Authorization'] = 'Bearer ' . $token;
        }
        $res = $this->json_get( $url, $headers );
        if ( is_wp_error( $res ) ) return $res;
        return array( 'sites' => (array) ( $res['d'] ?? $res['sites'] ?? $res ) );
    }

    /** @return array<string,mixed>|WP_Error */
    private function sync_bing(): array|WP_Error {
        $row = $this->get( 'bing', true );
        $site = trim( (string) ( $row['config']['site_url'] ?? home_url() ) );
        $headers = array();
        $base = 'https://www.bing.com/webmaster/api.svc/json/';
        $query_auth = '';
        if ( ! empty( $row['secrets']['api_key'] ) ) $query_auth = '&apikey=' . rawurlencode( (string) $row['secrets']['api_key'] );
        else {
            $token = $this->bearer_token( 'bing' );
            if ( is_wp_error( $token ) ) return $token;
            $headers['Authorization'] = 'Bearer ' . $token;
        }
        $url = $base . 'GetQueryStats?siteUrl=' . rawurlencode( $site );
        if ( '' !== $query_auth ) $url .= $query_auth;
        $res = $this->json_get( $url, $headers );
        if ( is_wp_error( $res ) ) return $res;
        $raw_rows = (array) ( $res['d'] ?? $res['QueryStats'] ?? $res );
        $rows = array();
        foreach ( $raw_rows as $item ) {
            if ( ! is_array( $item ) ) continue;
            $rows[] = array(
                'query' => (string) ( $item['Query'] ?? $item['query'] ?? '' ),
                'target_url' => (string) ( $item['Url'] ?? $item['url'] ?? '' ),
                'current_position' => $item['AvgImpressionPosition'] ?? $item['AveragePosition'] ?? null,
                'impressions' => $item['Impressions'] ?? null,
                'clicks' => $item['Clicks'] ?? null,
                'ctr' => isset( $item['Clicks'], $item['Impressions'] ) && (int) $item['Impressions'] > 0 ? round( 100 * (int) $item['Clicks'] / (int) $item['Impressions'], 4 ) : null,
                'search_engine' => 'bing',
                'checked_at' => current_time( 'mysql', true ),
            );
        }
        $import = $this->seo->import_keywords( $rows, 'bing-live' );
        if ( is_wp_error( $import ) ) return $import;
        return array( 'bing_rows' => (int) ( $import['imported'] ?? 0 ) );
    }

    /** @return array<string,mixed>|WP_Error */
    private function test_pagespeed(): array|WP_Error {
        $row = $this->get( 'pagespeed', true );
        if ( empty( $row['secrets']['api_key'] ) ) return new WP_Error( 'missing_key', __( 'PageSpeed API Key ثبت نشده است.', 'k20-ai-press' ) );
        $url = 'https://www.googleapis.com/pagespeedonline/v5/runPagespeed?strategy=mobile&category=performance&url=' . rawurlencode( home_url() ) . '&key=' . rawurlencode( (string) $row['secrets']['api_key'] );
        $res = $this->json_get( $url );
        if ( is_wp_error( $res ) ) return $res;
        return array( 'score' => isset( $res['lighthouseResult']['categories']['performance']['score'] ) ? round( 100 * (float) $res['lighthouseResult']['categories']['performance']['score'] ) : null, 'url' => home_url() );
    }

    /** @return array<string,mixed>|WP_Error */
    private function sync_pagespeed(): array|WP_Error {
        $result = $this->test_pagespeed();
        if ( is_wp_error( $result ) ) return $result;
        update_option( 'k20ai_pagespeed_last_snapshot', array_merge( $result, array( 'at' => current_time( 'mysql', true ) ) ), false );
        return $result;
    }

    /** @return array<string,mixed>|WP_Error */
    private function test_github(): array|WP_Error {
        $row = $this->get( 'github', true );
        if ( empty( $row['secrets']['token'] ) ) return new WP_Error( 'missing_token', __( 'GitHub token ثبت نشده است.', 'k20-ai-press' ) );
        $headers = array( 'Authorization' => 'Bearer ' . $row['secrets']['token'], 'Accept' => 'application/vnd.github+json', 'X-GitHub-Api-Version' => '2022-11-28', 'User-Agent' => 'K20AI-Press/' . K20AI_PRESS_VERSION );
        $user = $this->json_get( 'https://api.github.com/user', $headers );
        if ( is_wp_error( $user ) ) return $user;
        $repo = trim( (string) ( $row['config']['repository'] ?? '' ) );
        $repo_data = null;
        if ( preg_match( '#^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$#', $repo ) ) {
            $repo_data = $this->json_get( 'https://api.github.com/repos/' . $repo, $headers );
            if ( is_wp_error( $repo_data ) ) return $repo_data;
        }
        $workflows = array();
        if ( $repo_data ) {
            $workflow_data = $this->json_get( 'https://api.github.com/repos/' . $repo . '/actions/workflows?per_page=100', $headers );
            if ( ! is_wp_error( $workflow_data ) ) {
                foreach ( (array) ( $workflow_data['workflows'] ?? array() ) as $workflow ) {
                    if ( ! is_array( $workflow ) ) continue;
                    $workflows[] = array(
                        'id' => (int) ( $workflow['id'] ?? 0 ),
                        'name' => sanitize_text_field( (string) ( $workflow['name'] ?? '' ) ),
                        'path' => sanitize_text_field( (string) ( $workflow['path'] ?? '' ) ),
                        'state' => sanitize_key( (string) ( $workflow['state'] ?? '' ) ),
                    );
                }
            }
        }
        return array( 'login' => (string) ( $user['login'] ?? '' ), 'repository' => $repo_data ? (string) ( $repo_data['full_name'] ?? $repo ) : $repo, 'permissions' => $repo_data['permissions'] ?? array(), 'workflows' => $workflows );
    }

    /** @return array<string,mixed>|WP_Error */
    private function test_ai( string $provider ): array|WP_Error {
        $row = $this->get( $provider, true );
        if ( empty( $row['secrets']['api_key'] ) ) return new WP_Error( 'missing_key', __( 'API Key ثبت نشده است.', 'k20-ai-press' ) );
        $selected = trim( (string) ( $row['config']['model'] ?? '' ) );
        if ( 'openai' === $provider ) {
            $res = $this->json_get( 'https://api.openai.com/v1/models', array( 'Authorization' => 'Bearer ' . $row['secrets']['api_key'] ) );
            if ( is_wp_error( $res ) ) return $res;
            return $this->verified_model_result( (array) ( $res['data'] ?? array() ), $selected );
        }
        if ( 'deepseek' === $provider ) {
            $res = $this->json_get( 'https://api.deepseek.com/models', array( 'Authorization' => 'Bearer ' . $row['secrets']['api_key'] ) );
            if ( is_wp_error( $res ) ) return $res;
            return $this->verified_model_result( (array) ( $res['data'] ?? array() ), $selected );
        }
        if ( 'gemini' === $provider ) {
            $res = $this->json_get( 'https://generativelanguage.googleapis.com/v1beta/models', array( 'x-goog-api-key' => (string) $row['secrets']['api_key'] ) );
            if ( is_wp_error( $res ) ) return $res;
            $items = array_map( static function( $item ) {
                if ( ! is_array( $item ) ) return array();
                $item['id'] = preg_replace( '#^models/#', '', (string) ( $item['name'] ?? '' ) );
                return $item;
            }, (array) ( $res['models'] ?? array() ) );
            return $this->verified_model_result( $items, $selected );
        }
        if ( 'anthropic' === $provider ) {
            $res = $this->json_get( 'https://api.anthropic.com/v1/models', array( 'x-api-key' => $row['secrets']['api_key'], 'anthropic-version' => '2023-06-01' ) );
            if ( is_wp_error( $res ) ) return $res;
            return $this->verified_model_result( (array) ( $res['data'] ?? array() ), $selected );
        }
        if ( 'custom_ai' === $provider ) {
            $base = untrailingslashit( (string) ( $row['config']['base_url'] ?? '' ) );
            if ( ! K20AI_Data_Integrity::valid_external_https_url( $base ) ) return new WP_Error( 'invalid_base_url', __( 'Base URL باید HTTPS عمومی و معتبر باشد.', 'k20-ai-press' ) );
            $res = $this->json_get( $base . '/models', array( 'Authorization' => 'Bearer ' . $row['secrets']['api_key'] ) );
            if ( is_wp_error( $res ) ) return $res;
            return $this->verified_model_result( (array) ( $res['data'] ?? array() ), $selected );
        }
        return new WP_Error( 'unsupported_ai', __( 'AI provider پشتیبانی نمی‌شود.', 'k20-ai-press' ) );
    }

    /** @param array<int,mixed> $items @return array<string,mixed>|WP_Error */
    private function verified_model_result( array $items, string $selected ): array|WP_Error {
        $ids = array_values( array_unique( array_filter( array_map( static fn( $item ) => is_array( $item ) ? trim( (string) ( $item['id'] ?? '' ) ) : '', $items ) ) ) );
        if ( '' === $selected ) {
            return new WP_Error( 'model_required', __( 'اتصال API معتبر است؛ یک Model ID از فهرست مدل‌های قابل‌دسترسی این حساب انتخاب کنید.', 'k20-ai-press' ),
                array( 'status' => 409, 'selected_model' => '', 'available_models' => array_slice( $ids, 0, 100 ) )
            );
        }
        if ( ! in_array( $selected, $ids, true ) ) {
            return new WP_Error( 'selected_model_unavailable', __( 'Model انتخاب‌شده در لیست مدل‌های قابل‌دسترسی این حساب وجود ندارد.', 'k20-ai-press' ),
                array( 'status' => 409, 'selected_model' => $selected, 'available_models' => array_slice( $ids, 0, 100 ) )
            );
        }
        return array(
            'models' => count( $ids ),
            'model_ids' => array_slice( $ids, 0, 100 ),
            'selected_model' => $selected,
            'selected_model_verified' => true,
        );
    }

    /** @return array<string,mixed>|WP_Error */
    public function ai_generate( string $provider, array $request ): array|WP_Error {
        $provider = sanitize_key( $provider );
        $row = $this->get( $provider, true );
        if ( 'connected' !== (string) $row['status'] ) return new WP_Error( 'provider_disconnected', __( 'Provider هنوز با تست زنده تأیید نشده است؛ ابتدا «تست اتصال» را با موفقیت اجرا کنید.', 'k20-ai-press' ) );
        $key = (string) ( $row['secrets']['api_key'] ?? '' );
        $model = trim( (string) ( $row['config']['model'] ?? '' ) );
        if ( '' === $key || '' === $model ) return new WP_Error( 'provider_incomplete', __( 'API Key یا Model کامل نیست.', 'k20-ai-press' ) );
        $system = (string) ( $request['system'] ?? '' );
        $prompt = (string) ( $request['prompt'] ?? '' );
        if ( 'openai' === $provider ) {
            $format = array( 'type' => 'json_object' );
            if ( ! empty( $request['schema'] ) && is_array( $request['schema'] ) ) {
                $format = array(
                    'type' => 'json_schema',
                    'name' => 'k20_entity_completion',
                    'schema' => $request['schema'],
                    'strict' => false,
                );
            }
            $body = array(
                'model' => $model,
                'store' => false,
                'input' => array(
                    array( 'role' => 'system', 'content' => array( array( 'type' => 'input_text', 'text' => $system ) ) ),
                    array( 'role' => 'user', 'content' => array( array( 'type' => 'input_text', 'text' => $prompt ) ) ),
                ),
                'text' => array( 'format' => $format ),
            );
            if ( ! empty( $row['config']['web_search'] ) && ! empty( $request['web_search'] ) ) {
                $body['tools'] = array( array( 'type' => 'web_search' ) );
                $body['include'] = array( 'web_search_call.action.sources' );
            }
            $res = $this->json_request( 'POST', 'https://api.openai.com/v1/responses', array( 'Authorization' => 'Bearer ' . $key, 'Content-Type' => 'application/json' ), $body, 75 );
            if ( is_wp_error( $res ) ) return $res;
            $text = $this->openai_output_text( $res );
            $sources = $this->openai_sources( $res );
            return $this->decode_ai_json( $provider, $model, $text, $sources, $res );
        }
        if ( in_array( $provider, array( 'deepseek','custom_ai' ), true ) ) {
            $base = 'deepseek' === $provider ? 'https://api.deepseek.com' : untrailingslashit( (string) $row['config']['base_url'] );
            $body = array( 'model' => $model, 'messages' => array( array( 'role' => 'system', 'content' => $system ), array( 'role' => 'user', 'content' => $prompt ) ), 'response_format' => array( 'type' => 'json_object' ), 'temperature' => 0.2 );
            $res = $this->json_request( 'POST', $base . '/chat/completions', array( 'Authorization' => 'Bearer ' . $key, 'Content-Type' => 'application/json' ), $body, 75 );
            if ( is_wp_error( $res ) ) return $res;
            $text = (string) ( $res['choices'][0]['message']['content'] ?? '' );
            return $this->decode_ai_json( $provider, $model, $text, array(), $res );
        }
        if ( 'gemini' === $provider ) {
            $body = array( 'systemInstruction' => array( 'parts' => array( array( 'text' => $system ) ) ), 'contents' => array( array( 'role' => 'user', 'parts' => array( array( 'text' => $prompt ) ) ) ), 'generationConfig' => array( 'responseMimeType' => 'application/json', 'temperature' => 0.2 ) );
            $res = $this->json_request( 'POST', 'https://generativelanguage.googleapis.com/v1beta/models/' . rawurlencode( $model ) . ':generateContent', array( 'Content-Type' => 'application/json', 'x-goog-api-key' => $key ), $body, 75 );
            if ( is_wp_error( $res ) ) return $res;
            $text = (string) ( $res['candidates'][0]['content']['parts'][0]['text'] ?? '' );
            return $this->decode_ai_json( $provider, $model, $text, array(), $res );
        }
        if ( 'anthropic' === $provider ) {
            $body = array( 'model' => $model, 'max_tokens' => 6000, 'system' => $system . "\nReturn valid JSON only.", 'messages' => array( array( 'role' => 'user', 'content' => $prompt ) ), 'temperature' => 0.2 );
            $res = $this->json_request( 'POST', 'https://api.anthropic.com/v1/messages', array( 'x-api-key' => $key, 'anthropic-version' => '2023-06-01', 'Content-Type' => 'application/json' ), $body, 75 );
            if ( is_wp_error( $res ) ) return $res;
            $text = '';
            foreach ( (array) ( $res['content'] ?? array() ) as $part ) if ( 'text' === ( $part['type'] ?? '' ) ) $text .= (string) ( $part['text'] ?? '' );
            return $this->decode_ai_json( $provider, $model, $text, array(), $res );
        }
        return new WP_Error( 'unsupported_ai', __( 'AI provider پشتیبانی نمی‌شود.', 'k20-ai-press' ) );
    }

    /** @return array<string,mixed>|WP_Error */
    public function github_dispatch( array $inputs = array() ): array|WP_Error {
        $row = $this->get( 'github', false );
        $workflow = trim( (string) ( $row['config']['workflow'] ?? '' ) );
        if ( '' === $workflow ) return new WP_Error( 'github_incomplete', __( 'Default workflow is not configured.', 'k20-ai-press' ) );
        return $this->github_dispatch_workflow( $workflow, $inputs );
    }

    /** @return array<string,mixed>|WP_Error */
    public function github_dispatch_workflow( string $workflow, array $inputs = array() ): array|WP_Error {
        $row = $this->get( 'github', true );
        $repo = trim( (string) ( $row['config']['repository'] ?? '' ) );
        $branch = trim( (string) ( $row['config']['branch'] ?? 'main' ) );
        $workflow = trim( $workflow );
        if ( 'connected' !== (string) ( $row['status'] ?? '' ) ) return new WP_Error( 'github_not_connected', __( 'GitHub connection has not passed a live test.', 'k20-ai-press' ) );
        if ( ! preg_match( '#^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$#', $repo ) || '' === $workflow || empty( $row['secrets']['token'] ) ) return new WP_Error( 'github_incomplete', __( 'Repository, workflow, or token is incomplete.', 'k20-ai-press' ) );
        if ( ! preg_match( '#^[A-Za-z0-9_./-]+[.]ya?ml$#i', $workflow ) && ! ctype_digit( $workflow ) ) return new WP_Error( 'github_workflow_invalid', __( 'Workflow must be a YAML file path/name or workflow numeric ID.', 'k20-ai-press' ) );
        // workflow_dispatch inputs are untrusted; keep them scalar, bounded and sanitized before GitHub receives them.
        $safe_inputs = array();
        foreach ( array_slice( $inputs, 0, 20, true ) as $key => $value ) {
            $safe_key = preg_replace( '/[^A-Za-z0-9_.-]/', '', (string) $key );
            if ( '' === $safe_key || is_array( $value ) || is_object( $value ) || is_resource( $value ) ) continue;
            $safe_inputs[ substr( $safe_key, 0, 64 ) ] = substr( sanitize_text_field( (string) $value ), 0, 1000 );
        }
        $res = wp_safe_remote_post( 'https://api.github.com/repos/' . $repo . '/actions/workflows/' . rawurlencode( $workflow ) . '/dispatches', array(
            'timeout' => 20,
            'headers' => array( 'Authorization' => 'Bearer ' . $row['secrets']['token'], 'Accept' => 'application/vnd.github+json', 'X-GitHub-Api-Version' => '2022-11-28', 'User-Agent' => 'K20AI-Press/' . K20AI_PRESS_VERSION, 'Content-Type' => 'application/json' ),
            'body' => wp_json_encode( array( 'ref' => $branch ?: 'main', 'inputs' => $safe_inputs ) ),
        ) );
        if ( is_wp_error( $res ) ) return $res;
        $code = (int) wp_remote_retrieve_response_code( $res );
        if ( ! in_array( $code, array( 200, 201, 204 ), true ) ) return new WP_Error( 'github_dispatch_failed', sprintf( /* translators: %d: HTTP status code. */ __( 'GitHub workflow dispatch failed: HTTP %d', 'k20-ai-press' ), $code ) );
        $this->audit( 'github.workflow.dispatch', 'github', 'OK', array( 'repository' => $repo, 'workflow' => $workflow, 'branch' => $branch ) );
        return array( 'status' => 'dispatched', 'repository' => $repo, 'workflow' => $workflow, 'branch' => $branch );
    }

    /** @return string|WP_Error */
    private function bearer_token( string $provider ): string|WP_Error {
        $row = $this->get( $provider, true );
        $secrets = (array) ( $row['secrets'] ?? array() );
        $config = (array) $row['config'];
        if ( ! empty( $secrets['access_token'] ) && (int) ( $config['token_expires_at'] ?? 0 ) > time() + 90 ) return (string) $secrets['access_token'];
        if ( empty( $secrets['refresh_token'] ) || empty( $config['client_id'] ) || empty( $secrets['client_secret'] ) ) return new WP_Error( 'oauth_expired', __( 'توکن معتبر یا Refresh Token موجود نیست؛ اتصال را دوباره برقرار کنید.', 'k20-ai-press' ) );
        $url = 'google' === $provider ? 'https://oauth2.googleapis.com/token' : 'https://www.bing.com/webmasters/oauth/token';
        $response = wp_safe_remote_post( $url, array( 'timeout' => 20, 'body' => array( 'client_id' => $config['client_id'], 'client_secret' => $secrets['client_secret'], 'refresh_token' => $secrets['refresh_token'], 'grant_type' => 'refresh_token' ) ) );
        if ( is_wp_error( $response ) ) return $response;
        $payload = json_decode( (string) wp_remote_retrieve_body( $response ), true );
        if ( (int) wp_remote_retrieve_response_code( $response ) >= 300 || empty( $payload['access_token'] ) ) return new WP_Error( 'oauth_refresh_failed', sanitize_text_field( (string) ( $payload['error_description'] ?? $payload['error'] ?? 'Token refresh failed' ) ) );
        $secrets['access_token'] = (string) $payload['access_token'];
        if ( ! empty( $payload['refresh_token'] ) ) $secrets['refresh_token'] = (string) $payload['refresh_token'];
        $config['token_expires_at'] = time() + max( 60, (int) ( $payload['expires_in'] ?? 3600 ) );
        $this->write_row( $provider, $config, $secrets, 'connected', null, (array) $row['meta'] );
        return (string) $payload['access_token'];
    }

    /** @return array<string,mixed>|WP_Error */
    private function json_get( string $url, array $headers = array() ): array|WP_Error {
        return $this->json_request( 'GET', $url, $headers, null, 25 );
    }

    /** @return array<string,mixed>|WP_Error */
    private function json_request( string $method, string $url, array $headers = array(), ?array $body = null, int $timeout = 25 ): array|WP_Error {
        if ( ! K20AI_Data_Integrity::valid_external_https_url( $url ) ) return new WP_Error( 'invalid_url', __( 'Endpoint باید HTTPS عمومی و معتبر باشد.', 'k20-ai-press' ) );
        $args = array( 'method' => $method, 'timeout' => max( 5, min( 90, $timeout ) ), 'redirection' => 2, 'reject_unsafe_urls' => true, 'limit_response_size' => 5 * MB_IN_BYTES, 'headers' => $headers, 'user-agent' => 'K20AI-Press/' . K20AI_PRESS_VERSION . '; ' . home_url() );
        if ( null !== $body ) { $args['body'] = wp_json_encode( $body ); $args['headers']['Content-Type'] = 'application/json'; }
        $start = microtime( true );
        $response = wp_safe_remote_request( $url, $args );
        $latency = (int) round( 1000 * ( microtime( true ) - $start ) );
        if ( is_wp_error( $response ) ) return $response;
        $code = (int) wp_remote_retrieve_response_code( $response );
        $raw = (string) wp_remote_retrieve_body( $response );
        $json = '' !== $raw ? json_decode( $raw, true ) : array();
        if ( $code < 200 || $code >= 300 ) {
            $message = is_array( $json ) ? ( $json['error']['message'] ?? $json['message'] ?? $json['error_description'] ?? $json['error'] ?? null ) : null;
            return new WP_Error( 'remote_http_' . $code, sanitize_text_field( (string) ( $message ?: 'Remote HTTP ' . $code ) ), array( 'status' => 502, 'remote_status' => $code ) );
        }
        if ( ! is_array( $json ) ) $json = array( 'raw' => $raw );
        $json['_latency_ms'] = $latency;
        return $json;
    }

    /** @return array<string,mixed>|WP_Error */
    private function decode_ai_json( string $provider, string $model, string $text, array $sources, array $raw ): array|WP_Error {
        $text = trim( $text );
        if ( str_starts_with( $text, '```' ) ) $text = preg_replace( '/^```(?:json)?\s*|\s*```$/i', '', $text );
        $json = json_decode( (string) $text, true );
        if ( ! is_array( $json ) ) return new WP_Error( 'invalid_ai_json', __( 'مدل پاسخ JSON معتبر برنگرداند.', 'k20-ai-press' ) );
        global $wpdb;
        $t = K20AI_Database::tables();
        $wpdb->insert( $t['provider_usage'], array( 'provider' => $provider, 'model' => $model, 'module' => 'ai_orchestrator', 'task' => 'entity_completion', 'units' => null, 'cost' => null, 'latency_ms' => isset( $raw['_latency_ms'] ) ? (int) $raw['_latency_ms'] : null, 'status' => 'OK', 'created_at' => current_time( 'mysql', true ) ) );
        return array( 'provider' => $provider, 'model' => $model, 'data' => $json, 'sources' => $sources );
    }

    private function openai_output_text( array $response ): string {
        $text = '';
        foreach ( (array) ( $response['output'] ?? array() ) as $item ) {
            if ( 'message' !== ( $item['type'] ?? '' ) ) continue;
            foreach ( (array) ( $item['content'] ?? array() ) as $content ) if ( 'output_text' === ( $content['type'] ?? '' ) ) $text .= (string) ( $content['text'] ?? '' );
        }
        return $text;
    }

    /** @return array<int,array<string,string>> */
    private function openai_sources( array $response ): array {
        $out = array();
        foreach ( (array) ( $response['output'] ?? array() ) as $item ) {
            if ( 'web_search_call' === ( $item['type'] ?? '' ) ) {
                foreach ( (array) ( $item['action']['sources'] ?? array() ) as $src ) {
                    if ( ! empty( $src['url'] ) ) $out[] = array( 'url' => esc_url_raw( (string) $src['url'] ), 'title' => sanitize_text_field( (string) ( $src['title'] ?? '' ) ) );
                }
            }
        }
        return array_values( array_unique( $out, SORT_REGULAR ) );
    }

    /** @param array<string,mixed> $config @param array<string,mixed> $secrets @param array<string,mixed> $meta */
    private function write_row( string $provider, array $config, array $secrets, string $status, ?string $error, array $meta, bool $tested = false ): void {
        $encrypted = $this->encrypt_json( $secrets );
        if ( is_wp_error( $encrypted ) ) return;
        $all = $this->all();
        $old = isset( $all[ $provider ] ) && is_array( $all[ $provider ] ) ? $all[ $provider ] : array();
        $all[ $provider ] = array(
            'provider' => $provider,
            'status' => $status,
            'config' => $config,
            'secret' => $encrypted,
            'last_test_at' => $tested ? current_time( 'mysql', true ) : ( $old['last_test_at'] ?? null ),
            'last_sync_at' => $old['last_sync_at'] ?? null,
            'last_error' => $error,
            'meta' => $meta,
        );
        $this->persist( $all );
    }

    private function mark_error( string $provider, string $message ): void {
        $all = $this->all();
        if ( ! isset( $all[ $provider ] ) ) $all[ $provider ] = array( 'provider' => $provider, 'config' => array(), 'secret' => '', 'meta' => array() );
        $all[ $provider ]['status'] = 'error';
        $all[ $provider ]['last_test_at'] = current_time( 'mysql', true );
        $all[ $provider ]['last_error'] = sanitize_text_field( $message );
        $this->persist( $all );
        $this->audit( 'connection.error', $provider, 'ERROR', array( 'message' => $message ) );
    }

    /** @return string|WP_Error */
    private function encrypt_json( array $data ): string|WP_Error {
        return K20AI_Crypto::encrypt_json( $data, 'connection-center' );
    }

    /** @return array<string,mixed> */
    private function decrypt_json( string $blob ): array {
        return K20AI_Crypto::decrypt_json( $blob, 'connection-center' );
    }

    private function audit( string $action, string $provider, string $result, array $meta ): void {
        global $wpdb;
        $t = K20AI_Database::tables();
        $wpdb->insert( $t['audit_log'], array( 'actor_id' => get_current_user_id() ?: null, 'actor_type' => get_current_user_id() ? 'human' : 'system', 'action_name' => $action, 'target_type' => 'connection', 'target_id' => $provider, 'result' => $result, 'trace_id' => function_exists( 'wp_generate_uuid4' ) ? wp_generate_uuid4() : null, 'meta' => wp_json_encode( $meta ), 'created_at' => current_time( 'mysql', true ) ) );
    }
}
