<?php

defined( 'ABSPATH' ) || exit;

/**
 * Pure SEO/GEO scoring engine for K20 AI Press 3.
 *
 * The analyzer never invents provider metrics. It only scores evidence supplied
 * by WordPress/WooCommerce or a verified integration/import.
 */
final class K20AI_SEO_Analyzer {
    /** @return array<string,mixed> */
    public function analyze( array $evidence ): array {
        $issues = array_merge(
            $this->base_rules( $evidence ),
            $this->product_rules( $evidence ),
            $this->content_rules( $evidence ),
            $this->media_rules( $evidence ),
            $this->link_rules( $evidence )
        );

        $scores = array(
            'technical' => 100,
            'content'   => 100,
            'schema'    => 100,
            'media'     => 100,
            'commerce'  => 100,
        );
        foreach ( $issues as $issue ) {
            $component = (string) ( $issue['component'] ?? 'technical' );
            if ( isset( $scores[ $component ] ) ) {
                $scores[ $component ] = max( 0, $scores[ $component ] - (int) ( $issue['penalty'] ?? 0 ) );
            }
        }

        $kind = (string) ( $evidence['kind'] ?? 'content_post' );
        if ( 'product' === $kind ) {
            $weights = array( 'technical' => .25, 'content' => .20, 'schema' => .20, 'media' => .15, 'commerce' => .20 );
        } elseif ( in_array( $kind, array( 'content_post', 'page', 'news' ), true ) ) {
            $weights = array( 'technical' => .25, 'content' => .35, 'schema' => .20, 'media' => .10, 'commerce' => .10 );
        } elseif ( 'media' === $kind ) {
            $weights = array( 'technical' => .25, 'content' => .10, 'schema' => .10, 'media' => .45, 'commerce' => .10 );
        } else {
            $weights = array( 'technical' => .30, 'content' => .25, 'schema' => .15, 'media' => .15, 'commerce' => .15 );
        }

        $total = 0.0;
        foreach ( $weights as $key => $weight ) {
            $total += (float) $scores[ $key ] * $weight;
        }

        return array(
            'total'      => $this->bounded( $total ),
            'technical'  => $scores['technical'],
            'content'    => $scores['content'],
            'schema'     => $scores['schema'],
            'media'      => $scores['media'],
            'commerce'   => $scores['commerce'],
            'issues'     => $issues,
        );
    }

    /** @return array<int,array<string,mixed>> */
    private function base_rules( array $e ): array {
        $issues = array();
        $kind = (string) ( $e['kind'] ?? '' );
        if ( 'media' === $kind || ( array_key_exists( 'public_indexable', $e ) && empty( $e['public_indexable'] ) ) ) return $issues;
        $title = $this->text( $e['seo_title'] ?? $e['title'] ?? '' );
        $description = $this->text( $e['meta_description'] ?? $e['excerpt'] ?? '' );
        $url = $this->text( $e['url'] ?? '' );
        $canonical = $this->text( $e['canonical'] ?? '' );
        $status = $this->text( $e['status'] ?? '' );

        if ( '' === $title ) {
            $issues[] = $this->issue( 'meta.title.missing', 'critical', 'technical', 25, 'عنوان سئو ثبت نشده است', 'برای این موجودیت عنوان صفحه یا عنوان سئوی قابل استفاده وجود ندارد.', array( 'field' => 'seo_title' ) );
        } elseif ( mb_strlen( $title ) < 20 || mb_strlen( $title ) > 65 ) {
            $issues[] = $this->issue( 'meta.title.length', 'warning', 'content', 8, 'طول عنوان سئو نیازمند بازبینی است', 'عنوان باید روشن، منحصربه‌فرد و برای نتیجه جست‌وجو خوانا باشد.', array( 'length' => mb_strlen( $title ), 'min' => 20, 'max' => 65 ) );
        }

        if ( '' === $description ) {
            $issues[] = $this->issue( 'meta.description.missing', 'warning', 'content', 14, 'توضیحات متا ثبت نشده است', 'برای این صفحه توضیح متای اختصاصی یا توضیح قابل استفاده پیدا نشد.', array( 'field' => 'meta_description' ) );
        } elseif ( mb_strlen( $description ) < 70 || mb_strlen( $description ) > 180 ) {
            $issues[] = $this->issue( 'meta.description.length', 'info', 'content', 5, 'طول توضیحات متا نیازمند بازبینی است', 'توضیح متا بهتر است خلاصه، دقیق و هماهنگ با نیت صفحه باشد.', array( 'length' => mb_strlen( $description ) ) );
        }

        if ( '' === $url ) {
            $issues[] = $this->issue( 'url.missing', 'critical', 'technical', 20, 'آدرس عمومی صفحه پیدا نشد', 'این موجودیت URL عمومی پایدار ندارد.', array( 'field' => 'url' ) );
        }

        if ( '' === $canonical && '' !== $url ) {
            $issues[] = $this->issue( 'canonical.missing', 'warning', 'technical', 10, 'Canonical مشخص نیست', 'برای کاهش ابهام URL بهتر است Canonical معتبر و هم‌راستا با صفحه مشخص باشد.', array( 'suggested' => $url ) );
        }

        if ( in_array( $status, array( 'publish', 'published' ), true ) && ! empty( $e['noindex'] ) ) {
            $issues[] = $this->issue( 'robots.noindex.published', 'warning', 'technical', 15, 'صفحه منتشرشده Noindex است', 'این صفحه منتشر شده اما برای ایندکس مسدود است؛ تصمیم باید بازبینی شود.', array() );
        }

        if ( ! empty( $e['stale_days'] ) && (int) $e['stale_days'] >= 365 ) {
            $issues[] = $this->issue( 'freshness.stale', 'info', 'content', 5, 'محتوا قدیمی است', 'بیش از یک سال از آخرین به‌روزرسانی گذشته است؛ تازه‌بودن داده‌ها باید بررسی شود.', array( 'stale_days' => (int) $e['stale_days'] ) );
        }

        return $issues;
    }

    /** @return array<int,array<string,mixed>> */
    private function product_rules( array $e ): array {
        if ( 'product' !== ( $e['kind'] ?? '' ) || ( array_key_exists( 'public_indexable', $e ) && empty( $e['public_indexable'] ) ) ) {
            return array();
        }
        $issues = array();
        if ( '' === $this->text( $e['sku'] ?? '' ) ) {
            $issues[] = $this->issue( 'product.sku.missing', 'warning', 'commerce', 8, 'SKU ثبت نشده است', 'SKU برای مدیریت کاتالوگ، فید و تطبیق محصول مهم است.', array( 'field' => 'sku' ) );
        }
        if ( '' === $this->text( $e['brand'] ?? '' ) ) {
            $issues[] = $this->issue( 'product.brand.missing', 'warning', 'commerce', 8, 'برند محصول مشخص نیست', 'حداقل یک برند واقعی و قابل تأیید برای محصول انتخاب شود.', array( 'field' => 'brand' ) );
        }
        if ( empty( $e['categories'] ) ) {
            $issues[] = $this->issue( 'product.category.missing', 'critical', 'commerce', 12, 'دسته‌بندی محصول مشخص نیست', 'محصول بدون دسته در ناوبری، لینک‌سازی و Sitemap ضعیف می‌شود.', array( 'field' => 'category' ) );
        }
        if ( empty( $e['image_ids'] ) ) {
            $issues[] = $this->issue( 'media.image.missing', 'critical', 'media', 16, 'محصول تصویر ندارد', 'حداقل یک تصویر واقعی برای محصول لازم است.', array() );
        } elseif ( (int) ( $e['image_alt_count'] ?? 0 ) < count( (array) $e['image_ids'] ) ) {
            $issues[] = $this->issue( 'media.alt.missing', 'warning', 'media', 10, 'بعضی تصاویر ALT ندارند', 'برای تصاویر محصول متن جایگزین دقیق و غیرتکراری ثبت شود.', array( 'image_count' => count( (array) $e['image_ids'] ), 'alt_count' => (int) ( $e['image_alt_count'] ?? 0 ) ) );
        }
        if ( (int) ( $e['word_count'] ?? 0 ) < 80 ) {
            $issues[] = $this->issue( 'content.short', 'warning', 'content', 12, 'توضیحات محصول کوتاه است', 'محتوای قابل مشاهده برای تصمیم خرید و درک موتور جست‌وجو کافی نیست.', array( 'word_count' => (int) ( $e['word_count'] ?? 0 ) ) );
        }
        if ( null === ( $e['price'] ?? null ) || '' === (string) ( $e['price'] ?? '' ) ) {
            $issues[] = $this->issue( 'product.offer.incomplete', 'warning', 'schema', 10, 'Offer کامل نیست', 'قیمت واقعی برای Product/Offer و Merchant readiness پیدا نشد.', array( 'field' => 'price' ) );
        }
        if ( empty( $e['stock_status'] ) ) {
            $issues[] = $this->issue( 'product.stock.missing', 'warning', 'commerce', 8, 'وضعیت موجودی مشخص نیست', 'وضعیت موجودی باید با WooCommerce و داده ساختاریافته همخوان باشد.', array( 'field' => 'stock_status' ) );
        }
        $gtin_raw = trim( (string) ( $e['gtin_raw'] ?? $e['gtin'] ?? '' ) );
        $gtin_valid = null !== K20AI_Data_Integrity::normalize_gtin( $gtin_raw );
        if ( '' !== $gtin_raw && ! $gtin_valid ) {
            $issues[] = $this->issue( 'product.identifier.gtin_invalid', 'warning', 'schema', 9, 'GTIN نامعتبر است', 'شناسه ثبت‌شده طول یا رقم کنترل معتبر GS1 ندارد و در Feed/Schema استفاده نمی‌شود.', array( 'field' => 'gtin' ) );
        }
        if ( ! $gtin_valid && empty( $e['mpn'] ) ) {
            $issues[] = $this->issue( 'product.identifier.missing', 'info', 'schema', 6, 'شناسه جهانی معتبر یا MPN ثبت نشده است', 'اگر شناسه واقعی از سازنده یا GS1 وجود دارد ثبت شود؛ شناسه ساختگی تولید نمی‌شود.', array() );
        }
        if ( ! empty( $e['is_variable'] ) && empty( $e['attributes'] ) ) {
            $issues[] = $this->issue( 'product.variants.attributes_missing', 'warning', 'schema', 8, 'ویژگی‌های واریانت ناقص است', 'محصول متغیر باید ویژگی‌های تمایزدهنده روشن داشته باشد.', array() );
        }
        return $issues;
    }

    /** @return array<int,array<string,mixed>> */
    private function content_rules( array $e ): array {
        if ( ! in_array( (string) ( $e['kind'] ?? '' ), array( 'content_post', 'page', 'news' ), true ) || ( array_key_exists( 'public_indexable', $e ) && empty( $e['public_indexable'] ) ) ) {
            return array();
        }
        $issues = array();
        $count = (int) ( $e['word_count'] ?? 0 );
        if ( $count < 250 ) {
            $issues[] = $this->issue( 'content.article.short', 'warning', 'content', 15, 'متن محتوا کوتاه است', 'صفحه منتشرشده باید پاسخ کافی و قابل مشاهده به موضوع ارائه کند.', array( 'word_count' => $count ) );
        }
        if ( empty( $e['author_id'] ) ) {
            $issues[] = $this->issue( 'schema.article.author_missing', 'warning', 'schema', 10, 'نویسنده مشخص نیست', 'برای Article یا BlogPosting نویسنده واقعی و قابل نمایش لازم است.', array() );
        }
        if ( empty( $e['featured_image_id'] ) ) {
            $issues[] = $this->issue( 'content.featured_image.missing', 'info', 'media', 5, 'تصویر شاخص ثبت نشده است', 'برای محتواهای مهم تصویر شاخص واقعی و مرتبط در نظر بگیرید.', array() );
        }
        if ( empty( $e['internal_outbound_count'] ) ) {
            $issues[] = $this->issue( 'links.outbound.none', 'info', 'technical', 4, 'لینک داخلی خروجی دیده نشد', 'در صورت وجود صفحه یا محصول مرتبط، لینک داخلی طبیعی اضافه شود.', array() );
        }
        return $issues;
    }

    /** @return array<int,array<string,mixed>> */
    private function media_rules( array $e ): array {
        if ( 'media' !== ( $e['kind'] ?? '' ) ) {
            return array();
        }
        $issues = array();
        if ( '' === $this->text( $e['alt'] ?? '' ) ) {
            $issues[] = $this->issue( 'media.alt.missing', 'warning', 'media', 18, 'متن ALT ثبت نشده است', 'برای تصویر استفاده‌شده در صفحات عمومی، ALT توصیفی ثبت شود.', array( 'field' => 'alt' ) );
        }
        if ( empty( $e['width'] ) || empty( $e['height'] ) ) {
            $issues[] = $this->issue( 'media.dimensions.missing', 'info', 'technical', 6, 'ابعاد تصویر مشخص نیست', 'ابعاد واقعی برای جلوگیری از Layout Shift و مدیریت رسانه لازم است.', array() );
        }
        $mime = (string) ( $e['mime_type'] ?? '' );
        if ( str_starts_with( $mime, 'image/' ) && ! in_array( $mime, array( 'image/webp', 'image/avif', 'image/svg+xml' ), true ) ) {
            $issues[] = $this->issue( 'media.format.legacy', 'info', 'media', 4, 'فرمت تصویر قابل بهینه‌سازی است', 'در صورت سازگاری، WebP یا AVIF می‌تواند حجم انتقال را کاهش دهد.', array( 'mime_type' => $mime ) );
        }
        if ( ! empty( $e['filesize'] ) && (int) $e['filesize'] > 500 * 1024 ) {
            $issues[] = $this->issue( 'media.filesize.large', 'warning', 'media', 8, 'حجم تصویر زیاد است', 'حجم فایل بیش از ۵۰۰ کیلوبایت است و باید با حفظ کیفیت بررسی شود.', array( 'bytes' => (int) $e['filesize'] ) );
        }
        return $issues;
    }

    /** @return array<int,array<string,mixed>> */
    private function link_rules( array $e ): array {
        if ( 'media' === ( $e['kind'] ?? '' ) || ! in_array( (string) ( $e['status'] ?? '' ), array( 'publish', 'published' ), true ) ) {
            return array();
        }
        if ( ! empty( $e['internal_inbound_count'] ) ) {
            return array();
        }
        return array(
            $this->issue( 'links.orphan', 'warning', 'technical', 8, 'صفحه لینک داخلی ورودی ندارد', 'صفحه مهم بهتر است از حداقل یک صفحه قابل Crawl لینک داخلی دریافت کند.', array() ),
        );
    }

    /** @return array<string,mixed> */
    private function issue( string $code, string $severity, string $component, int $penalty, string $title, string $description, array $suggested ): array {
        return array(
            'rule_code'     => $code,
            'severity'      => $severity,
            'component'     => $component,
            'penalty'       => $penalty,
            'title'         => $title,
            'description'   => $description,
            'suggested_fix' => $suggested,
        );
    }

    private function text( mixed $value ): string {
        return trim( wp_strip_all_tags( (string) $value ) );
    }

    private function bounded( float $value ): int {
        return max( 0, min( 100, (int) round( $value ) ) );
    }
}
