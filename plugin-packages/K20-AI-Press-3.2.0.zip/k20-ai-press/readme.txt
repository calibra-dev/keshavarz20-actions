=== K20 AI Press ===
Contributors: keshavarz20
Tags: woocommerce, seo, ai, ecommerce, automation
Requires at least: 7.1
Tested up to: 7.1
Requires PHP: 8.3
Stable tag: 3.2.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Requires Plugins: woocommerce

Bilingual SEO/GEO, product intelligence, evidence, AI assistance and governed WooCommerce operations with audit and rollback.

== Description ==
K20 AI Press is a Persian/English operations layer for WordPress and WooCommerce. It combines SEO/GEO analysis, product-data quality, evidence and compatibility models, media and technical scans, AI-assisted editing, content engines, catalog feeds, bot policy, external service connections, audit trails, approvals and rollback.

The plugin is designed around three rules:

* Site data is the source of truth. Unknown technical or commercial facts stay unknown instead of being invented.
* Sensitive changes remain governed. Automation paths do not change price, stock, discounts, payment settings, users, roles or credentials.
* External services are optional. An administrator must configure and invoke them before selected site data is transmitted.

Version 3.2.0 completes the full-catalog admin workflow: numeric 20-per-page pagination and refresh controls, real product/media/content selectors, inline ALT editing, server-backed live issue preview, a full Jalali scheduling queue, bounded recoverable scans, and an optional SerpApi-backed live Google result view that remains explicitly separate from historical Search Console rank data.

== Installation ==
1. Create a database/site backup or snapshot before replacing an existing version.
2. Upload the K20 AI Press ZIP from Plugins > Add New > Upload Plugin.
3. Choose Replace current with uploaded if WordPress detects an existing installation.
4. Activate the plugin and open K20 AI Press in wp-admin.
5. Review Connection Center before enabling any external provider.
6. Run a Media Scan first, then a Full Scan, and confirm processed/total counts complete without duplicate workers.

Upgrades are designed to be idempotent and preserve existing plugin data. Uninstall also preserves data by default. Irreversible data removal requires the explicit K20AI_PRESS_REMOVE_DATA_ON_UNINSTALL constant.

== External services ==
K20 AI Press works without transmitting site data to an AI provider unless an administrator explicitly configures and uses that integration. Each optional connection is administrator-configured, can be disconnected, and sends only the data needed for the requested feature. Review the applicable provider terms and privacy policy before enabling a connection, especially before sending personal or confidential content.

* OpenAI API: https://platform.openai.com/ — policies and privacy: https://openai.com/policies/
* Google APIs (Gemini, Search Console, Analytics, Merchant and PageSpeed): https://console.cloud.google.com/ — privacy: https://policies.google.com/privacy — terms: https://policies.google.com/terms
* Anthropic API: https://console.anthropic.com/ — privacy/policies: https://privacy.anthropic.com/
* DeepSeek API: https://platform.deepseek.com/ — privacy: https://cdn.deepseek.com/policies/en-US/deepseek-privacy-policy.html — API terms: https://cdn.deepseek.com/policies/en-US/deepseek-open-platform-terms-of-service.html
* Microsoft Bing Webmaster: https://www.bing.com/webmasters/ — privacy: https://privacy.microsoft.com/privacystatement — services agreement: https://www.microsoft.com/servicesagreement
* GitHub API/Actions: https://github.com/ — privacy: https://docs.github.com/en/site-policy/privacy-policies/github-general-privacy-statement — terms: https://docs.github.com/en/site-policy/github-terms/github-terms-of-service
* SerpApi Google Search API: https://serpapi.com/search-api — legal/privacy: https://serpapi.com/legal — used only when an administrator configures the optional live SERP connection.
* Custom OpenAI-compatible endpoints: the administrator supplies the endpoint. The site operator is responsible for reviewing and disclosing that provider's terms, privacy policy and data-processing behavior before use.

Credentials are stored encrypted. Diagnostic logging is disabled by default and redacts credential-like values, email addresses and IP addresses when enabled.

== Privacy ==
K20 AI Press registers WordPress personal-data exporter and eraser callbacks. Scheduled retention cleanup covers operational logs, provider usage, prompt runs, bot telemetry, webhook deliveries, engine runs, audit records, supplier submissions, Agent runs, AI Visibility observations and migration snapshots according to configurable retention windows.

Personal-data erasure anonymizes WordPress user references in retained operational records and removes common contact fields from supplier-authored payloads while preserving non-personal evidence required for audit and rollback integrity. API credentials are excluded from privacy exports.

Uninstall preserves data by default. Complete plugin-owned data removal is opt-in through K20AI_PRESS_REMOVE_DATA_ON_UNINSTALL=true and removes plugin tables, options, transients and user metadata.

See PRIVACY.md in the plugin package for the engineering privacy model.

== Compatibility ==
Version 3.2.0 targets:

* WordPress 7.1+
* PHP 8.3+
* WooCommerce 11.1+

The plugin declares WooCommerce HPOS and Cart/Checkout Blocks compatibility through the public FeaturesUtil API. Release engineering includes PHP 8.3/8.4/8.5 regression gates and QIT profiles for stable WordPress/WooCommerce, HPOS, security, PHP compatibility, PHPStan, validation, Plugin Check, malware, API fuzz, Woo API and Woo E2E testing.

External managed tests must be run against the exact release ZIP in an authenticated Woo QIT environment before claiming Marketplace certification. Theme, payment-gateway and hosting-specific compatibility should also be verified on staging before production deployment.

== Security and governance ==
* REST routes use explicit permission callbacks; entity routes enforce read/edit capability on the exact target object.
* AI preview authorization occurs before entity disclosure or provider calls, and Apply rechecks ownership and target permission.
* Dynamic outbound endpoints must be valid public HTTPS URLs and use WordPress safe HTTP APIs.
* OAuth state is random, time-limited, user/provider-bound and one-time.
* Provider and webhook secrets are encrypted at rest.
* Automation rejects protected commerce/security fields including price, stock, discounts, tax/payment settings, users, roles and credentials.
* Scan continuation uses atomic scheduling guards with Action Scheduler and WP-Cron fallback.
* Writes that support rollback preserve before-state evidence and use optimistic concurrency where applicable.

== Accessibility and language ==
The admin UI supports Persian RTL and English LTR modes. It includes keyboard focus states, skip navigation, dialog focus return, ARIA states/names, reduced-motion handling, forced-colors support and high-contrast preferences. Core light/dark text pairs are release-tested against a 4.5:1 contrast gate for normal text.

The plugin loads the k20-ai-press text domain, registers script translations, respects the WordPress user locale when no explicit UI language is stored, and ships a generated POT catalog.

== Frequently Asked Questions ==
= Does the plugin change product price or stock through AI? =
No. Price, stock, discounts, tax/payment settings, users, roles and credentials are protected from AI and generic automation write paths.

= Does enabling the plugin automatically send data to AI providers? =
No. External provider connections are optional and administrator-configured. Data is transmitted only when a configured feature that requires the provider is invoked.

= Does uninstall delete all plugin data? =
No. Data is preserved by default to avoid accidental loss of audit/rollback evidence. A complete wipe requires the explicit K20AI_PRESS_REMOVE_DATA_ON_UNINSTALL=true constant before uninstall.

= Is the plugin WooCommerce Marketplace certified? =
Not by packaging alone. Marketplace/QIT certification requires successful managed test runs against the exact release artifact in an authenticated WooCommerce partner environment.

== Changelog ==
= 3.2.0 =
* Expanded product, media, schema, content, rank, competitor and technical workspaces to real data-wide pagination and refresh behavior.
* Product Intelligence enumerates the actual readable WooCommerce catalog and category set instead of a fixed sample.
* Live Editor can select real products/content, performs server-side preview analysis while typing, and removes resolved guidance before persistence.
* Media/ALT shows attachment identity, filename and usage location, supports inline save, and removes fixed rows from the missing-ALT view.
* Added optional SerpApi-backed live Google organic results with explicit separation from historical Search Console/imported rank evidence.
* Added source-grounded AI keyword suggestions from the first five returned live results without fabricating rank when a provider is not connected.
* Schema/preview gained real entity selection, pagination and guarded save controls.
* Jalali publication calendar reads the complete editable draft/pending/future queue, including supported news/article post types and WooCommerce coupons.
* Removed the global stuck scan strip and kept scan workers bounded, heartbeat-driven and stale-lock recoverable.
* Added a packaged master implementation contract and release acceptance checks for the 3.2.0 build.

= 3.1.4 =
* Removed the global stuck scan progress strip from the top of every workspace.
* Made scan start non-blocking in the admin UI.
* Reduced long entity/crawl worker time budgets for shared-hosting safety.
* Added per-URL crawl heartbeats so cursor/progress survives worker termination.
* Reduced stale scan lock recovery from 330 seconds to 60 seconds.
* Browser polling now wakes Action Scheduler instead of running a long synchronous worker.


= 3.1.3 =
* Fixed real workspace data contracts for images, keywords, rank tracking, competitors, technical health, content refresh and Control Tower.
* Added complete admin/REST filter plumbing for pagination, category and search filters.
* Enabled validated WooCommerce price and stock-status edits from Live Editor.
* Removed runtime references to nonexistent seo_image_alt, rank_tracking and crawl_log tables.

= 3.1.2 =
* Added governed Agent runtime with Plan -> Approval -> Execute -> Verify, bounded retry, cancellation and fail-fast plan persistence.
* Added official Abilities/MCP-safe exposure, Command Center, Product/Commerce Intelligence and measured AI Visibility Observatory.
* Added collector attribution for visibility evidence, deterministic planning-provider/cost disclosure, onboarding, reversible SEO migration and signed commercial update boundaries.
* Added privacy/retention coverage for Agent, Visibility and Migration data while retaining all 3.0.9 security and compatibility hardening.

= 3.0.9 =
* Commercial hardening: exact-object authorization, privacy lifecycle, encrypted secrets, bounded queries, accessibility/i18n improvements, class decomposition and reproducible quality gates.
* Added WordPress personal-data exporter/eraser integration and scheduled retention cleanup.
* Added WC_Logger-based opt-in diagnostics with sensitive-data redaction.
* Added WordPress 7.1+, PHP 8.3+ and WooCommerce 11.1+ commercial compatibility declarations.
* Added installation-package policy checks, accessibility contrast gates and QIT/Plugin Check/PHPCS/PHPStan/Playwright configuration.

= 3.0.8 =
* Stabilized scan accounting/scheduling, stale-lock recovery, target write permissions and Yoast fallback/concurrency behavior.

Full release history is available in changelog.txt.
